"""
Crop Knowledge Service for AgriNext.
Provides verified, scientifically-grounded crop profiles, botanical taxonomy,
soil suitability, nutrient demands, thermal/water stress thresholds, and rotation compatibility.

Primary Authorities:
- ANGRAU (Acharya N.G. Ranga Agricultural University) Vyavasaya Panchangam (Package of Practices) 2023-2024.
- ICAR-CRIDA (Central Research Institute for Dryland Agriculture) Contingency Crop Planning for Andhra Pradesh.
- ICAR (Indian Council of Agricultural Research) Handbook of Agriculture.
"""

import json
from pathlib import Path
from typing import Dict, Any, List, Optional
import logging

logger = logging.getLogger("agrinext.crop_knowledge")

CROP_PROFILES_FILE = Path(__file__).resolve().parent / "crop_profiles.json"
STATE_DATA_DIR = Path(__file__).resolve().parent.parent / "state_data"

class CropKnowledgeService:
    """Service providing verified Andhra Pradesh agronomic crop profiles and rotation compatibility."""

    def __init__(self):
        self._crops_cache: Optional[List[Dict[str, Any]]] = None
        self._load_catalog()

    def _load_catalog(self):
        """Loads verified crop profiles from disk."""
        if not CROP_PROFILES_FILE.exists():
            logger.error(f"Crop profiles catalog file missing at {CROP_PROFILES_FILE}")
            self._crops_cache = []
            return

        with open(CROP_PROFILES_FILE, "r", encoding="utf-8") as f:
            raw_crops = json.load(f)
            # Enforce validation: ensure no invented values; mark unverified as unknown
            self._crops_cache = [self._validate_and_sanitize(c) for c in raw_crops]

    def _validate_and_sanitize(self, crop: Dict[str, Any]) -> Dict[str, Any]:
        """Ensures all required fields exist; unverified attributes are marked unknown or illustrative."""
        sanitized = dict(crop)
        # Ensure botanical family
        if "crop_family" not in sanitized or not sanitized["crop_family"]:
            sanitized["crop_family"] = "Unknown / Unverified Family"
        
        # Ensure water requirement range
        if "water_requirement_mm" not in sanitized or not sanitized["water_requirement_mm"]:
            sanitized["water_requirement_mm"] = [0, 0]
            sanitized["water_requirement_status"] = "Unknown"

        # Ensure rotation compatibility exists
        if "rotation_compatibility" not in sanitized:
            sanitized["rotation_compatibility"] = {
                "beneficial_predecessors": [],
                "incompatible_predecessors": [],
                "rotational_benefits": "Unverified rotation impact",
                "pest_cycle_breaks": "Illustrative"
            }

        return sanitized

    def get_all_crops(self) -> List[Dict[str, Any]]:
        """Returns the complete verified crop knowledge catalog."""
        if self._crops_cache is None:
            self._load_catalog()
        return self._crops_cache or []

    def get_crop_by_id(self, crop_id: str) -> Optional[Dict[str, Any]]:
        """Retrieves a single verified crop profile by identifier."""
        crops = self.get_all_crops()
        for c in crops:
            if c.get("id") == crop_id.lower() or c.get("crop_name", "").lower() == crop_id.lower():
                return c
        return None

    def get_crops_by_season(self, season: str) -> List[Dict[str, Any]]:
        """Filters crops suitable for a specific season (Kharif, Rabi, Summer)."""
        normalized = season.strip().capitalize()
        crops = self.get_all_crops()
        return [c for c in crops if any(normalized in s for s in c.get("growing_season", []))]

    def get_crops_by_soil_type(self, soil_type: str) -> List[Dict[str, Any]]:
        """Filters crops whose soil suitability matches the given soil classification."""
        crops = self.get_all_crops()
        st_lower = soil_type.lower()
        matched = []
        for c in crops:
            suit = c.get("soil_suitability", {})
            suitable_types = [s.lower() for s in suit.get("suitable_soil_types", [])]
            if any(st_lower in t or t in st_lower for t in suitable_types):
                matched.append(c)
        return matched

    def evaluate_rotation_compatibility(
        self,
        previous_crop_id: Optional[str],
        candidate_crop_id: str
    ) -> Dict[str, Any]:
        """
        Evaluates rotational compatibility between previous and candidate crops.
        Checks:
        1. Monoculture / Family break (avoiding consecutive same-family crops).
        2. Nitrogen replenishment (legume following exhaustive cereal/cash crop).
        3. Pest break synergy and allelopathic warnings.
        """
        candidate = self.get_crop_by_id(candidate_crop_id)
        if not candidate:
            return {
                "compatible": True,
                "score_multiplier": 1.0,
                "rationale": "Candidate crop agronomic profile not found."
            }

        if not previous_crop_id or previous_crop_id.lower() in ["none", "fallow"]:
            return {
                "compatible": True,
                "score_multiplier": 1.0,
                "rationale": "No previous crop planted (or fallow); standard baseline compatibility."
            }

        previous = self.get_crop_by_id(previous_crop_id)
        if not previous:
            return {
                "compatible": True,
                "score_multiplier": 1.0,
                "rationale": f"Previous crop '{previous_crop_id}' profile unverified; neutral compatibility assumed."
            }

        prev_family = previous.get("crop_family", "").split("(")[0].strip()
        cand_family = candidate.get("crop_family", "").split("(")[0].strip()

        rot_compat = candidate.get("rotation_compatibility", {})
        beneficial_preds = rot_compat.get("beneficial_predecessors", [])
        incompatible_preds = rot_compat.get("incompatible_predecessors", [])

        # 1. Monoculture Check: Exact same crop or same botanical family
        if candidate["id"] == previous["id"]:
            return {
                "compatible": False,
                "score_multiplier": 0.65,
                "monoculture_risk": True,
                "rationale": (
                    f"Monoculture warning: Planting {candidate['crop_name']} immediately following itself "
                    f"depletes identical root-zone nutrient bands and amplifies soil-borne pathogen and pest reservoirs."
                )
            }

        # Botanical family monoculture (e.g., Solanaceae after Solanaceae, or Malvaceae after Malvaceae)
        if prev_family and cand_family and prev_family.lower() == cand_family.lower() and "poaceae" not in cand_family.lower():
            return {
                "compatible": False,
                "score_multiplier": 0.75,
                "monoculture_risk": True,
                "rationale": (
                    f"Botanical family monoculture alert: Both {previous['crop_name']} and {candidate['crop_name']} "
                    f"belong to {cand_family}. Consecutive cultivation carries severe risks of pest carryover (e.g., nematodes, wilt)."
                )
            }

        # 2. Known Incompatible Predecessor Check
        if previous["id"] in incompatible_preds:
            return {
                "compatible": False,
                "score_multiplier": 0.70,
                "rationale": (
                    f"Incompatible sequence: Agronomic guidance from ANGRAU advises against {candidate['crop_name']} "
                    f"following {previous['crop_name']}."
                )
            }

        # 3. Beneficial Legume Rotation Check (Rule 1: Legume after depleter)
        prev_n_impact = previous.get("nutrient_requirements", {}).get("nitrogen_impact", "neutral")
        cand_n_impact = candidate.get("nutrient_requirements", {}).get("nitrogen_impact", "neutral")

        if prev_n_impact == "depleting" and cand_n_impact == "fixing":
            return {
                "compatible": True,
                "score_multiplier": 1.25,
                "rotational_synergy": "Legume Nitrogen Replenishment",
                "rationale": (
                    f"Excellent rotational synergy: {candidate['crop_name']} fixes biological nitrogen "
                    f"(~{candidate.get('nutrient_requirements', {}).get('biological_nitrogen_fixation_kg_ha', 30)} kg N/ha), "
                    f"naturally restoring soil depleted by previous {previous['crop_name']}."
                )
            }

        # 4. Explicit Beneficial Predecessor Match
        if previous["id"] in beneficial_preds:
            return {
                "compatible": True,
                "score_multiplier": 1.20,
                "rotational_synergy": "Documented High Compatibility",
                "rationale": (
                    f"{candidate['crop_name']} thrives following {previous['crop_name']} according to ANGRAU "
                    f"cultivation evidence. {rot_compat.get('rotational_benefits', '')}"
                )
            }

        return {
            "compatible": True,
            "score_multiplier": 1.0,
            "rationale": f"Compatible sequence between {previous['crop_name']} and {candidate['crop_name']}."
        }
