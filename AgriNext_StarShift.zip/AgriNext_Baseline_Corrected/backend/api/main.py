"""
AgriNext API entrypoint alias.
Re-exports FastAPI app from root main.py for compatibility.
"""
import sys
from pathlib import Path

backend_dir = Path(__file__).resolve().parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from main import app

__all__ = ["app"]
