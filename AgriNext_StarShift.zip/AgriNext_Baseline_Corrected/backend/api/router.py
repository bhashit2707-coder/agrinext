"""
AgriNext Core API Routes.
Provides endpoints for health checks, state registry, mandals,
farm geospatial boundary analysis, farm profile persistence,
multi-source NASA Earth observations (POWER, SMAP, GPM),
farmer profile and soil ground-truth management,
verified ANGRAU/ICAR crop knowledge, unified environmental evidence dossiers,
and evidence-backed crop recommendations.
"""

import json
import logging
import os
import uuid
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from collections import defaultdict, deque
import requests
from datetime import datetime, timezone
from pathlib import Path
from fastapi import APIRouter, HTTPException, Query, status, Depends, Response, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

from nasa.power import NASAPowerService
from nasa.smap import NASASMAPService
from nasa.gpm import NASAGPMService
from nasa.gldas import GLDASService
from climate.era5_service import ERA5Service
from recommendation.rotation_engine import RotationEngine
from recommendation.season_planner import build_multi_season_plan
from recommendation.evidence_engine import UnifiedEvidenceService
from geospatial.polygon_analysis import analyze_farm_boundary
from geospatial.sentinel2_service import Sentinel2Service
from geospatial.sentinel2_processing import Sentinel2ProcessingService, Sentinel2ProcessingError
from geospatial.gaez_service import GAEZService
from geospatial.srtm_service import SRTMService
from geospatial.landsat_service import LandsatService
from geospatial.modis_viirs_service import MODISVIIRSService, PRODUCTS as MODIS_VIIRS_PRODUCTS
from geospatial.ecostress_gracefo_service import ECOSTRESSGRACEFOService, PRODUCTS as ECOSTRESS_GRACEFO_PRODUCTS
from crop_knowledge.crop_service import CropKnowledgeService
from data_processing.farmer_profile import FarmerProfileService, FarmerProfileInput
from reports.report_service import ReportService
from reports.soil_report_service import extract_soil_metrics, classify_metrics
from reports.pdf_generator import AgriNextPDFGenerator
from simulation.simulator import ClimateSimulator
import database
import auth

logger = logging.getLogger("agrinext.api")
router = APIRouter(prefix="/api", tags=["AgriNext Core"])

# Lightweight per-process protection for public authentication endpoints.
# For multi-worker or multi-instance deployments, replace this with shared Redis storage.
_AUTH_RATE_LIMIT = 20
_AUTH_RATE_WINDOW_SECONDS = 60
_LOGIN_FAILURE_LIMIT = 5
_LOGIN_LOCKOUT_SECONDS = 15 * 60
_auth_guard_lock = threading.Lock()
_auth_attempts = defaultdict(deque)
_login_failures = defaultdict(deque)
_login_locked_until = {}

def _request_client_key(request: Request) -> str:
    return request.client.host if request.client else "unknown"

def _enforce_auth_throttle(request: Request, action: str, identity: str = "") -> str:
    now = time.time()
    client_key = _request_client_key(request)
    key = f"{action}:{client_key}"
    identity_key = f"{client_key}:{identity.strip().lower()}" if identity else client_key
    with _auth_guard_lock:
        attempts = _auth_attempts[key]
        while attempts and now - attempts[0] > _AUTH_RATE_WINDOW_SECONDS:
            attempts.popleft()
        if len(attempts) >= _AUTH_RATE_LIMIT:
            raise HTTPException(status_code=429, detail="Too many authentication requests. Please try again later.", headers={"Retry-After": str(_AUTH_RATE_WINDOW_SECONDS)})
        if action == "login":
            locked_until = _login_locked_until.get(identity_key, 0)
            if locked_until > now:
                retry_after = max(1, int(locked_until - now))
                raise HTTPException(status_code=429, detail="Login temporarily locked after repeated failed attempts.", headers={"Retry-After": str(retry_after)})
        attempts.append(now)
    return identity_key

def _record_login_failure(identity_key: str) -> None:
    now = time.time()
    with _auth_guard_lock:
        failures = _login_failures[identity_key]
        while failures and now - failures[0] > _LOGIN_LOCKOUT_SECONDS:
            failures.popleft()
        failures.append(now)
        if len(failures) >= _LOGIN_FAILURE_LIMIT:
            _login_locked_until[identity_key] = now + _LOGIN_LOCKOUT_SECONDS

def _clear_login_failures(identity_key: str) -> None:
    with _auth_guard_lock:
        _login_failures.pop(identity_key, None)
        _login_locked_until.pop(identity_key, None)

BASE_DIR = Path(__file__).resolve().parent.parent
STATE_DATA_DIR = BASE_DIR / "state_data"

power_service = NASAPowerService()
smap_service = NASASMAPService()
gpm_service = NASAGPMService()
gldas_service = GLDASService()
era5_service = ERA5Service()
landsat_service = LandsatService()
modis_viirs_service = MODISVIIRSService()
ecostress_gracefo_service = ECOSTRESSGRACEFOService()
srtm_service = SRTMService()
sentinel2_service = Sentinel2Service()
sentinel2_processing_service = Sentinel2ProcessingService()
# Bounded worker pool: queued work is persisted in SQLite; workers never hold a request open.
def _configured_nasa_workers() -> int:
    try:
        return max(1, min(4, int(os.getenv("AGRINEXT_NASA_JOB_WORKERS", "2"))))
    except (TypeError, ValueError):
        logger.warning("Invalid AGRINEXT_NASA_JOB_WORKERS; defaulting to 2 workers")
        return 2

_NASA_JOB_WORKERS = _configured_nasa_workers()
_nasa_job_executor = ThreadPoolExecutor(max_workers=_NASA_JOB_WORKERS, thread_name_prefix="agrinext-nasa")
gaez_service = GAEZService()
rotation_engine = RotationEngine()
evidence_service = UnifiedEvidenceService()
crop_service = CropKnowledgeService()
farmer_service = FarmerProfileService()
simulator = ClimateSimulator()

# Initialize DB table on startup
database.init_db()

# --- Pydantic Request Models ---

class PolygonAnalysisRequest(BaseModel):
    boundary_geojson: Dict[str, Any] = Field(..., description="GeoJSON Feature or Polygon geometry")
    manual_acreage: Optional[float] = Field(None, description="Optional manual acreage declared by farmer")

class Sentinel2SearchRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    bbox_size: float = Field(0.05, gt=0, le=1)
    max_cloud_cover: float = Field(30.0, ge=0, le=100)
    limit: int = Field(10, ge=1, le=50)
    farm_id: Optional[str] = None


class Sentinel2FarmNDVIRequest(BaseModel):
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    max_cloud_cover: float = Field(40.0, ge=0, le=100)

class GLDASQueryRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    date: Optional[str] = Field(None, description="Optional YYYY-MM-DD date within the monthly product")
    farm_id: Optional[str] = None

class ERA5QueryRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    farm_id: Optional[str] = None

class MODISVIIRSSearchRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    products: Optional[List[str]] = None
    limit: int = Field(10, ge=1, le=50)

class ECOSTRESSGRACEFOSearchRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    products: Optional[List[str]] = None
    limit: int = Field(10, ge=1, le=50)

class LandsatSearchRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    bbox_size: float = Field(0.05, gt=0, le=1)
    max_cloud_cover: float = Field(30, ge=0, le=100)
    limit: int = Field(10, ge=1, le=50)
    farm_id: Optional[str] = None

class SRTMPoint(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)

class SRTMQueryRequest(BaseModel):
    points: List[SRTMPoint] = Field(..., min_length=1, max_length=100)
    farm_id: Optional[str] = None

class GAEZSearchRequest(BaseModel):
    query: Optional[str] = Field(None, max_length=120)
    collection_id: Optional[str] = Field(None, max_length=160)
    limit: int = Field(10, ge=1, le=50)

class NASAPowerQueryRequest(BaseModel):
    latitude: float = Field(..., ge=-90.0, le=90.0, description="Farm centroid latitude")
    longitude: float = Field(..., ge=-180.0, le=180.0, description="Farm centroid longitude")
    start_date: Optional[str] = Field(None, description="Start date in YYYYMMDD or YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYYMMDD or YYYY-MM-DD format")
    farm_id: Optional[str] = Field(None, description="Optional Farm Profile ID to associate evidence")
    use_cache: bool = Field(True, description="Whether to use cached responses if available")

class NASASMAPQueryRequest(BaseModel):
    latitude: float = Field(..., ge=-90.0, le=90.0, description="Farm centroid latitude")
    longitude: float = Field(..., ge=-180.0, le=180.0, description="Farm centroid longitude")
    polygon_bbox: Optional[Dict[str, float]] = Field(None, description="Optional bounding box for area sampling")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    farm_id: Optional[str] = Field(None, description="Optional Farm Profile ID to link evidence")
    use_cache: bool = Field(True, description="Whether to check SQLite cache")

class NASAGPMQueryRequest(BaseModel):
    latitude: float = Field(..., ge=-90.0, le=90.0, description="Farm centroid latitude")
    longitude: float = Field(..., ge=-180.0, le=180.0, description="Farm centroid longitude")
    polygon_bbox: Optional[Dict[str, float]] = Field(None, description="Optional bounding box for area sampling")
    start_date: Optional[str] = Field(None, description="Start date in YYYY-MM-DD format")
    end_date: Optional[str] = Field(None, description="End date in YYYY-MM-DD format")
    farm_id: Optional[str] = Field(None, description="Optional Farm Profile ID to link evidence")
    use_cache: bool = Field(True, description="Whether to check SQLite cache")
    compare_with_power: bool = Field(True, description="Whether to compare with NASA POWER precipitation")

class UnifiedEvidenceRequest(BaseModel):
    latitude: float = Field(..., ge=-90.0, le=90.0, description="Farm centroid latitude")
    longitude: float = Field(..., ge=-180.0, le=180.0, description="Farm centroid longitude")
    polygon_bbox: Optional[Dict[str, float]] = Field(None, description="Optional bounding box for area sampling")
    farm_id: Optional[str] = Field(None, description="Optional Farm Profile ID")
    use_cache: bool = Field(True, description="Whether to use cached queries")
    farmer_profile: Optional[Dict[str, Any]] = Field(None, description="Optional farmer profile inputs")

class GenerateRecommendationsRequest(BaseModel):
    state_id: str = Field("andhra_pradesh", description="Target state ID")
    latitude: float = Field(..., ge=-90.0, le=90.0, description="Farm centroid latitude")
    longitude: float = Field(..., ge=-180.0, le=180.0, description="Farm centroid longitude")
    farm_id: Optional[str] = Field(None, description="Optional Farm Profile ID")
    polygon_bbox: Optional[Dict[str, float]] = Field(None, description="Optional bounding box")
    use_cache: bool = Field(True, description="Whether to use cached queries")
    farmer_profile: Optional[Dict[str, Any]] = Field(None, description="Optional farmer profile inputs")
    weights: Optional[Dict[str, float]] = Field(None, description="Optional custom weights for water, soil, climate, local totaling 100")
    include_geospatial_context: bool = Field(True, description="Attach Sentinel-2 and FAO GAEZ context to the rotation plan")

class RecalculateScoresRequest(BaseModel):
    strategies: List[Dict[str, Any]] = Field(..., description="List of rotation strategies with individual_scores")
    weights: Dict[str, float] = Field(..., description="Custom weights for water, soil, climate, local totaling 100")
    baseline_weights: Optional[Dict[str, float]] = Field(None, description="Optional baseline weights totaling 100 (default 25% each)")

class GenerateReportRequest(BaseModel):
    farm_id: Optional[str] = Field(None, description="Optional Farm ID")
    farm_data: Optional[Dict[str, Any]] = Field(None, description="Farm metadata")
    farmer_profile: Optional[Dict[str, Any]] = Field(None, description="Farmer soil ground-truth profile")
    weights: Dict[str, float] = Field(..., description="Chosen priority weights totaling 100")
    baseline_weights: Optional[Dict[str, float]] = Field(None, description="Baseline weights")
    strategies: List[Dict[str, Any]] = Field(..., description="The rotation strategies")
    ranking_comparison: Optional[Dict[str, Any]] = Field(None, description="Baseline vs updated ranking comparison")
    dossier: Optional[Dict[str, Any]] = Field(None, description="Unified environmental evidence dossier")
    simulation_data: Optional[Dict[str, Any]] = Field(None, description="Optional simulated climate scenario data")

class ClimateSimulationRequest(BaseModel):
    state_id: str = Field("andhra_pradesh", description="Target state ID")
    latitude: float = Field(..., ge=-90.0, le=90.0, description="Farm centroid latitude")
    longitude: float = Field(..., ge=-180.0, le=180.0, description="Farm centroid longitude")
    farm_id: Optional[str] = Field(None, description="Optional Farm Profile ID")
    farmer_profile: Optional[Dict[str, Any]] = Field(None, description="Optional farmer profile")
    weights: Optional[Dict[str, float]] = Field(None, description="Current priority weights")
    baseline_dossier: Optional[Dict[str, Any]] = Field(None, description="Original NASA baseline dossier")
    rainfall_pct_change: float = Field(0.0, description="Rainfall percentage change e.g. -20 for -20%")
    temp_celsius_change: float = Field(0.0, description="Temperature change in degrees Celsius e.g. +2.0")
    water_availability_pct_change: float = Field(0.0, description="Water availability percentage change e.g. -25 for -25%")

class SaveFarmRequest(BaseModel):
    id: Optional[str] = None
    farm_name: str = Field("My Farm Plot", description="User-assigned farm name")
    state_id: str = Field("andhra_pradesh", description="Selected Indian state")
    district_id: str = Field(..., description="Selected district")
    mandal_id: str = Field(..., description="Selected mandal")
    village_id: Optional[str] = Field(None, description="Selected village ID")
    village_name: Optional[str] = Field(None, description="Selected village name")
    village_lgd: Optional[int] = Field(None, description="Village LGD code")
    district_lgd: Optional[int] = Field(None, description="District LGD code")
    mandal_lgd: Optional[int] = Field(None, description="Mandal LGD code")
    boundary_geojson: Dict[str, Any] = Field(..., description="GeoJSON Polygon geometry")
    manual_acreage: Optional[float] = Field(None, description="Optional manual acreage entry")

class RegisterRequest(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=100)
    email: str = Field(..., min_length=5, max_length=254)
    password: str = Field(..., min_length=10, max_length=128)

class LoginRequest(BaseModel):
    email: str = Field(..., min_length=5, max_length=254)
    password: str = Field(..., min_length=1, max_length=128)


class EvaluateFarmAlertsRequest(BaseModel):
    farm_id: str = Field(..., min_length=1)
    observed_at: str = Field(..., min_length=10, max_length=40)
    source: str = Field(..., min_length=2, max_length=120, description="Origin of the supplied observation")
    rainfall_24h_mm: Optional[float] = Field(None, ge=0, le=2000)
    max_temperature_c: Optional[float] = Field(None, ge=-20, le=65)
    soil_moisture_pct: Optional[float] = Field(None, ge=0, le=100)

@router.post("/auth/register", status_code=status.HTTP_201_CREATED)
def register_user(data: RegisterRequest, request: Request, response: Response) -> Dict[str, Any]:
    """Create a farmer account. Public registration always creates the farmer role."""
    _enforce_auth_throttle(request, "register")
    import re
    email = data.email.strip().lower()
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise HTTPException(status_code=422, detail="Enter a valid email address")
    if not data.full_name.strip():
        raise HTTPException(status_code=422, detail="Full name is required")
    if database.get_user_by_email(email):
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    user_id = str(__import__("uuid").uuid4())
    try:
        user = database.create_user(user_id, data.full_name, email, auth.hash_password(data.password))
    except Exception as exc:
        logger.warning("Account registration failed: %s", exc)
        raise HTTPException(status_code=409, detail="Unable to create account with this email")
    token = auth.create_session_for_user(user_id)
    _set_session_cookie(response, token)
    return {"status": "registered", "user": _public_user(user)}

@router.post("/auth/login")
def login_user(data: LoginRequest, request: Request, response: Response) -> Dict[str, Any]:
    identity_key = _enforce_auth_throttle(request, "login", data.email)
    user = database.get_user_by_email(data.email.strip().lower())
    if not user or not user.get("is_active") or not auth.verify_password(data.password, user["password_hash"]):
        _record_login_failure(identity_key)
        raise HTTPException(status_code=401, detail="Invalid email or password")
    _clear_login_failures(identity_key)
    token = auth.create_session_for_user(user["id"])
    _set_session_cookie(response, token)
    return {"status": "authenticated", "user": _public_user(user)}

def _ensure_farm_owner(farm_id: Optional[str], user: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not farm_id:
        return None
    farm = database.get_farm_by_id(farm_id)
    if not farm or farm.get("owner_user_id") != user["id"]:
        raise HTTPException(status_code=404, detail="Farm profile not found")
    return farm

@router.get("/auth/me")
def get_authenticated_user(current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    return {"user": _public_user(current_user)}

@router.post("/auth/logout")
def logout_user(request: Request, response: Response) -> Dict[str, str]:
    auth.revoke_token(request.cookies.get(auth.SESSION_COOKIE_NAME))
    same_site = os.getenv("AGRINEXT_COOKIE_SAMESITE", "lax").lower()
    if same_site not in {"lax", "strict", "none"}:
        same_site = "lax"
    secure = os.getenv("AGRINEXT_COOKIE_SECURE", "false").lower() == "true" or same_site == "none"
    response.delete_cookie(auth.SESSION_COOKIE_NAME, path="/", httponly=True, secure=secure, samesite=same_site)
    return {"status": "logged_out"}

def _public_user(user: Dict[str, Any]) -> Dict[str, Any]:
    return {"id": user["id"], "name": user["full_name"], "email": user["email"], "role": user.get("role", "farmer"), "verified": True, "member_since": user.get("created_at")}

def _set_session_cookie(response: Response, token: str) -> None:
    secure = os.getenv("AGRINEXT_COOKIE_SECURE", "false").lower() == "true"
    same_site = os.getenv("AGRINEXT_COOKIE_SAMESITE", "lax").lower()
    if same_site not in {"lax", "strict", "none"}:
        same_site = "lax"
    if same_site == "none":
        secure = True
    response.set_cookie(
        key=auth.SESSION_COOKIE_NAME, value=token, httponly=True, secure=secure,
        samesite=same_site, max_age=auth.SESSION_TTL_HOURS * 3600, path="/"
    )

# --- Location Data Manager & In-Memory Indexing ---

class LocationDataManager:
    """Manages verified multi-tier administrative revenue hierarchy with in-memory caching."""

    def __init__(self, state_data_dir: Path):
        self.state_data_dir = state_data_dir
        self._cache: Dict[str, Dict[str, Any]] = {}

    def get_state_data(self, state_id: str) -> Dict[str, Any]:
        if state_id in self._cache:
            return self._cache[state_id]

        state_dir = self.state_data_dir / state_id
        if not state_dir.exists() or not state_dir.is_dir():
            raise HTTPException(status_code=404, detail=f"State configuration not found: {state_id}")

        districts_file = state_dir / "districts.json"
        mandals_file = state_dir / "mandals.json"
        villages_file = state_dir / "villages.json"
        provenance_file = state_dir / "provenance.json"

        districts: List[Dict[str, Any]] = []
        if districts_file.exists():
            with open(districts_file, "r", encoding="utf-8") as f:
                districts = json.load(f)

        mandals: List[Dict[str, Any]] = []
        if mandals_file.exists():
            with open(mandals_file, "r", encoding="utf-8") as f:
                mandals = json.load(f)

        villages: List[Dict[str, Any]] = []
        if villages_file.exists():
            with open(villages_file, "r", encoding="utf-8") as f:
                villages = json.load(f)

        provenance: Dict[str, Any] = {}
        if provenance_file.exists():
            with open(provenance_file, "r", encoding="utf-8") as f:
                provenance = json.load(f)

        # High-performance indexes
        districts_by_id = {d["id"]: d for d in districts}
        mandals_by_id = {m["id"]: m for m in mandals}
        mandals_by_district: Dict[str, List[Dict[str, Any]]] = {}
        for m in mandals:
            d_id = m.get("district_id")
            if d_id:
                mandals_by_district.setdefault(d_id, []).append(m)

        villages_by_id = {v["id"]: v for v in villages}
        villages_by_mandal: Dict[str, List[Dict[str, Any]]] = {}
        for v in villages:
            m_id = v.get("mandal_id")
            if m_id:
                villages_by_mandal.setdefault(m_id, []).append(v)

        data = {
            "districts": districts,
            "mandals": mandals,
            "villages": villages,
            "provenance": provenance,
            "districts_by_id": districts_by_id,
            "mandals_by_id": mandals_by_id,
            "mandals_by_district": mandals_by_district,
            "villages_by_id": villages_by_id,
            "villages_by_mandal": villages_by_mandal
        }
        self._cache[state_id] = data
        return data

location_manager = LocationDataManager(STATE_DATA_DIR)

# --- System & State Data Endpoints ---

@router.get("/health")
def health_check() -> Dict[str, Any]:
    """Health check for AgriNext backend."""
    return {
        "status": "healthy",
        "service": "AgriNext API Engine",
        "version": "1.1.0",
        "region_scope": "Andhra Pradesh, India (Multi-state configurable)"
    }

@router.get("/states")
def get_supported_states() -> Dict[str, Any]:
    """Returns the list of supported states from registry.json."""
    registry_file = STATE_DATA_DIR / "registry.json"
    if not registry_file.exists():
        raise HTTPException(status_code=500, detail="State registry file missing")
    with open(registry_file, "r", encoding="utf-8") as f:
        return json.load(f)

@router.get("/states/{state_id}/districts")
def get_state_districts(state_id: str) -> List[Dict[str, Any]]:
    """Returns verified revenue districts for a given state."""
    state_data = location_manager.get_state_data(state_id)
    return state_data["districts"]

@router.get("/states/{state_id}/districts/{district_id}/mandals")
def get_district_mandals_hierarchical(state_id: str, district_id: str) -> List[Dict[str, Any]]:
    """Returns verified revenue mandals directly subordinate to a district."""
    state_data = location_manager.get_state_data(state_id)
    if district_id not in state_data["districts_by_id"]:
        raise HTTPException(status_code=404, detail=f"District '{district_id}' not found in state '{state_id}'")
    return state_data["mandals_by_district"].get(district_id, [])

@router.get("/states/{state_id}/districts/{district_id}/mandals/{mandal_id}/villages")
def get_mandal_villages_hierarchical(state_id: str, district_id: str, mandal_id: str) -> List[Dict[str, Any]]:
    """
    Returns verified revenue villages/cadastral units subordinate to a mandal.
    Validates complete parent chain:
    - 404 if state, district, or mandal not found.
    - 400 if mandal exists but does not belong to the specified district.
    """
    state_data = location_manager.get_state_data(state_id)
    if district_id not in state_data["districts_by_id"]:
        raise HTTPException(status_code=404, detail=f"District '{district_id}' not found in state '{state_id}'")

    mandal = state_data["mandals_by_id"].get(mandal_id)
    if not mandal:
        raise HTTPException(status_code=404, detail=f"Mandal '{mandal_id}' not found in state '{state_id}'")

    if mandal.get("district_id") != district_id:
        raise HTTPException(
            status_code=400,
            detail=f"Parent mismatch: Mandal '{mandal_id}' belongs to district '{mandal.get('district_id')}', not '{district_id}'"
        )

    return state_data["villages_by_mandal"].get(mandal_id, [])

@router.get("/states/{state_id}/provenance")
def get_state_provenance(state_id: str) -> Dict[str, Any]:
    """Returns machine-readable provenance metadata, retrieval timestamps, and checksums for the state."""
    state_data = location_manager.get_state_data(state_id)
    prov = state_data.get("provenance")
    if not prov:
        raise HTTPException(status_code=404, detail=f"Provenance metadata not found for state: {state_id}")
    return prov

@router.get("/states/{state_id}/mandals")
def get_state_mandals(state_id: str, district_id: Optional[str] = None) -> List[Dict[str, Any]]:
    """Backward-compatible endpoint: Returns mandals for a state, optionally filtered by district."""
    state_data = location_manager.get_state_data(state_id)
    if district_id:
        if district_id not in state_data["districts_by_id"]:
            raise HTTPException(status_code=404, detail=f"District '{district_id}' not found in state '{state_id}'")
        return state_data["mandals_by_district"].get(district_id, [])
    return state_data["mandals"]

@router.get("/states/{state_id}/villages")
def get_state_villages(
    state_id: str,
    mandal_id: Optional[str] = None,
    district_id: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Backward-compatible endpoint: Returns revenue villages/cadastral units, validating parent chain if both given."""
    state_data = location_manager.get_state_data(state_id)
    if district_id and mandal_id:
        if district_id not in state_data["districts_by_id"]:
            raise HTTPException(status_code=404, detail=f"District '{district_id}' not found in state '{state_id}'")
        mandal = state_data["mandals_by_id"].get(mandal_id)
        if not mandal:
            raise HTTPException(status_code=404, detail=f"Mandal '{mandal_id}' not found in state '{state_id}'")
        if mandal.get("district_id") != district_id:
            raise HTTPException(
                status_code=400,
                detail=f"Parent mismatch: Mandal '{mandal_id}' belongs to district '{mandal.get('district_id')}', not '{district_id}'"
            )
        return state_data["villages_by_mandal"].get(mandal_id, [])
    elif mandal_id:
        if mandal_id not in state_data["mandals_by_id"]:
            raise HTTPException(status_code=404, detail=f"Mandal '{mandal_id}' not found in state '{state_id}'")
        return state_data["villages_by_mandal"].get(mandal_id, [])
    elif district_id:
        if district_id not in state_data["districts_by_id"]:
            raise HTTPException(status_code=404, detail=f"District '{district_id}' not found in state '{state_id}'")
        mandals_in_dist = state_data["mandals_by_district"].get(district_id, [])
        villages_list = []
        for m in mandals_in_dist:
            villages_list.extend(state_data["villages_by_mandal"].get(m["id"], []))
        return villages_list
    return state_data["villages"]

@router.get("/states/{state_id}/crops")
def get_state_crops(state_id: str) -> List[Dict[str, Any]]:
    """Returns the crop catalog for a given state."""
    crops_file = STATE_DATA_DIR / state_id / "crops.json"
    if not crops_file.exists():
        raise HTTPException(status_code=404, detail=f"Crops catalog not found: {state_id}")
    with open(crops_file, "r", encoding="utf-8") as f:
        return json.load(f)

@router.get("/states/{state_id}/crop-rules")
def get_state_crop_rules(state_id: str) -> Dict[str, Any]:
    """Returns agronomic crop rotation rules for a given state."""
    rules_file = STATE_DATA_DIR / state_id / "crop_rules.json"
    if not rules_file.exists():
        raise HTTPException(status_code=404, detail=f"Crop rules not found: {state_id}")
    with open(rules_file, "r", encoding="utf-8") as f:
        return json.load(f)

# --- Soil Benchmarks & Farmer Profile Endpoints ---

@router.get("/soil-benchmarks/{district_id}")
def get_soil_benchmark(district_id: str) -> Dict[str, Any]:
    """Returns verified agricultural soil benchmark (Soil Health Card & ANGRAU) for a district."""
    bm = farmer_service.get_district_soil_benchmark(district_id)
    if not bm:
        raise HTTPException(status_code=404, detail=f"Soil benchmark not found for district: {district_id}")
    return bm

@router.post("/farmer-profile")
def create_or_update_farmer_profile(data: FarmerProfileInput, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """
    Saves or updates a farmer profile with soil measurements, irrigation, and crop history.
    Bridges farmer-measured data with verified agricultural benchmarks (Soil Health Card Scheme & ANGRAU).
    """
    try:
        district_id = None
        if not data.farm_id:
            raise HTTPException(status_code=400, detail="A farm_id is required for a farmer profile")
        farm = database.get_farm_by_id(data.farm_id)
        if not farm or farm.get("owner_user_id") != current_user["id"]:
            raise HTTPException(status_code=404, detail="Farm profile not found")
        district_id = farm.get("district_id")

        processed = farmer_service.process_farmer_profile(data, district_id=district_id)
        processed["owner_user_id"] = current_user["id"]
        saved = database.save_farmer_profile(processed)
        return {
            "status": "saved",
            "farmer_profile": saved
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to save farmer profile: {str(e)}")

@router.get("/farmer-profile/{farm_id}")
def get_farmer_profile_endpoint(farm_id: str, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """Retrieve farmer profile associated with a farm ID."""
    farm = database.get_farm_by_id(farm_id)
    if not farm or farm.get("owner_user_id") != current_user["id"]:
        raise HTTPException(status_code=404, detail="Farm profile not found")
    profile = database.get_farmer_profile_by_farm_id(farm_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Farmer profile not found for this farm")
    return profile


# --- Soil Health Report Upload & Analysis ---
SOIL_REPORT_DIR = BASE_DIR / "uploads" / "soil_reports"
SOIL_REPORT_MAX_BYTES = 10 * 1024 * 1024
SOIL_REPORT_TYPES = {"application/pdf", "image/jpeg", "image/png"}

def _farm_owned_by_user(farm_id: str, user_id: str) -> Dict[str, Any]:
    farm = database.get_farm_by_id(farm_id)
    if not farm or farm.get("owner_user_id") != user_id:
        raise HTTPException(status_code=404, detail="Farm profile not found")
    return farm

@router.post("/soil-reports", status_code=status.HTTP_201_CREATED)
async def upload_soil_report(
    farm_id: str = Form(...),
    report_file: UploadFile = File(...),
    current_user: Dict[str, Any] = Depends(auth.get_current_user),
) -> Dict[str, Any]:
    """Store a farmer-owned soil report and conservatively extract text-based metrics from PDFs."""
    _farm_owned_by_user(farm_id, current_user["id"])
    content_type = (report_file.content_type or "").lower()
    if content_type not in SOIL_REPORT_TYPES:
        raise HTTPException(status_code=415, detail="Upload a PDF, JPG or PNG soil report")
    raw = await report_file.read(SOIL_REPORT_MAX_BYTES + 1)
    if not raw or len(raw) > SOIL_REPORT_MAX_BYTES:
        raise HTTPException(status_code=413, detail="Soil report must be between 1 byte and 10 MB")
    valid_signature = (content_type == "application/pdf" and raw.startswith(b"%PDF-")) or (content_type == "image/jpeg" and raw.startswith(b"\xff\xd8\xff")) or (content_type == "image/png" and raw.startswith(b"\x89PNG\r\n\x1a\n"))
    if not valid_signature:
        raise HTTPException(status_code=415, detail="File content does not match its declared type")
    safe_name = Path(report_file.filename or "soil-report").name[:180]
    report_id = str(__import__("uuid").uuid4())
    stored_name = f"{report_id}.{'pdf' if content_type == 'application/pdf' else 'jpg' if content_type == 'image/jpeg' else 'png'}"
    SOIL_REPORT_DIR.mkdir(parents=True, exist_ok=True)
    destination = SOIL_REPORT_DIR / stored_name
    destination.write_bytes(raw)
    metrics: Dict[str, Any] = {}
    extraction_status = "manual_entry_required"
    if content_type == "application/pdf":
        try:
            from pypdf import PdfReader
            import io
            reader = PdfReader(io.BytesIO(raw))
            text_content = "\n".join((page.extract_text() or "") for page in reader.pages)
            metrics = extract_soil_metrics(text_content)
            extraction_status = "metrics_extracted" if metrics else "no_readable_metrics_found"
        except ImportError:
            extraction_status = "pdf_text_extraction_unavailable"
        except Exception as exc:
            logger.info("Could not extract soil report text: %s", exc)
            extraction_status = "pdf_text_extraction_failed"
    elif content_type.startswith("image/"):
        extraction_status = "image_saved_manual_entry_required"
    report = {
        "id": report_id, "owner_user_id": current_user["id"], "farm_id": farm_id,
        "original_filename": safe_name, "stored_filename": stored_name, "content_type": content_type,
        "file_size": len(raw), "extraction_status": extraction_status,
        "extracted_metrics": metrics, "created_at": datetime.now().astimezone().isoformat()
    }
    database.save_soil_report(report)
    return {"status": "uploaded", "report": {k:v for k,v in report.items() if k not in {"owner_user_id", "stored_filename"}}, "classifications": classify_metrics(metrics), "analysis_note": "Extracted values are suggestions for review, not verified laboratory results. Scanned PDFs and images require manual entry; no OCR is claimed."}

@router.get("/soil-reports/{farm_id}")
def get_soil_reports(farm_id: str, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> List[Dict[str, Any]]:
    _farm_owned_by_user(farm_id, current_user["id"])
    return database.list_soil_reports(current_user["id"], farm_id)

# --- Crop Knowledge Endpoints ---

@router.get("/crop-knowledge")
def get_crop_knowledge_catalog() -> List[Dict[str, Any]]:
    """Returns the verified crop knowledge catalog with botanical families, water/heat stress, and citations."""
    return crop_service.get_all_crops()

@router.get("/crop-knowledge/{crop_id}")
def get_crop_knowledge_detail(crop_id: str) -> Dict[str, Any]:
    """Retrieve detailed verified profile of a specific crop."""
    crop = crop_service.get_crop_by_id(crop_id)
    if not crop:
        raise HTTPException(status_code=404, detail=f"Crop knowledge profile not found for: {crop_id}")
    return crop

# --- Sentinel-2 and FAO GAEZ integrations ---

@router.post("/earth-observation/sentinel-2/search")
def search_sentinel2(req: Sentinel2SearchRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> Dict[str, Any]:
    """Search Copernicus Sentinel-2 L2A scene metadata for a farm area and date range."""
    if req.farm_id:
        if not current_user:
            raise HTTPException(status_code=401, detail="Sign in to query a registered farm")
        _ensure_farm_owner(req.farm_id, current_user)
    try:
        return sentinel2_service.search(req.latitude, req.longitude, req.start_date, req.end_date,
                                        req.bbox_size, req.max_cloud_cover, req.limit)
    except requests.RequestException as exc:
        logger.exception("Sentinel-2 catalog request failed")
        raise HTTPException(status_code=502, detail="Copernicus Sentinel-2 catalogue is temporarily unavailable") from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

@router.post("/earth-observation/sentinel-2/farms/{farm_id}/ndvi")
def analyze_farm_sentinel2_ndvi(
    farm_id: str,
    req: Sentinel2FarmNDVIRequest,
    current_user: Dict[str, Any] = Depends(auth.get_current_user),
) -> Dict[str, Any]:
    """Calculate Sentinel-2 NDVI statistics for a registered farm owned by the caller."""
    farm = _ensure_farm_owner(farm_id, current_user)
    if not farm:
        # The route requires a farm ID; retain a not-found response for missing records.
        raise HTTPException(status_code=404, detail="Farm profile not found")
    boundary = farm.get("boundary_geojson")
    if not boundary:
        raise HTTPException(status_code=422, detail="Farm profile has no saved boundary geometry")
    try:
        result = sentinel2_processing_service.analyze_farm(
            boundary_geojson=boundary,
            start_date=req.start_date,
            end_date=req.end_date,
            max_cloud_cover=req.max_cloud_cover,
        )
        return {
            "farm_id": farm_id,
            "farm_name": farm.get("farm_name"),
            "result": result,
        }
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Sentinel2ProcessingError as exc:
        logger.warning("Sentinel-2 farm NDVI processing failed for farm %s: %s", farm_id, exc)
        raise HTTPException(
            status_code=502,
            detail="Sentinel-2 processing is temporarily unavailable or returned unusable imagery",
        ) from exc


@router.get("/gaez/catalog")
def get_gaez_catalog() -> Dict[str, Any]:
    """Return FAO GAEZ catalogue metadata and the current GAEZ v5 portal reference."""
    try:
        return gaez_service.catalog()
    except requests.RequestException as exc:
        logger.exception("GAEZ catalogue request failed")
        raise HTTPException(status_code=502, detail="FAO GAEZ catalogue is temporarily unavailable") from exc

@router.post("/gaez/search")
def search_gaez(req: GAEZSearchRequest) -> Dict[str, Any]:
    """Search published FAO GAEZ v4 catalogue records; v5 portal is linked in the response."""
    try:
        return gaez_service.search(req.query, req.collection_id, req.limit)
    except requests.RequestException as exc:
        logger.exception("GAEZ search request failed")
        raise HTTPException(status_code=502, detail="FAO GAEZ search service is temporarily unavailable") from exc

# --- NASA Earth Observation Endpoints ---

def _service_status_snapshot(
    service_metadata: Dict[str, Any],
    *,
    authentication_required: bool = False,
    credentials_configured: Optional[bool] = None,
) -> Dict[str, Any]:
    """Normalize configuration metadata without pretending to perform a live health check.

    Provider reachability, successful authentication and data availability are unknown
    until a real provider query succeeds. This endpoint intentionally does not make
    outbound requests or expose credentials.
    """
    configured = credentials_configured if authentication_required else True
    if configured is None:
        configured = False
    snapshot = dict(service_metadata)
    snapshot.update({
        "configured": bool(configured),
        "authentication_required": authentication_required,
        "credentials_configured": bool(credentials_configured) if authentication_required else None,
        "reachable": None,
        "authenticated": False if authentication_required and not credentials_configured else None,
        "data_available": None,
        "status": "configuration_required" if authentication_required and not credentials_configured else "not_checked",
        "status_check_scope": "configuration_only",
        "status_checked_at": datetime.now(timezone.utc).isoformat(),
    })
    return snapshot


@router.get("/nasa/services")
def get_nasa_services_status() -> Dict[str, Any]:
    """Report configuration separately from live reachability, auth and data checks."""
    smap_metadata = smap_service.get_service_status()
    gpm_metadata = gpm_service.get_service_status()
    gldas_metadata = gldas_service.get_service_status()
    sentinel_credentials_configured = bool(
        sentinel2_processing_service.client_id and sentinel2_processing_service.client_secret
    )
    services = [
        _service_status_snapshot(power_service.get_service_status()),
        _service_status_snapshot(
            smap_metadata, authentication_required=True,
            credentials_configured=bool(smap_metadata.get("auth_configured")),
        ),
        _service_status_snapshot(
            gpm_metadata, authentication_required=True,
            credentials_configured=bool(gpm_metadata.get("auth_configured")),
        ),
        _service_status_snapshot(
            gldas_metadata, authentication_required=True,
            credentials_configured=bool(gldas_metadata.get("auth_configured")),
        ),
        _service_status_snapshot(srtm_service.get_service_status()),
        _service_status_snapshot(era5_service.get_service_status()),
        _service_status_snapshot(landsat_service.get_service_status()),
        _service_status_snapshot({
            "service": "Sentinel-2 STAC catalogue",
            "provider": "Copernicus Data Space Ecosystem",
            "note": "Public catalogue discovery; no OAuth credentials required.",
        }),
        _service_status_snapshot({
            "service": "Sentinel-2 farm-polygon NDVI processing",
            "provider": "Copernicus Data Space / Sentinel Hub Process API",
            "note": "Pixel processing requires Sentinel Hub OAuth credentials.",
        }, authentication_required=True, credentials_configured=sentinel_credentials_configured),
        _service_status_snapshot(modis_viirs_service.get_service_status()),
        _service_status_snapshot(ecostress_gracefo_service.get_service_status()),
        _service_status_snapshot({
            "service": "FAO GAEZ catalogue",
            "provider": "FAO/IIASA Global Agro-Ecological Zones",
            "note": "Catalogue discovery only; farm-level suitability raster extraction is not implemented.",
        }),
    ]
    return {
        "status": "not_checked",
        "status_check_scope": "configuration_only",
        "message": (
            "This endpoint reports local configuration only. Provider reachability, "
            "successful authentication and current data availability are not tested here."
        ),
        "services": services,
    }

@router.post("/climate/era5/query")
def query_era5_endpoint(req: ERA5QueryRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> Dict[str, Any]:
    """Query hourly ERA5-Land reanalysis time series for a point and date range."""
    if req.farm_id:
        if not current_user: raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
        _ensure_farm_owner(req.farm_id, current_user)
    try:
        return era5_service.query_point(req.latitude, req.longitude, req.start_date, req.end_date)
    except ValueError as exc: raise HTTPException(status_code=422, detail=str(exc)) from exc
    except requests.RequestException as exc:
        logger.exception("ERA5-Land archive request failed")
        raise HTTPException(status_code=502, detail="ERA5-Land archive service is unavailable") from exc

@router.post("/earth-observation/landsat/search")
def search_landsat_endpoint(req: LandsatSearchRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> Dict[str, Any]:
    """Search Landsat Collection 2 Level-2 scenes and selected asset links."""
    if req.farm_id:
        if not current_user: raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
        _ensure_farm_owner(req.farm_id, current_user)
    try:
        return landsat_service.search(req.latitude, req.longitude, req.start_date, req.end_date, req.bbox_size, req.max_cloud_cover, req.limit)
    except ValueError as exc: raise HTTPException(status_code=422, detail=str(exc)) from exc
    except requests.RequestException as exc:
        logger.exception("Landsat STAC search failed")
        raise HTTPException(status_code=502, detail="Landsat scene catalogue is unavailable") from exc

@router.post("/nasa/gldas/query")
def query_nasa_gldas_endpoint(req: GLDASQueryRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> Dict[str, Any]:
    """Query NASA GLDAS-2.1 Noah monthly land-surface model values at a farm point."""
    if req.farm_id:
        if not current_user:
            raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
        _ensure_farm_owner(req.farm_id, current_user)
    try:
        return gldas_service.query_point(req.latitude, req.longitude, req.date)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except requests.RequestException as exc:
        logger.exception("GLDAS query failed")
        raise HTTPException(status_code=502, detail="NASA GES DISC GLDAS service is unavailable") from exc
    except Exception as exc:
        logger.exception("GLDAS extraction failed")
        raise HTTPException(status_code=502, detail="GLDAS data could not be extracted") from exc

@router.post("/earth-observation/srtm/query")
def query_srtm_endpoint(req: SRTMQueryRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> Dict[str, Any]:
    """Retrieve SRTM 30 m terrain elevations for one or more WGS84 points."""
    if req.farm_id:
        if not current_user:
            raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
        _ensure_farm_owner(req.farm_id, current_user)
    try:
        return srtm_service.query_points([p.model_dump() for p in req.points])
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except requests.RequestException as exc:
        logger.exception("SRTM elevation request failed")
        raise HTTPException(status_code=502, detail="SRTM elevation service is unavailable") from exc

@router.post("/nasa/power/query")
def query_nasa_power_endpoint(req: NASAPowerQueryRequest, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """
    Queries real NASA POWER Agroclimatology API for the given farm centroid coordinates.
    Computes daily & monthly agroclimatological summaries, handles missing values,
    persists queries in SQLite cache, and extracts formal Environmental Evidence Objects.
    """
    try:
        if req.farm_id:
            if not current_user:
                raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
            _ensure_farm_owner(req.farm_id, current_user)
        data = power_service.fetch_agroclimatology(
            lat=req.latitude,
            lng=req.longitude,
            start_date=req.start_date,
            end_date=req.end_date,
            use_cache=req.use_cache
        )
        if req.farm_id:
            database.save_farm_evidence(
                farm_id=req.farm_id,
                lat=req.latitude,
                lng=req.longitude,
                evidence_list=data.get("evidence_objects", [])
            )
        return data
    except HTTPException:
        raise
    except Exception:
        logger.exception("NASA-backed API request failed")
        raise HTTPException(status_code=500, detail="The requested data could not be processed. Please try again later.")

@router.post("/nasa/smap/query")
def query_nasa_smap_endpoint(req: NASASMAPQueryRequest, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """
    Queries NASA SMAP SPL3SMP_E Version 6 product for surface soil moisture.
    Supports area sampling via bounding box, preserves quality flags,
    computes 14-day vs seasonal trend indicators, and enforces scientific integrity
    (reports auth_required/unavailable if unconfigured instead of faking data).
    """
    try:
        if req.farm_id:
            if not current_user:
                raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
            _ensure_farm_owner(req.farm_id, current_user)
        data = smap_service.fetch_surface_soil_moisture(
            lat=req.latitude,
            lng=req.longitude,
            polygon_bbox=req.polygon_bbox,
            start_date=req.start_date,
            end_date=req.end_date,
            use_cache=req.use_cache
        )
        if req.farm_id and data.get("evidence_object"):
            database.save_farm_evidence(
                farm_id=req.farm_id,
                lat=req.latitude,
                lng=req.longitude,
                evidence_list=[data["evidence_object"]]
            )
        return data
    except HTTPException:
        raise
    except Exception:
        logger.exception("NASA-backed API request failed")
        raise HTTPException(status_code=500, detail="The requested data could not be processed. Please try again later.")

@router.post("/nasa/gpm/query")
def query_nasa_gpm_endpoint(req: NASAGPMQueryRequest, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """
    Queries NASA GPM IMERG Version 07 Final Run product for satellite precipitation.
    Aggregates rainfall over farm boundary, preserves quality & version metadata,
    and optionally compares satellite rainfall with NASA POWER numerical reanalysis
    explaining physical differences scientifically.
    """
    try:
        if req.farm_id:
            if not current_user:
                raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
            _ensure_farm_owner(req.farm_id, current_user)
        data = gpm_service.fetch_precipitation(
            lat=req.latitude,
            lng=req.longitude,
            polygon_bbox=req.polygon_bbox,
            start_date=req.start_date,
            end_date=req.end_date,
            use_cache=req.use_cache
        )
        if req.compare_with_power and data.get("status") == "success":
            power_rain = None
            try:
                period = data.get("evidence_object", {}).get("observation_period", {})
                p_data = power_service.fetch_agroclimatology(
                    lat=req.latitude,
                    lng=req.longitude,
                    start_date=period.get("start_date"),
                    end_date=period.get("end_date"),
                    use_cache=req.use_cache
                )
                for ev in p_data.get("evidence_objects", []):
                    if ev.get("parameter_code") == "PRECTOTCORR":
                        power_rain = float(ev.get("actual_value"))
                        break
            except Exception as power_error:
                logger.warning("POWER comparison query failed: %s", power_error)

            gpm_annual = float(data.get("annual_precipitation_mm", 0.0))
            if gpm_annual > 0 and power_rain is not None and power_rain > 0:
                data["power_comparison"] = gpm_service.compare_with_power(gpm_annual, power_rain)
            else:
                data["power_comparison"] = {
                    "status": "not_available",
                    "message": "Comparison omitted because a real NASA POWER precipitation value was not available."
                }

        if req.farm_id and data.get("evidence_object"):
            database.save_farm_evidence(
                farm_id=req.farm_id,
                lat=req.latitude,
                lng=req.longitude,
                evidence_list=[data["evidence_object"]]
            )
        return data
    except HTTPException:
        raise
    except Exception:
        logger.exception("NASA-backed API request failed")
        raise HTTPException(status_code=500, detail="The requested data could not be processed. Please try again later.")

# --- Asynchronous NASA Job API ---

_NASA_JOB_REQUESTS = {
    "power": NASAPowerQueryRequest,
    "smap": NASASMAPQueryRequest,
    "gpm": NASAGPMQueryRequest,
}

def _run_nasa_job(job_id: str, owner_id: str, job_type: str, payload: Dict[str, Any]) -> None:
    if not database.claim_queued_nasa_job(job_id, owner_id):
        return
    try:
        if job_type == "power":
            data = power_service.fetch_agroclimatology(
                lat=payload["latitude"], lng=payload["longitude"],
                start_date=payload.get("start_date"), end_date=payload.get("end_date"),
                use_cache=payload.get("use_cache", True))
            evidence = data.get("evidence_objects", [])
        elif job_type == "smap":
            data = smap_service.fetch_surface_soil_moisture(
                lat=payload["latitude"], lng=payload["longitude"],
                polygon_bbox=payload.get("polygon_bbox"), start_date=payload.get("start_date"),
                end_date=payload.get("end_date"), use_cache=payload.get("use_cache", True))
            evidence = [data["evidence_object"]] if data.get("evidence_object") else []
        else:
            data = gpm_service.fetch_precipitation(
                lat=payload["latitude"], lng=payload["longitude"],
                polygon_bbox=payload.get("polygon_bbox"), start_date=payload.get("start_date"),
                end_date=payload.get("end_date"), use_cache=payload.get("use_cache", True))
            if payload.get("compare_with_power") and data.get("status") == "success":
                try:
                    period = data.get("evidence_object", {}).get("observation_period", {})
                    power = power_service.fetch_agroclimatology(
                        lat=payload["latitude"], lng=payload["longitude"],
                        start_date=period.get("start_date"), end_date=period.get("end_date"),
                        use_cache=payload.get("use_cache", True))
                    power_rain = next((float(ev.get("actual_value")) for ev in power.get("evidence_objects", [])
                                       if ev.get("parameter_code") == "PRECTOTCORR" and ev.get("actual_value") is not None), None)
                    gpm_rain = float(data.get("annual_precipitation_mm", 0.0))
                    data["power_comparison"] = (gpm_service.compare_with_power(gpm_rain, power_rain)
                        if gpm_rain > 0 and power_rain is not None and power_rain > 0 else
                        {"status": "not_available", "message": "Comparison omitted because a real NASA POWER precipitation value was not available."})
                except Exception:
                    logger.exception("NASA POWER comparison failed inside GPM job")
                    data["power_comparison"] = {"status": "not_available", "message": "NASA POWER comparison could not be completed."}
            evidence = [data["evidence_object"]] if data.get("evidence_object") else []
        if payload.get("farm_id") and evidence:
            database.save_farm_evidence(farm_id=payload["farm_id"], lat=payload["latitude"],
                                        lng=payload["longitude"], evidence_list=evidence)
        database.update_nasa_job(job_id, "succeeded", result=data)
    except Exception:
        logger.exception("NASA background job %s attempt 1 failed", job_id)
        try:
            time.sleep(1.0)
            database.update_nasa_job(job_id, "running", increment_attempts=True)
            # Retry once; the services retain their own network timeout and cache safeguards.
            _run_nasa_job_once(job_id, owner_id, job_type, payload)
        except Exception:
            logger.exception("NASA background job %s retry failed", job_id)
            database.update_nasa_job(job_id, "failed", error_message="NASA data retrieval failed after one retry. Please submit the request again.")

def _run_nasa_job_once(job_id: str, owner_id: str, job_type: str, payload: Dict[str, Any]) -> None:
    # The retry path reuses the same processor without recursively retrying.
    if job_type == "power":
        data = power_service.fetch_agroclimatology(lat=payload["latitude"], lng=payload["longitude"], start_date=payload.get("start_date"), end_date=payload.get("end_date"), use_cache=payload.get("use_cache", True))
        evidence = data.get("evidence_objects", [])
    elif job_type == "smap":
        data = smap_service.fetch_surface_soil_moisture(lat=payload["latitude"], lng=payload["longitude"], polygon_bbox=payload.get("polygon_bbox"), start_date=payload.get("start_date"), end_date=payload.get("end_date"), use_cache=payload.get("use_cache", True))
        evidence = [data["evidence_object"]] if data.get("evidence_object") else []
    else:
        data = gpm_service.fetch_precipitation(lat=payload["latitude"], lng=payload["longitude"], polygon_bbox=payload.get("polygon_bbox"), start_date=payload.get("start_date"), end_date=payload.get("end_date"), use_cache=payload.get("use_cache", True))
        if payload.get("compare_with_power") and data.get("status") == "success":
            period = data.get("evidence_object", {}).get("observation_period", {})
            power = power_service.fetch_agroclimatology(lat=payload["latitude"], lng=payload["longitude"], start_date=period.get("start_date"), end_date=period.get("end_date"), use_cache=payload.get("use_cache", True))
            power_rain = next((float(ev.get("actual_value")) for ev in power.get("evidence_objects", []) if ev.get("parameter_code") == "PRECTOTCORR" and ev.get("actual_value") is not None), None)
            gpm_rain = float(data.get("annual_precipitation_mm", 0.0))
            data["power_comparison"] = (gpm_service.compare_with_power(gpm_rain, power_rain) if gpm_rain > 0 and power_rain is not None and power_rain > 0 else {"status": "not_available", "message": "Comparison omitted because a real NASA POWER precipitation value was not available."})
        evidence = [data["evidence_object"]] if data.get("evidence_object") else []
    if payload.get("farm_id") and evidence:
        database.save_farm_evidence(farm_id=payload["farm_id"], lat=payload["latitude"], lng=payload["longitude"], evidence_list=evidence)
    database.update_nasa_job(job_id, "succeeded", result=data)

@router.post("/nasa/jobs/{job_type}", status_code=202)
async def submit_nasa_job(job_type: str, request: Request, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """Submit a POWER, SMAP, or GPM retrieval without blocking the HTTP request."""
    if job_type not in _NASA_JOB_REQUESTS:
        raise HTTPException(status_code=404, detail="Unsupported NASA job type")
    try:
        body = await request.json()
        payload = _NASA_JOB_REQUESTS[job_type].model_validate(body).model_dump()
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=422, detail="Invalid NASA job request payload") from exc
    if payload.get("farm_id"):
        _ensure_farm_owner(payload["farm_id"], current_user)
    if database.count_active_nasa_jobs(current_user["id"]) >= 3:
        raise HTTPException(status_code=429, detail="You already have 3 NASA jobs queued or running. Wait for one to finish before submitting another.")
    if database.count_active_nasa_jobs() >= 20:
        raise HTTPException(status_code=503, detail="The NASA processing queue is full. Please try again shortly.", headers={"Retry-After": "30"})
    job_id = str(uuid.uuid4())
    database.create_nasa_job(job_id, current_user["id"], job_type, payload)
    _nasa_job_executor.submit(_run_nasa_job, job_id, current_user["id"], job_type, payload)
    return {"job_id": job_id, "job_type": job_type, "status": "queued", "status_url": f"/api/nasa/jobs/{job_id}"}

@router.get("/nasa/jobs/{job_id}")
def get_nasa_job_status(job_id: str, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    job = database.get_nasa_job(job_id, current_user["id"])
    if not job:
        raise HTTPException(status_code=404, detail="NASA job not found")
    job.pop("request", None)
    return job

@router.delete("/nasa/jobs/{job_id}")
def cancel_nasa_job(job_id: str, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    if database.cancel_queued_nasa_job(job_id, current_user["id"]):
        return {"job_id": job_id, "status": "cancelled"}
    job = database.get_nasa_job(job_id, current_user["id"])
    if not job:
        raise HTTPException(status_code=404, detail="NASA job not found")
    raise HTTPException(status_code=409, detail="Only queued jobs can be cancelled; running jobs cannot be interrupted safely.")

# --- Unified Evidence & Recommendation Endpoints ---

@router.post("/evidence/unified")
def get_unified_evidence_endpoint(req: UnifiedEvidenceRequest, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """
    Unified Environmental Evidence Dossier endpoint.
    Aggregates multi-source NASA observations (POWER, SMAP, GPM) alongside
    farmer ground-truth soil data into a single traceable evidence collection.
    """
    try:
        if req.farm_id:
            if not current_user:
                raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
            _ensure_farm_owner(req.farm_id, current_user)
        power_data = None
        smap_data = None
        gpm_data = None

        try:
            power_data = power_service.fetch_agroclimatology(
                lat=req.latitude,
                lng=req.longitude,
                use_cache=req.use_cache
            )
        except Exception as pe:
            logger.warning(f"POWER query error: {pe}")

        try:
            smap_data = smap_service.fetch_surface_soil_moisture(
                lat=req.latitude,
                lng=req.longitude,
                polygon_bbox=req.polygon_bbox,
                use_cache=req.use_cache
            )
        except Exception as se:
            logger.warning(f"SMAP query error: {se}")

        try:
            gpm_data = gpm_service.fetch_precipitation(
                lat=req.latitude,
                lng=req.longitude,
                polygon_bbox=req.polygon_bbox,
                use_cache=req.use_cache
            )
        except Exception as ge:
            logger.warning(f"GPM query error: {ge}")

        # Check farmer profile
        fp = req.farmer_profile
        if not fp and req.farm_id:
            fp = database.get_farmer_profile_by_farm_id(req.farm_id)

        dossier = evidence_service.build_unified_dossier(
            lat=req.latitude,
            lng=req.longitude,
            power_data=power_data,
            smap_data=smap_data,
            gpm_data=gpm_data,
            farmer_profile=fp,
            farm_id=req.farm_id
        )
        return dossier
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unified evidence request failed")
        raise HTTPException(status_code=500, detail="Environmental evidence could not be assembled. Please try again later.")

@router.post("/recommendations/generate")
def generate_recommendations_endpoint(req: GenerateRecommendationsRequest, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """
    Generates multi-season crop rotation recommendations backed by unified NASA Earth observation evidence,
    farmer ground-truth soil data, and ANGRAU/ICAR crop knowledge.
    """
    try:
        if req.farm_id:
            if not current_user:
                raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
            _ensure_farm_owner(req.farm_id, current_user)
        # 1. Fetch crops & rules for state
        crops_file = STATE_DATA_DIR / req.state_id / "crops.json"
        rules_file = STATE_DATA_DIR / req.state_id / "crop_rules.json"

        if not crops_file.exists() or not rules_file.exists():
            raise HTTPException(status_code=404, detail=f"State catalog missing for {req.state_id}")

        with open(crops_file, "r", encoding="utf-8") as f:
            crops = json.load(f)
        with open(rules_file, "r", encoding="utf-8") as f:
            rules_data = json.load(f)
            rules = rules_data.get("agronomic_rules", [])

        # 2. Build unified evidence dossier
        power_data = None
        smap_data = None
        gpm_data = None
        dataset_status = {}

        for dataset_name, fetch in (
            ("NASA_POWER", lambda: power_service.fetch_agroclimatology(
                lat=req.latitude, lng=req.longitude, use_cache=req.use_cache)),
            ("NASA_SMAP", lambda: smap_service.fetch_surface_soil_moisture(
                lat=req.latitude, lng=req.longitude, polygon_bbox=req.polygon_bbox,
                use_cache=req.use_cache)),
            ("NASA_GPM", lambda: gpm_service.fetch_precipitation(
                lat=req.latitude, lng=req.longitude, polygon_bbox=req.polygon_bbox,
                use_cache=req.use_cache)),
        ):
            try:
                payload = fetch()
                status = payload.get("status", "unknown") if isinstance(payload, dict) else "unknown"
                dataset_status[dataset_name] = {
                    "status": status,
                    "data_unavailable": status not in ("success", "ready"),
                    "used": status == "success",
                }
                if dataset_name == "NASA_POWER":
                    power_data = payload if status == "success" else None
                elif dataset_name == "NASA_SMAP":
                    smap_data = payload if status == "success" else None
                else:
                    gpm_data = payload if status == "success" else None
            except Exception as exc:
                logger.exception("%s fetch failed during recommendation generation", dataset_name)
                dataset_status[dataset_name] = {
                    "status": "error", "data_unavailable": True, "used": False,
                    "message": "Dataset retrieval failed; it was not used in this recommendation.",
                }

        # Check farmer profile
        fp = req.farmer_profile
        if not fp and req.farm_id:
            fp = database.get_farmer_profile_by_farm_id(req.farm_id)

        dossier = evidence_service.build_unified_dossier(
            lat=req.latitude,
            lng=req.longitude,
            power_data=power_data,
            smap_data=smap_data,
            gpm_data=gpm_data,
            farmer_profile=fp,
            farm_id=req.farm_id
        )

        # 3. Generate crop-rotation strategies from the existing evidence engine.
        result = rotation_engine.generate_recommendations(
            crops=crops,
            crop_rules=rules,
            dossier=dossier,
            farmer_profile=fp,
            custom_weights=req.weights
        )

        # 4. Build an annual Kharif/Rabi/Summer plan from the state's declared
        # crop-season catalogue. No unsupported season crops are fabricated.
        result["seasonal_plan"] = build_multi_season_plan(crops, fp)
        result["dataset_status"] = dataset_status
        result["data_unavailable"] = any(item["data_unavailable"] for item in dataset_status.values())
        result["datasets_not_used"] = [name for name, item in dataset_status.items() if not item["used"]]

        # 5. Attach Sentinel-2 and FAO GAEZ context for planning review. These
        # sources are contextual only until pixel-level indices and matching
        # GAEZ suitability layers are available; they do not alter numeric scores.
        if req.include_geospatial_context:
            from geospatial.rotation_context import build_rotation_geospatial_context
            crop_names = []
            for strategy in result.get("strategies", []):
                for crop_entry in strategy.get("crop_sequence", []) or []:
                    if isinstance(crop_entry, dict):
                        crop_names.append(crop_entry.get("crop") or crop_entry.get("crop_name") or "")
                    elif isinstance(crop_entry, str):
                        crop_names.append(crop_entry)
            result["geospatial_rotation_context"] = build_rotation_geospatial_context(
                req.latitude, req.longitude, crop_names, sentinel2_service, gaez_service,
                farm_id=req.farm_id
            )
        return result
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except HTTPException:
        raise
    except Exception:
        logger.exception("Recommendation generation failed")
        raise HTTPException(status_code=500, detail="Recommendations could not be generated. Please try again later.")

@router.get("/recommendations/archetypes")
def get_recommendation_archetypes() -> List[Dict[str, Any]]:
    """Returns the 3 core rotation strategy archetypes."""
    return rotation_engine.get_supported_strategies()

@router.post("/recommendations/recalculate")
def recalculate_recommendations_endpoint(req: RecalculateScoresRequest) -> Dict[str, Any]:
    """
    Recalculates all three crop rotation scores immediately using the farmer's updated priority weights.
    Re-evaluates the actual scoring formula: Overall = (Water*W_w + Soil*W_s + Climate*W_c + Local*W_l)/100,
    reorders strategies by updated score, compares baseline and updated rankings, and provides
    plain-language mathematical explanations for movements.
    """
    try:
        return rotation_engine.recalculate_scores(
            strategies=req.strategies,
            weights=req.weights,
            baseline_weights=req.baseline_weights
        )
    except Exception as e:
        logger.error(f"Failed to recalculate scores: {e}")
        raise HTTPException(status_code=400, detail=f"Failed to recalculate recommendation scores: {str(e)}")

@router.post("/reports/generate")
def generate_report_endpoint(req: GenerateReportRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> Dict[str, Any]:
    """
    Assembles a complete evidence-backed audit report preserving the farmer's chosen priority weights.
    Includes baseline vs updated rankings, side-by-side strategy comparison, and satellite evidence citations.
    """
    try:
        if req.farm_id:
            if not current_user:
                raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
            _ensure_farm_owner(req.farm_id, current_user)
        farm_data = req.farm_data
        if not farm_data and req.farm_id:
            farm_data = database.get_farm_by_id(req.farm_id)

        farmer_prof = req.farmer_profile
        if not farmer_prof and req.farm_id:
            farmer_prof = database.get_farmer_profile_by_farm_id(req.farm_id)

        b_weights = req.baseline_weights or {"water": 25.0, "soil": 25.0, "climate": 25.0, "local": 25.0}

        report_payload = ReportService.generate_report_payload(
            farm_data=farm_data,
            farmer_profile=farmer_prof,
            weights=req.weights,
            baseline_weights=b_weights,
            strategies=req.strategies,
            ranking_comparison=req.ranking_comparison,
            dossier=req.dossier
        )
        return report_payload
    except Exception as e:
        logger.error(f"Report generation failed: {e}")
        raise HTTPException(status_code=400, detail=f"Report generation failed: {str(e)}")

@router.post("/reports/html", response_class=HTMLResponse)
def generate_report_html_endpoint(req: GenerateReportRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> str:
    """
    Generates a print-ready HTML report tailored for PDF export via browser print or rendering engines.
    Preserves all chosen weights, ranking shift tables, and NASA evidence provenance.
    """
    try:
        if req.farm_id:
            if not current_user:
                raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
            _ensure_farm_owner(req.farm_id, current_user)
        farm_data = req.farm_data
        if not farm_data and req.farm_id:
            farm_data = database.get_farm_by_id(req.farm_id)

        farmer_prof = req.farmer_profile
        if not farmer_prof and req.farm_id:
            farmer_prof = database.get_farmer_profile_by_farm_id(req.farm_id)

        b_weights = req.baseline_weights or {"water": 25.0, "soil": 25.0, "climate": 25.0, "local": 25.0}

        report_payload = ReportService.generate_report_payload(
            farm_data=farm_data,
            farmer_profile=farmer_prof,
            weights=req.weights,
            baseline_weights=b_weights,
            strategies=req.strategies,
            ranking_comparison=req.ranking_comparison,
            dossier=req.dossier
        )
        return ReportService.generate_printable_html(report_payload)
    except Exception as e:
        logger.error(f"Report HTML generation failed: {e}")
        raise HTTPException(status_code=400, detail=f"Report HTML generation failed: {str(e)}")

@router.post("/reports/pdf")
def generate_report_pdf_endpoint(req: GenerateReportRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> Response:
    """
    Generates an official audit-grade PDF recommendation report using ReportLab.
    Enforces the Simulator Rule:
    - If the farmer skips the simulator: uses original NASA baseline and original recommendation scores.
    - If the farmer uses the simulator: includes both original and scenario-adjusted scores,
      with scenario parameters and assumptions clearly identified under [SIMULATED - HYPOTHETICAL].
    - Never mixes observed NASA measurements with simulated values.
    Returns binary PDF with Content-Type: application/pdf.
    """
    try:
        if req.farm_id:
            if not current_user:
                raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
            _ensure_farm_owner(req.farm_id, current_user)
        farm_data = req.farm_data
        if not farm_data and req.farm_id:
            farm_data = database.get_farm_by_id(req.farm_id)

        farmer_prof = req.farmer_profile
        if not farmer_prof and req.farm_id:
            farmer_prof = database.get_farmer_profile_by_farm_id(req.farm_id)

        pdf_bytes = AgriNextPDFGenerator.generate_pdf(
            farm_data=farm_data,
            farmer_profile=farmer_prof,
            weights=req.weights,
            strategies=req.strategies,
            ranking_comparison=req.ranking_comparison,
            dossier=req.dossier,
            simulation_data=req.simulation_data
        )

        filename = f"AgriNext_Crop_Rotation_Report_{datetime.now().strftime('%Y%m%d')}.pdf"
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
                "Content-Type": "application/pdf"
            }
        )
    except Exception as e:
        logger.error(f"Report PDF generation failed: {e}", exc_info=True)
        raise HTTPException(status_code=400, detail=f"Report PDF generation failed: {str(e)}")

_SIMULATION_DOSSIER_CACHE: Dict[str, Dict[str, Any]] = {}

@router.post("/simulation/simulate")
def simulate_climate_scenario_endpoint(req: ClimateSimulationRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> Dict[str, Any]:
    """
    Executes a hypothetical climate stress simulation against actual NASA Earth observations.
    Recalculates crop suitability scores using the identical recommendation engine,
    preserves the original NASA baseline without overwriting, records all assumptions and
    transformations, and generates explainable agronomic resilience comparisons.
    """
    try:
        if req.farm_id:
            if not current_user:
                raise HTTPException(status_code=401, detail="Authentication required for farm-linked data")
            _ensure_farm_owner(req.farm_id, current_user)
        farmer_prof = req.farmer_profile
        if not farmer_prof and req.farm_id:
            farmer_prof = database.get_farmer_profile_by_farm_id(req.farm_id)

        dossier = req.baseline_dossier
        if not dossier:
            sim_cache_key = f"{req.state_id}_{round(req.latitude, 3)}_{round(req.longitude, 3)}_{req.farm_id or 'none'}"
            if sim_cache_key in _SIMULATION_DOSSIER_CACHE:
                dossier = _SIMULATION_DOSSIER_CACHE[sim_cache_key]
            else:
                power_data = None
                smap_data = None
                gpm_data = None
                try:
                    power_data = power_service.fetch_agroclimatology(lat=req.latitude, lng=req.longitude, use_cache=True)
                except Exception:
                    pass
                try:
                    smap_data = smap_service.fetch_surface_soil_moisture(lat=req.latitude, lng=req.longitude, use_cache=True)
                except Exception:
                    pass
                try:
                    gpm_data = gpm_service.fetch_precipitation(lat=req.latitude, lng=req.longitude, use_cache=True)
                except Exception:
                    pass
                dossier = evidence_service.build_unified_dossier(
                    lat=req.latitude,
                    lng=req.longitude,
                    power_data=power_data,
                    smap_data=smap_data,
                    gpm_data=gpm_data,
                    farmer_profile=farmer_prof,
                    farm_id=req.farm_id
                )
                _SIMULATION_DOSSIER_CACHE[sim_cache_key] = dossier

        crops_file = STATE_DATA_DIR / req.state_id / "crops.json"
        rules_file = STATE_DATA_DIR / req.state_id / "crop_rules.json"
        crops = []
        crop_rules = []
        if crops_file.exists():
            with open(crops_file, "r", encoding="utf-8") as f:
                crops = json.load(f)
        else:
            crops = crop_service.get_all_crops()

        if rules_file.exists():
            with open(rules_file, "r", encoding="utf-8") as f:
                rules_data = json.load(f)
                crop_rules = rules_data.get("agronomic_rules", [])

        result = simulator.simulate_scenario(
            baseline_dossier=dossier,
            crops=crops,
            crop_rules=crop_rules,
            farmer_profile=farmer_prof,
            weights=req.weights,
            rainfall_pct_change=req.rainfall_pct_change,
            temp_celsius_change=req.temp_celsius_change,
            water_availability_pct_change=req.water_availability_pct_change
        )
        return result
    except Exception as e:
        logger.error(f"Climate simulation failed: {e}")
        raise HTTPException(status_code=400, detail=f"Climate simulation failed: {str(e)}")

# --- Geospatial & Farm Location Endpoints ---

@router.post("/geospatial/analyze-polygon")
def analyze_polygon(req: PolygonAnalysisRequest) -> Dict[str, Any]:
    """
    Analyzes a farm boundary polygon:
    - Calculates geodesic area in acres
    - Calculates centroid (lat, lng) for NASA POWER point queries
    - Prepares bounding box for NASA SMAP/GPM area sampling
    - Detects acreage discrepancies if manual entry is provided
    """
    try:
        geom = req.boundary_geojson
        if geom.get("type") == "Feature":
            geom = geom.get("geometry", {})

        analysis = analyze_farm_boundary(geom)
        
        polygon_acreage = analysis["acreage"]
        manual_acreage = req.manual_acreage
        discrepancy_warning = None

        if manual_acreage is not None and manual_acreage > 0 and polygon_acreage > 0:
            diff = abs(manual_acreage - polygon_acreage)
            pct = (diff / polygon_acreage) * 100.0
            if pct > 15.0 or diff > 0.5:
                discrepancy_warning = (
                    f"Notice: Declared manual acreage ({manual_acreage:.2f} acres) differs from "
                    f"digitized polygon area ({polygon_acreage:.2f} acres) by {pct:.1f}%. "
                    f"Please confirm boundary edges on the satellite map or check land survey records."
                )

        return {
            "status": "success",
            "polygon_acreage": polygon_acreage,
            "manual_acreage": manual_acreage,
            "effective_acreage": manual_acreage if manual_acreage is not None and manual_acreage > 0 else polygon_acreage,
            "centroid": analysis["centroid"],
            "bounding_box": analysis["bounding_box"],
            "vertex_count": analysis["vertex_count"],
            "discrepancy_warning": discrepancy_warning,
            "nasa_targets": analysis["nasa_sampling"]
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Polygon analysis failed: {str(e)}")

@router.post("/farms", status_code=status.HTTP_201_CREATED)
def create_or_update_farm(req: SaveFarmRequest, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """
    Saves or updates a farm profile in SQLite with GeoJSON polygon,
    centroid coordinates, acreage declarations, and validated 4-tier LGD hierarchy.
    """
    try:
        # 1. Validate complete administrative location hierarchy
        state_data = location_manager.get_state_data(req.state_id)
        district = state_data["districts_by_id"].get(req.district_id)
        if not district:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid location: District '{req.district_id}' not found in state '{req.state_id}'"
            )

        mandal = state_data["mandals_by_id"].get(req.mandal_id)
        if not mandal:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid location: Mandal '{req.mandal_id}' not found in state '{req.state_id}'"
            )

        if mandal.get("district_id") != req.district_id:
            raise HTTPException(
                status_code=400,
                detail=f"Hierarchy mismatch: Mandal '{req.mandal_id}' does not belong to district '{req.district_id}'"
            )

        village = None
        if req.village_id:
            village = state_data["villages_by_id"].get(req.village_id)
            if not village:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid location: Village '{req.village_id}' not found in state '{req.state_id}'"
                )
            if village.get("mandal_id") != req.mandal_id:
                raise HTTPException(
                    status_code=400,
                    detail=f"Hierarchy mismatch: Village '{req.village_id}' does not belong to mandal '{req.mandal_id}'"
                )

        # 2. Extract or backfill authoritative LGD codes and names
        district_lgd = req.district_lgd or district.get("lgd_code")
        mandal_lgd = req.mandal_lgd or mandal.get("lgd_code")
        village_name = req.village_name or (village.get("name") if village else None)
        village_lgd = req.village_lgd if req.village_lgd is not None else (village.get("lgd_code") if village else None)

        geom = req.boundary_geojson
        if geom.get("type") == "Feature":
            geom = geom.get("geometry", {})

        analysis = analyze_farm_boundary(geom)
        polygon_acreage = analysis["acreage"]
        centroid = analysis["centroid"]

        discrepancy_warning = None
        if req.manual_acreage is not None and req.manual_acreage > 0 and polygon_acreage > 0:
            diff = abs(req.manual_acreage - polygon_acreage)
            pct = (diff / polygon_acreage) * 100.0
            if pct > 15.0 or diff > 0.5:
                discrepancy_warning = (
                    f"Declared manual acreage ({req.manual_acreage:.2f} acres) differs from "
                    f"digitized polygon area ({polygon_acreage:.2f} acres) by {pct:.1f}%."
                )

        if req.id:
            existing = database.get_farm_by_id(req.id)
            if not existing or existing.get("owner_user_id") != current_user["id"]:
                raise HTTPException(status_code=404, detail="Farm profile not found")

        farm_record = {
            "id": req.id,
            "owner_user_id": current_user["id"],
            "farm_name": req.farm_name,
            "state_id": req.state_id,
            "district_id": req.district_id,
            "mandal_id": req.mandal_id,
            "village_id": req.village_id,
            "village_name": village_name,
            "village_lgd": village_lgd,
            "district_lgd": district_lgd,
            "mandal_lgd": mandal_lgd,
            "latitude": centroid["lat"],
            "longitude": centroid["lng"],
            "polygon_acreage": polygon_acreage,
            "manual_acreage": req.manual_acreage,
            "effective_acreage": req.manual_acreage if (req.manual_acreage and req.manual_acreage > 0) else polygon_acreage,
            "acreage_discrepancy_warning": discrepancy_warning,
            "boundary_geojson": req.boundary_geojson
        }

        saved = database.save_farm(farm_record)
        return {
            "status": "saved",
            "farm": saved,
            "nasa_query_targets": {
                "power_point_query": {"lat": centroid["lat"], "lng": centroid["lng"]},
                "smap_area_query": {"bbox": analysis["bounding_box"], "polygon": geom},
                "gpm_area_query": {"bbox": analysis["bounding_box"], "polygon": geom}
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to save farm: {str(e)}")

@router.post("/alerts/evaluate", status_code=status.HTTP_201_CREATED)
def evaluate_farm_alerts(req: EvaluateFarmAlertsRequest, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """Evaluate explicitly supplied observations against transparent screening thresholds.

    This endpoint does not fetch forecasts or claim official warnings. The source and
    observation timestamp are retained so farmers can trace each advisory.
    """
    from datetime import datetime, timezone
    import uuid
    _ensure_farm_owner(req.farm_id, current_user)
    try:
        observed = datetime.fromisoformat(req.observed_at.replace("Z", "+00:00"))
    except ValueError:
        raise HTTPException(status_code=422, detail="observed_at must be an ISO-8601 date/time")
    if req.rainfall_24h_mm is None and req.max_temperature_c is None and req.soil_moisture_pct is None:
        raise HTTPException(status_code=422, detail="Provide at least one measured weather or soil observation")

    candidates = []
    rain = req.rainfall_24h_mm
    if rain is not None and rain >= 204.5:
        candidates.append(("extreme_rainfall", "critical", "Extremely heavy rainfall observation", f"Reported 24-hour rainfall is {rain:g} mm. Check field drainage, waterlogging and safe access.", rain, 204.5, "mm/24h"))
    elif rain is not None and rain >= 115.6:
        candidates.append(("very_heavy_rainfall", "high", "Very heavy rainfall observation", f"Reported 24-hour rainfall is {rain:g} mm. Inspect drainage and vulnerable crops.", rain, 115.6, "mm/24h"))
    elif rain is not None and rain >= 64.5:
        candidates.append(("heavy_rainfall", "moderate", "Heavy rainfall observation", f"Reported 24-hour rainfall is {rain:g} mm. Monitor field drainage and crop lodging.", rain, 64.5, "mm/24h"))
    if req.max_temperature_c is not None and req.max_temperature_c >= 40:
        candidates.append(("high_temperature", "high" if req.max_temperature_c >= 45 else "moderate", "High temperature observation", f"Reported maximum temperature is {req.max_temperature_c:g} °C. Check crop water needs and avoid heat exposure during field work.", req.max_temperature_c, 40.0, "°C"))
    if req.soil_moisture_pct is not None and req.soil_moisture_pct <= 10:
        candidates.append(("low_soil_moisture", "high", "Very low soil moisture observation", f"Reported soil moisture is {req.soil_moisture_pct:g}%. Inspect root-zone moisture and irrigation availability.", req.soil_moisture_pct, 10.0, "%"))
    elif req.soil_moisture_pct is not None and req.soil_moisture_pct <= 20:
        candidates.append(("low_soil_moisture", "moderate", "Low soil moisture observation", f"Reported soil moisture is {req.soil_moisture_pct:g}%. Check crop stress and irrigation needs.", req.soil_moisture_pct, 20.0, "%"))

    alerts = []
    now = datetime.now(timezone.utc).isoformat()
    for kind, severity, title, message, value, threshold, unit in candidates:
        alerts.append(database.create_farm_alert({
            "id": str(uuid.uuid4()), "owner_user_id": current_user["id"], "farm_id": req.farm_id,
            "alert_type": kind, "severity": severity, "title": title, "message": message,
            "observed_value": value, "threshold_value": threshold, "unit": unit,
            "source": req.source.strip(), "observed_at": observed.isoformat(), "created_at": now
        }))
    return {"status": "evaluated", "alerts_created": len(alerts), "alerts": alerts,
            "notice": "These are screening advisories based on supplied observations, not official forecasts or government warnings."}


@router.get("/alerts")
def list_alerts(farm_id: Optional[str] = Query(None), current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> List[Dict[str, Any]]:
    if farm_id:
        _ensure_farm_owner(farm_id, current_user)
    return database.list_farm_alerts(current_user["id"], farm_id)


@router.post("/alerts/{alert_id}/acknowledge")
def acknowledge_alert(alert_id: str, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, str]:
    alert = database.get_farm_alert(alert_id, current_user["id"])
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    database.acknowledge_farm_alert(alert_id, current_user["id"])
    return {"status": "acknowledged", "alert_id": alert_id}


class CropRotationRecordRequest(BaseModel):
    farm_id: str
    crop_name: str = Field(..., min_length=1, max_length=100)
    season: str = Field(..., pattern="^(Kharif|Rabi|Summer|Perennial)$")
    crop_year: int = Field(..., ge=2000, le=2100)
    planting_date: Optional[str] = None
    harvest_date: Optional[str] = None
    yield_value: Optional[float] = Field(None, ge=0)
    yield_unit: Optional[str] = Field(None, max_length=30)
    notes: Optional[str] = Field(None, max_length=2000)


@router.post("/farms/{farm_id}/rotation-history", status_code=201)
def add_rotation_history(farm_id: str, req: CropRotationRecordRequest, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    _ensure_farm_owner(farm_id, current_user)
    if req.farm_id != farm_id:
        raise HTTPException(status_code=400, detail="Farm ID mismatch")
    if req.planting_date and req.harvest_date and req.harvest_date < req.planting_date:
        raise HTTPException(status_code=422, detail="Harvest date cannot be before planting date")
    now = datetime.now(timezone.utc).isoformat()
    payload = req.model_dump()
    payload.update({"id": str(uuid.uuid4()), "owner_user_id": current_user["id"], "created_at": now, "updated_at": now})
    return database.create_rotation_record(payload)


@router.get("/farms/{farm_id}/rotation-history")
def get_rotation_history(farm_id: str, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> List[Dict[str, Any]]:
    _ensure_farm_owner(farm_id, current_user)
    return database.list_rotation_records(current_user["id"], farm_id)


@router.delete("/rotation-history/{record_id}")
def remove_rotation_history(record_id: str, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, str]:
    record = database.get_rotation_record(record_id, current_user["id"])
    if not record:
        raise HTTPException(status_code=404, detail="Crop history record not found")
    database.delete_rotation_record(record_id, current_user["id"])
    return {"status": "deleted", "record_id": record_id}


@router.get("/farms/{farm_id}/activity")
def get_farm_activity(farm_id: str, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> List[Dict[str, Any]]:
    _ensure_farm_owner(farm_id, current_user)
    return database.list_farm_activity(current_user["id"], farm_id)


@router.get("/farms")
def list_farms(current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> List[Dict[str, Any]]:
    """List only farms owned by the authenticated user."""
    return database.get_farms(owner_user_id=current_user["id"])

@router.get("/farms/{farm_id}")
def get_farm(farm_id: str, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """Retrieve a single farm profile."""
    farm = database.get_farm_by_id(farm_id)
    if not farm or farm.get("owner_user_id") != current_user["id"]:
        raise HTTPException(status_code=404, detail="Farm profile not found")
    return farm

@router.delete("/farms/{farm_id}")
def delete_farm_endpoint(farm_id: str, current_user: Dict[str, Any] = Depends(auth.get_current_user)) -> Dict[str, Any]:
    """Delete a farm profile."""
    farm = database.get_farm_by_id(farm_id)
    if not farm or farm.get("owner_user_id") != current_user["id"]:
        raise HTTPException(status_code=404, detail="Farm profile not found")
    success = database.delete_farm(farm_id)
    if not success:
        raise HTTPException(status_code=404, detail="Farm profile not found")
    return {"status": "deleted", "farm_id": farm_id}


@router.post("/earth-observation/ecostress-gracefo/search")
def search_ecostress_gracefo_endpoint(req: ECOSTRESSGRACEFOSearchRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> Dict[str, Any]:
    """Discover ECOSTRESS and GRACE/GRACE-FO granules at a farm coordinate."""
    try:
        return ecostress_gracefo_service.search(req.latitude, req.longitude, req.start_date, req.end_date, req.products, req.limit)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("NASA ECOSTRESS/GRACE-FO CMR search failed")
        raise HTTPException(status_code=502, detail="NASA CMR ECOSTRESS/GRACE-FO catalogue is unavailable") from exc


@router.post("/earth-observation/modis-viirs/search")
def search_modis_viirs_endpoint(req: MODISVIIRSSearchRequest, current_user: Optional[Dict[str, Any]] = Depends(auth.get_optional_current_user)) -> Dict[str, Any]:
    """Discover NASA MODIS and VIIRS granules intersecting a point and date range."""
    try:
        return modis_viirs_service.search(req.latitude, req.longitude, req.start_date, req.end_date, req.products, req.limit)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("NASA MODIS/VIIRS CMR search failed")
        raise HTTPException(status_code=502, detail="NASA CMR granule catalogue is unavailable") from exc
