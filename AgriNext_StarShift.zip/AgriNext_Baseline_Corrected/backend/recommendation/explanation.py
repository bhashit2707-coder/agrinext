"""
Evidence Trace and Traceability Generator for AgriNext.
Constructs rigorous, mathematically traceable explanations for each suitability score dimension:
- Water Suitability: NASA POWER precipitation, NASA SMAP soil moisture, NASA GPM rainfall.
- Climate Suitability: NASA POWER T2M, T2M_MAX, solar radiation, humidity vs ANGRAU heat sensitivity.
- Soil-Health Potential: Ground-truth soil profile and ANGRAU botanical family nutrient cycling.
- Local Suitability: ANGRAU crop calendars, local cultivation evidence, and irrigation feasibility.

Packages complete Evidence Trace objects formatted for immediate display and PDF audit report generation.
"""

from typing import Dict, Any, List, Optional

class EvidenceTraceGenerator:
    """Generates traceable, transparent agronomic explanations and evidence dossiers."""

    SPATIAL_LIMITATION_DISCLAIMER = (
        "Gridded satellite and reanalysis observations (NASA POWER ~50 km, NASA SMAP ~9 km, NASA GPM ~10 km) "
        "measure regional atmospheric and surface regimes across multi-kilometer cells. "
        "They characterize agro-climatic pressures and regional suitability, but do not directly measure "
        "the individual farm parcel's localized micro-topography, sub-surface aquifer yield, or tree-canopy shade."
    )

    SOIL_PROVENANCE_DISCLAIMER = (
        "NASA Earth observation satellites do not measure parcel-level soil fertility, chemical N-P-K concentrations, "
        "or soil pH. Soil health potential is derived strictly from farmer-declared laboratory test reports or "
        "verified district baselines from the Government of India Soil Health Card portal and ANGRAU agronomy."
    )

    NON_GUARANTEE_DISCLAIMER = (
        "AgriNext provides evidence-backed agronomic decision guidance to mitigate climate and soil degradation risks. "
        "Recommendations do not constitute guaranteed yield predictions or absolute soil improvement promises."
    )

    def build_strategy_evidence_trace(
        self,
        strategy_id: str,
        strategy_title: str,
        crop_sequence: List[Dict[str, Any]],
        individual_scores: Dict[str, float],
        overall_score: float,
        weights: Dict[str, float],
        water_meta: Dict[str, Any],
        climate_meta: Dict[str, Any],
        soil_meta: Dict[str, Any],
        local_meta: Dict[str, Any],
        dossier: Dict[str, Any],
        farmer_profile: Optional[Dict[str, Any]],
        completeness: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Constructs a comprehensive, traceable evidence trace object for a rotation strategy."""
        crop_names = [c.get("crop", c.get("crop_name", "Crop")) for c in crop_sequence]
        crops_str = " → ".join(crop_names)

        # 1. Water Dimension Trace: include only observations actually present in the dossier.
        water_evidence = []
        for item in dossier.get("evidence_items", []) or []:
            code = item.get("parameter_code")
            if code == "PRECTOTCORR" and item.get("actual_value") is not None:
                water_evidence.append({
                    "source": "NASA POWER Agroclimatology (Reanalysis)",
                    "parameter": "PRECTOTCORR",
                    "observed_value": item.get("actual_value"),
                    "unit": item.get("unit", "mm/year"),
                    "observation_period": item.get("observation_period", "Period supplied by NASA POWER")
                })
            elif (code == "GPM_3IMERGDF" or str(item.get("product_code", "")).startswith("GPM_3IMERGDF")) and item.get("actual_value") is not None:
                water_evidence.append({
                    "source": "NASA GPM IMERG V07 (Satellite Radar/Radiometer)",
                    "parameter": "GPM_3IMERGDF Precipitation",
                    "observed_value": item.get("actual_value"),
                    "unit": item.get("unit", "mm/year"),
                    "observation_period": item.get("observation_period", "Period supplied by NASA GPM")
                })

        swb = dossier.get("soil_water_balance") or {}
        if dossier.get("dataset_status", {}).get("nasa_smap", {}).get("connected") and swb.get("surface_moisture_m3_m3") is not None:
            water_evidence.append({
                "source": "NASA SMAP SPL3SMP_E V6 (L-Band Radiometer)",
                "parameter": "Surface Volumetric Soil Moisture (0-5 cm)",
                "observed_value": swb.get("surface_moisture_m3_m3"),
                "unit": "m^3/m^3",
                "observation_period": "Recent satellite pass (9 km EASE-Grid 2.0)"
            })

        water_explanation = (
            f"The rotation sequence ({crops_str}) demands an average of {water_meta.get('average_water_demand_mm')} mm of water. "
            f"Observed effective precipitation is {water_meta.get('effective_rainfall_mm')} mm. "
        )
        if water_meta.get("irrigation_buffer_mm", 0) > 0:
            water_explanation += (
                f"Assured irrigation ({farmer_profile.get('irrigation_source') if farmer_profile else 'irrigation'}) "
                f"provides an estimated {water_meta.get('irrigation_buffer_mm')} mm buffer, bringing total water availability "
                f"to {water_meta.get('total_water_supply_mm')} mm (supply-to-demand ratio: {water_meta.get('supply_to_demand_ratio')}). "
            )
        else:
            water_explanation += (
                f"Under rainfed conditions, the supply-to-demand ratio is {water_meta.get('supply_to_demand_ratio')}. "
            )

        if water_meta.get("smap_regime") != "not_available":
            water_explanation += (
                f"NASA SMAP surface soil moisture indicates a '{water_meta.get('smap_regime')}' regime; "
                f"drought-hardy components buffer against root-zone water stress."
            )
        else:
            water_explanation += (
                "NASA SMAP evidence is unavailable; no SMAP adjustment was applied to the water score."
            )

        # 2. Climate Dimension Trace
        climate_evidence = [
            {
                "source": "NASA POWER Agroclimatology",
                "parameter": "T2M (Air Temperature)",
                "observed_value": climate_meta.get("t2m_average_c"),
                "unit": "°C",
                "observation_period": "2-meter diurnal mean reanalysis"
            },
            {
                "source": "NASA POWER Agroclimatology",
                "parameter": "T2M_MAX (Maximum Daily Air Temperature)",
                "observed_value": climate_meta.get("t2m_max_c"),
                "unit": "°C",
                "observation_period": "Peak seasonal thermal envelope"
            }
        ]
        if climate_meta.get("solar_radiation_mj") is not None:
            climate_evidence.append({
                "source": "NASA POWER Agroclimatology",
                "parameter": "ALLSKY_SFC_SW_DWN (Solar Radiation)",
                "observed_value": climate_meta["solar_radiation_mj"],
                "unit": "MJ/m^2/day",
                "observation_period": "Surface solar insolation"
            })
        if climate_meta.get("relative_humidity_pct") is not None:
            climate_evidence.append({
                "source": "NASA POWER Agroclimatology",
                "parameter": "RH2M (Relative Humidity)",
                "observed_value": climate_meta["relative_humidity_pct"],
                "unit": "%",
                "observation_period": "2-meter atmospheric vapor content"
            })

        climate_explanation = (
            f"Observed NASA POWER peak temperature of {climate_meta.get('t2m_max_c')}°C was evaluated against documented "
            f"ANGRAU thermal limits for rotation crops ({', '.join([str(t) + '°C' for t in climate_meta.get('critical_temperatures_evaluated', [])])}). "
        )
        if climate_meta.get("heat_penalty_applied", 0) > 0:
            climate_explanation += (
                f"A thermal penalty of {climate_meta.get('heat_penalty_applied')} points was applied to buffer heat-sensitive flowering windows."
            )
        else:
            climate_explanation += (
                "Peak temperatures remain safely within the vegetative and reproductive comfort envelope of the selected sequence."
            )

        # 3. Soil-Health Dimension Trace
        soil_evidence = [
            {
                "source": f"Ground-Truth Soil ({farmer_profile.get('soil_source_type', 'farmer_measured') if farmer_profile else 'District Baseline'})",
                "parameter": "Soil Texture & Type",
                "observed_value": soil_meta.get("soil_texture_evaluated", "Red Sandy Loam"),
                "unit": "Textural classification",
                "observation_period": "Field soil test / Soil Health Card"
            },
            {
                "source": "ANGRAU / ICAR Botanical Taxonomy",
                "parameter": "Biological Nitrogen Fixation & Crop Family",
                "observed_value": f"{soil_meta.get('legume_count', 0)} Legume(s) in rotation (+{soil_meta.get('biological_nitrogen_credit_kg_ha', 0)} kg BNF/ha)",
                "unit": "kg N/ha biological credit",
                "observation_period": "ANGRAU Package of Practices (2023-24)"
            }
        ]
        if soil_meta.get("soil_ph_evaluated") is not None:
            soil_evidence.append({
                "source": "Ground-Truth Soil Test",
                "parameter": "Soil pH",
                "observed_value": soil_meta["soil_ph_evaluated"],
                "unit": "pH scale (0-14)",
                "observation_period": "Laboratory measurement"
            })

        soil_explanation = (
            f"Soil health score reflects ground-truth parcel texture '{soil_meta.get('soil_texture_evaluated')}' and integration of "
            f"{soil_meta.get('legume_count')} legume crop(s). Provides an estimated +{soil_meta.get('biological_nitrogen_credit_kg_ha')} kg/ha "
            f"of biological nitrogen fixation credit, alternating nutrient-depleting crops with nitrogen-fixing cover."
        )
        if soil_meta.get("monoculture_risk_detected"):
            soil_explanation += " Monoculture penalty applied due to consecutive same-family cultivation."
        else:
            soil_explanation += " Alternates botanical families to disrupt pathogen and nematode cycles as per ANGRAU agronomy."

        # 4. Local Agricultural Suitability Trace
        local_evidence = [
            {
                "source": "ANGRAU Vyavasaya Panchangam (2023-24)",
                "parameter": "Andhra Pradesh Regional Agro-Climatic Calendar",
                "observed_value": f"Season: {local_meta.get('calendar_season_evaluated', 'Kharif')}",
                "unit": "Crop duration & window",
                "observation_period": "State package of practices"
            },
            {
                "source": "Farmer Infrastructure Profile",
                "parameter": "Irrigation Source & Feasibility",
                "observed_value": local_meta.get("irrigation_source_evaluated", "Rainfed"),
                "unit": "Infrastructure class",
                "observation_period": "Direct farmer declaration"
            }
        ]

        local_explanation = (
            f"Aligns with Andhra Pradesh sowing calendar for {local_meta.get('calendar_season_evaluated')} under "
            f"'{local_meta.get('irrigation_source_evaluated')}' conditions. Crop maturity durations fit within local rainfed and rabi windows."
        )

        # Potential Risks Synthesis
        potential_risks = []
        if water_meta.get("supply_to_demand_ratio", 1.0) < 0.9 and "rainfed" in str(local_meta.get("irrigation_source_evaluated", "")).lower():
            potential_risks.append("Moisture stress risk during reproductive stage under prolonged rainfed dry spell")
        if climate_meta.get("heat_penalty_applied", 0) > 0:
            potential_risks.append(f"Heat sensitivity risk: Peak temperatures ({climate_meta.get('t2m_max_c')}°C) approach thermal limits")
        if soil_meta.get("monoculture_risk_detected"):
            potential_risks.append("Pest/pathogen carryover risk from repeating same botanical family in succession")
        if "rainfed" in str(local_meta.get("irrigation_source_evaluated", "")).lower() and len(crop_sequence) >= 3:
            potential_risks.append("Summer crop viability is strictly moisture-constrained without protective irrigation")

        if not potential_risks:
            potential_risks.append("Standard seasonal rainfall variability and market price fluctuations at harvest")

        # Trace Data Object
        return {
            "strategy_id": strategy_id,
            "strategy_title": strategy_title,
            "crop_sequence_summary": crops_str,
            "overall_score": overall_score,
            "weights": weights,
            "individual_scores": individual_scores,
            "dimensions": {
                "water_suitability": {
                    "score": individual_scores["water_suitability"],
                    "weight": weights["water"],
                    "weighted_contribution": round((individual_scores["water_suitability"] * weights["water"]) / 100.0, 2),
                    "supporting_evidence": water_evidence,
                    "derived_indicators": water_meta,
                    "traceable_explanation": water_explanation,
                    "data_limitations": self.SPATIAL_LIMITATION_DISCLAIMER
                },
                "climate_suitability": {
                    "score": individual_scores["climate_suitability"],
                    "weight": weights["climate"],
                    "weighted_contribution": round((individual_scores["climate_suitability"] * weights["climate"]) / 100.0, 2),
                    "supporting_evidence": climate_evidence,
                    "derived_indicators": climate_meta,
                    "traceable_explanation": climate_explanation,
                    "data_limitations": self.SPATIAL_LIMITATION_DISCLAIMER
                },
                "soil_health_potential": {
                    "score": individual_scores["soil_health_potential"],
                    "weight": weights["soil"],
                    "weighted_contribution": round((individual_scores["soil_health_potential"] * weights["soil"]) / 100.0, 2),
                    "supporting_evidence": soil_evidence,
                    "derived_indicators": soil_meta,
                    "traceable_explanation": soil_explanation,
                    "data_limitations": self.SOIL_PROVENANCE_DISCLAIMER
                },
                "local_agricultural_suitability": {
                    "score": individual_scores["local_agricultural_suitability"],
                    "weight": weights["local"],
                    "weighted_contribution": round((individual_scores["local_agricultural_suitability"] * weights["local"]) / 100.0, 2),
                    "supporting_evidence": local_evidence,
                    "derived_indicators": local_meta,
                    "traceable_explanation": local_explanation,
                    "data_limitations": "Local suitability assumes standard regional sowing dates and input accessibility."
                }
            },
            "evidence_completeness": completeness,
            "potential_risks": potential_risks,
            "data_limitations": [
                self.SPATIAL_LIMITATION_DISCLAIMER,
                self.SOIL_PROVENANCE_DISCLAIMER,
                self.NON_GUARANTEE_DISCLAIMER
            ]
        }
