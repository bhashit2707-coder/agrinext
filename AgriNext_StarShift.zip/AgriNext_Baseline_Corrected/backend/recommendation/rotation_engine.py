"""
Crop Rotation Engine for AgriNext.
Generates 3 distinct evidence-backed crop rotation strategies:
1. Maximum Climate Resilience
2. Soil Health & Nutrient Regeneration
3. Balanced Economic & Risk Diversification

Calculates transparent, normalized (0 to 100) scores for:
- Water suitability
- Soil-health potential
- Climate suitability
- Local agricultural suitability
- Overall weighted score

Attaches complete evidence traces, data limitations, potential risks, and completeness metrics.
"""

from typing import List, Dict, Any, Optional
import logging

from recommendation.scoring import RecommendationScorer
from recommendation.explanation import EvidenceTraceGenerator
from crop_knowledge.crop_service import CropKnowledgeService

logger = logging.getLogger("agrinext.rotation_engine")

class RotationEngine:
    """Core recommendation engine generating 3 evidence-grounded rotation strategies."""

    STRATEGY_ARCHETYPES = [
        {
            "id": "climate_resilient",
            "title": "Maximum Climate Resilience",
            "description": "Engineered for variable precipitation and moisture stress buffering using drought-hardy staples."
        },
        {
            "id": "soil_restoration",
            "title": "Soil Health & Nutrient Regeneration",
            "description": "Maximizes biological nitrogen fixation and organic matter replenishment through legume integration."
        },
        {
            "id": "economic_balanced",
            "title": "Balanced Economic & Risk Diversification",
            "description": "Balances cash crop revenue potential with staple food security and yield stability."
        }
    ]

    def __init__(self):
        self.scorer = RecommendationScorer()
        self.trace_generator = EvidenceTraceGenerator()
        self.crop_service = CropKnowledgeService()

    def get_supported_strategies(self) -> List[Dict[str, Any]]:
        """Returns the 3 core strategy archetypes."""
        return self.STRATEGY_ARCHETYPES

    def generate_recommendations(
        self,
        crops: List[Dict[str, Any]],
        crop_rules: List[Dict[str, Any]],
        dossier: Dict[str, Any],
        farmer_profile: Optional[Dict[str, Any]] = None,
        custom_weights: Optional[Dict[str, float]] = None
    ) -> Dict[str, Any]:
        """
        Generates 3 distinct multi-season crop rotation strategies with traceable
        water, climate, soil, and local scores derived from retrieved NASA observations
        and farmer ground truth.
        """
        # 1. Extract environmental indicators from dossier
        precip_info = dossier.get("precipitation_synthesis", {})
        swb_info = dossier.get("soil_water_balance", {})

        # Extract only real, finite environmental observations. Never substitute defaults.
        def valid_observation(value, evidence=None):
            numeric = (
                isinstance(value, (int, float))
                and not isinstance(value, bool)
                and value == value
                and abs(float(value)) != float("inf")
            )
            if not numeric:
                return False
            quality = (evidence or {}).get("missing_data_info") or {}
            valid_count = quality.get("valid_count")
            return valid_count is None or valid_count > 0

        evidence_items = dossier.get("evidence_items", []) or []
        gpm_rain = None
        power_rain = None
        t2m_avg = None
        t2m_max = None
        solar_mj = None
        humidity_pct = None

        precipitation_info = precip_info or {}
        if valid_observation(precipitation_info.get("gpm_satellite_annual_mm")):
            gpm_rain = float(precipitation_info["gpm_satellite_annual_mm"])
        if valid_observation(precipitation_info.get("power_reanalysis_annual_mm")):
            power_rain = float(precipitation_info["power_reanalysis_annual_mm"])

        for ev in evidence_items:
            code = ev.get("parameter_code", "")
            value = ev.get("actual_value")
            product_code = str(ev.get("product_code", ""))
            if code == "PRECTOTCORR" and valid_observation(value, ev):
                power_rain = float(value)
            elif (code == "GPM_3IMERGDF" or product_code.startswith("GPM_3IMERGDF")) and valid_observation(value, ev):
                gpm_rain = float(value)
            elif code == "T2M" and valid_observation(value, ev):
                stats = ev.get("statistics") or {}
                mean_value = stats.get("mean_c", value)
                max_value = stats.get("extreme_max_c")
                if valid_observation(mean_value, ev):
                    t2m_avg = float(mean_value)
                if valid_observation(max_value, ev):
                    t2m_max = float(max_value)
            elif code == "T2M_MAX" and valid_observation(value, ev):
                t2m_max = float(value)
            elif code == "ALLSKY_SFC_SW_DWN" and valid_observation(value, ev):
                solar_mj = float(value)
            elif code == "RH2M" and valid_observation(value, ev):
                humidity_pct = float(value)

        # GPM is preferred when a valid annual total is available; POWER is the fallback.
        effective_rain = gpm_rain if gpm_rain is not None else power_rain
        missing_inputs = []
        if effective_rain is None:
            missing_inputs.append("annual precipitation (NASA GPM or NASA POWER PRECTOTCORR)")
        if t2m_avg is None:
            missing_inputs.append("NASA POWER mean 2 m air temperature (T2M)")
        if t2m_max is None:
            missing_inputs.append("NASA POWER maximum 2 m air temperature (T2M statistics.extreme_max_c or T2M_MAX)")
        if missing_inputs:
            raise ValueError(
                "Cannot generate evidence-backed crop recommendations. Missing valid environmental observations: "
                + "; ".join(missing_inputs)
                + ". Check NASA POWER/GPM availability and retry after data retrieval succeeds."
            )

        effective_rain = float(effective_rain)
        smap_status = dossier.get("dataset_status", {}).get("nasa_smap", {}).get("connected", False)
        smap_moisture = swb_info.get("surface_moisture_m3_m3") if smap_status and swb_info else None
        smap_regime = swb_info.get("regime") if smap_status and swb_info else None
        smap_trend = swb_info.get("trend") if smap_status and swb_info else None

        # Farmer profile inputs
        irrigation_source = farmer_profile.get("irrigation_source", "Rainfed") if farmer_profile else "Rainfed"
        farming_season = farmer_profile.get("farming_season", "Kharif") if farmer_profile else "Kharif"
        previous_crops = farmer_profile.get("previous_crops", []) if farmer_profile else []
        is_rainfed = "rainfed" in irrigation_source.lower()

        # Evidence Completeness
        completeness = self.scorer.compute_evidence_completeness(dossier, farmer_profile)

        # 2. Enrich crop list with verified crop profiles
        enriched_crops = []
        for c in crops:
            cid = c.get("id", "").lower()
            prof = self.crop_service.get_crop_by_id(cid)
            merged = dict(c)
            if prof:
                merged["crop_family"] = prof.get("crop_family", merged.get("crop_family", "Unknown"))
                merged["telugu_name"] = prof.get("telugu_name", merged.get("telugu_name"))
                merged["soil_suitability"] = prof.get("soil_suitability", merged.get("soil_suitability", {}))
                merged["nutrient_requirements"] = prof.get("nutrient_requirements", merged.get("nutrient_requirements", {}))
                merged["heat_sensitivity"] = prof.get("heat_sensitivity", merged.get("heat_sensitivity", {}))
                merged["water_stress_sensitivity"] = prof.get("water_stress_sensitivity", merged.get("water_stress_sensitivity", {}))
                merged["rotation_compatibility"] = prof.get("rotation_compatibility", merged.get("rotation_compatibility", {}))
            enriched_crops.append(merged)

        # Categorize crops
        pulses = [c for c in enriched_crops if "pulse" in c.get("category", "").lower() or c.get("nitrogen_impact") == "fixing"]
        cereals = [c for c in enriched_crops if "cereal" in c.get("category", "").lower() or "millet" in c.get("category", "").lower()]
        commercial = [c for c in enriched_crops if any(cat in c.get("category", "").lower() for cat in ["oilseed", "commercial", "cash", "fiber", "spice"])]

        # Fallback safety if catalogs are sparse
        if not pulses:
            pulses = [c for c in enriched_crops if c.get("id") in ["bengal_gram", "red_gram", "green_gram", "black_gram", "groundnut"]]
        if not cereals:
            cereals = [c for c in enriched_crops if c.get("id") in ["sorghum", "maize", "pearl_millet", "paddy"]]
        if not commercial:
            commercial = [c for c in enriched_crops if c.get("id") in ["groundnut", "cotton", "chilli"]]

        # 3. Assemble Strategy Archetypes
        strategies_output = []

        # Archetype 1: Maximum Climate Resilience
        c1_kharif = next((c for c in commercial if c.get("drought_tolerance") == "high"), commercial[0] if commercial else enriched_crops[0])
        c1_rabi = next((c for c in pulses if c.get("drought_tolerance") == "high"), pulses[0] if pulses else enriched_crops[1])
        c1_summer = (
            {"id": "fallow_green_manure", "name": "Fallow / Sesbania Green Manure", "category": "Green Manure Cover", "water_requirement_mm": [100, 200], "crop_family": "Fabaceae", "drought_tolerance": "high", "nitrogen_impact": "fixing"}
            if is_rainfed else
            next((c for c in pulses if "green_gram" in c.get("id", "") or "black_gram" in c.get("id", "")), pulses[0] if pulses else enriched_crops[0])
        )
        s1_crops = [c1_kharif, c1_rabi, c1_summer]
        s1_weights = custom_weights or self.scorer.ARCHETYPE_WEIGHTS["climate_resilient"]

        # Archetype 2: Soil Health & Nutrient Regeneration
        c2_kharif = next((c for c in cereals if c.get("id") in ["sorghum", "maize", "pearl_millet"]), cereals[0] if cereals else enriched_crops[0])
        c2_rabi = next((c for c in pulses if c.get("id") in ["bengal_gram", "red_gram", "black_gram"]), pulses[0] if pulses else enriched_crops[1])
        c2_summer = next((c for c in pulses if c.get("id") in ["green_gram", "cowpea"]), pulses[0] if pulses else enriched_crops[0])
        s2_crops = [c2_kharif, c2_rabi, c2_summer]
        s2_weights = custom_weights or self.scorer.ARCHETYPE_WEIGHTS["soil_restoration"]

        # Archetype 3: Balanced Economic & Risk Diversification
        c3_kharif = next((c for c in commercial if c.get("id") in ["cotton", "groundnut", "chilli"]), commercial[0] if commercial else enriched_crops[0])
        c3_rabi = next((c for c in cereals if c.get("id") in ["sorghum", "maize"]), cereals[0] if cereals else (pulses[0] if pulses else enriched_crops[1]))
        c3_summer = next((c for c in pulses if c.get("id") in ["green_gram", "bengal_gram"]), pulses[0] if pulses else enriched_crops[0])
        s3_crops = [c3_kharif, c3_rabi, c3_summer]
        s3_weights = custom_weights or self.scorer.ARCHETYPE_WEIGHTS["economic_balanced"]

        archetype_configs = [
            ("climate_resilient", "Maximum Climate Resilience", s1_crops, s1_weights, [
                {"season": "Kharif (Monsoon)", "crop": c1_kharif.get("name", "Groundnut"), "role": "Drought-hardy anchor cash crop with low water index"},
                {"season": "Rabi (Winter)", "crop": c1_rabi.get("name", "Bengal Gram"), "role": "Utilizes residual post-monsoon soil moisture + biological N fixation"},
                {"season": "Summer (Zaid)", "crop": c1_summer.get("name", "Fallow / Green Manure"), "role": "Prevents soil erosion and conserves deep soil moisture"}
            ]),
            ("soil_restoration", "Soil Health & Nutrient Regeneration", s2_crops, s2_weights, [
                {"season": "Kharif (Monsoon)", "crop": c2_kharif.get("name", "Sorghum"), "role": "High-biomass nutrient scavenger and organic carbon replenisher"},
                {"season": "Rabi (Winter)", "crop": c2_rabi.get("name", "Bengal Gram"), "role": "Biological nitrogen fixation (+35 kg N/ha biological credit)"},
                {"season": "Summer (Zaid)", "crop": c2_summer.get("name", "Green Gram"), "role": "Quick-maturing pulse catch crop for soil biological activity"}
            ]),
            ("economic_balanced", "Balanced Economic & Risk Diversification", s3_crops, s3_weights, [
                {"season": "Kharif (Monsoon)", "crop": c3_kharif.get("name", "Cotton / Groundnut"), "role": "Primary commercial revenue generator for household cash flow"},
                {"season": "Rabi (Winter)", "crop": c3_rabi.get("name", "Sorghum / Bengal Gram"), "role": "Household food security and dry-season livestock fodder"},
                {"season": "Summer (Zaid)", "crop": c3_summer.get("name", "Green Gram / Catch Pulse"), "role": "Liquidity catch crop buffer with low market volatility"}
            ])
        ]

        for strat_id, strat_title, crop_list, weights, seq in archetype_configs:
            # 1. Water suitability
            w_score, w_meta = self.scorer.compute_water_suitability(
                crops=crop_list,
                effective_annual_rainfall_mm=effective_rain,
                smap_soil_moisture=smap_moisture,
                smap_regime=smap_regime,
                smap_trend=smap_trend,
                irrigation_source=irrigation_source
            )

            # 2. Climate suitability
            c_score, c_meta = self.scorer.compute_climate_suitability(
                crops=crop_list,
                t2m_avg=t2m_avg,
                t2m_max=t2m_max,
                solar_radiation_mj=solar_mj,
                relative_humidity_pct=humidity_pct
            )

            # 3. Soil health potential
            s_score, s_meta = self.scorer.compute_soil_health_potential(
                crops=crop_list,
                farmer_profile=farmer_profile,
                previous_crops=previous_crops
            )

            # 4. Local agricultural suitability
            l_score, l_meta = self.scorer.compute_local_suitability(
                crops=crop_list,
                farmer_profile=farmer_profile,
                target_season=farming_season
            )

            # 5. Overall score
            overall, validated_weights = self.scorer.compute_overall_score(
                water_score=w_score,
                soil_score=s_score,
                climate_score=c_score,
                local_score=l_score,
                weights=weights
            )

            indiv_scores = {
                "water_suitability": w_score,
                "soil_health_potential": s_score,
                "climate_suitability": c_score,
                "local_agricultural_suitability": l_score
            }

            # 6. Build Evidence Trace
            trace = self.trace_generator.build_strategy_evidence_trace(
                strategy_id=strat_id,
                strategy_title=strat_title,
                crop_sequence=seq,
                individual_scores=indiv_scores,
                overall_score=overall,
                weights=validated_weights,
                water_meta=w_meta,
                climate_meta=c_meta,
                soil_meta=s_meta,
                local_meta=l_meta,
                dossier=dossier,
                farmer_profile=farmer_profile,
                completeness=completeness
            )

            strategy_record = {
                "id": strat_id,
                "title": strat_title,
                "description": next((a["description"] for a in self.STRATEGY_ARCHETYPES if a["id"] == strat_id), ""),
                "crop_sequence": seq,
                "rotation": seq,  # alias for backwards compatibility
                "season": farming_season,
                "individual_scores": indiv_scores,
                "overall_score": overall,
                "weights": validated_weights,
                "supporting_nasa_evidence": trace["dimensions"]["water_suitability"]["supporting_evidence"] + trace["dimensions"]["climate_suitability"]["supporting_evidence"],
                "supporting_local_evidence": trace["dimensions"]["soil_health_potential"]["supporting_evidence"] + trace["dimensions"]["local_agricultural_suitability"]["supporting_evidence"],
                "explanation": trace["dimensions"]["water_suitability"]["traceable_explanation"] + " " + trace["dimensions"]["soil_health_potential"]["traceable_explanation"],
                "environmental_rationale": trace["dimensions"]["water_suitability"]["traceable_explanation"], # alias
                "potential_risks": trace["potential_risks"],
                "data_limitations": trace["data_limitations"],
                "evidence_completeness": completeness,
                "evidence_trace": trace
            }
            strategies_output.append(strategy_record)

        # 4. Rank and explain strategies based on farmer priority weights
        applied_w = custom_weights or self.scorer.DEFAULT_WEIGHTS
        ranked_strategies = self.scorer.rank_and_explain_strategies(
            strategies=strategies_output,
            updated_weights=applied_w,
            baseline_weights=self.scorer.DEFAULT_WEIGHTS
        )

        # 5. Individual crop evaluations
        evaluated_crops = self._evaluate_individual_crops(
            crops=enriched_crops,
            effective_rain=effective_rain,
            smap_status=smap_status,
            swb_info=swb_info,
            t2m_max=t2m_max,
            farmer_profile=farmer_profile
        )

        b_weights = self.scorer.DEFAULT_WEIGHTS
        u_weights = self.scorer.validate_weights(applied_w)

        return {
            "dossier_id": dossier.get("dossier_id", "UNIFIED_EVIDENCE_DOSSIER"),
            "evaluated_crops": evaluated_crops,
            "strategies": ranked_strategies,
            "applied_weights": u_weights,
            "baseline_weights": b_weights,
            "ranking_comparison": {
                "baseline_weights": b_weights,
                "applied_weights": u_weights,
                "rankings": [
                    {
                        "strategy_id": s["id"],
                        "title": s["title"],
                        "baseline_rank": s["baseline_rank"],
                        "baseline_score": s["baseline_score"],
                        "updated_rank": s["updated_rank"],
                        "updated_score": s["overall_score"],
                        "rank_change": s["rank_change"],
                        "movement_direction": s["movement_direction"],
                        "movement_explanation": s["movement_explanation"]
                    }
                    for s in ranked_strategies
                ]
            },
            "provenance_summary": {
                "datasets_utilized": completeness["connected_sources"],
                "datasets_missing_or_unauthenticated": completeness["missing_sources"],
                "evidence_completeness_pct": completeness["percentage"],
                "farmer_soil_data_source": farmer_profile.get("soil_source_type", "unspecified") if farmer_profile else "none_provided",
                "agricultural_knowledge_authority": "ANGRAU Vyavasaya Panchangam (2023-24) & ICAR-CRIDA"
            }
        }

    def recalculate_scores(
        self,
        strategies: List[Dict[str, Any]],
        weights: Dict[str, float],
        baseline_weights: Optional[Dict[str, float]] = None
    ) -> Dict[str, Any]:
        """
        Immediately recalculates overall scores and re-ranks all 3 strategies when priority weights change.
        Strictly re-evaluates the actual scoring formula without fabricated data.
        """
        b_weights = self.scorer.validate_weights(baseline_weights or self.scorer.DEFAULT_WEIGHTS)
        u_weights = self.scorer.validate_weights(weights)

        recalculated_strategies = self.scorer.rank_and_explain_strategies(
            strategies=strategies,
            updated_weights=u_weights,
            baseline_weights=b_weights
        )

        return {
            "strategies": recalculated_strategies,
            "applied_weights": u_weights,
            "baseline_weights": b_weights,
            "ranking_comparison": {
                "baseline_weights": b_weights,
                "applied_weights": u_weights,
                "rankings": [
                    {
                        "strategy_id": s["id"],
                        "title": s["title"],
                        "baseline_rank": s["baseline_rank"],
                        "baseline_score": s["baseline_score"],
                        "updated_rank": s["updated_rank"],
                        "updated_score": s["overall_score"],
                        "rank_change": s["rank_change"],
                        "movement_direction": s["movement_direction"],
                        "movement_explanation": s["movement_explanation"]
                    }
                    for s in recalculated_strategies
                ]
            }
        }

    def _evaluate_individual_crops(
        self,
        crops: List[Dict[str, Any]],
        effective_rain: float,
        smap_status: bool,
        swb_info: Dict[str, Any],
        t2m_max: float,
        farmer_profile: Optional[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Evaluates individual crop suitability against NASA observations, soil ground truth, and ANGRAU agronomy."""
        evaluated = []
        farmer_soil = (farmer_profile.get("soil_type", "") if farmer_profile else "") or ""
        farmer_ph = farmer_profile.get("soil_ph") if farmer_profile else None
        farmer_irrigation = farmer_profile.get("irrigation_source", "Rainfed") if farmer_profile else "Rainfed"
        farmer_current = farmer_profile.get("current_crop") if farmer_profile else None
        farmer_prev = farmer_profile.get("previous_crops", []) if farmer_profile else []

        for crop in crops:
            crop_id = crop.get("id", "").lower()
            base_score = 75.0
            citations = []

            # 1. NASA Rainfall vs Water Demand
            water_req = crop.get("water_requirement_mm", [450, 650])
            mid_req = (water_req[0] + water_req[1]) / 2.0 if isinstance(water_req, (list, tuple)) else 550.0

            if effective_rain < water_req[0]:
                deficit = water_req[0] - effective_rain
                penalty = min(25.0, (deficit / 100.0) * 8.0)
                base_score -= penalty
                citations.append(
                    f"[NASA Observation] Rainfall ({effective_rain:.1f} mm) is below minimum crop water requirement ({water_req[0]} mm) by {deficit:.1f} mm."
                )
            else:
                base_score += 8.0
                citations.append(
                    f"[NASA Observation] Rainfall ({effective_rain:.1f} mm) safely meets baseline requirement ({water_req[0]}-{water_req[1]} mm)."
                )

            # 2. NASA SMAP Surface Soil Moisture
            if smap_status and swb_info:
                regime = swb_info.get("regime")
                moisture = swb_info.get("surface_moisture_m3_m3")
                drought_tol = crop.get("drought_tolerance", "moderate").lower()

                # Do not manufacture a satellite observation when the value is absent.
                if not isinstance(moisture, (int, float)) or isinstance(moisture, bool) or not 0.0 <= float(moisture) <= 1.0:
                    citations.append(
                        "[NASA Observation] SMAP retrieval is connected, but no valid surface-moisture value is available; no SMAP crop adjustment was applied."
                    )
                else:
                    # Match the scoring service's project thresholds and scale crop-level
                    # adjustments by measured moisture severity rather than a binary label.
                    measured_moisture = float(moisture)
                    if measured_moisture < 0.12:
                        regime = "deficit"
                        severity = min(1.0, (0.12 - measured_moisture) / 0.12)
                        if drought_tol == "high":
                            base_score += 18.0 * severity
                            citations.append(
                                f"[NASA Observation] NASA SMAP V6 surface soil moisture ({measured_moisture:.3f} m³/m³) indicates deficit "
                                f"(severity {severity:.2f}); {crop.get('name')} receives a drought-tolerance adjustment."
                            )
                        else:
                            base_score -= 22.0 * severity
                            citations.append(
                                f"[NASA Observation] NASA SMAP V6 surface moisture ({measured_moisture:.3f} m³/m³) indicates deficit "
                                f"(severity {severity:.2f}); {crop.get('name')} receives a moisture-stress penalty."
                            )
                    elif measured_moisture > 0.25:
                        regime = "surplus"
                        severity = min(1.0, (measured_moisture - 0.25) / 0.25)
                        if crop.get("flood_tolerance", "").lower() == "high":
                            base_score += 12.0 * severity
                            citations.append(f"[NASA Observation] SMAP surplus moisture ({measured_moisture:.3f} m³/m³; severity {severity:.2f}) favors flood-tolerant {crop.get('name')}.")
                        elif crop.get("flood_tolerance", "").lower() == "low":
                            base_score -= 15.0 * severity
                            citations.append(f"[NASA Observation] SMAP surplus moisture ({measured_moisture:.3f} m³/m³; severity {severity:.2f}) raises waterlogging risk for {crop.get('name')}.")
                    else:
                        regime = "adequate"
            else:
                citations.append(
                    "[NASA Observation] SMAP soil moisture not connected (NASA Earthdata login required). Climatological normal utilized."
                )

            # 3. NASA POWER Heat Stress
            heat_sens = crop.get("heat_sensitivity", {})
            crit_t = heat_sens.get("critical_temperature_celsius", 38.0) if isinstance(heat_sens, dict) else 38.0
            crit_t = crit_t or 38.0
            if t2m_max > crit_t:
                heat_pen = min(18.0, (t2m_max - crit_t) * 4.0)
                base_score -= heat_pen
                citations.append(
                    f"[NASA Observation] NASA POWER T2M_MAX ({t2m_max:.1f}°C) exceeds ANGRAU critical thermal threshold ({crit_t:.1f}°C): Heat stress risk."
                )

            # 4. Farmer Soil Ground-Truth
            soil_suit = crop.get("soil_suitability", {})
            if isinstance(soil_suit, dict) and farmer_soil:
                suitable_types = [s.lower() for s in soil_suit.get("suitable_soil_types", [])]
                unsuitable_types = [s.lower() for s in soil_suit.get("unsuitable_soil_types", [])]
                fs_lower = farmer_soil.lower()

                if any(fs_lower in s or s in fs_lower for s in suitable_types):
                    base_score += 12.0
                    citations.append(f"[Farmer Ground-Truth Soil] '{farmer_soil}' matches optimal soil classification.")
                elif any(fs_lower in s or s in fs_lower for s in unsuitable_types):
                    base_score -= 22.0
                    citations.append(f"[Farmer Ground-Truth Soil] Warning: '{farmer_soil}' is unsuitable ({soil_suit.get('drainage_requirement')}).")

            if isinstance(soil_suit, dict) and farmer_ph is not None and soil_suit.get("optimal_ph_range"):
                rng = soil_suit["optimal_ph_range"]
                if rng[0] <= farmer_ph <= rng[1]:
                    base_score += 5.0
                    citations.append(f"[Farmer Ground-Truth Soil] Measured pH {farmer_ph} is within optimal range ({rng[0]} - {rng[1]}).")
                else:
                    base_score -= 10.0
                    citations.append(f"[Farmer Ground-Truth Soil] Measured pH {farmer_ph} falls outside optimal range ({rng[0]} - {rng[1]}).")

            # 5. Irrigation constraint
            if "rainfed" in farmer_irrigation.lower():
                if water_req[0] > 750 and effective_rain < 750:
                    base_score -= 30.0
                    citations.append(f"[Farmer Ground-Truth Inputs] Strictly Rainfed: High water demand ({water_req[0]} mm) poses drought risk.")
                elif crop.get("drought_tolerance", "").lower() == "high":
                    base_score += 10.0
                    citations.append(f"[Farmer Ground-Truth Inputs] Rainfed farming aligns well with drought-tolerant {crop.get('name')}.")
            else:
                base_score += 8.0
                citations.append(f"[Farmer Ground-Truth Inputs] Assured irrigation via {farmer_irrigation} mitigates rainfall deficits.")

            # 6. ANGRAU Rotation Compatibility
            last_crop = farmer_current or (farmer_prev[-1] if farmer_prev else None)
            if last_crop:
                rot_eval = self.crop_service.evaluate_rotation_compatibility(last_crop, crop_id)
                base_score *= rot_eval.get("score_multiplier", 1.0)
                citations.append(f"[ANGRAU Crop Knowledge] {rot_eval.get('rationale')}")

            final_score = max(5.0, min(99.0, round(base_score, 1)))
            evaluated.append({
                "crop_id": crop_id,
                "crop_name": crop.get("name"),
                "telugu_name": crop.get("telugu_name"),
                "crop_family": crop.get("crop_family", "Unknown"),
                "category": crop.get("category"),
                "suitability_score": final_score,
                "season": crop.get("season", []),
                "nitrogen_impact": crop.get("nitrogen_impact"),
                "drought_tolerance": crop.get("drought_tolerance"),
                "water_requirement_mm": water_req,
                "evidence_citations": citations
            })

        evaluated.sort(key=lambda x: x["suitability_score"], reverse=True)
        return evaluated
