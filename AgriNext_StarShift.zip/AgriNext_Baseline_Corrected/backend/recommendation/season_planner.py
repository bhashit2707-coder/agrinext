"""Catalog-driven seasonal crop planning for Kharif, Rabi and Summer.

This module filters crops using their declared season metadata. It does not
invent summer crops or claim yield/economic forecasts where catalog data is absent.
"""
from typing import Any, Dict, List, Optional

SEASONS = [
    {"id": "Kharif", "months": "June–October", "window": [6, 7, 8, 9, 10]},
    {"id": "Rabi", "months": "November–March", "window": [11, 12, 1, 2, 3]},
    {"id": "Summer", "months": "March–May", "window": [3, 4, 5]},
]


def build_multi_season_plan(crops: List[Dict[str, Any]], farmer_profile: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Build transparent seasonal crop options from the state crop catalogue."""
    profile = farmer_profile or {}
    soil_type = str(profile.get("soil_type") or "").strip().lower()
    previous = profile.get("previous_crops") or []
    previous_ids = {str(item).strip().lower().replace(" ", "_") for item in previous if item}
    current = str(profile.get("current_crop") or "").strip().lower().replace(" ", "_")
    excluded = previous_ids | ({current} if current else set())

    season_plans = []
    for season in SEASONS:
        candidates = []
        for crop in crops:
            declared_seasons = crop.get("season") or []
            if season["id"].lower() not in {str(s).lower() for s in declared_seasons}:
                continue
            crop_id = str(crop.get("id") or "").lower()
            if crop_id in excluded:
                continue
            soil_types = [str(s).lower() for s in crop.get("soil_type_suitability") or []]
            soil_match = bool(soil_type and any(soil_type in allowed or allowed in soil_type for allowed in soil_types))
            water = crop.get("water_requirement_mm") or []
            water_range = {"minimum_mm": water[0], "maximum_mm": water[1]} if isinstance(water, list) and len(water) >= 2 else None
            candidates.append({
                "crop_id": crop_id,
                "crop_name": crop.get("name", crop_id.replace("_", " ").title()),
                "telugu_name": crop.get("telugu_name"),
                "crop_family": crop.get("crop_family") or crop.get("category"),
                "nitrogen_impact": crop.get("nitrogen_impact"),
                "growth_days": crop.get("growth_days"),
                "water_requirement_mm": water_range,
                "soil_type_match": soil_match if soil_type else None,
                "selection_basis": "Declared crop-season compatibility in the state catalogue",
            })
        # Put soil-compatible options first when a soil type is supplied; preserve stable order otherwise.
        if soil_type:
            candidates.sort(key=lambda item: (not bool(item["soil_type_match"]), item["crop_name"]))
        season_plans.append({
            **season,
            "status": "options_available" if candidates else "no_catalog_options",
            "candidate_count": len(candidates),
            "candidates": candidates,
            "message": ("Options are filtered from the state crop catalogue. Confirm local sowing windows, water access and current ANGRAU/ICAR advisories before planting." if candidates else "No crops in the current state catalogue are declared for this season. No crop has been invented or substituted."),
        })

    return {
        "status": "generated",
        "planning_horizon": "Annual seasonal planning cycle",
        "seasons": season_plans,
        "excluded_recent_crops": sorted(excluded),
        "method": "Season eligibility is taken from each crop's season field in the state catalogue; soil matches are descriptive filters, not validated suitability scores.",
        "limitations": [
            "This planner provides catalogue-based options, not a field-specific agronomic prescription.",
            "It does not forecast yield, market price, profitability or irrigation demand.",
            "The current Andhra Pradesh catalogue has no crop entries explicitly tagged Summer; that season is shown as unavailable until verified crop-calendar data is added.",
            "Farmers should confirm district-specific sowing dates and crop duration with local agricultural extension officers.",
        ],
    }
