"""
AgriNext Recommendation Engine Package.
Adheres strictly to the Critical Design Principle:
NASA data is used directly as evidence in recommendation calculations,
with complete provenance and traceability.
"""
