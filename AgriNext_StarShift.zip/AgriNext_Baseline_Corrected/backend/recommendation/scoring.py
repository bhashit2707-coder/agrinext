"""
Multi-Dimensional Scoring Service for AgriNext.
Calculates normalized (0 to 100) suitability scores across 4 key agronomic dimensions:
1. Water Suitability Score (S_water)
2. Soil-Health Potential Score (S_soil)
3. Climate Suitability Score (S_climate)
4. Local Agricultural Suitability Score (S_local)

Follows documented, explainable transformation rules:
Overall = (Water * Water_Weight + Soil * Soil_Weight + Climate * Climate_Weight + Local * Local_Weight) / 100
Weights must total 100.
"""

from typing import Dict, Any, List, Optional, Tuple
import logging
import math

from nasa.smap import SOIL_MOISTURE_MIN_M3_M3, SOIL_MOISTURE_MAX_M3_M3

logger = logging.getLogger("agrinext.scoring")

class RecommendationScorer:
    """Calculates explainable, evidence-backed crop suitability and rotation scores."""

    DEFAULT_WEIGHTS = {
        "water": 25.0,
        "soil": 25.0,
        "climate": 25.0,
        "local": 25.0
    }

    # Archetype default weight biases reflecting their strategic goals
    ARCHETYPE_WEIGHTS = {
        "climate_resilient": {"water": 35.0, "climate": 35.0, "soil": 15.0, "local": 15.0},
        "soil_restoration": {"water": 15.0, "climate": 15.0, "soil": 50.0, "local": 20.0},
        "economic_balanced": {"water": 25.0, "climate": 20.0, "soil": 25.0, "local": 30.0}
    }

    DIMENSION_MAPPING = {
        "water": "water_suitability",
        "soil": "soil_health_potential",
        "climate": "climate_suitability",
        "local": "local_agricultural_suitability"
    }

    DIMENSION_NAMES = {
        "water": "Water Efficiency",
        "soil": "Soil-Health Potential",
        "climate": "Climate Resilience",
        "local": "Local Agricultural Suitability"
    }

    @staticmethod
    def validate_weights(weights: Dict[str, float]) -> Dict[str, float]:
        """Validates that weights sum to 100 within a tiny float tolerance, or normalizes them."""
        required_keys = ["water", "soil", "climate", "local"]
        cleaned = {k: float(weights.get(k, 25.0)) for k in required_keys}
        total = sum(cleaned.values())
        if abs(total - 100.0) > 0.05:
            # Normalize to 100
            if total > 0:
                cleaned = {k: round((v / total) * 100.0, 2) for k, v in cleaned.items()}
            else:
                cleaned = {"water": 25.0, "soil": 25.0, "climate": 25.0, "local": 25.0}
        return cleaned

    def compute_water_suitability(
        self,
        crops: List[Dict[str, Any]],
        effective_annual_rainfall_mm: float,
        smap_soil_moisture: Optional[float] = None,
        smap_regime: Optional[str] = None,
        smap_trend: Optional[str] = None,
        irrigation_source: str = "Rainfed"
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Calculates Water Suitability Score (0 to 100).
        Evaluates cumulative crop water demand against effective precipitation and irrigation buffer,
        modulated by NASA SMAP surface soil moisture regime and crop drought tolerance.
        """
        # Reject invalid rainfall rather than silently scoring it as a severe deficit.
        if (isinstance(effective_annual_rainfall_mm, bool)
                or not isinstance(effective_annual_rainfall_mm, (int, float))
                or not math.isfinite(float(effective_annual_rainfall_mm))
                or float(effective_annual_rainfall_mm) < 0):
            raise ValueError("effective_annual_rainfall_mm must be a finite, non-negative number")

        validation_notes = []
        if irrigation_source is None or not isinstance(irrigation_source, str):
            irrigation_source = ""
            validation_notes.append("Irrigation source unavailable; no irrigation buffer was applied.")

        # 1. Calculate weighted average water requirement of rotation crops
        demands = []
        drought_tolerances = []
        flood_tolerances = []

        for crop in crops:
            req = crop.get("water_requirement_mm", [450, 700])
            mid_req = (req[0] + req[1]) / 2.0 if isinstance(req, (list, tuple)) and len(req) >= 2 else 550.0
            demands.append(mid_req)
            drought = crop.get("drought_tolerance")
            flood = crop.get("flood_tolerance")
            if not isinstance(drought, str) or not drought.strip():
                drought = "moderate"
                validation_notes.append("Missing drought tolerance treated as moderate.")
            if not isinstance(flood, str) or not flood.strip():
                flood = "low"
                validation_notes.append("Missing flood tolerance treated as low.")
            drought_tolerances.append(drought.lower())
            flood_tolerances.append(flood.lower())

        avg_demand = sum(demands) / len(demands) if demands else 550.0

        # 2. Irrigation buffer calculation
        irrigation_buffer_mm = 0.0
        irr_lower = irrigation_source.lower()
        if "borewell" in irr_lower or "well" in irr_lower:
            irrigation_buffer_mm = 400.0
        elif "canal" in irr_lower:
            irrigation_buffer_mm = 500.0
        elif "drip" in irr_lower:
            irrigation_buffer_mm = 350.0
        elif "sprinkler" in irr_lower:
            irrigation_buffer_mm = 300.0
        elif "pond" in irr_lower or "tank" in irr_lower:
            irrigation_buffer_mm = 200.0

        total_water_supply = effective_annual_rainfall_mm + irrigation_buffer_mm
        ratio = total_water_supply / max(100.0, avg_demand)

        # Base water score from supply/demand ratio
        if ratio >= 1.0:
            # Baseline satisfaction
            base_score = 80.0 + min(18.0, (ratio - 1.0) * 36.0)
        else:
            # Deficit penalty scaled by drought tolerance
            deficit_pct = 1.0 - ratio
            high_drought_count = drought_tolerances.count("high")
            low_drought_count = drought_tolerances.count("low")

            tolerance_factor = 1.0 - (0.35 * (high_drought_count / len(drought_tolerances))) + (0.25 * (low_drought_count / len(drought_tolerances)))
            penalty = deficit_pct * 70.0 * tolerance_factor
            base_score = max(15.0, 80.0 - penalty)

        # 3. NASA SMAP surface-moisture modulation.
        # Use the shared physical range defined for NASA SMAP SPL3SMP_E (0..0.50 m3/m3).
        # The regime thresholds match nasa/smap.py: deficit < 0.12, adequate
        # 0.12..0.25, surplus > 0.25. Severity scales the adjustment so a
        # reading just across a threshold does not receive the same adjustment
        # as a much drier/wetter reading. These are project heuristics and
        # require regional agronomic calibration before operational use.
        valid_smap_moisture = (
            isinstance(smap_soil_moisture, (int, float))
            and not isinstance(smap_soil_moisture, bool)
            and SOIL_MOISTURE_MIN_M3_M3 <= float(smap_soil_moisture) <= SOIL_MOISTURE_MAX_M3_M3
        )
        moisture_value = float(smap_soil_moisture) if valid_smap_moisture else None
        effective_smap_regime = None
        smap_adjustment = 0.0
        moisture_severity = 0.0

        if moisture_value is not None:
            if moisture_value < 0.12:
                effective_smap_regime = "deficit"
                moisture_severity = min(1.0, (0.12 - moisture_value) / 0.12)
                high_count = drought_tolerances.count("high")
                low_count = drought_tolerances.count("low")
                smap_adjustment = (
                    ((high_count * 4.0) - (low_count * 8.0))
                    / max(1, len(drought_tolerances))
                ) * moisture_severity
            elif moisture_value > 0.25:
                effective_smap_regime = "surplus"
                moisture_severity = min(1.0, (moisture_value - 0.25) / 0.25)
                high_flood = flood_tolerances.count("high")
                low_flood = flood_tolerances.count("low")
                smap_adjustment = (
                    ((high_flood * 5.0) - (low_flood * 7.0))
                    / max(1, len(flood_tolerances))
                ) * moisture_severity
            else:
                effective_smap_regime = "adequate"

            if smap_trend == "drying" and "low" in drought_tolerances:
                smap_adjustment -= 2.0

        final_score = max(5.0, min(100.0, round(base_score + smap_adjustment, 1)))

        metadata = {
            "average_water_demand_mm": round(avg_demand, 1),
            "effective_rainfall_mm": round(effective_annual_rainfall_mm, 1),
            "irrigation_buffer_mm": round(irrigation_buffer_mm, 1),
            "total_water_supply_mm": round(total_water_supply, 1),
            "supply_to_demand_ratio": round(ratio, 2),
            "smap_moisture_m3_m3": round(moisture_value, 3) if moisture_value is not None else None,
            "smap_regime": effective_smap_regime or "not_available",
            "smap_moisture_severity": round(moisture_severity, 3),
            "smap_adjustment_applied": round(smap_adjustment, 1),
            "validation_notes": sorted(set(validation_notes))
        }
        return final_score, metadata

    def compute_climate_suitability(
        self,
        crops: List[Dict[str, Any]],
        t2m_avg: float,
        t2m_max: float,
        solar_radiation_mj: Optional[float] = None,
        relative_humidity_pct: Optional[float] = None
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Calculates Climate Suitability Score (0 to 100).
        Evaluates NASA POWER temperature, maximum heat peaks, solar radiation, and humidity
        against documented ANGRAU critical temperatures and physiological thresholds.
        """
        for field_name, value in (("t2m_avg", t2m_avg), ("t2m_max", t2m_max)):
            if (isinstance(value, bool) or not isinstance(value, (int, float))
                    or not math.isfinite(float(value))):
                raise ValueError(f"{field_name} must be a finite numeric temperature")

        base_score = 82.0
        penalties = 0.0
        bonuses = 0.0

        critical_temps = []
        heat_ratings = []

        for crop in crops:
            heat_sens = crop.get("heat_sensitivity", {})
            crit_t = heat_sens.get("critical_temperature_celsius", 38.0) if isinstance(heat_sens, dict) else 38.0
            crit_t = crit_t or 38.0
            rating = (heat_sens.get("rating", "Moderate") if isinstance(heat_sens, dict) else "Moderate").capitalize()
            critical_temps.append(crit_t)
            heat_ratings.append(rating)

            # Compare t2m_max against critical threshold
            if t2m_max > crit_t:
                excess = t2m_max - crit_t
                weight = 1.3 if rating == "High" else 0.85 if rating == "Moderate" else 0.4
                penalties += min(32.0, excess * 5.0 * weight)
            elif t2m_max <= crit_t - 2.0:
                bonuses += 2.5

        # Solar radiation bonus (C4 cereals and oilseeds benefit from abundant sunshine, but compounds heat stress in heatwaves)
        solar_impact = 0.0
        if solar_radiation_mj is not None:
            if solar_radiation_mj >= 16.0:
                solar_impact = -3.0 if penalties > 20.0 else 4.0
            elif solar_radiation_mj < 12.0:
                solar_impact = -4.0

        # High humidity fungal disease penalty check
        humidity_impact = 0.0
        if relative_humidity_pct is not None:
            if relative_humidity_pct > 78.0 and t2m_avg > 27.0:
                humidity_impact = -3.5  # Increased foliar blight/rot vulnerability

        score = base_score - (penalties / max(1, len(crops))) + (bonuses / max(1, len(crops))) + solar_impact + humidity_impact
        final_score = max(5.0, min(100.0, round(score, 1)))

        metadata = {
            "t2m_average_c": round(t2m_avg, 1),
            "t2m_max_c": round(t2m_max, 1),
            "solar_radiation_mj": round(solar_radiation_mj, 2) if solar_radiation_mj else None,
            "relative_humidity_pct": round(relative_humidity_pct, 1) if relative_humidity_pct else None,
            "critical_temperatures_evaluated": critical_temps,
            "heat_ratings": heat_ratings,
            "heat_penalty_applied": round(penalties / max(1, len(crops)), 1)
        }
        return final_score, metadata

    def compute_soil_health_potential(
        self,
        crops: List[Dict[str, Any]],
        farmer_profile: Optional[Dict[str, Any]],
        previous_crops: Optional[List[str]] = None
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Calculates Soil-Health Potential Score (0 to 100).
        Evaluates biological nitrogen fixation credits, botanical family alternation (pest breaks),
        soil textural suitability, and pH tolerance from ground-truth soil tests.
        Does NOT claim NASA measures parcel soil NPK or pH.
        """
        base_score = 68.0
        bnf_credits = 0.0
        legume_count = 0
        depleter_count = 0
        soil_texture_match_points = 0.0
        ph_points = 0.0
        rotation_break_points = 0.0

        farmer_soil = (farmer_profile.get("soil_type") if farmer_profile else "") or ""
        farmer_ph = farmer_profile.get("soil_ph") if farmer_profile else None
        farmer_oc = farmer_profile.get("organic_carbon_pct") if farmer_profile else None

        # 1. Evaluate Nitrogen Impact & Biological Nitrogen Fixation
        for crop in crops:
            n_impact = crop.get("nitrogen_impact", "depleting")
            nutrient_req = crop.get("nutrient_requirements", {})
            bnf_kg = 0.0
            if isinstance(nutrient_req, dict):
                bnf_kg = nutrient_req.get("biological_nitrogen_fixation_kg_ha", 0.0) or 0.0
                if nutrient_req.get("nitrogen_impact") == "fixing":
                    n_impact = "fixing"

            if n_impact == "fixing" or "pulse" in crop.get("category", "").lower() or "legume" in crop.get("category", "").lower():
                legume_count += 1
                bnf_credits += bnf_kg if bnf_kg > 0 else 35.0
            else:
                depleter_count += 1

        if legume_count >= 2:
            base_score += 20.0
        elif legume_count == 1:
            base_score += 12.0

        # 2. Soil Textural Suitability
        if farmer_soil:
            fs_lower = farmer_soil.lower()
            suit_matches = 0
            for crop in crops:
                suit = crop.get("soil_suitability", {})
                if isinstance(suit, dict):
                    suitable = [s.lower() for s in suit.get("suitable_soil_types", [])]
                    unsuitable = [u.lower() for u in suit.get("unsuitable_soil_types", [])]
                    if any(fs_lower in s or s in fs_lower for s in suitable):
                        suit_matches += 1
                    elif any(fs_lower in u or u in fs_lower for u in unsuitable):
                        suit_matches -= 2

            soil_texture_match_points = (suit_matches / max(1, len(crops))) * 10.0

        # 3. Soil pH Compatibility
        if farmer_ph is not None:
            ph_matches = 0
            for crop in crops:
                suit = crop.get("soil_suitability", {})
                if isinstance(suit, dict) and suit.get("optimal_ph_range"):
                    rng = suit["optimal_ph_range"]
                    if rng[0] <= farmer_ph <= rng[1]:
                        ph_matches += 1
                    elif abs(farmer_ph - rng[0]) <= 0.6 or abs(farmer_ph - rng[1]) <= 0.6:
                        ph_matches += 0
                    else:
                        ph_matches -= 1
            ph_points = (ph_matches / max(1, len(crops))) * 6.0

        # 4. Botanical Family Alternation & Monoculture Break
        families = [crop.get("crop_family", "") for crop in crops if crop.get("crop_family")]
        has_monoculture = False
        for i in range(len(families) - 1):
            if families[i] and families[i] == families[i + 1]:
                has_monoculture = True
                break

        prev_crops_list = [c.lower() for c in (previous_crops or [])]
        if farmer_profile and farmer_profile.get("current_crop"):
            prev_crops_list.append(farmer_profile["current_crop"].lower())

        if crops and crops[0].get("id", "").lower() in prev_crops_list:
            rotation_break_points -= 14.0  # Repeating same crop back-to-back
        elif not has_monoculture:
            rotation_break_points += 8.0   # Clean family diversity break

        # 5. Organic Carbon Restoration Potential
        oc_points = 0.0
        if farmer_oc is not None:
            if farmer_oc < 0.50 and legume_count >= 1:
                oc_points = 5.0  # High restoration utility for depleted soils

        score = base_score + soil_texture_match_points + ph_points + rotation_break_points + oc_points
        final_score = max(10.0, min(100.0, round(score, 1)))

        metadata = {
            "legume_count": legume_count,
            "biological_nitrogen_credit_kg_ha": round(bnf_credits, 1),
            "soil_texture_evaluated": farmer_soil or "unspecified",
            "soil_ph_evaluated": farmer_ph,
            "organic_carbon_evaluated": farmer_oc,
            "monoculture_risk_detected": has_monoculture,
            "family_break_applied": not has_monoculture
        }
        return final_score, metadata

    def compute_local_suitability(
        self,
        crops: List[Dict[str, Any]],
        farmer_profile: Optional[Dict[str, Any]],
        target_season: str = "Kharif"
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Calculates Local Agricultural Suitability Score (0 to 100).
        Evaluates official Andhra Pradesh crop calendar alignment, seed/market availability,
        irrigation feasibility, and farmer crop preference match.
        """
        base_score = 76.0
        calendar_points = 0.0
        availability_points = 0.0
        preference_points = 0.0
        irrigation_points = 0.0

        avail_crops = [c.lower() for c in (farmer_profile.get("available_crops", []) if farmer_profile else [])]
        pref_crops = [c.lower() for c in (farmer_profile.get("preferred_crops", []) if farmer_profile else [])]
        irrigation = (farmer_profile.get("irrigation_source", "Rainfed") if farmer_profile else "Rainfed").lower()

        for idx, crop in enumerate(crops):
            crop_id = crop.get("id", "").lower()
            crop_name = crop.get("name", "").lower()

            # Calendar season match (ANGRAU calendar)
            growing_seasons = [s.lower() for s in crop.get("season", crop.get("growing_season", []))]
            assigned_season = "kharif" if idx == 0 else "rabi" if idx == 1 else "summer"
            if assigned_season in growing_seasons or any(assigned_season in s for s in growing_seasons):
                calendar_points += 3.5
            else:
                calendar_points -= 4.0

            # Available crops filter
            if avail_crops:
                if crop_id in avail_crops or crop_name in avail_crops:
                    availability_points += 3.0
                else:
                    availability_points -= 5.0

            # Farmer preferred crops
            if pref_crops and (crop_id in pref_crops or crop_name in pref_crops):
                preference_points += 4.0

            # Summer crop feasibility under rainfed conditions
            if assigned_season == "summer" and "rainfed" in irrigation:
                if "fallow" in crop_name or "green manure" in crop_name or "sesbania" in crop_name:
                    irrigation_points += 2.0  # Planned moisture cover
                else:
                    irrigation_points -= 18.0 # Acute failure risk in dry AP summer without water

        score = base_score + calendar_points + availability_points + preference_points + irrigation_points
        final_score = max(10.0, min(100.0, round(score, 1)))

        metadata = {
            "calendar_season_evaluated": target_season,
            "irrigation_source_evaluated": irrigation,
            "availability_match_points": round(availability_points, 1),
            "preference_match_points": round(preference_points, 1),
            "calendar_alignment_points": round(calendar_points, 1)
        }
        return final_score, metadata

    def compute_overall_score(
        self,
        water_score: float,
        soil_score: float,
        climate_score: float,
        local_score: float,
        weights: Optional[Dict[str, float]] = None
    ) -> Tuple[float, Dict[str, float]]:
        """
        Computes the unified Overall Score using the transparent normalized formula:
        Overall = (Water * Water_Weight + Soil * Soil_Weight + Climate * Climate_Weight + Local * Local_Weight) / 100.
        Weights must total 100.
        """
        w = self.validate_weights(weights or self.DEFAULT_WEIGHTS)
        raw_overall = (
            (water_score * w["water"]) +
            (soil_score * w["soil"]) +
            (climate_score * w["climate"]) +
            (local_score * w["local"])
        ) / 100.0

        overall = max(0.0, min(100.0, round(raw_overall, 1)))
        return overall, w

    def generate_movement_explanation(
        self,
        strategy_title: str,
        indiv_scores: Dict[str, float],
        baseline_score: float,
        updated_score: float,
        baseline_rank: int,
        updated_rank: int,
        baseline_weights: Dict[str, float],
        updated_weights: Dict[str, float],
        competitors: Optional[List[Dict[str, Any]]] = None
    ) -> str:
        """
        Generates a transparent, mathematically grounded explanation for why a rotation strategy
        moved up, moved down, or maintained its position based on farmer priority changes.
        Recalculates the actual scoring formula; never hardcodes rankings or fake explanations.
        """
        score_diff = round(updated_score - baseline_score, 1)
        rank_diff = baseline_rank - updated_rank  # positive = moved up, negative = moved down

        contrib_deltas = {}
        for dim, field in self.DIMENSION_MAPPING.items():
            w_delta = updated_weights.get(dim, 25.0) - baseline_weights.get(dim, 25.0)
            score = indiv_scores.get(field, 75.0)
            c_delta = (w_delta * score) / 100.0
            contrib_deltas[dim] = {
                "w_delta": round(w_delta, 1),
                "score": round(score, 1),
                "c_delta": round(c_delta, 2),
                "name": self.DIMENSION_NAMES[dim]
            }

        sorted_pos = sorted(
            [d for d in contrib_deltas.values() if d["w_delta"] > 0],
            key=lambda x: x["c_delta"],
            reverse=True
        )
        sorted_neg = sorted(
            [d for d in contrib_deltas.values() if d["w_delta"] < 0],
            key=lambda x: x["c_delta"]
        )

        all_zero_w_delta = all(abs(d["w_delta"]) < 0.1 for d in contrib_deltas.values())
        if all_zero_w_delta:
            return (
                f"Baseline ranking #{updated_rank} ({updated_score:.1f}/100): Calculated under balanced baseline priorities "
                f"(25% equal allocation across water efficiency, soil health, climate resilience, and local agronomy)."
            )

        sign = "+" if score_diff >= 0 else ""

        if rank_diff > 0:
            pos_driver = sorted_pos[0] if sorted_pos else None
            driver_text = ""
            if pos_driver:
                driver_text = (
                    f"due to increased priority on {pos_driver['name']} (+{pos_driver['w_delta']}%), "
                    f"where this strategy achieved an outstanding score of {pos_driver['score']:.1f}/100 "
                    f"(+{pos_driver['c_delta']:.1f} weighted pts gain)"
                )
            else:
                driver_text = "as priorities shifted in favor of its core agronomic strengths"

            overtaken_name = ""
            if competitors:
                for c in competitors:
                    c_base_rank = c.get("baseline_rank", 99)
                    c_up_rank = c.get("updated_rank", 99)
                    if c_base_rank < baseline_rank and c_up_rank >= updated_rank:
                        overtaken_name = c.get("title", "")
                        break

            overtake_clause = f", overtaking '{overtaken_name}'" if overtaken_name else ""
            return (
                f"Promoted from Rank #{baseline_rank} to Rank #{updated_rank} ({sign}{score_diff:.1f} pts){overtake_clause} {driver_text}."
            )

        elif rank_diff < 0:
            increased_dim_lagging = None
            if sorted_pos:
                lowest_in_increased = min(sorted_pos, key=lambda x: x["score"])
                if lowest_in_increased["score"] < 80.0:
                    increased_dim_lagging = lowest_in_increased

            neg_driver = sorted_neg[0] if sorted_neg else None

            reasons = []
            if neg_driver:
                reasons.append(
                    f"reduced weight on {neg_driver['name']} ({neg_driver['w_delta']}%)"
                )
            if increased_dim_lagging:
                reasons.append(
                    f"its lower score in {increased_dim_lagging['name']} ({increased_dim_lagging['score']:.1f}/100) limited gains from the +{increased_dim_lagging['w_delta']}% weight boost"
                )

            reason_str = " and ".join(reasons) if reasons else "re-weighting across priority criteria"

            pull_ahead_name = ""
            if competitors:
                for c in competitors:
                    c_base_rank = c.get("baseline_rank", 99)
                    c_up_rank = c.get("updated_rank", 99)
                    if c_base_rank > baseline_rank and c_up_rank <= updated_rank:
                        pull_ahead_name = c.get("title", "")
                        break

            ahead_clause = f", yielding top rank to '{pull_ahead_name}'" if pull_ahead_name else ""
            return (
                f"Shifted from Rank #{baseline_rank} to Rank #{updated_rank} ({sign}{score_diff:.1f} pts){ahead_clause} "
                f"primarily because of {reason_str}."
            )

        else:
            if updated_rank == 1:
                top_dim = max(contrib_deltas.values(), key=lambda x: x["score"])
                return (
                    f"Maintained top ranking (#1, {updated_score:.1f}/100, {sign}{score_diff:.1f} pts): "
                    f"Continues as the optimal overall rotation sequence. Strong baseline performance in "
                    f"{top_dim['name']} ({top_dim['score']:.1f}/100) maintained its lead across priority adjustments."
                )
            else:
                top_dim = max(contrib_deltas.values(), key=lambda x: x["score"])
                weakest_dim = min(contrib_deltas.values(), key=lambda x: x["score"])
                return (
                    f"Maintained Rank #{updated_rank} ({updated_score:.1f}/100, {sign}{score_diff:.1f} pts): "
                    f"Solid performance in {top_dim['name']} ({top_dim['score']:.1f}/100) kept its ranking stable, "
                    f"while {weakest_dim['name']} ({weakest_dim['score']:.1f}/100) remained a comparative constraint against higher-ranked alternatives."
                )

    def rank_and_explain_strategies(
        self,
        strategies: List[Dict[str, Any]],
        updated_weights: Dict[str, float],
        baseline_weights: Optional[Dict[str, float]] = None
    ) -> List[Dict[str, Any]]:
        """
        Recalculates scores for all strategies using updated weights, determines baseline and updated ranks,
        sorts strategies in descending order of updated score, and attaches explainable rank movement reasons.
        """
        b_weights = self.validate_weights(baseline_weights or self.DEFAULT_WEIGHTS)
        u_weights = self.validate_weights(updated_weights)

        scored_items = []
        for strat in strategies:
            indiv = strat.get("individual_scores", {})
            w_score = float(indiv.get("water_suitability", 75.0))
            s_score = float(indiv.get("soil_health_potential", 75.0))
            c_score = float(indiv.get("climate_suitability", 75.0))
            l_score = float(indiv.get("local_agricultural_suitability", 75.0))

            b_overall, _ = self.compute_overall_score(w_score, s_score, c_score, l_score, b_weights)
            u_overall, _ = self.compute_overall_score(w_score, s_score, c_score, l_score, u_weights)

            scored_items.append({
                "strat": strat,
                "baseline_score": b_overall,
                "updated_score": u_overall,
                "indiv_scores": indiv
            })

        # Assign baseline ranks (1 to len) based on descending baseline_score
        scored_items.sort(key=lambda x: x["baseline_score"], reverse=True)
        for rank_idx, item in enumerate(scored_items, start=1):
            item["baseline_rank"] = rank_idx

        # Assign updated ranks (1 to len) based on descending updated_score
        scored_items.sort(key=lambda x: x["updated_score"], reverse=True)
        for rank_idx, item in enumerate(scored_items, start=1):
            item["updated_rank"] = rank_idx

        competitor_summary = [
            {
                "id": item["strat"].get("id"),
                "title": item["strat"].get("title"),
                "baseline_rank": item["baseline_rank"],
                "updated_rank": item["updated_rank"],
                "baseline_score": item["baseline_score"],
                "updated_score": item["updated_score"],
            }
            for item in scored_items
        ]

        updated_strategies = []
        for item in scored_items:
            strat = dict(item["strat"])
            strat_id = strat.get("id")
            other_competitors = [c for c in competitor_summary if c["id"] != strat_id]

            explanation = self.generate_movement_explanation(
                strategy_title=strat.get("title", "Strategy"),
                indiv_scores=item["indiv_scores"],
                baseline_score=item["baseline_score"],
                updated_score=item["updated_score"],
                baseline_rank=item["baseline_rank"],
                updated_rank=item["updated_rank"],
                baseline_weights=b_weights,
                updated_weights=u_weights,
                competitors=other_competitors
            )

            strat["overall_score"] = item["updated_score"]
            strat["baseline_score"] = item["baseline_score"]
            strat["baseline_rank"] = item["baseline_rank"]
            strat["updated_rank"] = item["updated_rank"]
            strat["current_rank"] = item["updated_rank"]
            strat["rank_change"] = item["baseline_rank"] - item["updated_rank"]
            strat["movement_direction"] = (
                "up" if strat["rank_change"] > 0 else
                "down" if strat["rank_change"] < 0 else
                "unchanged"
            )
            strat["movement_explanation"] = explanation
            strat["weights"] = u_weights
            strat["baseline_weights"] = b_weights

            # Synchronize evidence_trace if present
            if "evidence_trace" in strat and isinstance(strat["evidence_trace"], dict):
                trace = dict(strat["evidence_trace"])
                trace["overall_score"] = item["updated_score"]
                trace["weights"] = u_weights
                if "dimensions" in trace:
                    for dim_key, field_name in self.DIMENSION_MAPPING.items():
                        if field_name in trace["dimensions"]:
                            score_val = float(item["indiv_scores"].get(field_name, 75.0))
                            dim_weight = float(u_weights.get(dim_key, 25.0))
                            trace["dimensions"][field_name]["weight"] = dim_weight
                            trace["dimensions"][field_name]["weighted_contribution"] = round(
                                (score_val * dim_weight) / 100.0, 2
                            )
                strat["evidence_trace"] = trace

            updated_strategies.append(strat)

        return updated_strategies

    def compute_evidence_completeness(
        self,
        dossier: Dict[str, Any],
        farmer_profile: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Calculates quantitative evidence completeness percentage across 12 tracked agro-climatic indicators.
        Missing indicators are never fabricated; their absence reduces completeness explicitly.
        """
        tracked_indicators = [
            # NASA POWER
            {"name": "NASA POWER Precipitation", "available": False, "category": "climate"},
            {"name": "NASA POWER Temperature (T2M / T2M_MAX)", "available": False, "category": "climate"},
            {"name": "NASA POWER Solar Radiation", "available": False, "category": "climate"},
            {"name": "NASA POWER Relative Humidity", "available": False, "category": "climate"},
            # NASA SMAP
            {"name": "NASA SMAP V6 Surface Soil Moisture", "available": False, "category": "soil_moisture"},
            # NASA GPM
            {"name": "NASA GPM IMERG V07 Precipitation", "available": False, "category": "precipitation"},
            # Farmer Ground-Truth Soil
            {"name": "Farmer Soil Textural Classification", "available": False, "category": "ground_truth"},
            {"name": "Farmer Soil pH Measurement", "available": False, "category": "ground_truth"},
            {"name": "Farmer N-P-K Nutrient Ratings", "available": False, "category": "ground_truth"},
            {"name": "Farmer Soil Organic Carbon (OC %)", "available": False, "category": "ground_truth"},
            {"name": "Farmer Irrigation Availability", "available": False, "category": "farm_infrastructure"},
            # Local Agricultural Knowledge
            {"name": "ANGRAU Verified Crop Calendar & Practices", "available": True, "category": "local_agronomy"}
        ]

        dataset_status = dossier.get("dataset_status", {})
        power_connected = dataset_status.get("nasa_power", {}).get("connected", False)
        smap_connected = dataset_status.get("nasa_smap", {}).get("connected", False)
        gpm_connected = dataset_status.get("nasa_gpm", {}).get("connected", False)

        if power_connected:
            tracked_indicators[0]["available"] = True
            tracked_indicators[1]["available"] = True
            tracked_indicators[2]["available"] = True
            tracked_indicators[3]["available"] = True

        if smap_connected:
            tracked_indicators[4]["available"] = True

        if gpm_connected:
            tracked_indicators[5]["available"] = True

        if farmer_profile:
            if farmer_profile.get("soil_type"):
                tracked_indicators[6]["available"] = True
            if farmer_profile.get("soil_ph") is not None:
                tracked_indicators[7]["available"] = True
            if (farmer_profile.get("nitrogen_value") is not None or farmer_profile.get("nitrogen_rating") or
                farmer_profile.get("phosphorus_value") is not None or farmer_profile.get("potassium_value") is not None):
                tracked_indicators[8]["available"] = True
            if farmer_profile.get("organic_carbon_pct") is not None:
                tracked_indicators[9]["available"] = True
            if farmer_profile.get("irrigation_source"):
                tracked_indicators[10]["available"] = True

        available_count = sum(1 for ind in tracked_indicators if ind["available"])
        total_count = len(tracked_indicators)
        pct = round((available_count / total_count) * 100.0, 1)

        connected_sources = []
        missing_sources = []

        if power_connected:
            connected_sources.append("NASA POWER Agroclimatology (0.5° reanalysis)")
        else:
            missing_sources.append("NASA POWER Agroclimatology")

        if smap_connected:
            connected_sources.append("NASA SMAP SPL3SMP_E V6 (9 km satellite)")
        else:
            missing_sources.append("NASA SMAP SPL3SMP_E V6 (Requires Earthdata Login)")

        if gpm_connected:
            connected_sources.append("NASA GPM IMERG V07 (0.1° satellite precipitation)")
        else:
            missing_sources.append("NASA GPM IMERG V07 (Requires Earthdata Login)")

        if farmer_profile and farmer_profile.get("soil_type"):
            connected_sources.append(f"Farmer Ground-Truth Soil ({farmer_profile.get('soil_source_type', 'farmer_measured')})")
        else:
            missing_sources.append("Farmer Field Soil Test (Using district regional benchmark)")

        connected_sources.append("ANGRAU & ICAR-CRIDA Package of Practices (2023-24)")

        return {
            "percentage": pct,
            "available_indicators": available_count,
            "total_indicators_tracked": total_count,
            "connected_sources": connected_sources,
            "missing_sources": missing_sources,
            "tracked_indicator_breakdown": tracked_indicators,
            "missing_data_policy": (
                "Strict Zero-Fabrication Policy: Unauthenticated or unavailable satellite datasets "
                "are never simulated. Evidence completeness is proportionally reduced and transparently reported."
            )
        }
