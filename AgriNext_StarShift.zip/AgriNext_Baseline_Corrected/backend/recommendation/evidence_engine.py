"""
Unified Environmental Evidence Service for AgriNext.
Extracts, structures, synthesizes, and links multi-sensor NASA Earth observation datasets
(NASA POWER, NASA SMAP SPL3SMP_E V6, and NASA GPM IMERG V07), Farmer Ground-Truth Soil Inputs,
and verified ANGRAU/ICAR Crop Knowledge directly into the crop recommendation engine.

Ensures strict scientific integrity:
- Explicitly distinguishes NASA environmental observations from farmer-provided soil information and local agricultural knowledge.
- If a dataset is unconfigured or unavailable, marks it transparently as disconnected.
- Never substitutes fabricated/simulated data.
- Explicitly enforces spatial resolution limitations (9 km SMAP, 10 km GPM) across all evidence.
"""

from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

from crop_knowledge.crop_service import CropKnowledgeService

class ObservationEvidence(BaseModel):
    source: str = Field(..., description="NASA POWER, NASA SMAP, or NASA GPM")
    dataset_name: str
    parameter_code: str
    parameter_name: str
    observed_value: float
    units: str
    spatial_resolution: str
    observation_period: str
    quality_status: str
    impact_on_score: float = 0.0
    rationale: str

class UnifiedEvidenceService:
    """Unified service that aggregates multi-sensor NASA Earth observation data into actionable decision support evidence."""

    SPATIAL_LIMITATION_DISCLAIMER = (
        "Macro-environmental resolution disclaimer: NASA SMAP (9 km x 9 km) and NASA GPM IMERG "
        "(0.1° x 0.1°, ~10 km) capture atmospheric and surface conditions integrated across a regional grid cell. "
        "A typical farm parcel (2 to 10 acres) is orders of magnitude smaller than a single cell. "
        "AgriNext uses these observations to characterize the regional agro-ecological zone and climatic pressures, "
        "and never claims to provide independently measured conditions for each isolated acre."
    )

    def __init__(self):
        self.version = "2.2.0"
        self.crop_service = CropKnowledgeService()
        from recommendation.rotation_engine import RotationEngine
        self.rotation_engine = RotationEngine()

    def build_unified_dossier(
        self,
        lat: float,
        lng: float,
        power_data: Optional[Dict[str, Any]] = None,
        smap_data: Optional[Dict[str, Any]] = None,
        gpm_data: Optional[Dict[str, Any]] = None,
        farmer_profile: Optional[Dict[str, Any]] = None,
        farm_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Assembles all available NASA Earth observation datasets, farmer soil ground-truth,
        and local agricultural knowledge into a unified environmental evidence dossier.
        Gracefully handles datasets that are not yet authenticated or connected.
        """
        now_utc = datetime.now(timezone.utc).isoformat()
        evidence_items: List[Dict[str, Any]] = []

        # 1. Dataset Status Tracking
        power_status = "connected" if (power_data and power_data.get("status") == "success") else "unavailable"
        smap_status = "connected" if (smap_data and smap_data.get("status") == "success") else (
            smap_data.get("status") if smap_data else "not_queried"
        )
        gpm_status = "connected" if (gpm_data and gpm_data.get("status") == "success") else (
            gpm_data.get("status") if gpm_data else "not_queried"
        )

        dataset_status_summary = {
            "nasa_power": {
                "name": "NASA POWER Agroclimatology",
                "status": power_status,
                "connected": power_status == "connected",
                "grid_resolution": "0.5° x 0.5° (~50 km) meteorology, 1.0° solar",
                "evidence_count": len(power_data.get("evidence_objects", [])) if power_data else 0
            },
            "nasa_smap": {
                "name": "NASA SMAP SPL3SMP_E V006",
                "status": smap_status,
                "connected": smap_status == "connected",
                "grid_resolution": "9 km x 9 km EASE-Grid 2.0 (~81 km²)",
                "evidence_count": 1 if (smap_status == "connected" and smap_data and smap_data.get("evidence_object")) else 0,
                "requires_auth": smap_status == "auth_required"
            },
            "nasa_gpm": {
                "name": "NASA GPM IMERG V07 Final Run",
                "status": gpm_status,
                "connected": gpm_status == "connected",
                "grid_resolution": "0.1° x 0.1° (~10 km grid cell)",
                "evidence_count": 1 if (gpm_status == "connected" and gpm_data and gpm_data.get("evidence_object")) else 0,
                "requires_auth": gpm_status == "auth_required"
            }
        }

        # 2. Ingest NASA POWER Evidence
        power_annual_rain = 0.0
        if power_status == "connected" and power_data:
            for ev in power_data.get("evidence_objects", []):
                evidence_items.append(ev)
                if ev.get("parameter_code") == "PRECTOTCORR":
                    power_annual_rain = float(ev.get("actual_value", 0.0))

        # 3. Ingest NASA SMAP Evidence (if connected)
        smap_ev = None
        smap_moisture = None
        smap_regime = None
        smap_trend = None
        if smap_status == "connected" and smap_data and smap_data.get("evidence_object"):
            smap_ev = smap_data["evidence_object"]
            evidence_items.append(smap_ev)
            smap_moisture = smap_ev.get("actual_value")
            smap_regime = smap_ev.get("regime")
            smap_trend = smap_ev.get("trend_indicator", {}).get("trend")

        # 4. Ingest NASA GPM Evidence (if connected)
        gpm_ev = None
        gpm_annual_rain = 0.0
        if gpm_status == "connected" and gpm_data and gpm_data.get("evidence_object"):
            gpm_ev = gpm_data["evidence_object"]
            evidence_items.append(gpm_ev)
            gpm_annual_rain = float(gpm_ev.get("actual_value", 0.0))

        # 5. Dual-Source Precipitation Synthesis (GPM IMERG vs NASA POWER)
        precipitation_synthesis = None
        if gpm_status == "connected" and power_status == "connected" and gpm_annual_rain > 0 and power_annual_rain > 0:
            diff_mm = round(gpm_annual_rain - power_annual_rain, 1)
            pct_diff = round((diff_mm / power_annual_rain) * 100.0, 1)
            concordance = "High" if abs(pct_diff) < 10.0 else "Moderate" if abs(pct_diff) < 20.0 else "Divergent"
            precipitation_synthesis = {
                "gpm_satellite_annual_mm": gpm_annual_rain,
                "power_reanalysis_annual_mm": power_annual_rain,
                "difference_mm": diff_mm,
                "variance_percentage": pct_diff,
                "concordance": concordance,
                "reconciliation_rationale": (
                    "GPM IMERG (~10 km) captures localized South-West monsoon convective rain cells, "
                    "whereas NASA POWER MERRA-2 (~50 km) provides smooth climatological integration. "
                    f"Concordance is classified as {concordance}."
                )
            }

        # 6. Soil Water-Balance Synthesis (SMAP vs Precipitation)
        soil_water_balance = None
        effective_annual_rain = gpm_annual_rain if gpm_status == "connected" and gpm_annual_rain > 0 else power_annual_rain
        if smap_status == "connected" and smap_moisture is not None:
            if smap_moisture < 0.12 and effective_annual_rain > 600:
                water_dynamic = "High drainage or high surface runoff. Soil moisture drops rapidly between rain events."
            elif smap_moisture > 0.22 and effective_annual_rain < 500:
                water_dynamic = "High water-retention clay matrix or sustained supplemental irrigation."
            else:
                water_dynamic = "Soil moisture closely follows regional rain events with standard retention."

            soil_water_balance = {
                "surface_moisture_m3_m3": smap_moisture,
                "regime": smap_regime,
                "trend": smap_trend,
                "effective_annual_rainfall_mm": effective_annual_rain,
                "moisture_retention_assessment": water_dynamic
            }

        # 7. Climate Risk Multipliers
        # Risk indices are derived only when the underlying precipitation observation exists.
        # These are transparent project heuristics, not measured NASA risk products.
        drought_risk_score = None
        waterlog_risk_score = None
        if effective_annual_rain > 0:
            drought_risk_score = 75 if effective_annual_rain < 450 else 55 if effective_annual_rain < 600 else 25
            waterlog_risk_score = 65 if effective_annual_rain > 900 else 20
            if smap_status == "connected" and smap_regime == "deficit":
                drought_risk_score = min(95, drought_risk_score + 20)

        connected_count = sum(1 for s in dataset_status_summary.values() if s["connected"])

        # 8. Distinct Provenance Mapping
        provenance_sources = {
            "satellite_environmental_observations": {
                "provider": "NASA Earth Science Division (POWER, SMAP, GPM)",
                "scope": "Regional Macro-Environment (0.1° to 0.5° Grid Cells)",
                "datasets_active": [k for k, v in dataset_status_summary.items() if v["connected"]]
            },
            "farmer_soil_ground_truth": {
                "provider": "Farmer Parcel Direct Inputs & Verified Benchmarks",
                "scope": "On-Farm Plot Ground-Truth (Specific Field Soil, Irrigation & History)",
                "soil_source_type": farmer_profile.get("soil_source_type", "unspecified") if farmer_profile else "none_provided",
                "reference": farmer_profile.get("soil_source_reference") if farmer_profile else None
            },
            "local_agricultural_knowledge": {
                "authority": "ANGRAU & ICAR-CRIDA",
                "scope": "State Agronomic Rules, Botanical Compatibility & Package of Practices",
                "state": "Andhra Pradesh"
            }
        }

        return {
            "dossier_id": f"UNIFIED_ENV_{round(lat, 3)}_{round(lng, 3)}_{farm_id or 'farm'}",
            "generated_at": now_utc,
            "coordinates": {"lat": lat, "lng": lng},
            "farm_id": farm_id,
            "connected_datasets_count": connected_count,
            "total_datasets_tracked": 3,
            "dataset_status": dataset_status_summary,
            "evidence_items": evidence_items,
            "evidence_count": len(evidence_items),
            "precipitation_synthesis": precipitation_synthesis,
            "soil_water_balance": soil_water_balance,
            "climate_risk_indicators": {
                "drought_risk_index": drought_risk_score,
                "waterlogging_risk_index": waterlog_risk_score,
                "sowing_moisture_confidence": "High" if (smap_status == "connected" and smap_regime in ["adequate", "surplus"]) else "Moderate" if (smap_status == "connected" or (power_status == "connected" and effective_annual_rain > 0)) else "Low"
            },
            "farmer_profile": farmer_profile,
            "provenance_sources": provenance_sources,
            "spatial_resolution_disclaimer": self.SPATIAL_LIMITATION_DISCLAIMER
        }

    def evaluate_crop_suitability(
        self,
        crops: List[Dict[str, Any]],
        crop_rules: List[Dict[str, Any]],
        dossier: Dict[str, Any],
        farmer_profile: Optional[Dict[str, Any]] = None,
        custom_weights: Optional[Dict[str, float]] = None
    ) -> Dict[str, Any]:
        """
        Integrates the unified evidence dossier, farmer soil inputs, and ANGRAU/ICAR crop knowledge
        into 3 multi-season crop rotation strategies and individual crop suitability evaluations.
        Calculates traceable water, soil, climate, and local agricultural suitability scores.
        """
        return self.rotation_engine.generate_recommendations(
            crops=crops,
            crop_rules=crop_rules,
            dossier=dossier,
            farmer_profile=farmer_profile,
            custom_weights=custom_weights
        )
