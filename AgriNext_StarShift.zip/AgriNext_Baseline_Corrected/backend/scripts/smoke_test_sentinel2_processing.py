"""Opt-in live Sentinel-2 farm-polygon NDVI smoke test.

This executes the same Sentinel2ProcessingService used by the API. It is deliberately
not named test_*.py and performs no network calls on import.

Run explicitly from the backend directory:
    python scripts/smoke_test_sentinel2_processing.py
"""
from pathlib import Path
import os
import sys

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))
load_dotenv(BACKEND_DIR / ".env")
load_dotenv(BACKEND_DIR / ".env.local")


def main() -> int:
    from geospatial.sentinel2_processing import (
        Sentinel2ProcessingError,
        Sentinel2ProcessingService,
    )

    if not os.getenv("SENTINEL_HUB_CLIENT_ID") or not os.getenv("SENTINEL_HUB_CLIENT_SECRET"):
        print("BLOCKED: Sentinel Hub OAuth credentials are not configured.")
        return 2

    # Small test polygon near Vijayawada, Andhra Pradesh. This is a smoke-test
    # location only; it is not represented as a user's farm or observation.
    center_lat, center_lon = 16.5062, 80.6480
    delta = 0.0005
    polygon = {
        "type": "Polygon",
        "coordinates": [[
            [center_lon - delta, center_lat - delta],
            [center_lon + delta, center_lat - delta],
            [center_lon + delta, center_lat + delta],
            [center_lon - delta, center_lat + delta],
            [center_lon - delta, center_lat - delta],
        ]],
    }
    try:
        result = Sentinel2ProcessingService().analyze_farm(
            polygon, max_cloud_cover=60.0
        )
    except Sentinel2ProcessingError as exc:
        print("SENTINEL-2 LIVE SMOKE TEST: FAILED")
        print("Provider/service error:", str(exc))
        return 1
    except Exception as exc:
        print("SENTINEL-2 LIVE SMOKE TEST: FAILED")
        print("Unexpected error:", type(exc).__name__, str(exc))
        return 1

    print("Provider:", result.get("source"))
    print("Dataset:", result.get("dataset"))
    print("Requested period:", result.get("requested_period"))
    print("Result status:", result.get("status"))
    print("Valid pixels:", result.get("valid_pixel_count"))
    print("NDVI statistics:", result.get("ndvi"))
    print("Coverage (%):", result.get("valid_coverage_percent"))
    if result.get("status") == "success" and result.get("valid_pixel_count", 0) > 0:
        print("SENTINEL-2 LIVE SMOKE TEST: SUCCESS")
        return 0
    print("SENTINEL-2 LIVE SMOKE TEST: NO VALID PIXELS")
    return 3


if __name__ == "__main__":
    raise SystemExit(main())
