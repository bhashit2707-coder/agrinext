"""Run a real NASA AppEEARS SMAP point-sample smoke test.

Example (from backend):
    python scripts/test_smap_live.py --lat 14.68 --lng 77.60 --start 2023-12-04 --end 2023-12-10

Requires EARTHDATA_USERNAME and EARTHDATA_PASSWORD in backend/.env.
This script never prints credentials or access tokens.
"""
import argparse
import json
import sys
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_DIR))

from nasa.smap import NASASMAPService  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Live NASA SMAP AppEEARS integration smoke test")
    parser.add_argument("--lat", type=float, required=True, help="Farm centroid latitude")
    parser.add_argument("--lng", type=float, required=True, help="Farm centroid longitude")
    parser.add_argument("--start", default="2023-12-04", help="Start date YYYY-MM-DD (V006 coverage begins 2023-12-04)")
    parser.add_argument("--end", required=True, help="End date YYYY-MM-DD")
    args = parser.parse_args()

    service = NASASMAPService(timeout_sec=60)
    status = service.get_service_status()
    if not status.get("auth_configured"):
        print("SMAP LIVE TEST: BLOCKED — Earthdata credentials are not configured.")
        return 2

    print("Submitting live AppEEARS point sample. This can take several minutes...")
    result = service.fetch_surface_soil_moisture(
        lat=args.lat, lng=args.lng, start_date=args.start, end_date=args.end, use_cache=False
    )
    safe_summary = {
        "status": result.get("status"),
        "connected": result.get("connected"),
        "is_live_query": result.get("is_live_query"),
        "product": result.get("product"),
        "sampling_method": result.get("sampling_method"),
        "observation_period": (result.get("evidence_object") or {}).get("observation_period"),
        "mean_moisture_m3_m3": result.get("mean_moisture_m3_m3"),
        "quality_summary": result.get("quality_summary"),
        "appeears_task_id": result.get("appeears_task_id"),
        "message": result.get("message"),
        "error_details": result.get("error_details"),
    }
    print(json.dumps(safe_summary, indent=2, default=str))
    return 0 if result.get("status") == "success" else 1


if __name__ == "__main__":
    raise SystemExit(main())
