#!/usr/bin/env python3
"""
AgriNext Location Data Hierarchy Validation Script.
Validates the complete 4-tier Local Government Directory (LGD) administrative revenue hierarchy:
State -> District (28) -> Mandal (688) -> Village / Cadastral Units (18,392)
"""

import sys
import json
import hashlib
from pathlib import Path

def run_validation():
    print("=" * 80)
    print("  AGRINEXT LOCATION DATA INTEGRITY & LGD HIERARCHY VALIDATION")
    print("=" * 80)

    base_dir = Path(__file__).resolve().parent.parent
    state_dir = base_dir / "state_data" / "andhra_pradesh"

    districts_file = state_dir / "districts.json"
    mandals_file = state_dir / "mandals.json"
    villages_file = state_dir / "villages.json"
    provenance_file = state_dir / "provenance.json"

    errors = []
    warnings = []

    # 1. Check file existence
    for f in [districts_file, mandals_file, villages_file, provenance_file]:
        if not f.exists():
            errors.append(f"Missing required data file: {f.name}")
            print(f"[FAIL] Missing {f.name}")
        else:
            print(f"[OK] Found {f.name} ({f.stat().st_size:,} bytes)")

    if errors:
        print("\nAborting validation due to missing files.")
        sys.exit(1)

    # 2. Load JSON files
    with open(districts_file, "r", encoding="utf-8") as f:
        districts = json.load(f)
    with open(mandals_file, "r", encoding="utf-8") as f:
        mandals = json.load(f)
    with open(villages_file, "r", encoding="utf-8") as f:
        villages = json.load(f)
    with open(provenance_file, "r", encoding="utf-8") as f:
        provenance = json.load(f)

    # 3. Validate Districts
    print("\n--- Validating Districts ---")
    dist_count = len(districts)
    print(f"Total districts found: {dist_count}")
    if dist_count != 28:
        errors.append(f"Expected 28 districts, found {dist_count}")

    district_ids = set()
    district_lgds = set()
    district_map = {}

    for idx, d in enumerate(districts):
        d_id = d.get("id")
        d_name = d.get("name")
        d_lgd = d.get("lgd_code")
        lat = d.get("lat")
        lng = d.get("lng")

        if not d_id or not isinstance(d_id, str):
            errors.append(f"District index {idx}: missing or invalid 'id'")
        elif d_id in district_ids:
            errors.append(f"Duplicate district id: '{d_id}'")
        district_ids.add(d_id)
        district_map[d_id] = d

        if not d_lgd or not isinstance(d_lgd, int):
            errors.append(f"District '{d_id}': missing or invalid 'lgd_code'")
        elif d_lgd in district_lgds:
            errors.append(f"Duplicate district lgd_code: {d_lgd}")
        district_lgds.add(d_lgd)

        if lat is None or lng is None or not (12.0 <= lat <= 20.0) or not (76.0 <= lng <= 85.0):
            warnings.append(f"District '{d_id}': coordinates ({lat}, {lng}) outside AP bounding envelope")

    print(f"[OK] {len(district_ids)} unique district IDs verified.")
    print(f"[OK] {len(district_lgds)} unique district LGD codes verified.")

    # 4. Validate Mandals
    print("\n--- Validating Mandals ---")
    mandal_count = len(mandals)
    print(f"Total mandals found: {mandal_count}")
    if mandal_count != 688:
        errors.append(f"Expected 688 mandals, found {mandal_count}")

    mandal_ids = set()
    mandal_lgds = set()
    mandal_map = {}
    mandals_by_district = {}

    for idx, m in enumerate(mandals):
        m_id = m.get("id")
        m_name = m.get("name")
        m_lgd = m.get("lgd_code")
        parent_d_id = m.get("district_id")
        lat = m.get("lat")
        lng = m.get("lng")

        if not m_id or not isinstance(m_id, str):
            errors.append(f"Mandal index {idx}: missing or invalid 'id'")
        elif m_id in mandal_ids:
            errors.append(f"Duplicate mandal id: '{m_id}'")
        mandal_ids.add(m_id)
        mandal_map[m_id] = m

        if not m_lgd or not isinstance(m_lgd, int):
            errors.append(f"Mandal '{m_id}': missing or invalid 'lgd_code'")
        elif m_lgd in mandal_lgds:
            errors.append(f"Duplicate mandal lgd_code: {m_lgd}")
        mandal_lgds.add(m_lgd)

        # Parent hierarchy check
        if not parent_d_id:
            errors.append(f"Mandal '{m_id}': missing 'district_id'")
        elif parent_d_id not in district_map:
            errors.append(f"Mandal '{m_id}': parent district '{parent_d_id}' does not exist in districts.json")
        else:
            mandals_by_district.setdefault(parent_d_id, []).append(m)

        if lat is None or lng is None or not (12.0 <= lat <= 20.0) or not (76.0 <= lng <= 85.0):
            warnings.append(f"Mandal '{m_id}': coordinates ({lat}, {lng}) outside AP bounding envelope")

    print(f"[OK] {len(mandal_ids)} unique mandal IDs verified.")
    print(f"[OK] {len(mandal_lgds)} unique mandal LGD codes verified.")
    print(f"[OK] All {mandal_count} mandals have valid parent district linkages.")

    # 5. Validate Villages
    print("\n--- Validating Villages & Cadastral Units ---")
    village_count = len(villages)
    print(f"Total village features found: {village_count}")
    if village_count != 18392:
        errors.append(f"Expected 18,392 villages/cadastral units, found {village_count}")

    village_ids = set()
    revenue_lgd_count = 0
    non_revenue_count = 0
    villages_by_mandal = {}

    for idx, v in enumerate(villages):
        v_id = v.get("id")
        v_name = v.get("name")
        v_lgd = v.get("lgd_code")
        parent_m_id = v.get("mandal_id")
        parent_d_id = v.get("district_id")

        if not v_id or not isinstance(v_id, str):
            errors.append(f"Village index {idx}: missing or invalid 'id'")
        elif v_id in village_ids:
            errors.append(f"Duplicate village id: '{v_id}'")
        village_ids.add(v_id)

        if v_lgd is not None and isinstance(v_lgd, int) and v_lgd > 0:
            revenue_lgd_count += 1
        else:
            non_revenue_count += 1

        # Parent hierarchy checks
        if not parent_m_id:
            errors.append(f"Village '{v_id}': missing 'mandal_id'")
        elif parent_m_id not in mandal_map:
            errors.append(f"Village '{v_id}': parent mandal '{parent_m_id}' does not exist in mandals.json")
        else:
            villages_by_mandal.setdefault(parent_m_id, []).append(v)
            expected_d_id = mandal_map[parent_m_id].get("district_id")
            if parent_d_id and parent_d_id != expected_d_id:
                errors.append(
                    f"Village '{v_id}': district_id '{parent_d_id}' conflicts with mandal's district_id '{expected_d_id}'"
                )

    print(f"[OK] {len(village_ids)} unique village IDs verified.")
    print(f"[OK] {revenue_lgd_count} revenue villages with official LGD codes.")
    print(f"[OK] {non_revenue_count} non-revenue cadastral units (forests, water bodies, hill tracts).")
    print(f"[OK] All {village_count} villages have valid parent mandal linkages.")

    # 6. Verify Urban Mandals with 0 villages
    print("\n--- Verifying Urban Mandals with 0 Rural Villages ---")
    urban_mandal_ids = ["vijayawada_east", "vijayawada_north", "vijayawada_west"]
    for um_id in urban_mandal_ids:
        if um_id in mandal_map:
            u_villages = villages_by_mandal.get(um_id, [])
            if len(u_villages) == 0:
                print(f"[OK] Verified 100% urban mandal '{um_id}' has exactly 0 rural revenue villages.")
            else:
                errors.append(f"Expected urban mandal '{um_id}' to have 0 rural villages, found {len(u_villages)}")
        else:
            errors.append(f"Urban mandal '{um_id}' not found in mandals.json")

    # 7. Check Provenance Metadata Reconciliation
    print("\n--- Reconciling Provenance Metadata ---")
    rec_counts = provenance.get("record_counts", {})
    if rec_counts.get("districts_count") != dist_count:
        errors.append(f"Provenance districts_count ({rec_counts.get('districts_count')}) != actual ({dist_count})")
    if rec_counts.get("mandals_count") != mandal_count:
        errors.append(f"Provenance mandals_count ({rec_counts.get('mandals_count')}) != actual ({mandal_count})")
    if rec_counts.get("total_villages_count") != village_count:
        errors.append(f"Provenance total_villages_count ({rec_counts.get('total_villages_count')}) != actual ({village_count})")
    if rec_counts.get("revenue_villages_with_official_lgd") != revenue_lgd_count:
        errors.append(f"Provenance revenue_villages ({rec_counts.get('revenue_villages_with_official_lgd')}) != actual ({revenue_lgd_count})")
    if rec_counts.get("non_revenue_cadastral_tracts") != non_revenue_count:
        errors.append(f"Provenance non_revenue ({rec_counts.get('non_revenue_cadastral_tracts')}) != actual ({non_revenue_count})")

    print(f"[OK] Provenance record counts reconcile perfectly with verified data.")

    # 8. Summary
    print("\n" + "=" * 80)
    print("  VALIDATION SUMMARY")
    print("=" * 80)
    print(f"Total Errors:   {len(errors)}")
    print(f"Total Warnings: {len(warnings)}")

    if warnings:
        print("\nWarnings:")
        for w in warnings[:10]:
            print(f"  - {w}")

    if errors:
        print("\nErrors:")
        for e in errors[:20]:
            print(f"  - {e}")
        print("\n[RESULT] VALIDATION FAILED")
        sys.exit(1)
    else:
        print("\n[RESULT] ALL DATA INTEGRITY & LGD HIERARCHY CHECKS PASSED PERFECTLY!")
        sys.exit(0)

if __name__ == "__main__":
    run_validation()
