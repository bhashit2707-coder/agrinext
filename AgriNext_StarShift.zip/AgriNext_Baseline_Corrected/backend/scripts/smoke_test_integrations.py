"""Explicit live integration smoke tests for AgriNext data providers.

This script is NOT discovered by pytest. It makes real outbound requests and is
intended to be run manually from the backend directory in a network-enabled
environment. Authenticated NASA/Sentinel Hub checks report BLOCKED when credentials
are not configured; they never substitute sample or synthetic observations.

Run:
    python scripts/smoke_test_integrations.py
"""
from __future__ import annotations

from datetime import date, timedelta, timezone, datetime
from pathlib import Path
import json
import os
import sys
from typing import Any, Callable

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))
load_dotenv(BACKEND_DIR / ".env")
load_dotenv(BACKEND_DIR / ".env.local")


def summarize(name: str, call: Callable[[], Any]) -> dict[str, Any]:
    try:
        result = call()
        if not isinstance(result, dict):
            print(f"{name}: FAIL (unexpected response type {type(result).__name__})")
            return {"service": name, "result": "failed", "reason": "unexpected response type"}
        status = result.get("status")
        count = result.get("count")
        if status == "auth_required":
            state, reason = "blocked", "credentials are not configured or accepted"
        elif status in {"unavailable", "error", "failed"}:
            state, reason = "failed", result.get("message") or result.get("error") or status
        elif status == "no_data":
            state, reason = "reachable_no_data", result.get("message", "provider returned no data")
        elif status in {"success", "ok"} or count is not None:
            state, reason = "success", None
        else:
            state, reason = "returned", result.get("message")
        safe_summary = {
            "service": name,
            "result": state,
            "status": status,
            "count": count,
            "period": result.get("period") or result.get("observation_period") or result.get("query"),
            "reason": reason,
        }
        print(f"{name}: {state.upper()}")
        if count is not None:
            print(f"  returned items: {count}")
        if reason:
            print(f"  note: {reason}")
        return safe_summary
    except Exception as exc:
        print(f"{name}: FAILED ({type(exc).__name__}: {exc})")
        return {"service": name, "result": "failed", "reason": f"{type(exc).__name__}: {exc}"}


def main() -> int:
    # Public catalogue/data services.
    from climate.era5_service import ERA5Service
    from geospatial.sentinel2_service import Sentinel2Service
    from geospatial.landsat_service import LandsatService
    from geospatial.srtm_service import SRTMService
    from geospatial.gaez_service import GAEZService
    from geospatial.modis_viirs_service import MODISVIIRSService
    from geospatial.ecostress_gracefo_service import ECOSTRESSGRACEFOService

    # NASA data services that require Earthdata login for data retrieval.
    from nasa.power import NASAPowerService
    from nasa.smap import NASASMAPService
    from nasa.gpm import NASAGPMService
    from nasa.gldas import GLDASService

    latitude, longitude = 16.5062, 80.6480
    today = datetime.now(timezone.utc).date()
    archive_end = today - timedelta(days=7)
    archive_start = archive_end - timedelta(days=2)
    power_start, power_end = "2024-11-01", "2024-11-03"

    checks: list[dict[str, Any]] = []
    checks.append(summarize("ERA5 historical reanalysis", lambda: ERA5Service().query_point(
        latitude, longitude, archive_start.isoformat(), archive_end.isoformat()
    )))
    checks.append(summarize("Sentinel-2 STAC catalogue", lambda: Sentinel2Service().search(
        latitude, longitude, max_cloud_cover=80, limit=5
    )))
    checks.append(summarize("Landsat Collection 2 STAC catalogue", lambda: LandsatService().search(
        latitude, longitude, max_cloud_cover=80, limit=5
    )))
    checks.append(summarize("SRTM elevation", lambda: SRTMService().query_points([
        {"latitude": latitude, "longitude": longitude}
    ])))
    checks.append(summarize("FAO GAEZ v4 catalogue", lambda: GAEZService().catalog()))
    checks.append(summarize("NASA MODIS/VIIRS CMR metadata", lambda: MODISVIIRSService().search(
        latitude, longitude, start_date=(today - timedelta(days=60)).isoformat(),
        end_date=today.isoformat(), products=["MODIS_NDVI_EVI"], limit=3
    )))
    checks.append(summarize("NASA ECOSTRESS CMR metadata", lambda: ECOSTRESSGRACEFOService().search(
        latitude, longitude, start_date="2025-01-01", end_date=today.isoformat(),
        products=["ECOSTRESS_LST"], limit=3
    )))
    checks.append(summarize("NASA GRACE-FO CMR metadata", lambda: ECOSTRESSGRACEFOService().search(
        latitude, longitude, start_date="2025-01-01", end_date=today.isoformat(),
        products=["GRACE_FO_TWS_MASCON"], limit=3
    )))

    # NASA POWER is public; use an explicit short historical interval rather than
    # the service's fixed climatology baseline default.
    checks.append(summarize("NASA POWER daily data", lambda: NASAPowerService().fetch_agroclimatology(
        latitude, longitude, start_date=power_start, end_date=power_end, use_cache=False
    )))

    # Authenticated downloads. These return auth_required rather than fake data
    # when Earthdata credentials are absent.
    checks.append(summarize("NASA SMAP AppEEARS data", lambda: NASASMAPService().fetch_surface_soil_moisture(
        latitude, longitude, use_cache=False
    )))
    checks.append(summarize("NASA GPM IMERG Final V07 data", lambda: NASAGPMService().fetch_precipitation(
        latitude, longitude, use_cache=False
    )))
    checks.append(summarize("NASA GLDAS Noah monthly data", lambda: GLDASService().query_point(
        latitude, longitude
    )))

    output = BACKEND_DIR / "phase2_live_smoke_results.json"
    output.write_text(json.dumps({
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "test_location": {"latitude": latitude, "longitude": longitude,
                          "description": "fixed integration smoke-test point near Vijayawada; not a farm record"},
        "checks": checks,
    }, indent=2), encoding="utf-8")
    print(f"\nSummary JSON: {output}")
    failures = [item for item in checks if item["result"] == "failed"]
    blocked = [item for item in checks if item["result"] == "blocked"]
    print(f"Checks: {len(checks)} | failures: {len(failures)} | credential-blocked: {len(blocked)}")
    return 1 if failures else (2 if blocked else 0)


if __name__ == "__main__":
    raise SystemExit(main())
