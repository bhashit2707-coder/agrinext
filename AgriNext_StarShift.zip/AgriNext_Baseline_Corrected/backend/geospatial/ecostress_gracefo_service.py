"""NASA CMR discovery for ECOSTRESS and GRACE/GRACE-FO products.

Returns granule catalogue metadata and data links only. It does not claim farm-pixel
retrieval; gridded monthly GRACE mascon values require a separate NetCDF/subsetting
workflow and are spatially coarse relative to an individual farm.
"""
from datetime import date
from typing import Any, Dict, Optional
import requests

CMR_URL = "https://cmr.earthdata.nasa.gov/search/granules.json"
PRODUCTS = {
    "ECOSTRESS_LST": {
        "short_name": "ECO_L2G_LSTE", "version": "003",
        "resolution": "70 m", "cadence": "irregular overpass",
        "description": "Gridded land-surface temperature and emissivity",
        "mission": "ECOSTRESS", "spatial_coverage": "Global land, subject to product coverage",
    },
    "ECOSTRESS_CLOUD": {
        "short_name": "ECO_L2G_CLOUD", "version": "003",
        "resolution": "70 m", "cadence": "irregular overpass",
        "description": "Cloud mask and confidence for ECOSTRESS LST quality screening",
        "mission": "ECOSTRESS", "spatial_coverage": "Global land, subject to product coverage",
    },
    "ECOSTRESS_NDVI_ALBEDO": {
        "short_name": "ECO_L2T_STARS", "version": "003",
        "resolution": "70 m", "cadence": "irregular overpass",
        "description": "Ancillary NDVI and albedo",
        "mission": "ECOSTRESS", "spatial_coverage": "Global land, subject to product coverage",
    },
    "ECOSTRESS_ET_ALEXI": {
        "short_name": "ECO_L3T_ET_ALEXI", "version": "002",
        "resolution": "70 m", "cadence": "daily estimate / irregular coverage",
        "description": "Tiled evapotranspiration ALEXI product",
        "mission": "ECOSTRESS", "spatial_coverage": "CONUS only",
    },
    "GRACE_FO_TWS_MASCON": {
        "short_name": "TELLUS_GRAC-GRFO_MASCON_CRI_GRID_RL06.3_V4",
        "version": None, "resolution": "0.5° grid; native mascon support ~3°",
        "cadence": "monthly",
        "description": "JPL GRACE/GRACE-FO terrestrial water storage equivalent-water-thickness anomaly (CRI filtered)",
        "mission": "GRACE and GRACE-FO", "spatial_coverage": "Global",
    },
}

class ECOSTRESSGRACEFOService:
    def __init__(self, session=None, timeout: int = 45):
        self.session = session or requests.Session()
        self.timeout = timeout

    def search(self, latitude: float, longitude: float,
               start_date: Optional[str] = None, end_date: Optional[str] = None,
               products=None, limit: int = 10) -> Dict[str, Any]:
        if not -90 <= latitude <= 90 or not -180 <= longitude <= 180:
            raise ValueError("Coordinates are outside valid latitude/longitude ranges")
        if not 1 <= limit <= 50:
            raise ValueError("limit must be between 1 and 50")
        start = date.fromisoformat(start_date) if start_date else date(2018, 7, 1)
        end = date.fromisoformat(end_date) if end_date else date.today()
        if start > end:
            raise ValueError("start_date must be on or before end_date")
        if (end - start).days > 3660:
            raise ValueError("Date range cannot exceed 10 years")
        selected = products or list(PRODUCTS)
        unknown = sorted(set(selected) - set(PRODUCTS))
        if unknown:
            raise ValueError("Unsupported product keys: " + ", ".join(unknown))
        temporal = f"{start.isoformat()}T00:00:00Z,{end.isoformat()}T23:59:59Z"
        results = []
        for key in selected:
            product = PRODUCTS[key]
            params = {
                "short_name": product["short_name"],
                "point": f"{longitude},{latitude}",
                "temporal": temporal,
                "page_size": limit,
                "sort_key": "-start_date",
            }
            if product.get("version"):
                params["version"] = product["version"]
            response = self.session.get(CMR_URL, params=params,
                                        headers={"Accept": "application/json"},
                                        timeout=self.timeout)
            response.raise_for_status()
            entries = response.json().get("feed", {}).get("entry", [])
            for entry in entries:
                links = entry.get("links", [])
                data_links = [link.get("href") for link in links
                              if link.get("href") and not link.get("inherited")
                              and link.get("rel", "").endswith("/data#")]
                results.append({
                    "product_key": key, "short_name": product["short_name"],
                    "title": entry.get("title"), "granule_id": entry.get("id"),
                    "mission": product["mission"], "resolution": product["resolution"],
                    "spatial_coverage": product["spatial_coverage"],
                    "cadence": product["cadence"], "description": product["description"],
                    "start_time": entry.get("time_start"), "end_time": entry.get("time_end"),
                    "data_links": data_links[:3],
                })
        results.sort(key=lambda item: item.get("start_time") or "", reverse=True)
        return {
            "status": "success", "source": "NASA CMR",
            "query": {"latitude": latitude, "longitude": longitude,
                      "start_date": start.isoformat(), "end_date": end.isoformat()},
            "count": len(results), "items": results,
            "data_level": "granule_catalogue_metadata",
            "pixel_values_extracted": False,
            "note": (
                "ECOSTRESS and GRACE/GRACE-FO granules were discovered from NASA CMR. "
                "This response contains catalogue metadata and data links, not extracted "
                "farm-pixel measurements. ECOSTRESS is a high-resolution but intermittent "
                "overpass product. GRACE/GRACE-FO mascon anomalies are monthly and much "
                "coarser than an individual farm; use them for regional water-storage context, "
                "not field-scale soil-moisture estimates."
            ),
        }

    def get_service_status(self):
        return {"service": "NASA CMR ECOSTRESS and GRACE-FO granule catalogue",
                "status": "configured", "products": list(PRODUCTS),
                "pixel_extraction": "not_implemented"}
