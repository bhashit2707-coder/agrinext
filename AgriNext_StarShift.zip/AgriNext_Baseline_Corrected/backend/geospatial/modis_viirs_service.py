"""NASA CMR granule discovery for MODIS and VIIRS products.

This module discovers available NASA granules; it does not download or decode
raster pixels. Pixel-level NDVI/LST/ET extraction requires a separate
AppEEARS/DAAC processing workflow.
"""
from datetime import date
from typing import Any, Dict, Optional
import requests

CMR_URL = "https://cmr.earthdata.nasa.gov/search/granules.json"
PRODUCTS = {
    "MODIS_NDVI_EVI": {"short_name": "MOD13Q1", "platform": "Terra", "resolution": "250 m", "cadence": "16-day", "description": "Vegetation indices (NDVI/EVI)"},
    "MODIS_LST": {"short_name": "MOD11A2", "platform": "Terra", "resolution": "1 km", "cadence": "8-day", "description": "Land surface temperature"},
    "MODIS_ET": {"short_name": "MOD16A2", "platform": "Terra", "resolution": "500 m", "cadence": "8-day", "description": "Evapotranspiration"},
    "VIIRS_NDVI_EVI": {"short_name": "VNP13A1", "platform": "Suomi-NPP", "resolution": "500 m", "cadence": "16-day", "description": "Vegetation indices (NDVI/EVI)"},
    "VIIRS_LST": {"short_name": "VNP21A2", "platform": "Suomi-NPP", "resolution": "1 km", "cadence": "8-day", "description": "Land surface temperature"},
}

class MODISVIIRSService:
    def __init__(self, session=None, timeout: int = 30):
        self.session = session or requests.Session()
        self.timeout = timeout

    def search(self, latitude: float, longitude: float, start_date: Optional[str] = None,
               end_date: Optional[str] = None, products=None, limit: int = 10) -> Dict[str, Any]:
        if not -90 <= latitude <= 90 or not -180 <= longitude <= 180:
            raise ValueError("Coordinates are outside valid latitude/longitude ranges")
        if not 1 <= limit <= 50:
            raise ValueError("limit must be between 1 and 50")
        start = date.fromisoformat(start_date) if start_date else date.today().replace(day=1)
        end = date.fromisoformat(end_date) if end_date else date.today()
        if start > end:
            raise ValueError("start_date must be on or before end_date")
        if (end - start).days > 366:
            raise ValueError("Date range cannot exceed 366 days")
        selected = products or list(PRODUCTS)
        unknown = sorted(set(selected) - set(PRODUCTS))
        if unknown:
            raise ValueError("Unsupported product keys: " + ", ".join(unknown))
        temporal = f"{start.isoformat()}T00:00:00Z,{end.isoformat()}T23:59:59Z"
        results = []
        for key in selected:
            product = PRODUCTS[key]
            response = self.session.get(CMR_URL, params={
                "short_name": product["short_name"],
                "point": f"{longitude},{latitude}",
                "temporal": temporal,
                "page_size": limit,
                "sort_key": "-start_date",
            }, headers={"Accept": "application/json"}, timeout=self.timeout)
            response.raise_for_status()
            payload = response.json()
            entries = payload.get("feed", {}).get("entry", [])
            for entry in entries:
                links = entry.get("links", [])
                data_links = [link.get("href") for link in links
                              if link.get("href") and not link.get("inherited")
                              and link.get("rel", "").endswith("/data#")]
                results.append({
                    "product_key": key, "short_name": product["short_name"],
                    "title": entry.get("title"), "granule_id": entry.get("id"),
                    "platform": product["platform"], "resolution": product["resolution"],
                    "cadence": product["cadence"], "description": product["description"],
                    "start_time": entry.get("time_start"), "end_time": entry.get("time_end"),
                    "data_links": data_links[:3],
                })
        results.sort(key=lambda item: item.get("start_time") or "", reverse=True)
        return {
            "status": "success", "source": "NASA CMR",
            "query": {"latitude": latitude, "longitude": longitude,
                      "start_date": start.isoformat(), "end_date": end.isoformat()},
            "count": len(results), "items": results,
            "data_level": "granule_catalogue_metadata",
            "pixel_values_extracted": False,
            "note": "NASA granules discovered from CMR. This response contains catalogue metadata and data links, not extracted farm-pixel NDVI, temperature or ET values. Download/subset and QA processing are required for those measurements.",
        }

    def get_service_status(self):
        return {"service": "NASA CMR MODIS/VIIRS granule catalogue",
                "status": "configured", "products": list(PRODUCTS),
                "pixel_extraction": "not_implemented"}
