"""SRTM 30 m point elevation lookup using OpenTopoData's SRTM dataset endpoint."""
from typing import Any, Dict, List
import requests

class SRTMService:
    ENDPOINT = "https://api.opentopodata.org/v1/srtm30m"
    def __init__(self, timeout: int = 20):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "AgriNext/1.0 terrain-context"})

    def get_service_status(self) -> Dict[str, Any]:
        return {"service": "SRTM elevation", "status": "ready", "dataset": "SRTM 30m (SRTMGL1-derived endpoint)",
                "spatial_resolution": "approximately 30 m", "endpoint": self.ENDPOINT,
                "note": "SRTM radar-derived surface elevation. Vegetation/buildings can affect elevations; not a bare-earth survey."}

    def query_points(self, points: List[Dict[str, float]]) -> Dict[str, Any]:
        if not points or len(points) > 100:
            raise ValueError("Provide between 1 and 100 points")
        locations = []
        for point in points:
            lat, lon = float(point["latitude"]), float(point["longitude"])
            if not -90 <= lat <= 90 or not -180 <= lon <= 180:
                raise ValueError("Latitude or longitude is outside valid WGS84 bounds")
            locations.append(f"{lat},{lon}")
        response = self.session.get(self.ENDPOINT, params={"locations": "|".join(locations), "interpolation": "bilinear"}, timeout=self.timeout)
        response.raise_for_status()
        payload = response.json()
        if payload.get("status") != "OK":
            raise RuntimeError(payload.get("error", "SRTM elevation service returned an unsuccessful response"))
        results = payload.get("results", [])
        mapped = []
        for result in results:
            mapped.append({"latitude": result.get("location", {}).get("lat"),
                           "longitude": result.get("location", {}).get("lng"),
                           "elevation_m": result.get("elevation"), "dataset": result.get("dataset", "srtm30m")})
        return {"status": "success", "connected": True, "source": "SRTM 30m via OpenTopoData",
                "spatial_resolution": "approximately 30 m", "vertical_units": "metres", "results": mapped,
                "note": "SRTM is a radar-derived surface model; canopy and built structures may influence elevation. Use for terrain context, not precision surveying."}
