"""Sentinel-2 discovery via Copernicus Data Space Ecosystem STAC catalog.
Catalog search is public metadata discovery; pixel processing requires a separately
configured Sentinel Hub OAuth client and is intentionally not claimed here.
"""
from datetime import date, timedelta
from typing import Any, Dict, Optional
import requests

STAC_SEARCH_URL = "https://stac.dataspace.copernicus.eu/v1/search"

class Sentinel2Service:
    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "AgriNext/1.0 (+farm-monitoring)"})

    def search(self, latitude: float, longitude: float, start_date: Optional[str] = None,
               end_date: Optional[str] = None, bbox_size: float = 0.05,
               max_cloud_cover: float = 30.0, limit: int = 10) -> Dict[str, Any]:
        if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
            raise ValueError("Invalid latitude or longitude")
        if not (0 < bbox_size <= 1):
            raise ValueError("bbox_size must be greater than 0 and at most 1 degree")
        if not (0 <= max_cloud_cover <= 100):
            raise ValueError("max_cloud_cover must be between 0 and 100")
        end = end_date or date.today().isoformat()
        start = start_date or (date.today() - timedelta(days=45)).isoformat()
        bbox = [longitude-bbox_size, latitude-bbox_size, longitude+bbox_size, latitude+bbox_size]
        payload = {
            "collections": ["sentinel-2-l2a"], "bbox": bbox,
            "datetime": f"{start}T00:00:00Z/{end}T23:59:59Z", "limit": min(max(limit, 1), 50),
            "query": {"eo:cloud_cover": {"lte": max_cloud_cover}}
        }
        response = self.session.post(STAC_SEARCH_URL, json=payload, timeout=self.timeout)
        response.raise_for_status()
        raw = response.json()
        features = raw.get("features", [])
        items = []
        for feature in features:
            props = feature.get("properties", {})
            items.append({
                "id": feature.get("id"), "datetime": props.get("datetime"),
                "cloud_cover_percent": props.get("eo:cloud_cover"),
                "platform": props.get("platform"), "instrument": props.get("instruments"),
                "processing_level": props.get("processing:level"),
                "geometry": feature.get("geometry"), "assets": {
                    key: value.get("href") for key, value in feature.get("assets", {}).items()
                    if key in ("thumbnail", "visual", "B04", "B08") and value.get("href")
                },
                "collection": "sentinel-2-l2a"
            })
        return {"source": "Copernicus Data Space Ecosystem", "dataset": "Sentinel-2 L2A",
                "catalog_api": STAC_SEARCH_URL, "access_mode": "public_catalog_metadata",
                "pixel_processing_available": False, "bbox": bbox, "start_date": start,
                "end_date": end, "max_cloud_cover_percent": max_cloud_cover,
                "count": len(items), "items": items,
                "note": "These are catalogued scene metadata, not a farm-level NDVI result. Pixel/index processing requires a configured Sentinel Hub processing service."}
