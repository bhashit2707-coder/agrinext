"""FAO GAEZ catalogue integration.
Uses the published GAEZ v4 OGC API Records search endpoint for machine-readable
catalogue discovery. GAEZ v5 is the current FAO assessment and is linked separately;
this service does not pretend that v4 catalogue metadata is v5 pixel-level output.
"""
from typing import Any, Dict, Optional
import requests

GAEZ_V4_API = "https://gaez.fao.org/api/search/v1"
GAEZ_V5_PORTAL = "https://data.apps.fao.org/gaez/?lang=en"

class GAEZService:
    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "AgriNext/1.0 (+agroecological-planning)"})

    def catalog(self) -> Dict[str, Any]:
        response = self.session.get(f"{GAEZ_V4_API}/collections", timeout=self.timeout)
        response.raise_for_status()
        data = response.json()
        collections = data.get("collections", []) if isinstance(data, dict) else []
        return {"source": "FAO/IIASA Global Agro-Ecological Zones", "api_version": "GAEZ v4 Search API",
                "collections": [{"id": c.get("id"), "title": c.get("title"),
                                 "description": c.get("description"), "links": c.get("links", [])}
                                for c in collections],
                "count": len(collections), "current_version": "GAEZ v5",
                "current_version_portal": GAEZ_V5_PORTAL,
                "note": "The searchable API endpoint is the GAEZ v4 catalogue. GAEZ v5 is the current FAO assessment; use its portal for current v5 layers and crop summaries."}

    def search(self, query: Optional[str] = None, collection_id: Optional[str] = None,
               limit: int = 10) -> Dict[str, Any]:
        if collection_id:
            url = f"{GAEZ_V4_API}/collections/{collection_id}/items"
        else:
            url = f"{GAEZ_V4_API}/collections"
        params: Dict[str, Any] = {"limit": min(max(limit, 1), 50)}
        if query:
            params["q"] = query
        response = self.session.get(url, params=params, timeout=self.timeout)
        response.raise_for_status()
        data = response.json()
        features = data.get("features", []) if isinstance(data, dict) else []
        collections = data.get("collections", []) if isinstance(data, dict) else []
        return {"source": "FAO/IIASA GAEZ", "api_version": "GAEZ v4 Search API",
                "query": query, "collection_id": collection_id,
                "count": len(features) if features else len(collections),
                "items": features, "collections": collections,
                "current_version": "GAEZ v5", "current_version_portal": GAEZ_V5_PORTAL,
                "note": "GAEZ suitability and attainable-yield layers are modelled agro-ecological assessments, not live field measurements. Confirm dataset version, crop, water regime, input level and baseline/scenario before comparing values."}
