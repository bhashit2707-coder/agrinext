"""Landsat Collection 2 Level-2 scene discovery through Earth Search STAC."""
from datetime import date, timedelta
from typing import Any, Dict, Optional
import requests

class LandsatService:
    ENDPOINT = "https://earth-search.aws.element84.com/v1/search"
    COLLECTION = "landsat-c2-l2"
    def __init__(self, timeout: int = 30, session=None): self.timeout, self.session = timeout, session or requests.Session()
    def get_service_status(self) -> Dict[str, Any]:
        return {"service": "Landsat Collection 2 Level-2", "status": "ready", "provider": "Earth Search STAC", "collection": self.COLLECTION, "spatial_resolution": "30 m surface reflectance", "sensors": ["Landsat 8 OLI/TIRS", "Landsat 9 OLI-2/TIRS-2"], "note": "Scene metadata and asset discovery only; pixel processing and QA masking are separate operations."}
    def search(self, latitude: float, longitude: float, start_date: Optional[str] = None, end_date: Optional[str] = None, bbox_size: float = 0.05, max_cloud_cover: float = 30, limit: int = 10) -> Dict[str, Any]:
        if not -90 <= latitude <= 90 or not -180 <= longitude <= 180: raise ValueError("Latitude or longitude is outside valid WGS84 bounds")
        if not 0 < bbox_size <= 1 or not 0 <= max_cloud_cover <= 100 or not 1 <= limit <= 50: raise ValueError("bbox_size, cloud cover or limit is outside supported bounds")
        end = date.fromisoformat(end_date) if end_date else date.today(); start = date.fromisoformat(start_date) if start_date else end-timedelta(days=365)
        if start > end: raise ValueError("start_date must be on or before end_date")
        half=bbox_size/2; body={"collections":[self.COLLECTION],"bbox":[longitude-half,latitude-half,longitude+half,latitude+half],"datetime":f"{start.isoformat()}T00:00:00Z/{end.isoformat()}T23:59:59Z","limit":limit,"query":{"eo:cloud_cover":{"lte":max_cloud_cover}}}
        response=self.session.post(self.ENDPOINT,json=body,timeout=self.timeout); response.raise_for_status(); payload=response.json(); items=[]
        for feature in payload.get("features",[]):
            props=feature.get("properties",{}); assets=feature.get("assets",{})
            items.append({"id":feature.get("id"),"datetime":props.get("datetime"),"platform":props.get("platform"),"cloud_cover_percent":props.get("eo:cloud_cover"),"processing_level":props.get("landsat:collection_category"),"assets":{k:{"href":v.get("href"),"type":v.get("type"),"title":v.get("title")} for k,v in assets.items() if k in {"red","green","blue","nir08","swir16","swir22","qa_pixel","mtl.json","thumbnail"}}})
        return {"status":"success","provider":"Earth Search STAC","collection":self.COLLECTION,"count":len(items),"items":items,"search":{"latitude":latitude,"longitude":longitude,"start_date":start.isoformat(),"end_date":end.isoformat(),"max_cloud_cover":max_cloud_cover},"note":"Scene discovery only. Apply Landsat Collection 2 scaling and QA_PIXEL cloud/shadow masking before calculating indices. Surface reflectance scale: DN × 0.0000275 − 0.2."}
