"""Combine Sentinel-2 scene metadata and FAO GAEZ catalogue context for rotation planning.

This module deliberately does not convert scene metadata into NDVI or GAEZ catalogue
records into numeric suitability scores. Those require raster/layer access and
matching crop, water regime, input level, and scenario metadata.
"""
from typing import Any, Dict, Iterable, Optional


def build_rotation_geospatial_context(
    latitude: float, longitude: float, crop_names: Iterable[str],
    sentinel_service: Any, gaez_service: Any, farm_id: Optional[str] = None,
    start_date: Optional[str] = None, end_date: Optional[str] = None,
) -> Dict[str, Any]:
    crops = sorted({str(name).strip() for name in crop_names if str(name).strip()})
    context: Dict[str, Any] = {
        "status": "partial",
        "farm_id": farm_id,
        "sentinel2": {"status": "unavailable", "scene_count": 0, "items": [],
                      "role": "vegetation-monitoring scene discovery; no vegetation index calculated"},
        "gaez": {"status": "unavailable", "query": ", ".join(crops) or "crop suitability",
                 "record_count": 0, "items": [],
                 "role": "modelled agro-ecological suitability context; not a field measurement"},
        "planning_guidance": [
            "Use Sentinel-2 acquisition dates and cloud cover to identify imagery suitable for later vegetation monitoring.",
            "Review GAEZ records for matching crop, water regime, input level, spatial resolution and scenario before applying suitability findings.",
            "These catalogue results do not alter rotation scores; no NDVI/NDWI or numeric GAEZ suitability value is inferred."
        ],
    }
    try:
        scenes = sentinel_service.search(latitude, longitude, start_date=start_date, end_date=end_date,
                                         max_cloud_cover=30.0, limit=10)
        context["sentinel2"] = {
            "status": "available", "source": scenes.get("source"),
            "dataset": scenes.get("dataset"), "scene_count": scenes.get("count", 0),
            "items": scenes.get("items", []), "pixel_processing_available": scenes.get("pixel_processing_available", False),
            "note": scenes.get("note"),
            "role": "vegetation-monitoring scene discovery; no vegetation index calculated"
        }
    except Exception as exc:
        context["sentinel2"]["error"] = f"Sentinel-2 catalogue unavailable: {type(exc).__name__}"
    try:
        query = ", ".join(crops) if crops else "crop suitability"
        records = gaez_service.search(query=query, limit=10)
        context["gaez"] = {
            "status": "available", "source": records.get("source"),
            "api_version": records.get("api_version"), "query": query,
            "record_count": records.get("count", 0), "items": records.get("items", []),
            "collections": records.get("collections", []),
            "current_version": records.get("current_version"),
            "current_version_portal": records.get("current_version_portal"),
            "note": records.get("note"),
            "role": "modelled agro-ecological suitability context; not a field measurement"
        }
    except Exception as exc:
        context["gaez"]["error"] = f"GAEZ catalogue unavailable: {type(exc).__name__}"
    statuses = (context["sentinel2"]["status"], context["gaez"]["status"])
    context["status"] = "available" if statuses == ("available", "available") else (
        "unavailable" if statuses == ("unavailable", "unavailable") else "partial")
    return context
