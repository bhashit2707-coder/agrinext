"""
AgriNext Geospatial Module.
Provides polygon validation, geodesic acreage calculation, centroid computation,
and NASA Earth observation spatial-sampling compatibility formatting.
"""

import math
from typing import Dict, Any, List, Tuple, Optional

SQ_METERS_PER_ACRE = 4046.8564224
EARTH_RADIUS_METERS = 6378137.0

def calculate_geodesic_polygon_area_acres(coordinates: List[List[float]]) -> float:
    """
    Calculate the geodesic surface area of a WGS84 polygon in acres using spherical excess.
    Coordinates is a list of [lng, lat] pairs (GeoJSON standard).
    """
    if len(coordinates) < 4:
        return 0.0

    # Ensure closed ring
    ring = coordinates
    if ring[0] != ring[-1]:
        ring = ring + [ring[0]]

    # Spherical excess calculation
    area_rad = 0.0
    for i in range(len(ring) - 1):
        p1 = ring[i]
        p2 = ring[i + 1]
        
        lng1 = math.radians(p1[0])
        lat1 = math.radians(p1[1])
        lng2 = math.radians(p2[0])
        lat2 = math.radians(p2[1])
        
        area_rad += (lng2 - lng1) * (2.0 + math.sin(lat1) + math.sin(lat2))

    area_sq_meters = abs(area_rad * (EARTH_RADIUS_METERS ** 2) / 2.0)
    area_acres = area_sq_meters / SQ_METERS_PER_ACRE
    return round(area_acres, 4)

def calculate_polygon_centroid(coordinates: List[List[float]]) -> Dict[str, float]:
    """
    Calculate the centroid (lat, lng) of a polygon for NASA POWER point observation queries.
    Coordinates is a list of [lng, lat] pairs.
    """
    ring = coordinates
    if ring[0] == ring[-1]:
        ring = ring[:-1]

    if not ring:
        return {"lat": 0.0, "lng": 0.0}

    # Planar centroid calculation for localized agricultural plots
    area_2 = 0.0
    cx = 0.0
    cy = 0.0
    n = len(ring)

    for i in range(n):
        p1 = ring[i]
        p2 = ring[(i + 1) % n]
        
        x0, y0 = p1[0], p1[1]
        x1, y1 = p2[0], p2[1]
        
        cross = (x0 * y1) - (x1 * y0)
        area_2 += cross
        cx += (x0 + x1) * cross
        cy += (y0 + y1) * cross

    if abs(area_2) > 1e-9:
        centroid_lng = cx / (3.0 * area_2)
        centroid_lat = cy / (3.0 * area_2)
    else:
        # Fallback to arithmetic mean
        centroid_lng = sum(p[0] for p in ring) / n
        centroid_lat = sum(p[1] for p in ring) / n

    return {
        "lat": round(centroid_lat, 6),
        "lng": round(centroid_lng, 6)
    }

def calculate_bounding_box(coordinates: List[List[float]]) -> Dict[str, float]:
    """Calculate min and max coordinates (bbox) for area sampling."""
    lngs = [p[0] for p in coordinates]
    lats = [p[1] for p in coordinates]
    return {
        "min_lng": round(min(lngs), 6),
        "min_lat": round(min(lats), 6),
        "max_lng": round(max(lngs), 6),
        "max_lat": round(max(lats), 6)
    }

def analyze_farm_boundary(geojson_geometry: Dict[str, Any]) -> Dict[str, Any]:
    """
    Comprehensive analysis of a farm boundary geometry:
    - Calculates geodesic area in acres
    - Calculates centroid for NASA POWER point API
    - Formats bounding box and polygon for NASA SMAP/GPM area sampling
    """
    geom_type = geojson_geometry.get("type")
    if geom_type != "Polygon":
        raise ValueError(f"Expected GeoJSON Polygon, got {geom_type}")

    raw_coords = geojson_geometry.get("coordinates", [])
    if not raw_coords or not isinstance(raw_coords[0], list):
        raise ValueError("Invalid polygon coordinates structure")

    outer_ring = raw_coords[0]
    if len(outer_ring) < 4:
        raise ValueError("A polygon outer ring requires at least 4 coordinates")

    acreage = calculate_geodesic_polygon_area_acres(outer_ring)
    centroid = calculate_polygon_centroid(outer_ring)
    bbox = calculate_bounding_box(outer_ring)

    return {
        "acreage": acreage,
        "centroid": centroid,
        "bounding_box": bbox,
        "vertex_count": len(outer_ring),
        "nasa_sampling": {
            "power_point_target": {
                "lat": centroid["lat"],
                "lng": centroid["lng"],
                "description": "Centroid point used for NASA POWER Agroclimatology API queries"
            },
            "area_target": {
                "bbox": bbox,
                "supports_polygon_clip": True,
                "description": "Actual farm polygon boundary used for NASA SMAP and GPM grid sampling"
            }
        }
    }
