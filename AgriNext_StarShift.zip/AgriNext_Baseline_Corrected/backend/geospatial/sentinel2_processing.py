"""Farm-polygon Sentinel-2 L2A NDVI processing through Copernicus Data Space.

This module is intentionally separate from sentinel2_service.py, which remains
responsible for public STAC catalogue discovery.
"""
from __future__ import annotations

import math
import os
import threading
import time
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, Optional, Tuple

import numpy as np
import requests
import rasterio
from rasterio.features import geometry_mask
from rasterio.io import MemoryFile

TOKEN_URL = (
    "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/"
    "protocol/openid-connect/token"
)
PROCESS_URL = "https://sh.dataspace.copernicus.eu/process/v1"
NODATA_VALUE = -9999.0
CLOUD_SCL_CLASSES = {3, 8, 9, 10, 11}
INVALID_SCL_CLASSES = {0, 1}

NDVI_EVALSCRIPT = """//VERSION=3
function setup() {
  return {
    input: [{bands: ["B04", "B08", "SCL"]}],
    output: {bands: 2, sampleType: "FLOAT32", nodataValue: -9999}
  };
}
function evaluatePixel(s) {
  // SCL: 3=cloud shadow, 8/9=cloud, 10=cirrus, 11=snow/ice.
  if ([0, 1, 3, 8, 9, 10, 11].includes(s.SCL)) {
    return [-9999, s.SCL];
  }
  const denominator = s.B08 + s.B04;
  if (!isFinite(denominator) || denominator <= 0) {
    return [-9999, s.SCL];
  }
  return [(s.B08 - s.B04) / denominator, s.SCL];
}
"""


class Sentinel2ProcessingError(RuntimeError):
    """Raised when Sentinel Hub processing or raster interpretation fails."""


class Sentinel2ProcessingService:
    def __init__(
        self,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        session: Optional[requests.Session] = None,
        timeout: int = 120,
        max_dimension: int = 2048,
    ) -> None:
        self.client_id = client_id if client_id is not None else os.getenv("SENTINEL_HUB_CLIENT_ID")
        self.client_secret = client_secret if client_secret is not None else os.getenv("SENTINEL_HUB_CLIENT_SECRET")
        self.session = session or requests.Session()
        self.timeout = timeout
        self.max_dimension = max_dimension
        self._token: Optional[str] = None
        self._token_expires_at = 0.0
        self._token_lock = threading.Lock()

    def _get_access_token(self) -> str:
        if not self.client_id or not self.client_secret:
            raise Sentinel2ProcessingError(
                "Sentinel Hub credentials are missing. Configure SENTINEL_HUB_CLIENT_ID "
                "and SENTINEL_HUB_CLIENT_SECRET in the backend environment."
            )
        with self._token_lock:
            if self._token and time.monotonic() < self._token_expires_at - 60:
                return self._token
            try:
                response = self.session.post(
                    TOKEN_URL,
                    data={
                        "grant_type": "client_credentials",
                        "client_id": self.client_id,
                        "client_secret": self.client_secret,
                    },
                    timeout=30,
                )
                response.raise_for_status()
                payload = response.json()
                token = payload.get("access_token")
                if not token:
                    raise Sentinel2ProcessingError("OAuth response did not contain an access token")
                expires_in = max(int(payload.get("expires_in", 1800)), 120)
                self._token = token
                self._token_expires_at = time.monotonic() + expires_in
                return token
            except (requests.RequestException, ValueError, TypeError) as exc:
                raise Sentinel2ProcessingError(f"Sentinel Hub authentication failed: {exc}") from exc

    @staticmethod
    def _normalize_geometry(geometry: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(geometry, dict):
            raise ValueError("Farm boundary must be a GeoJSON geometry or Feature")
        if geometry.get("type") == "Feature":
            geometry = geometry.get("geometry") or {}
        geom_type = geometry.get("type")
        if geom_type not in {"Polygon", "MultiPolygon"}:
            raise ValueError("Farm boundary must be a GeoJSON Polygon or MultiPolygon")
        coordinates = geometry.get("coordinates")
        if not coordinates:
            raise ValueError("Farm boundary has no coordinates")
        try:
            if geom_type == "Polygon":
                rings = coordinates
            else:
                rings = [ring for polygon in coordinates for ring in polygon]
            points = [point for ring in rings for point in ring]
            if not points or any(len(point) < 2 for point in points):
                raise ValueError
            longitudes = [float(point[0]) for point in points]
            latitudes = [float(point[1]) for point in points]
        except (TypeError, ValueError, IndexError) as exc:
            raise ValueError("Farm boundary coordinates are invalid") from exc
        if (any(not math.isfinite(v) for v in longitudes + latitudes)
                or min(longitudes) < -180 or max(longitudes) > 180
                or min(latitudes) < -90 or max(latitudes) > 90):
            raise ValueError("Farm boundary coordinates must be valid WGS84 longitude/latitude")
        if max(longitudes) - min(longitudes) <= 0 or max(latitudes) - min(latitudes) <= 0:
            raise ValueError("Farm boundary must cover a non-zero area")
        return geometry

    def _output_dimensions(self, bbox: Tuple[float, float, float, float]) -> Tuple[int, int]:
        west, south, east, north = bbox
        center_lat = (south + north) / 2.0
        width = max(1, math.ceil((east - west) * 111320.0 * max(math.cos(math.radians(center_lat)), 0.05) / 10.0))
        height = max(1, math.ceil((north - south) * 110574.0 / 10.0))
        largest = max(width, height)
        if largest > self.max_dimension:
            scale = self.max_dimension / largest
            width = max(1, int(width * scale))
            height = max(1, int(height * scale))
        return width, height

    def analyze_farm(
        self,
        boundary_geojson: Dict[str, Any],
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        max_cloud_cover: float = 40.0,
    ) -> Dict[str, Any]:
        """Return NDVI statistics clipped to a WGS84 farm polygon.

        `cloud_masked_pixel_percent` is based on Sentinel-2 SCL classifications
        among pixels with a valid SCL observation; it is not scene metadata cloud cover.
        """
        geometry = self._normalize_geometry(boundary_geojson)
        if not 0 <= max_cloud_cover <= 100:
            raise ValueError("max_cloud_cover must be between 0 and 100")
        end = date.fromisoformat(end_date) if end_date else date.today()
        start = date.fromisoformat(start_date) if start_date else end - timedelta(days=45)
        if start > end:
            raise ValueError("start_date must be on or before end_date")

        if geometry["type"] == "Polygon":
            points = [p for ring in geometry["coordinates"] for p in ring]
        else:
            points = [p for polygon in geometry["coordinates"] for ring in polygon for p in ring]
        longitudes = [float(p[0]) for p in points]
        latitudes = [float(p[1]) for p in points]
        bbox = [min(longitudes), min(latitudes), max(longitudes), max(latitudes)]
        width, height = self._output_dimensions(tuple(bbox))

        payload = {
            "input": {
                "bounds": {
                    "bbox": bbox,
                    "properties": {"crs": "http://www.opengis.net/def/crs/EPSG/0/4326"},
                },
                "data": [{
                    "type": "sentinel-2-l2a",
                    "dataFilter": {
                        "timeRange": {
                            "from": f"{start.isoformat()}T00:00:00Z",
                            "to": f"{end.isoformat()}T23:59:59Z",
                        },
                        "maxCloudCoverage": float(max_cloud_cover),
                    },
                }],
            },
            "output": {
                "width": width,
                "height": height,
                "responses": [{"identifier": "default", "format": {"type": "image/tiff"}}],
            },
            "evalscript": NDVI_EVALSCRIPT,
        }
        try:
            response = self.session.post(
                PROCESS_URL,
                headers={"Authorization": f"Bearer {self._get_access_token()}"},
                json=payload,
                timeout=self.timeout,
            )
            response.raise_for_status()
        except requests.RequestException as exc:
            detail = getattr(getattr(exc, "response", None), "text", "")
            raise Sentinel2ProcessingError(
                f"Sentinel-2 Processing API request failed: {detail[:500] or exc}"
            ) from exc

        content_type = response.headers.get("Content-Type", "").lower()
        if "tiff" not in content_type and "octet-stream" not in content_type:
            raise Sentinel2ProcessingError(
                f"Processing API returned unexpected content type: {content_type or 'unknown'}"
            )
        try:
            with MemoryFile(response.content) as memory_file:
                with memory_file.open() as dataset:
                    if dataset.count < 2:
                        raise Sentinel2ProcessingError("NDVI raster is missing its SCL quality band")
                    ndvi = dataset.read(1).astype("float32")
                    scl = dataset.read(2).astype("float32")
                    inside = geometry_mask(
                        [geometry], out_shape=(dataset.height, dataset.width),
                        transform=dataset.transform, invert=True, all_touched=False,
                    )
                    raster_nodata = dataset.nodata
                    transform = dataset.transform
                    crs = str(dataset.crs) if dataset.crs else "unknown"
        except Sentinel2ProcessingError:
            raise
        except Exception as exc:
            raise Sentinel2ProcessingError(f"Unable to read Sentinel-2 GeoTIFF response: {exc}") from exc

        total_polygon_pixels = int(np.count_nonzero(inside))
        scl_available = inside & np.isfinite(scl) & (scl > 0) & (scl != NODATA_VALUE)
        cloud_pixels = scl_available & np.isin(scl.astype("int16"), list(CLOUD_SCL_CLASSES))
        invalid_scl_pixels = scl_available & np.isin(scl.astype("int16"), list(INVALID_SCL_CLASSES))
        valid = inside & np.isfinite(ndvi) & (ndvi != NODATA_VALUE)
        if raster_nodata is not None:
            valid &= ndvi != float(raster_nodata)
        valid &= ~cloud_pixels & ~invalid_scl_pixels
        values = ndvi[valid]
        valid_count = int(values.size)
        scl_count = int(np.count_nonzero(scl_available))
        cloud_percent = round(100.0 * np.count_nonzero(cloud_pixels) / scl_count, 2) if scl_count else None
        coverage_percent = round(100.0 * valid_count / total_polygon_pixels, 2) if total_polygon_pixels else 0.0

        stats = {
            "mean": round(float(np.mean(values)), 4) if valid_count else None,
            "min": round(float(np.min(values)), 4) if valid_count else None,
            "max": round(float(np.max(values)), 4) if valid_count else None,
        }
        return {
            "status": "success" if valid_count else "no_valid_pixels",
            "source": "Copernicus Data Space Ecosystem",
            "dataset": "Sentinel-2 L2A",
            "processing_api": PROCESS_URL,
            "index": "NDVI",
            "formula": "(B08 - B04) / (B08 + B04)",
            "farm_boundary_type": geometry["type"],
            "bbox": bbox,
            "requested_period": {"start": start.isoformat(), "end": end.isoformat()},
            "max_scene_cloud_cover_percent": float(max_cloud_cover),
            "ndvi": stats,
            "valid_pixel_count": valid_count,
            "polygon_pixel_count": total_polygon_pixels,
            "valid_coverage_percent": coverage_percent,
            "cloud_masked_pixel_percent": cloud_percent,
            "cloud_mask_classes": sorted(CLOUD_SCL_CLASSES),
            "quality_band": "Sentinel-2 Scene Classification Layer (SCL)",
            "raster": {"width": int(width), "height": int(height), "crs": crs,
                       "transform": list(transform)[:6]},
            "observation_date": None,
            "observation_date_note": "A single acquisition date is not asserted for a multi-date Process API mosaic.",
            "limitations": [
                "The Process API may mosaic multiple acquisitions in the requested period.",
                "Cloud percentage is calculated from SCL pixels inside the farm, not scene metadata.",
                "No valid pixels means no NDVI statistics are reported.",
            ],
        }
