"""
Farmer Profile & Soil Data Service for AgriNext.
Captures ground-truth farm parcel inputs and bridges farmer-measured data
with verified agricultural soil benchmarks (Soil Health Card Scheme & ANGRAU).

Maintains strict provenance separation:
- NASA Environmental Observations (Regional Satellite & Model Reanalysis ~9-50 km).
- Farmer Ground-Truth Measurements & Inputs (Parcel-level direct declarations).
- Agricultural Soil Benchmarks (District baseline from Soil Health Card Portal & ANGRAU).
"""

import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

SOIL_BENCHMARKS_FILE = Path(__file__).resolve().parent.parent / "state_data" / "andhra_pradesh" / "soil_benchmarks.json"

class FarmerProfileInput(BaseModel):
    farm_id: Optional[str] = Field(None, description="Linked Farm Profile ID")
    soil_type: str = Field(..., description="1. Soil type (e.g. Red Sandy Loam, Black Cotton Soil, Alluvial Clay Loam)")
    soil_ph: Optional[float] = Field(None, description="2. Soil pH, if known (e.g. 6.5 - 8.5)")
    nitrogen_kg_ha: Optional[float] = Field(None, description="3a. Available Nitrogen in kg/ha, if known")
    nitrogen_rating: Optional[str] = Field(None, description="3b. Nitrogen rating (Low, Medium, High)")
    phosphorus_kg_ha: Optional[float] = Field(None, description="3c. Available Phosphorus in kg/ha, if known")
    phosphorus_rating: Optional[str] = Field(None, description="3d. Phosphorus rating (Low, Medium, High)")
    potassium_kg_ha: Optional[float] = Field(None, description="3e. Available Potassium in kg/ha, if known")
    potassium_rating: Optional[str] = Field(None, description="3f. Potassium rating (Low, Medium, High)")
    organic_carbon_pct: Optional[float] = Field(None, description="4. Organic Carbon percentage, if known")
    current_crop: Optional[str] = Field(None, description="5. Current standing crop (or fallow)")
    previous_crops: List[str] = Field(default_factory=list, description="6. History of previously cultivated crops")
    available_crops: List[str] = Field(default_factory=list, description="7. Crops available/feasible for cultivation")
    irrigation_source: str = Field("Rainfed", description="8. Irrigation source (Rainfed, Borewell, Canal, Drip, etc.)")
    farming_season: str = Field("Kharif", description="9. Target farming season (Kharif, Rabi, Summer)")
    preferred_crops: List[str] = Field(default_factory=list, description="10. Farmer's preferred crops")
    soil_source_type: str = Field("farmer_measured", description="'farmer_measured' or 'agricultural_benchmark'")
    soil_source_reference: Optional[str] = Field(None, description="Reference citation for soil data")

class FarmerProfileService:
    """Service to process, benchmark, and enrich farmer-provided soil and crop inputs."""

    def __init__(self):
        self._benchmarks: Optional[Dict[str, Any]] = None
        self._load_benchmarks()

    def _load_benchmarks(self):
        if SOIL_BENCHMARKS_FILE.exists():
            with open(SOIL_BENCHMARKS_FILE, "r", encoding="utf-8") as f:
                self._benchmarks = json.load(f)
        else:
            self._benchmarks = {}

    def get_district_soil_benchmark(self, district_id: str) -> Optional[Dict[str, Any]]:
        """Retrieves verified agricultural soil benchmark from Soil Health Card & ANGRAU records."""
        if not self._benchmarks:
            self._load_benchmarks()
        districts = self._benchmarks.get("benchmark_districts", {})
        clean_id = district_id.lower()
        if clean_id in districts:
            return districts[clean_id]

        # Parent district fallback mapping for newly reorganized Andhra Pradesh districts
        parent_fallbacks = {
            "sri_sathya_sai": "anantapur",
            "nandyal": "kurnool",
            "palnadu": "guntur",
            "bapatla": "guntur",
            "ntr": "krishna",
            "tirupati": "chittoor",
            "annamayya": "ysr_kadapa",
            "anakapalli": "visakhapatnam",
            "alluri_sitharama_raju": "visakhapatnam",
            "kakinada": "east_godavari",
            "dr_br_ambedkar_konaseema": "east_godavari",
            "eluru": "west_godavari",
            "parvathipuram_manyam": "vizianagaram",
            "spsr_nellore": "prakasam",
            "markapuram": "prakasam",
            "polavaram": "alluri_sitharama_raju"
        }
        parent_id = parent_fallbacks.get(clean_id)
        if parent_id:
            root_parent_id = parent_id
            if root_parent_id not in districts and root_parent_id in parent_fallbacks:
                root_parent_id = parent_fallbacks[root_parent_id]
            if root_parent_id in districts:
                bm = dict(districts[root_parent_id])
                bm["district_id"] = clean_id
                bm["district_name"] = clean_id.replace("_", " ").title()
                bm["is_parent_proxy"] = True
                bm["proxy_parent_district"] = parent_id
                bm["proxy_notes"] = f"Soil benchmark proxied from parent administrative unit '{parent_id}' (benchmark baseline '{root_parent_id}') pending dedicated station publication."
                return bm
        return None

    def classify_soil_metrics(
        self,
        soil_ph: Optional[float],
        nitrogen: Optional[float],
        phosphorus: Optional[float],
        potassium: Optional[float],
        organic_carbon: Optional[float]
    ) -> Dict[str, Any]:
        """
        Classifies soil metrics according to Government of India Soil Health Card standard scales.
        If a characteristic is not provided, marks it as 'unknown' without inventing values.
        """
        ph_class = "unknown"
        if soil_ph is not None:
            if soil_ph < 6.5:
                ph_class = "Acidic (< 6.5)"
            elif soil_ph <= 7.5:
                ph_class = "Neutral (6.5 - 7.5)"
            elif soil_ph <= 8.5:
                ph_class = "Moderately Alkaline (7.6 - 8.5)"
            else:
                ph_class = "Strongly Alkaline (> 8.5)"

        n_rating = "unknown"
        if nitrogen is not None:
            if nitrogen < 140.0:
                n_rating = "Low (< 140 kg/ha)"
            elif nitrogen <= 280.0:
                n_rating = "Medium (140 - 280 kg/ha)"
            else:
                n_rating = "High (> 280 kg/ha)"

        p_rating = "unknown"
        if phosphorus is not None:
            if phosphorus < 10.0:
                p_rating = "Low (< 10 kg/ha)"
            elif phosphorus <= 25.0:
                p_rating = "Medium (10 - 25 kg/ha)"
            else:
                p_rating = "High (> 25 kg/ha)"

        k_rating = "unknown"
        if potassium is not None:
            if potassium < 120.0:
                k_rating = "Low (< 120 kg/ha)"
            elif potassium <= 280.0:
                k_rating = "Medium (120 - 280 kg/ha)"
            else:
                k_rating = "High (> 280 kg/ha)"

        oc_rating = "unknown"
        if organic_carbon is not None:
            if organic_carbon < 0.50:
                oc_rating = "Low (< 0.50%)"
            elif organic_carbon <= 0.75:
                oc_rating = "Medium (0.50 - 0.75%)"
            else:
                oc_rating = "High (> 0.75%)"

        return {
            "ph_classification": ph_class,
            "nitrogen_rating": n_rating,
            "phosphorus_rating": p_rating,
            "potassium_rating": k_rating,
            "organic_carbon_rating": oc_rating
        }

    def process_farmer_profile(
        self,
        data: FarmerProfileInput,
        district_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Processes farmer inputs, fills in benchmark data if requested or missing,
        and records provenance transparently.
        """
        soil_type = data.soil_type
        ph = data.soil_ph
        n_val = data.nitrogen_kg_ha
        p_val = data.phosphorus_kg_ha
        k_val = data.potassium_kg_ha
        oc_val = data.organic_carbon_pct

        source_type = data.soil_source_type
        source_ref = data.soil_source_reference

        # If user chooses benchmark or fields are empty and district is provided, retrieve benchmark
        benchmark = self.get_district_soil_benchmark(district_id) if district_id else None

        if source_type == "agricultural_benchmark" and benchmark:
            soil_type = soil_type or benchmark.get("dominant_soil_type", "Red Sandy Loam")
            ph = ph if ph is not None else benchmark.get("soil_ph")
            n_val = n_val if n_val is not None else benchmark.get("available_nitrogen_kg_ha")
            p_val = p_val if p_val is not None else benchmark.get("available_phosphorus_kg_ha")
            k_val = k_val if k_val is not None else benchmark.get("available_potassium_kg_ha")
            oc_val = oc_val if oc_val is not None else benchmark.get("organic_carbon_pct")
            source_ref = benchmark.get("source_reference", "Government of India Soil Health Card Portal (https://soilhealth.dac.gov.in/)")
        elif not source_ref:
            source_ref = "Farmer self-reported field/laboratory measurement"

        classified = self.classify_soil_metrics(
            soil_ph=ph,
            nitrogen=n_val,
            phosphorus=p_val,
            potassium=k_val,
            organic_carbon=oc_val
        )

        return {
            "farm_id": data.farm_id,
            "soil_type": soil_type,
            "soil_source_type": source_type,
            "soil_source_reference": source_ref,
            "soil_ph": ph,
            "ph_classification": classified["ph_classification"],
            "nitrogen_value": n_val,
            "nitrogen_rating": data.nitrogen_rating or classified["nitrogen_rating"],
            "phosphorus_value": p_val,
            "phosphorus_rating": data.phosphorus_rating or classified["phosphorus_rating"],
            "potassium_value": k_val,
            "potassium_rating": data.potassium_rating or classified["potassium_rating"],
            "organic_carbon_pct": oc_val,
            "organic_carbon_rating": classified["organic_carbon_rating"],
            "current_crop": data.current_crop,
            "previous_crops": data.previous_crops,
            "available_crops": data.available_crops,
            "irrigation_source": data.irrigation_source,
            "farming_season": data.farming_season,
            "preferred_crops": data.preferred_crops,
            "provenance_notice": (
                "Ground-truth parcel data provided by farmer or official Soil Health Card benchmark. "
                "Distinct from regional NASA Earth observation satellites (POWER, SMAP, GPM)."
            )
        }
