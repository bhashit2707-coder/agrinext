"""
Unit and integration tests for Crop Knowledge Service.
Validates crop profiles, botanical family taxonomy, soil & water suitability,
heat/water stress sensitivities, rotation compatibility logic, ANGRAU/ICAR citations,
and API endpoints.
"""

import sys
from pathlib import Path
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
from crop_knowledge.crop_service import CropKnowledgeService

client = TestClient(app)
crop_service = CropKnowledgeService()

def test_crop_knowledge_catalog_completeness():
    """Verify that all major Andhra Pradesh crops are loaded with verified agronomic attributes."""
    crops = crop_service.get_all_crops()
    assert len(crops) >= 10

    crop_ids = [c["id"] for c in crops]
    assert "groundnut" in crop_ids
    assert "paddy" in crop_ids
    assert "bengal_gram" in crop_ids
    assert "red_gram" in crop_ids
    assert "cotton" in crop_ids
    assert "maize" in crop_ids
    assert "chilli" in crop_ids

def test_crop_profile_schema_and_citations():
    """Verify that each crop profile contains all required agronomic fields and official citations."""
    groundnut = crop_service.get_crop_by_id("groundnut")
    assert groundnut is not None
    assert groundnut["crop_name"] == "Groundnut (Peanut)"
    assert "వేరుశనగ" in groundnut["telugu_name"]
    assert "Fabaceae" in groundnut["crop_family"]
    assert "Kharif" in groundnut["growing_season"]
    assert groundnut["crop_duration_days"] == [100, 115]
    assert groundnut["water_requirement_mm"] == [450, 650]

    # Soil suitability
    soil = groundnut["soil_suitability"]
    assert "Red Sandy Loam" in soil["suitable_soil_types"]
    assert soil["optimal_ph_range"] == [6.0, 7.5]

    # Nutrient requirements & N fixation
    nutrients = groundnut["nutrient_requirements"]
    assert nutrients["nitrogen_impact"] == "fixing"
    assert nutrients["biological_nitrogen_fixation_kg_ha"] >= 30.0

    # Thermal and Water Stress
    assert groundnut["heat_sensitivity"]["rating"] in ["Low", "Moderate", "High"]
    assert len(groundnut["water_stress_sensitivity"]["critical_growth_stages"]) >= 2

    # Official Citation
    citation = groundnut["source_and_reference_date"]
    assert "ANGRAU" in citation["primary_authority"]
    assert "2023" in citation["reference_year"]

def test_rotation_compatibility_legume_after_depleter():
    """Verify Rule 1: Legume following nitrogen-depleting cereal/cash crop receives bonus synergy."""
    eval_res = crop_service.evaluate_rotation_compatibility(
        previous_crop_id="paddy", # nitrogen depleter
        candidate_crop_id="bengal_gram" # nitrogen-fixing legume
    )

    assert eval_res["compatible"] is True
    assert eval_res["score_multiplier"] >= 1.20
    assert "Legume Nitrogen Replenishment" in eval_res.get("rotational_synergy", "")
    assert "fixes biological nitrogen" in eval_res.get("rationale", "")

def test_rotation_compatibility_monoculture_warning():
    """Verify Rule 3: Consecutive cultivation of identical crop is heavily penalized."""
    eval_res = crop_service.evaluate_rotation_compatibility(
        previous_crop_id="groundnut",
        candidate_crop_id="groundnut"
    )

    assert eval_res["compatible"] is False
    assert eval_res["score_multiplier"] <= 0.70
    assert eval_res.get("monoculture_risk") is True
    assert "Monoculture warning" in eval_res["rationale"]

def test_rotation_compatibility_botanical_family_break():
    """Verify that repeating the same botanical family (e.g. Solanaceae) triggers pest-break warning."""
    eval_res = crop_service.evaluate_rotation_compatibility(
        previous_crop_id="chilli", # Solanaceae
        candidate_crop_id="chilli" # Solanaceae
    )

    assert eval_res["compatible"] is False
    assert eval_res.get("monoculture_risk") is True

def test_api_crop_knowledge_endpoints():
    """Verify GET /api/crop-knowledge and /api/crop-knowledge/{crop_id} routes."""
    res_list = client.get("/api/crop-knowledge")
    assert res_list.status_code == 200
    catalog = res_list.json()
    assert len(catalog) >= 10

    res_detail = client.get("/api/crop-knowledge/groundnut")
    assert res_detail.status_code == 200
    detail = res_detail.json()
    assert detail["id"] == "groundnut"
    assert "Fabaceae" in detail["crop_family"]
    assert "ANGRAU" in detail["source_and_reference_date"]["primary_authority"]
