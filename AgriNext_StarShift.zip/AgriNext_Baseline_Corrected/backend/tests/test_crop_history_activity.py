import sys, uuid
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
BACKEND_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_DIR))
import database
from main import app

@pytest.fixture
def history_client(tmp_path, monkeypatch):
    monkeypatch.setattr(database, 'DB_PATH', tmp_path / 'history.db')
    database.init_db()
    client = TestClient(app)
    assert client.post('/api/auth/register', json={'full_name':'History Farmer','email':'history@example.com','password':'StrongPassword123!'}).status_code == 201
    user = database.get_user_by_email('history@example.com')
    farm_id = str(uuid.uuid4())
    database.save_farm({'id':farm_id,'owner_user_id':user['id'],'farm_name':'History Farm','state_id':'andhra_pradesh','district_id':'guntur','mandal_id':'guntur_rural','latitude':16.3,'longitude':80.4,'polygon_acreage':1.0,'effective_acreage':1.0,'boundary_geojson':{'type':'Polygon','coordinates':[]}})
    return client, farm_id

def test_create_list_delete_crop_history_and_activity(history_client):
    client, farm_id = history_client
    payload = {'farm_id':farm_id,'crop_name':'Paddy','season':'Kharif','crop_year':2026,'planting_date':'2026-06-10','harvest_date':'2026-10-20','yield_value':2200,'yield_unit':'kg/acre','notes':'Test record'}
    created = client.post(f'/api/farms/{farm_id}/rotation-history', json=payload)
    assert created.status_code == 201, created.text
    record = created.json()
    assert record['crop_name'] == 'Paddy'
    assert len(client.get(f'/api/farms/{farm_id}/rotation-history').json()) == 1
    activity = client.get(f'/api/farms/{farm_id}/activity').json()
    assert activity[0]['activity_type'] == 'crop_planted'
    assert client.delete(f"/api/rotation-history/{record['id']}").status_code == 200
    assert client.get(f'/api/farms/{farm_id}/rotation-history').json() == []
    assert len(client.get(f'/api/farms/{farm_id}/activity').json()) == 2

def test_history_requires_auth_and_owner(history_client):
    client, farm_id = history_client
    anonymous = TestClient(app)
    assert anonymous.get(f'/api/farms/{farm_id}/rotation-history').status_code == 401
    other = TestClient(app)
    assert other.post('/api/auth/register', json={'full_name':'Other','email':'other-history@example.com','password':'StrongPassword123!'}).status_code == 201
    assert other.get(f'/api/farms/{farm_id}/activity').status_code == 404
    assert other.post(f'/api/farms/{farm_id}/rotation-history', json={'farm_id':farm_id,'crop_name':'Maize','season':'Rabi','crop_year':2026}).status_code == 404

def test_rejects_invalid_season_and_harvest_before_planting(history_client):
    client, farm_id = history_client
    base={'farm_id':farm_id,'crop_name':'Paddy','season':'Monsoon','crop_year':2026}
    assert client.post(f'/api/farms/{farm_id}/rotation-history', json=base).status_code == 422
    base.update({'season':'Kharif','planting_date':'2026-10-01','harvest_date':'2026-09-01'})
    assert client.post(f'/api/farms/{farm_id}/rotation-history', json=base).status_code == 422
