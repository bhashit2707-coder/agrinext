"""Tests for secure soil report upload and conservative PDF metric extraction."""
import sys
import uuid
from pathlib import Path

from fastapi.testclient import TestClient
import pytest

BACKEND_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_DIR))

import database
import api.router as api_router
from main import app
from reports.soil_report_service import extract_soil_metrics, classify_metrics


@pytest.fixture
def soil_client(tmp_path, monkeypatch):
    monkeypatch.setattr(database, "DB_PATH", tmp_path / "soil_test.db")
    monkeypatch.setattr(api_router, "SOIL_REPORT_DIR", tmp_path / "uploads")
    database.init_db()
    client = TestClient(app)
    reg = client.post("/api/auth/register", json={
        "full_name": "Soil Farmer", "email": "soil@example.com", "password": "StrongPassword123!"
    })
    assert reg.status_code == 201
    user = database.get_user_by_email("soil@example.com")
    farm_id = str(uuid.uuid4())
    database.save_farm({
        "id": farm_id, "owner_user_id": user["id"], "farm_name": "Test Farm",
        "state_id": "andhra_pradesh", "district_id": "guntur", "mandal_id": "guntur_rural",
        "latitude": 16.3, "longitude": 80.4, "polygon_acreage": 1.0, "effective_acreage": 1.0,
        "boundary_geojson": {"type": "Polygon", "coordinates": []}
    })
    return client, farm_id


def test_pdf_metric_extraction_and_classification():
    metrics = extract_soil_metrics("Soil pH: 6.8 Available Nitrogen 120 Available Phosphorus 18 Available Potassium 150 Organic Carbon 0.62%")
    assert metrics == {
        "soil_ph": 6.8, "nitrogen_kg_ha": 120.0, "phosphorus_kg_ha": 18.0,
        "potassium_kg_ha": 150.0, "organic_carbon_pct": 0.62
    }
    labels = classify_metrics(metrics)
    assert labels["soil_ph"] == "Neutral"
    assert labels["nitrogen"] == "Low"
    assert labels["phosphorus"] == "Medium"
    assert labels["potassium"] == "Medium"
    assert labels["organic_carbon"] == "Medium"


def test_owner_can_upload_and_list_image_report(soil_client):
    client, farm_id = soil_client
    response = client.post("/api/soil-reports", data={"farm_id": farm_id}, files={
        "report_file": ("soil-card.png", b"\x89PNG\r\n\x1a\n" + b"fake-image-data", "image/png")
    })
    assert response.status_code == 201, response.text
    payload = response.json()
    assert payload["report"]["extraction_status"] == "image_saved_manual_entry_required"
    assert payload["report"]["extracted_metrics"] == {}
    listed = client.get(f"/api/soil-reports/{farm_id}")
    assert listed.status_code == 200
    assert len(listed.json()) == 1
    assert "stored_filename" not in listed.json()[0]


def test_unauthenticated_and_wrong_owner_uploads_are_rejected(soil_client):
    client, farm_id = soil_client
    anon = TestClient(app)
    data = {"farm_id": farm_id}
    file = {"report_file": ("soil.png", b"\x89PNG\r\n\x1a\nabc", "image/png")}
    assert anon.post("/api/soil-reports", data=data, files=file).status_code == 401
    other = TestClient(app)
    other.post("/api/auth/register", json={"full_name": "Other Farmer", "email": "other@example.com", "password": "StrongPassword123!"})
    assert other.post("/api/soil-reports", data=data, files=file).status_code == 404


def test_rejects_mismatched_file_signature(soil_client):
    client, farm_id = soil_client
    response = client.post("/api/soil-reports", data={"farm_id": farm_id}, files={
        "report_file": ("fake.pdf", b"not a pdf", "application/pdf")
    })
    assert response.status_code == 415


def test_text_pdf_upload_extracts_suggested_metrics(soil_client):
    from io import BytesIO
    from reportlab.pdfgen import canvas
    client, farm_id = soil_client
    buffer = BytesIO()
    pdf = canvas.Canvas(buffer)
    pdf.drawString(72, 760, "Soil pH: 6.8 Available Nitrogen 120 Available Phosphorus 18")
    pdf.drawString(72, 740, "Available Potassium 150 Organic Carbon 0.62%")
    pdf.save()
    response = client.post("/api/soil-reports", data={"farm_id": farm_id}, files={
        "report_file": ("soil-lab.pdf", buffer.getvalue(), "application/pdf")
    })
    assert response.status_code == 201, response.text
    report = response.json()["report"]
    assert report["extraction_status"] == "metrics_extracted"
    assert report["extracted_metrics"]["soil_ph"] == 6.8
    assert report["extracted_metrics"]["nitrogen_kg_ha"] == 120.0
    assert response.json()["classifications"]["nitrogen"] == "Low"
