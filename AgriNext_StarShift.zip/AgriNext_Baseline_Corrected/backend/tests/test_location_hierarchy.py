"""
Unit and Integration Tests for AgriNext LGD Location Data Hierarchy.
Validates:
- All 28 districts, 688 mandals, and 18,392 villages/cadastral units
- Strict parent-child relationship integrity
- API endpoint routing, 400 parent mismatch, and 404 unknown handling
- Provenance metadata integrity
- Database persistence of full LGD hierarchy in farm profiles
- Soil benchmark fallback proxy behavior for newly reorganized districts
"""

import sys
from pathlib import Path
import pytest
from fastapi import HTTPException

# Ensure backend directory is in python path
BACKEND_DIR = Path(__file__).resolve().parent.parent
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from api.router import (
    location_manager,
    get_state_districts,
    get_district_mandals_hierarchical,
    get_mandal_villages_hierarchical,
    get_state_mandals,
    get_state_villages,
    get_state_provenance,
    create_or_update_farm,
    SaveFarmRequest
)
from data_processing.farmer_profile import FarmerProfileService
import database
import auth
import uuid

SAMPLE_POLYGON = {
    "type": "Polygon",
    "coordinates": [
        [
            [77.6000, 14.6000],
            [77.6100, 14.6000],
            [77.6100, 14.6100],
            [77.6000, 14.6100],
            [77.6000, 14.6000]
        ]
    ]
}


class TestLocationHierarchyData:
    """Tests the integrity of the raw and in-memory indexed location records."""

    def test_state_districts_count_and_structure(self):
        state_data = location_manager.get_state_data("andhra_pradesh")
        districts = state_data["districts"]
        assert len(districts) == 28, f"Expected 28 districts, got {len(districts)}"

        ids = [d["id"] for d in districts]
        assert len(ids) == len(set(ids)), "District IDs must be strictly unique"

        lgds = [d["lgd_code"] for d in districts]
        assert len(lgds) == len(set(lgds)), "District LGD codes must be strictly unique"

        # Check key newly established districts are included
        assert "markapuram" in ids, "Markapuram district (LGD 790) must be present"
        assert "polavaram" in ids, "Polavaram district (LGD 791) must be present"
        assert "anantapur" in ids, "Anantapur district must be present"

    def test_state_mandals_count_and_parents(self):
        state_data = location_manager.get_state_data("andhra_pradesh")
        mandals = state_data["mandals"]
        districts_by_id = state_data["districts_by_id"]

        assert len(mandals) == 688, f"Expected 688 mandals, got {len(mandals)}"

        ids = [m["id"] for m in mandals]
        assert len(ids) == len(set(ids)), "Mandal IDs must be strictly unique"

        lgds = [m["lgd_code"] for m in mandals]
        assert len(lgds) == len(set(lgds)), "Mandal LGD codes must be strictly unique"

        # Verify every mandal links to an existing district
        for m in mandals:
            parent_d = m.get("district_id")
            assert parent_d in districts_by_id, f"Mandal {m['id']} has invalid parent district {parent_d}"

    def test_state_villages_count_and_parents(self):
        state_data = location_manager.get_state_data("andhra_pradesh")
        villages = state_data["villages"]
        mandals_by_id = state_data["mandals_by_id"]

        assert len(villages) == 18392, f"Expected 18,392 villages/cadastral units, got {len(villages)}"

        ids = [v["id"] for v in villages]
        assert len(ids) == len(set(ids)), "Village IDs must be strictly unique"

        # Verify every village links to an existing mandal and matches mandal's district
        for v in villages:
            parent_m = v.get("mandal_id")
            assert parent_m in mandals_by_id, f"Village {v['id']} has invalid parent mandal {parent_m}"
            mandal = mandals_by_id[parent_m]
            if v.get("district_id"):
                assert v["district_id"] == mandal["district_id"], (
                    f"Village {v['id']} district {v['district_id']} conflicts with mandal district {mandal['district_id']}"
                )

    def test_urban_mandals_have_zero_rural_villages(self):
        state_data = location_manager.get_state_data("andhra_pradesh")
        villages_by_mandal = state_data["villages_by_mandal"]

        for urban_mandal in ["vijayawada_east", "vijayawada_north", "vijayawada_west"]:
            mandal_villages = villages_by_mandal.get(urban_mandal, [])
            assert len(mandal_villages) == 0, (
                f"100% Urban mandal {urban_mandal} must contain 0 rural revenue villages, got {len(mandal_villages)}"
            )


class TestLocationAPIEndpoints:
    """Tests the FastAPI route handlers for the hierarchical location endpoints."""

    def test_get_districts_success(self):
        dists = get_state_districts("andhra_pradesh")
        assert len(dists) == 28

    def test_get_districts_unknown_state_raises_404(self):
        with pytest.raises(HTTPException) as exc_info:
            get_state_districts("telangana_unknown")
        assert exc_info.value.status_code == 404

    def test_get_district_mandals_hierarchical_success(self):
        mandals = get_district_mandals_hierarchical("andhra_pradesh", "anantapur")
        assert len(mandals) == 32
        for m in mandals:
            assert m["district_id"] == "anantapur"

    def test_get_district_mandals_unknown_district_raises_404(self):
        with pytest.raises(HTTPException) as exc_info:
            get_district_mandals_hierarchical("andhra_pradesh", "invalid_district")
        assert exc_info.value.status_code == 404

    def test_get_mandal_villages_hierarchical_success(self):
        villages = get_mandal_villages_hierarchical("andhra_pradesh", "anantapur", "kalyandurg")
        assert len(villages) == 15
        for v in villages:
            assert v["mandal_id"] == "kalyandurg"
            assert v["district_id"] == "anantapur"

    def test_get_mandal_villages_parent_mismatch_raises_400(self):
        """Mandal belongs to anantapur, but caller requested it under chittoor."""
        with pytest.raises(HTTPException) as exc_info:
            get_mandal_villages_hierarchical("andhra_pradesh", "chittoor", "kalyandurg")
        assert exc_info.value.status_code == 400
        assert "belongs to district 'anantapur', not 'chittoor'" in exc_info.value.detail

    def test_get_mandal_villages_unknown_mandal_raises_404(self):
        with pytest.raises(HTTPException) as exc_info:
            get_mandal_villages_hierarchical("andhra_pradesh", "anantapur", "nonexistent_mandal")
        assert exc_info.value.status_code == 404

    def test_backward_compatible_mandals_endpoint(self):
        # Without filter: returns all 688
        all_mandals = get_state_mandals("andhra_pradesh")
        assert len(all_mandals) == 688

        # With filter: returns filtered
        filtered = get_state_mandals("andhra_pradesh", district_id="sri_sathya_sai")
        assert len(filtered) == 32

    def test_backward_compatible_villages_endpoint(self):
        # With valid pair
        vills = get_state_villages("andhra_pradesh", mandal_id="kalyandurg", district_id="anantapur")
        assert len(vills) == 15

        # With mismatched pair: raises 400
        with pytest.raises(HTTPException) as exc_info:
            get_state_villages("andhra_pradesh", mandal_id="kalyandurg", district_id="guntur")
        assert exc_info.value.status_code == 400

    def test_provenance_endpoint(self):
        prov = get_state_provenance("andhra_pradesh")
        assert prov["state"] == "Andhra Pradesh"
        assert prov["state_lgd_code"] == 28
        assert prov["record_counts"]["districts_count"] == 28
        assert prov["record_counts"]["mandals_count"] == 688
        assert prov["record_counts"]["total_villages_count"] == 18392
        assert len(prov["primary_sources"]) >= 3


class TestFarmPersistenceAndValidation:
    """Tests farm saving with parent hierarchy validation and database storage."""

    def test_create_farm_success_with_complete_hierarchy(self):
        req = SaveFarmRequest(
            farm_name="LGD Test Plot Alpha",
            state_id="andhra_pradesh",
            district_id="anantapur",
            mandal_id="kalyandurg",
            village_id="v_594945",
            boundary_geojson=SAMPLE_POLYGON
        )
        user = database.get_user_by_email("location-test@agrinext.local")
        if not user:
            user = database.create_user(str(uuid.uuid4()), "Location Test Farmer", "location-test@agrinext.local", auth.hash_password("TestPassword123!"))
        res = create_or_update_farm(req, current_user=user)
        assert res["status"] == "saved"
        farm = res["farm"]
        assert farm["district_id"] == "anantapur"
        assert farm["district_lgd"] == 502
        assert farm["mandal_id"] == "kalyandurg"
        assert farm["mandal_lgd"] == 5321
        assert farm["village_id"] == "v_594945"
        assert farm["village_name"] == "Kurubarahalli"
        assert farm["village_lgd"] == 594945

        # Verify retrieval from DB
        loaded = database.get_farm_by_id(farm["id"])
        assert loaded is not None
        assert loaded["village_name"] == "Kurubarahalli"
        assert loaded["village_lgd"] == 594945

        # Clean up
        database.delete_farm(farm["id"])

    def test_create_farm_rejects_mismatched_district_mandal(self):
        req = SaveFarmRequest(
            farm_name="Mismatched Plot",
            state_id="andhra_pradesh",
            district_id="guntur",
            mandal_id="kalyandurg", # belongs to anantapur
            boundary_geojson=SAMPLE_POLYGON
        )
        with pytest.raises(HTTPException) as exc_info:
            create_or_update_farm(req)
        assert exc_info.value.status_code == 400
        assert "Hierarchy mismatch" in exc_info.value.detail

    def test_create_farm_rejects_mismatched_mandal_village(self):
        req = SaveFarmRequest(
            farm_name="Mismatched Village Plot",
            state_id="andhra_pradesh",
            district_id="anantapur",
            mandal_id="kudair",
            village_id="v_594945", # belongs to kalyandurg
            boundary_geojson=SAMPLE_POLYGON
        )
        with pytest.raises(HTTPException) as exc_info:
            create_or_update_farm(req)
        assert exc_info.value.status_code == 400
        assert "Hierarchy mismatch" in exc_info.value.detail


class TestSoilBenchmarkProxies:
    """Tests soil benchmark proxy fallback behavior for newly formed districts."""

    def test_markapuram_fallback_proxy(self):
        service = FarmerProfileService()
        bm = service.get_district_soil_benchmark("markapuram")
        assert bm is not None
        assert bm["district_id"] == "markapuram"
        assert bm.get("is_parent_proxy") is True
        assert bm.get("proxy_parent_district") == "prakasam"

    def test_polavaram_fallback_proxy(self):
        service = FarmerProfileService()
        bm = service.get_district_soil_benchmark("polavaram")
        assert bm is not None
        assert bm["district_id"] == "polavaram"
        assert bm.get("is_parent_proxy") is True
        assert bm.get("proxy_parent_district") == "alluri_sitharama_raju"
