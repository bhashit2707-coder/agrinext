"""
Unit and integration tests for NASA GPM IMERG Service.
Validates GPM IMERG Version 07 Final Run product identification (GPM_3IMERGDF),
boundary aggregation, unit conversion (mm/day to annual and monthly totals),
quality and missing value preservation, comparison with NASA POWER precipitation,
scientific explanation of differences, spatial limitation disclaimers,
unauthenticated status transparency (no simulated data substituted),
and SQLite persistent caching.
"""

import sys
import uuid
from pathlib import Path
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
import auth
from nasa.gpm import NASAGPMService, PRODUCT_SHORT_NAME, PRODUCT_VERSION, FILL_VALUE
import database

client = TestClient(app)

# Protected NASA/recommendation API tests run as an authenticated farmer.
_test_user_id = str(uuid.uuid4())
_test_user_email = f"qa-{_test_user_id}@example.test"
database.create_user(_test_user_id, "QA Test Farmer", _test_user_email, auth.hash_password("TestPassword!123"))
client.cookies.set(auth.SESSION_COOKIE_NAME, auth.create_session_for_user(_test_user_id))
gpm_service = NASAGPMService()

# Sample real-world daily IMERG Final precipitation readings (mm/day) across 15 days
SAMPLE_GPM_OBSERVATIONS = [
    {"date": "2023-07-01", "precipitation_mm": 0.0, "quality_index": 0.98},
    {"date": "2023-07-02", "precipitation_mm": 14.5, "quality_index": 0.95},
    {"date": "2023-07-03", "precipitation_mm": 28.2, "quality_index": 0.92},
    {"date": "2023-07-04", "precipitation_mm": -9999.0, "quality_index": 0.0}, # Missing fill value
    {"date": "2023-07-05", "precipitation_mm": 5.1, "quality_index": 0.97},
    {"date": "2023-07-06", "precipitation_mm": 0.2, "quality_index": 0.99},
    {"date": "2023-07-07", "precipitation_mm": 0.0, "quality_index": 0.99},
    {"date": "2023-07-08", "precipitation_mm": 0.0, "quality_index": 0.99},
    {"date": "2023-07-09", "precipitation_mm": 42.0, "quality_index": 0.89}, # Convective storm cell
    {"date": "2023-07-10", "precipitation_mm": 18.4, "quality_index": 0.94},
    {"date": "2023-07-11", "precipitation_mm": 2.0, "quality_index": 0.98},
    {"date": "2023-07-12", "precipitation_mm": 0.0, "quality_index": 0.99},
    {"date": "2023-07-13", "precipitation_mm": 0.0, "quality_index": 0.99},
    {"date": "2023-07-14", "precipitation_mm": 8.6, "quality_index": 0.96},
    {"date": "2023-07-15", "precipitation_mm": 1.2, "quality_index": 0.98},
]

def test_gpm_product_metadata_version_07():
    """Verify GPM IMERG Version 07 Final Run specification."""
    status = gpm_service.get_service_status()
    assert status["service"] == "NASA GPM"
    assert status["product"] == "GPM_3IMERGDF.07"
    assert "V07" in status["title"]
    
    meta = status["metadata"]
    assert "07" in meta["version"]
    assert "0.1°" in meta["spatial_resolution"]
    assert meta["units"] == "mm/day"
    assert "https://gpm.nasa.gov/data/directory" in meta["documentation"]
    assert "GPCC" in meta["gauge_calibration"]

def test_gpm_spatial_limitation_warning():
    """Verify that spatial limitations (~10 km grid cell) are explicitly declared."""
    status = gpm_service.get_service_status()
    warning = status["metadata"]["spatial_limitation_warning"]
    assert "0.1°" in warning or "10 km" in warning
    assert "Never claim" in warning or "much smaller" in warning

def test_gpm_unauthenticated_returns_auth_required_no_fake_data():
    """Rule enforcement: If credentials missing, must return auth_required without simulating data."""
    unauth_service = NASAGPMService()
    unauth_service.username = ""
    unauth_service.password = ""
    unauth_service.bearer_token = ""

    result = unauth_service.fetch_precipitation(
        lat=14.68,
        lng=77.60,
        use_cache=False
    )

    assert result["status"] == "auth_required"
    assert result["connected"] is False
    assert result["product"] == "GPM_3IMERGDF.07"
    assert "NASA Earthdata credentials not configured" in result["message"]
    assert result["evidence_object"] is None

def test_gpm_observation_processing_and_unit_conversion():
    """Verify conversion from daily mm/day to period total mm, annual rate, and monthly aggregation."""
    bbox = {"min_lat": 14.65, "min_lng": 77.55, "max_lat": 14.70, "max_lng": 77.65}
    processed = gpm_service.process_gpm_observations(
        lat=14.68,
        lng=77.60,
        observations=SAMPLE_GPM_OBSERVATIONS,
        start="2023-07-01",
        end="2023-07-15",
        polygon_bbox=bbox
    )

    assert processed["status"] == "success"
    assert processed["connected"] is True
    assert processed["product"] == "GPM_3IMERGDF.07"
    assert processed["requested_period"] == {"start_date": "2023-07-01", "end_date": "2023-07-15"}
    assert processed["actual_observation_period"] == {"start_date": "2023-07-01", "end_date": "2023-07-15"}
    assert processed["observation_period"]["valid_days"] == 14
    assert processed["source_units"] == "mm/day"

    # Total valid rainfall: 14.5 + 28.2 + 5.1 + 0.2 + 42.0 + 18.4 + 2.0 + 8.6 + 1.2 = 120.2 mm
    ev = processed["evidence_object"]
    stats = ev["statistics"]
    assert abs(stats["total_period_precipitation_mm"] - 120.2) < 0.2
    assert stats["max_single_day_rain_mm"] == 42.0 # Convective cell peak

    # Quality and missing value handling
    missing_info = ev["missing_data_info"]
    assert missing_info["missing_count"] == 1 # 1 fill value (-9999.0)
    assert missing_info["valid_count"] == 14
    assert missing_info["total_count"] == 15

    # Area sampling preserved
    assert ev["area_sampling_used"] is True
    assert ev["polygon_bbox"] == bbox

    # Monthly aggregation
    monthly = processed["monthly_rainfall"]
    assert len(monthly) >= 1
    jul_item = [m for m in monthly if m["month"] == "Jul"][0]
    # Monthly chart values are actual observed calendar-month totals, not
    # annualized totals divided by a fractional-year denominator.
    assert abs(jul_item["gpm_rain_mm"] - 120.2) < 0.2
    assert jul_item["year_month"] == "2023-07"
    assert jul_item["month_label"] == "Jul 2023"
    assert jul_item["observed_days"] == 14

def test_gpm_empty_observations_returns_no_data():
    """Rule enforcement: Empty observation payload returns no_data, not simulated data."""
    processed = gpm_service.process_gpm_observations(
        lat=14.68,
        lng=77.60,
        observations=[],
        start="2023-07-01",
        end="2023-07-15"
    )

    assert processed["status"] == "no_data"
    assert processed["evidence_object"] is None
    assert processed["monthly_rainfall"] == []
    assert processed["requested_period"] == {"start_date": "2023-07-01", "end_date": "2023-07-15"}
    assert processed["actual_observation_period"] == {"start_date": None, "end_date": None}
    assert processed["observation_period"]["valid_days"] == 0

def test_compare_gpm_with_power_and_explain_differences():
    """Verify comparison with NASA POWER precipitation and scientific explanations of divergence."""
    gpm_rain = 745.0
    power_rain = 680.0

    comparison = gpm_service.compare_with_power(gpm_rain, power_rain)
    summary = comparison["comparison_summary"]

    assert summary["gpm_annual_rainfall_mm"] == 745.0
    assert summary["power_annual_rainfall_mm"] == 680.0
    assert summary["difference_mm"] == 65.0
    assert summary["concordance"] == "High" # (65 / 680) * 100 = ~9.6% (< 10%)

    # Verify 3 scientific explanations are present
    factors = comparison["scientific_explanation_of_differences"]
    assert len(factors) == 3
    factor_titles = [f["factor"] for f in factors]
    assert any("Physical Measurement" in t for t in factor_titles)
    assert any("Spatial Grid Differences" in t for t in factor_titles)
    assert any("Light Rain" in t for t in factor_titles)

    # Verify agronomic recommendation
    assert "agronomic_recommendation" in comparison
    assert "NASA POWER" in comparison["agronomic_recommendation"]
    assert "GPM IMERG" in comparison["agronomic_recommendation"]

def test_gpm_sqlite_cache_persistence():
    """Verify that processed GPM data persists in SQLite cache and is retrieved on cache hit."""
    cache_key = "test_gpm_cache_key_anantapur"
    test_payload = {
        "status": "success",
        "product": "GPM_3IMERGDF.07",
        "annual_precipitation_mm": 725.4,
        "evidence_object": {"parameter_code": "GPM_IMERG_PRECIP", "actual_value": 725.4}
    }

    database.save_cached_gpm_data(
        cache_key=cache_key,
        lat=14.68,
        lng=77.60,
        start_date="2023-01-01",
        end_date="2023-12-31",
        product_version="07",
        response_data=test_payload
    )

    cached = database.get_cached_gpm_data(cache_key)
    assert cached is not None
    assert cached["_cache_hit"] is True
    assert cached["annual_precipitation_mm"] == 725.4

def test_gpm_query_api_endpoint_with_cache():
    """Verify /api/nasa/gpm/query FastAPI route with comparison with NASA POWER."""
    cache_key = gpm_service._generate_cache_key(
        lat=14.68,
        lng=77.60,
        start="2023-07-01",
        end="2023-07-15"
    )
    processed = gpm_service.process_gpm_observations(
        lat=14.68,
        lng=77.60,
        observations=SAMPLE_GPM_OBSERVATIONS,
        start="2023-07-01",
        end="2023-07-15"
    )
    database.save_cached_gpm_data(
        cache_key=cache_key,
        lat=14.68,
        lng=77.60,
        start_date="2023-07-01",
        end_date="2023-07-15",
        product_version="07",
        response_data=processed
    )

    req_payload = {
        "latitude": 14.68,
        "longitude": 77.60,
        "start_date": "2023-07-01",
        "end_date": "2023-07-15",
        "use_cache": True,
        "compare_with_power": True
    }
    response = client.post("/api/nasa/gpm/query", json=req_payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert data["product"] == "GPM_3IMERGDF.07"
    assert "power_comparison" in data


def test_gpm_hdf5_grid_extraction_point_and_bbox(tmp_path):
    """Read actual IMERG-like HDF5 grid cells rather than accepting empty metadata results."""
    import h5py
    import numpy as np

    granule = tmp_path / "sample_imerg_daily.nc4"
    with h5py.File(granule, "w") as data:
        grid = data.create_group("Grid")
        grid.create_dataset("lat", data=np.array([14.6, 14.7], dtype="float32"))
        grid.create_dataset("lon", data=np.array([77.5, 77.6], dtype="float32"))
        grid.create_dataset(
            "precipitation",
            data=np.array([[[1.0, 2.0], [3.0, 4.0]]], dtype="float32")
        )

    point_value = NASAGPMService._extract_granule_precipitation(
        str(granule), 14.68, 77.60
    )
    assert point_value == 4.0

    bbox_value = NASAGPMService._extract_granule_precipitation(
        str(granule), 14.68, 77.60,
        {"min_lat": 14.59, "max_lat": 14.71, "min_lng": 77.49, "max_lng": 77.61}
    )
    assert bbox_value == 2.5


def test_gpm_cmr_query_downloads_and_processes_real_granule(tmp_path, monkeypatch):
    """Mock the network boundary but exercise CMR->download->HDF5 extraction->evidence."""
    import h5py
    import numpy as np
    import requests

    granule_file = tmp_path / "daily.nc4"
    with h5py.File(granule_file, "w") as data:
        grid = data.create_group("Grid")
        grid.create_dataset("lat", data=np.array([14.7], dtype="float32"))
        grid.create_dataset("lon", data=np.array([77.6], dtype="float32"))
        grid.create_dataset("precipitation", data=np.array([[[12.5]]], dtype="float32"))
    payload = granule_file.read_bytes()

    class FakeResponse:
        status_code = 200
        def __init__(self, content=b"", json_data=None):
            self.content = content
            self._json_data = json_data or {}
        def json(self):
            return self._json_data
        def raise_for_status(self):
            return None
        def iter_content(self, chunk_size=1024 * 1024):
            yield self.content
        def close(self):
            return None

    def fake_get(url, params=None, headers=None, timeout=None, stream=False):
        if url.endswith("/granules.json"):
            return FakeResponse(json_data={"feed": {"entry": [{
                "time_start": "2023-07-01T00:00:00.000Z",
                "links": [{
                    "href": "https://example.test/GPM_3IMERGDF.07/daily.nc4",
                    "rel": "http://esipfed.org/ns/fedsearch/1.1/data#"
                }]
            }]}})
        raise AssertionError(f"Unexpected direct requests.get URL: {url}")

    monkeypatch.setattr(requests, "get", fake_get)
    monkeypatch.setattr(requests.Session, "get", lambda self, *a, **k: FakeResponse(payload))
    monkeypatch.setattr(database, "save_cached_gpm_data", lambda **kwargs: None)

    service = NASAGPMService()
    service.username = "test-user"
    service.password = "test-password"
    service.bearer_token = ""
    result = service._query_ges_disc_api(
        lat=14.68, lng=77.60, polygon_bbox=None,
        start="2023-07-01", end="2023-07-01", cache_key="test"
    )

    assert result["status"] == "success"
    assert result["connected"] is True
    assert result["granules_found"] == 1
    assert result["granules_downloaded"] == 1
    assert result["period_precipitation_mm"] == 12.5
    assert result["evidence_object"]["statistics"]["total_period_precipitation_mm"] == 12.5



def test_gpm_monthly_rainfall_keeps_calendar_years_separate_and_skips_missing():
    observations = [
        {"date": "2023-07-01", "precipitation_mm": 10.0},
        {"date": "2023-07-02", "precipitation_mm": None},
        {"date": "2024-07-01", "precipitation_mm": 20.0},
        {"date": "2024-07-02", "precipitation_mm": -9999.0},
    ]
    result = gpm_service.process_gpm_observations(
        lat=14.68, lng=77.60, observations=observations,
        start="2023-07-01", end="2024-07-02",
    )
    july = [item for item in result["monthly_rainfall"] if item["month"] == "Jul"]
    assert [item["year_month"] for item in july] == ["2023-07", "2024-07"]
    assert [item["gpm_rain_mm"] for item in july] == [10.0, 20.0]
    assert [item["observed_days"] for item in july] == [1, 1]
