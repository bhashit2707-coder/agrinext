"""Security regression tests for farmer authentication and farm ownership."""
import sys
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

BACKEND_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_DIR))

import database
from main import app


@pytest.fixture
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setattr(database, "DB_PATH", tmp_path / "auth_test.db")
    database.init_db()
    return database.DB_PATH


def test_registration_login_me_and_logout(isolated_db):
    client = TestClient(app)
    response = client.post("/api/auth/register", json={
        "full_name": "Test Farmer",
        "email": "farmer@example.com",
        "password": "StrongPassword123!",
        "role": "administrator"
    })
    assert response.status_code == 201
    assert response.json()["user"]["role"] == "farmer"
    assert "agrinext_session" in response.cookies
    stored_user = database.get_user_by_email("farmer@example.com")
    assert stored_user["password_hash"] != "StrongPassword123!"
    assert stored_user["password_hash"].startswith("pbkdf2_sha256$")
    assert "httponly" in response.headers.get("set-cookie", "").lower()

    me = client.get("/api/auth/me")
    assert me.status_code == 200
    assert me.json()["user"]["email"] == "farmer@example.com"

    logout = client.post("/api/auth/logout")
    assert logout.status_code == 200
    assert client.get("/api/auth/me").status_code == 401

    login = client.post("/api/auth/login", json={
        "email": "farmer@example.com",
        "password": "StrongPassword123!"
    })
    assert login.status_code == 200
    assert client.get("/api/auth/me").status_code == 200


def test_duplicate_registration_and_bad_password(isolated_db):
    client = TestClient(app)
    payload = {"full_name": "Test Farmer", "email": "same@example.com", "password": "StrongPassword123!"}
    assert client.post("/api/auth/register", json=payload).status_code == 201
    assert client.post("/api/auth/register", json=payload).status_code == 409
    assert client.post("/api/auth/login", json={"email": "same@example.com", "password": "wrong"}).status_code == 401


def test_farms_require_authentication_and_are_owner_scoped(isolated_db):
    client_a = TestClient(app)
    client_b = TestClient(app)
    for client, email in [(client_a, "a@example.com"), (client_b, "b@example.com")]:
        response = client.post("/api/auth/register", json={
            "full_name": "Farmer " + email[0].upper(),
            "email": email,
            "password": "StrongPassword123!"
        })
        assert response.status_code == 201

    user_a = database.get_user_by_email("a@example.com")
    user_b = database.get_user_by_email("b@example.com")
    farm_id = str(uuid.uuid4())
    database.save_farm({
        "id": farm_id,
        "owner_user_id": user_a["id"],
        "farm_name": "A Farm",
        "state_id": "andhra_pradesh",
        "district_id": "guntur",
        "mandal_id": "guntur_rural",
        "latitude": 16.3,
        "longitude": 80.4,
        "polygon_acreage": 1.0,
        "effective_acreage": 1.0,
        "boundary_geojson": {"type": "Polygon", "coordinates": []}
    })

    assert TestClient(app).get("/api/farms").status_code == 401
    assert [f["id"] for f in client_a.get("/api/farms").json()] == [farm_id]
    assert client_b.get(f"/api/farms/{farm_id}").status_code == 404
    assert client_b.delete(f"/api/farms/{farm_id}").status_code == 404
    assert database.get_farm_by_id(farm_id) is not None


def test_registration_rejects_short_password(isolated_db):
    client = TestClient(app)
    response = client.post("/api/auth/register", json={
        "full_name": "Test Farmer",
        "email": "short@example.com",
        "password": "short"
    })
    assert response.status_code == 422


def test_farmer_profile_is_scoped_to_farm_owner(isolated_db):
    client_a = TestClient(app)
    client_b = TestClient(app)
    for client, email in [(client_a, "profile-a@example.com"), (client_b, "profile-b@example.com")]:
        response = client.post("/api/auth/register", json={
            "full_name": "Profile Farmer",
            "email": email,
            "password": "StrongPassword123!"
        })
        assert response.status_code == 201

    owner = database.get_user_by_email("profile-a@example.com")
    farm_id = str(uuid.uuid4())
    database.save_farm({
        "id": farm_id,
        "owner_user_id": owner["id"],
        "farm_name": "Profile Farm",
        "state_id": "andhra_pradesh",
        "district_id": "anantapur",
        "mandal_id": "kalyandurg",
        "latitude": 14.68,
        "longitude": 77.60,
        "polygon_acreage": 1.0,
        "effective_acreage": 1.0,
        "boundary_geojson": {"type": "Polygon", "coordinates": []}
    })

    saved = client_a.post("/api/farmer-profile", json={
        "farm_id": farm_id,
        "soil_type": "Red Sandy Loam",
        "soil_ph": 6.8,
        "irrigation_source": "Rainfed",
        "farming_season": "Kharif"
    })
    assert saved.status_code == 200, saved.text
    assert client_b.get(f"/api/farmer-profile/{farm_id}").status_code == 404
    rejected = client_b.post("/api/farmer-profile", json={
        "farm_id": farm_id,
        "soil_type": "Red Sandy Loam",
        "irrigation_source": "Rainfed",
        "farming_season": "Kharif"
    })
    assert rejected.status_code == 404
