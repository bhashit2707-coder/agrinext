"""
Integration tests for AgriNext Recommendation Engine combining:
1. NASA Environmental Observations (POWER, SMAP, GPM)
2. Farmer-provided Soil Ground-Truth & Parcel Inputs (Soil type, pH, NPK, Irrigation, Crop History)
3. Local Agricultural Crop Knowledge (ANGRAU / ICAR Package of Practices)
"""

import sys
import uuid
from pathlib import Path
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
import database
import auth
import api.router as api_router
from recommendation.evidence_engine import UnifiedEvidenceService
from recommendation.rotation_engine import RotationEngine

client = TestClient(app)

# Protected NASA/recommendation API tests run as an authenticated farmer.
_test_user_id = str(uuid.uuid4())
_test_user_email = f"qa-{_test_user_id}@example.test"
database.create_user(_test_user_id, "QA Test Farmer", _test_user_email, auth.hash_password("TestPassword!123"))
client.cookies.set(auth.SESSION_COOKIE_NAME, auth.create_session_for_user(_test_user_id))


def _mock_recommendation_nasa_services(monkeypatch):
    """Keep recommendation endpoint tests deterministic and offline."""
    monkeypatch.setattr(api_router.power_service, "fetch_agroclimatology", lambda **kwargs: {
        "status": "success",
        "evidence_objects": [
            {"parameter_code": "PRECTOTCORR", "parameter_name": "Mean Annual Precipitation", "actual_value": 620.0, "unit": "mm/year"},
            {"parameter_code": "T2M", "parameter_name": "Temperature Profile at 2 Meters", "actual_value": 27.5,
             "statistics": {"mean_c": 27.5, "extreme_max_c": 36.4}, "unit": "°C"}
        ]
    })
    monkeypatch.setattr(api_router.smap_service, "fetch_surface_soil_moisture", lambda **kwargs: {"status": "not_configured"})
    monkeypatch.setattr(api_router.gpm_service, "fetch_precipitation", lambda **kwargs: {"status": "not_configured"})
evidence_service = UnifiedEvidenceService()
rotation_engine = RotationEngine()

# Mock NASA observation streams
MOCK_POWER_DATA = {
    "status": "success",
    "evidence_objects": [
        {
            "dataset_name": "NASA POWER Agroclimatology",
            "parameter_code": "PRECTOTCORR",
            "parameter_name": "Precipitation",
            "actual_value": 580.0,
            "unit": "mm/year",
            "spatial_resolution": "0.5° (~50 km)"
        },
        {
            "dataset_name": "NASA POWER Agroclimatology",
            "parameter_code": "T2M",
            "parameter_name": "Temperature Profile at 2 Meters",
            "actual_value": 27.5,
            "statistics": {"mean_c": 27.5, "extreme_max_c": 36.4},
            "unit": "°C",
            "spatial_resolution": "0.5° (~50 km)"
        }
    ]
}

MOCK_SMAP_DATA = {
    "status": "success",
    "product": "SPL3SMP_E.006",
    "regime": "deficit",
    "trend": "drying",
    "mean_moisture_m3_m3": 0.105,
    "evidence_object": {
        "dataset_name": "SMAP Enhanced L3 Radiometer Global Daily 9 km EASE-Grid Soil Moisture V006",
        "product_code": "SPL3SMP_E.006",
        "parameter_name": "Surface Volumetric Soil Moisture",
        "actual_value": 0.105,
        "unit": "m^3/m^3",
        "regime": "deficit",
        "trend_indicator": {"trend": "drying", "delta_m3_m3": -0.028},
        "spatial_resolution": "9 km x 9 km EASE-Grid 2.0 (~81 km² grid cell)"
    }
}

SAMPLE_CROPS = [
    {
        "id": "groundnut",
        "name": "Groundnut (Peanut)",
        "category": "Legume/Oilseed",
        "water_requirement_mm": [450, 650],
        "season": ["Kharif", "Rabi"],
        "drought_tolerance": "high",
        "flood_tolerance": "low",
        "nitrogen_impact": "fixing"
    },
    {
        "id": "paddy",
        "name": "Paddy (Rice)",
        "category": "Cereal",
        "water_requirement_mm": [950, 1400],
        "season": ["Kharif", "Rabi"],
        "drought_tolerance": "low",
        "flood_tolerance": "high",
        "nitrogen_impact": "depleting"
    },
    {
        "id": "cotton",
        "name": "Cotton",
        "category": "Cash Crop / Fiber",
        "water_requirement_mm": [700, 1000],
        "season": ["Kharif"],
        "drought_tolerance": "moderate",
        "flood_tolerance": "low",
        "nitrogen_impact": "depleting"
    }
]

def test_recommendation_with_farmer_ground_truth_and_nasa_evidence():
    """Verify integration of NASA satellite observations, farmer parcel soil, and ANGRAU rotation rules."""
    farmer_profile = {
        "soil_type": "Red Sandy Loam",
        "soil_ph": 6.8,
        "nitrogen_kg_ha": 130.0,
        "irrigation_source": "Rainfed",
        "farming_season": "Kharif",
        "current_crop": "paddy", # previous depleter
        "previous_crops": ["paddy"],
        "preferred_crops": ["groundnut"],
        "soil_source_type": "farmer_measured"
    }

    dossier = evidence_service.build_unified_dossier(
        lat=14.68,
        lng=77.60,
        power_data=MOCK_POWER_DATA,
        smap_data=MOCK_SMAP_DATA,
        farmer_profile=farmer_profile
    )

    result = evidence_service.evaluate_crop_suitability(
        crops=SAMPLE_CROPS,
        crop_rules=[],
        dossier=dossier,
        farmer_profile=farmer_profile
    )

    evaluated = result["evaluated_crops"]
    groundnut = [c for c in evaluated if c["crop_id"] == "groundnut"][0]
    paddy = [c for c in evaluated if c["crop_id"] == "paddy"][0]

    # Groundnut must score high: matches Red Sandy Loam + drought-tolerant under SMAP deficit + legume after paddy
    assert groundnut["suitability_score"] >= 85.0

    # Paddy must score very low: rainfed under 580mm rain + SMAP deficit + soil mismatch
    assert paddy["suitability_score"] < 40.0

    # Citations must explicitly distinguish provenance tags
    citations_text = " ".join(groundnut["evidence_citations"])
    assert "[NASA Observation]" in citations_text
    assert "[Farmer Ground-Truth Soil]" in citations_text
    assert "[ANGRAU Crop Knowledge]" in citations_text

def test_api_generate_recommendations_with_farmer_profile(monkeypatch):
    """Verify POST /api/recommendations/generate with full farmer profile inputs."""
    _mock_recommendation_nasa_services(monkeypatch)
    req_payload = {
        "state_id": "andhra_pradesh",
        "latitude": 14.68,
        "longitude": 77.60,
        "use_cache": True,
        "farmer_profile": {
            "soil_type": "Deep Black Cotton Soil",
            "soil_ph": 7.9,
            "irrigation_source": "Borewell",
            "farming_season": "Kharif",
            "current_crop": "cotton",
            "previous_crops": ["cotton"],
            "preferred_crops": ["bengal_gram", "red_gram"],
            "soil_source_type": "agricultural_benchmark"
        }
    }

    res = client.post("/api/recommendations/generate", json=req_payload)
    assert res.status_code == 200
    data = res.json()
    assert "evaluated_crops" in data
    assert len(data["evaluated_crops"]) >= 3
    assert "provenance_summary" in data
    assert "agricultural_benchmark" in data["provenance_summary"]["farmer_soil_data_source"]
    assert "ANGRAU" in data["provenance_summary"]["agricultural_knowledge_authority"]
