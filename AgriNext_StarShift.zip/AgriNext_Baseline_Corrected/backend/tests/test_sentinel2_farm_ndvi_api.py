"""Authenticated API tests for farm-level Sentinel-2 NDVI processing."""
import sys
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

BACKEND_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_DIR))

import database
from main import app
from api import router as api_router


@pytest.fixture
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setattr(database, "DB_PATH", tmp_path / "sentinel2_api_test.db")
    database.init_db()


def _register(client, email):
    response = client.post("/api/auth/register", json={
        "full_name": "Sentinel Test Farmer",
        "email": email,
        "password": "StrongPassword123!",
    })
    assert response.status_code == 201, response.text
    return response.json()["user"]


def _save_farm(owner_id):
    farm_id = str(uuid.uuid4())
    database.save_farm({
        "id": farm_id,
        "owner_user_id": owner_id,
        "farm_name": "NDVI Test Farm",
        "state_id": "andhra_pradesh",
        "district_id": "guntur",
        "mandal_id": "guntur_rural",
        "latitude": 16.3,
        "longitude": 80.4,
        "polygon_acreage": 1.0,
        "effective_acreage": 1.0,
        "boundary_geojson": {
            "type": "Polygon",
            "coordinates": [[[80.40, 16.30], [80.41, 16.30], [80.41, 16.31],
                              [80.40, 16.31], [80.40, 16.30]]],
        },
    })
    return farm_id


def test_farm_ndvi_requires_authentication_and_owner_scope(isolated_db):
    owner_client = TestClient(app)
    other_client = TestClient(app)
    owner = _register(owner_client, "ndvi-owner@example.com")
    _register(other_client, "ndvi-other@example.com")
    farm_id = _save_farm(owner["id"])
    path = f"/api/earth-observation/sentinel-2/farms/{farm_id}/ndvi"

    assert TestClient(app).post(path, json={}).status_code == 401
    assert other_client.post(path, json={}).status_code == 404


def test_farm_ndvi_returns_processing_result_for_owner(isolated_db, monkeypatch):
    client = TestClient(app)
    owner = _register(client, "ndvi-success@example.com")
    farm_id = _save_farm(owner["id"])
    expected = {
        "status": "success",
        "source": "Copernicus Data Space Ecosystem",
        "index": "NDVI",
        "ndvi": {"mean": 0.61, "min": 0.42, "max": 0.79},
        "valid_pixel_count": 81,
        "valid_coverage_percent": 90.0,
    }
    calls = {}

    def fake_analyze_farm(**kwargs):
        calls.update(kwargs)
        return expected

    monkeypatch.setattr(api_router.sentinel2_processing_service, "analyze_farm", fake_analyze_farm)
    response = client.post(
        f"/api/earth-observation/sentinel-2/farms/{farm_id}/ndvi",
        json={"start_date": "2026-09-01", "end_date": "2026-10-15", "max_cloud_cover": 35},
    )

    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["farm_id"] == farm_id
    assert payload["farm_name"] == "NDVI Test Farm"
    assert payload["result"] == expected
    assert calls["boundary_geojson"]["type"] == "Polygon"
    assert calls["start_date"] == "2026-09-01"
    assert calls["end_date"] == "2026-10-15"
    assert calls["max_cloud_cover"] == 35.0


def test_farm_ndvi_maps_invalid_date_or_geometry_to_422(isolated_db, monkeypatch):
    client = TestClient(app)
    owner = _register(client, "ndvi-invalid@example.com")
    farm_id = _save_farm(owner["id"])

    def invalid_geometry(**kwargs):
        raise ValueError("Farm boundary must be a GeoJSON Polygon or MultiPolygon")

    monkeypatch.setattr(api_router.sentinel2_processing_service, "analyze_farm", invalid_geometry)
    response = client.post(
        f"/api/earth-observation/sentinel-2/farms/{farm_id}/ndvi", json={}
    )
    assert response.status_code == 422
    assert "GeoJSON Polygon" in response.json()["detail"]
