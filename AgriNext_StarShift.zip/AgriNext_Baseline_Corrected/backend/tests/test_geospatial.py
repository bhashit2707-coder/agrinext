"""
Unit and integration tests for AgriNext Farm Location and Geospatial module.
Tests geodesic area in acres, centroid calculation, manual acreage discrepancy warnings,
and SQLite farm persistence.
"""

import sys
from pathlib import Path
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
import database
import auth
import uuid
from geospatial.polygon_analysis import (
    calculate_geodesic_polygon_area_acres,
    calculate_polygon_centroid,
    analyze_farm_boundary
)

client = TestClient(app)

# Sample 100m x 100m square polygon (~10,000 m2 = ~2.471 acres) in Anantapur, AP
# Coordinates in [lng, lat]
SAMPLE_POLYGON = {
    "type": "Polygon",
    "coordinates": [
        [
            [77.6000, 14.6800],
            [77.6010, 14.6800],
            [77.6010, 14.6810],
            [77.6000, 14.6810],
            [77.6000, 14.6800]
        ]
    ]
}

def test_geodesic_area_calculation():
    coords = SAMPLE_POLYGON["coordinates"][0]
    acres = calculate_geodesic_polygon_area_acres(coords)
    # 0.001 deg lat ~ 111m, 0.001 deg lng ~ 107m -> area ~ 11,877 m2 -> ~2.93 acres
    assert 2.5 <= acres <= 3.5
    assert isinstance(acres, float)

def test_centroid_calculation():
    coords = SAMPLE_POLYGON["coordinates"][0]
    centroid = calculate_polygon_centroid(coords)
    assert abs(centroid["lng"] - 77.6005) < 0.0002
    assert abs(centroid["lat"] - 14.6805) < 0.0002

def test_get_mandals_for_state_and_filter():
    # All AP mandals
    res = client.get("/api/states/andhra_pradesh/mandals")
    assert res.status_code == 200
    all_mandals = res.json()
    assert len(all_mandals) >= 20

    # Filter by Anantapur district
    res_filtered = client.get("/api/states/andhra_pradesh/mandals?district_id=anantapur")
    assert res_filtered.status_code == 200
    atp_mandals = res_filtered.json()
    assert len(atp_mandals) >= 3
    for m in atp_mandals:
        assert m["district_id"] == "anantapur"

def test_analyze_polygon_endpoint():
    payload = {
        "boundary_geojson": SAMPLE_POLYGON,
        "manual_acreage": 5.0 # Deliberately higher to test discrepancy warning
    }
    response = client.post("/api/geospatial/analyze-polygon", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert data["polygon_acreage"] > 0
    assert data["manual_acreage"] == 5.0
    assert data["discrepancy_warning"] is not None
    assert "Notice: Declared manual acreage" in data["discrepancy_warning"]
    assert "centroid" in data
    assert "nasa_targets" in data
    assert "power_point_target" in data["nasa_targets"]
    assert "area_target" in data["nasa_targets"]

def test_save_and_retrieve_farm():
    user = database.get_user_by_email("geospatial-test@agrinext.local")
    if not user:
        user = database.create_user(str(uuid.uuid4()), "Geospatial Test Farmer", "geospatial-test@agrinext.local", auth.hash_password("TestPassword123!"))
    client.cookies.set("agrinext_session", auth.create_session_for_user(user["id"]))
    payload = {
        "farm_name": "Kalyandurg Test Plot",
        "state_id": "andhra_pradesh",
        "district_id": "anantapur",
        "mandal_id": "kalyandurg",
        "boundary_geojson": SAMPLE_POLYGON,
        "manual_acreage": 3.0
    }
    # Save farm
    create_res = client.post("/api/farms", json=payload)
    assert create_res.status_code == 201
    save_data = create_res.json()
    assert save_data["status"] == "saved"
    farm = save_data["farm"]
    farm_id = farm["id"]
    assert farm["farm_name"] == "Kalyandurg Test Plot"
    assert farm["district_id"] == "anantapur"
    assert farm["mandal_id"] == "kalyandurg"
    assert farm["latitude"] > 0
    assert farm["longitude"] > 0
    assert farm["polygon_acreage"] > 0
    assert "nasa_query_targets" in save_data

    # Retrieve farm by ID
    get_res = client.get(f"/api/farms/{farm_id}")
    assert get_res.status_code == 200
    retrieved = get_res.json()
    assert retrieved["id"] == farm_id
    assert retrieved["mandal_id"] == "kalyandurg"

    # List farms
    list_res = client.get("/api/farms")
    assert list_res.status_code == 200
    farms_list = list_res.json()
    assert any(f["id"] == farm_id for f in farms_list)

    # Delete farm
    del_res = client.delete(f"/api/farms/{farm_id}")
    assert del_res.status_code == 200
    assert del_res.json()["status"] == "deleted"

    # Confirm deleted
    assert client.get(f"/api/farms/{farm_id}").status_code == 404
