"""
Unit and integration tests for NASA SMAP Service.
Validates SPL3SMP_E Version 6 product identification, area sampling,
quality flag preservation, missing value handling, grid resolution (9 km),
soil-moisture trend indicator, spatial limitation disclaimers,
unauthenticated status transparency (no simulated data substituted),
and SQLite persistent caching.
"""

import sys
import uuid
from pathlib import Path
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
import auth
from nasa.smap import NASASMAPService, PRODUCT_SHORT_NAME, PRODUCT_VERSION, FILL_VALUE
import database

client = TestClient(app)

# Protected NASA/recommendation API tests run as an authenticated farmer.
_test_user_id = str(uuid.uuid4())
_test_user_email = f"qa-{_test_user_id}@example.test"
database.create_user(_test_user_id, "QA Test Farmer", _test_user_email, auth.hash_password("TestPassword!123"))
client.cookies.set(auth.SESSION_COOKIE_NAME, auth.create_session_for_user(_test_user_id))
smap_service = NASASMAPService()

# Sample real-world SMAP observations (0-5 cm volumetric moisture in m^3/m^3)
SAMPLE_SMAP_OBSERVATIONS = [
    {"date": "2023-01-01", "soil_moisture": 0.145, "quality_flag": 8},
    {"date": "2023-01-02", "soil_moisture": 0.140, "quality_flag": 8},
    {"date": "2023-01-03", "soil_moisture": -9999.0, "quality_flag": 7}, # Missing fill value
    {"date": "2023-01-04", "soil_moisture": 0.138, "quality_flag": 8},
    {"date": "2023-01-05", "soil_moisture": 0.135, "quality_flag": 8},
    {"date": "2023-01-06", "soil_moisture": 0.130, "quality_flag": 8},
    {"date": "2023-01-07", "soil_moisture": 0.125, "quality_flag": 8},
    {"date": "2023-01-08", "soil_moisture": 0.120, "quality_flag": 8},
    {"date": "2023-01-09", "soil_moisture": 0.115, "quality_flag": 8},
    {"date": "2023-01-10", "soil_moisture": 0.110, "quality_flag": 8},
    {"date": "2023-01-11", "soil_moisture": 0.105, "quality_flag": 8},
    {"date": "2023-01-12", "soil_moisture": 0.100, "quality_flag": 8},
    {"date": "2023-01-13", "soil_moisture": 0.095, "quality_flag": 8},
    {"date": "2023-01-14", "soil_moisture": 0.090, "quality_flag": 8},
    {"date": "2023-01-15", "soil_moisture": 0.088, "quality_flag": 8},
]

def test_smap_product_metadata_version_6():
    """Verify SPL3SMP_E Version 6 product specification."""
    status = smap_service.get_service_status()
    assert status["service"] == "NASA SMAP"
    assert status["product"] == "SPL3SMP_E.006"
    assert "Version 6" in status["title"] or "V006" in status["title"]
    
    meta = status["metadata"]
    assert meta["version"] == "6"
    assert "9 km" in meta["spatial_resolution"]
    assert meta["units"] == "m^3/m^3 (volumetric fraction)"
    assert meta["fill_value"] == -9999.0
    assert "https://nsidc.org/data/spl3smp_e/versions/6" in meta["documentation"]

def test_smap_spatial_limitation_warning():
    """Verify that spatial limitations (~9 km grid cell vs farm parcel) are explicitly declared."""
    status = smap_service.get_service_status()
    warning = status["metadata"]["spatial_limitation_warning"]
    assert "9 km" in warning
    assert "Never claim" in warning or "much smaller" in warning

def test_smap_unauthenticated_returns_auth_required_no_fake_data():
    """Rule enforcement: If credentials missing, must return auth_required without simulating data."""
    # Create service instance without credentials
    unauth_service = NASASMAPService()
    unauth_service.username = ""
    unauth_service.password = ""
    unauth_service.bearer_token = ""

    result = unauth_service.fetch_surface_soil_moisture(
        lat=14.68,
        lng=77.60,
        use_cache=False
    )

    assert result["status"] == "auth_required"
    assert result["connected"] is False
    assert result["product"] == "SPL3SMP_E.006"
    assert "NASA Earthdata credentials not configured" in result["message"]
    assert result["evidence_object"] is None

def test_smap_observation_processing_and_missing_values():
    """Verify filtering of -9999.0 fill values and computation of statistics & quality flags."""
    bbox = {"min_lat": 14.65, "min_lng": 77.55, "max_lat": 14.70, "max_lng": 77.65}
    processed = smap_service.process_smap_observations(
        lat=14.68,
        lng=77.60,
        observations=SAMPLE_SMAP_OBSERVATIONS,
        start="2023-01-01",
        end="2023-01-15",
        polygon_bbox=bbox
    )

    assert processed["status"] == "success"
    assert processed["connected"] is True
    assert processed["product"] == "SPL3SMP_E.006"
    
    # Missing value handling: 1 missing out of 15
    q_summary = processed["quality_summary"]
    assert q_summary["missing_count"] == 1
    assert q_summary["valid_count"] == 14
    assert q_summary["fill_value"] == FILL_VALUE
    assert q_summary["missing_percentage"] > 0.0

    # Area sampling preserved
    ev = processed["evidence_object"]
    assert ev["area_sampling_used"] is True
    assert ev["polygon_bbox"] == bbox

    # Resolution & Retrieval Date
    assert "9 km" in ev["spatial_resolution"]
    assert "retrieval_time" in ev

def test_smap_soil_moisture_trend_and_regime():
    """Verify detection of drying trend and regime classification."""
    processed = smap_service.process_smap_observations(
        lat=14.68,
        lng=77.60,
        observations=SAMPLE_SMAP_OBSERVATIONS,
        start="2023-01-01",
        end="2023-01-15"
    )

    ev = processed["evidence_object"]
    trend_data = ev["trend_indicator"]
    assert trend_data["trend"] == "drying"
    assert trend_data["delta_m3_m3"] < 0
    assert "drying" in trend_data["interpretation"]

    # Mean moisture is ~0.117 m^3/m^3 -> classified as deficit (< 0.12)
    assert processed["regime"] == "deficit"
    assert "moisture stress" in ev["regime_description"]

def test_smap_empty_observations_returns_no_data():
    """Rule enforcement: Empty observation payload returns no_data, not fabricated numbers."""
    processed = smap_service.process_smap_observations(
        lat=14.68,
        lng=77.60,
        observations=[],
        start="2023-01-01",
        end="2023-01-15"
    )

    assert processed["status"] == "no_data"
    assert processed["evidence_object"] is None
    assert processed["recent_readings"] == []

def test_smap_sqlite_cache_persistence():
    """Verify that processed SMAP data persists in SQLite cache and is retrieved on cache hit."""
    cache_key = "test_smap_cache_key_anantapur"
    test_payload = {
        "status": "success",
        "product": "SPL3SMP_E.006",
        "mean_moisture_m3_m3": 0.185,
        "evidence_object": {"parameter_code": "SPL3SMP_E_SM", "actual_value": 0.185}
    }

    database.save_cached_smap_data(
        cache_key=cache_key,
        lat=14.68,
        lng=77.60,
        start_date="2023-01-01",
        end_date="2023-01-15",
        product_version="006",
        response_data=test_payload
    )

    cached = database.get_cached_smap_data(cache_key)
    assert cached is not None
    assert cached["_cache_hit"] is True
    assert cached["mean_moisture_m3_m3"] == 0.185

def test_smap_query_api_endpoint_with_cache():
    """Verify /api/nasa/smap/query FastAPI route."""
    cache_key = smap_service._generate_cache_key(
        lat=14.68,
        lng=77.60,
        start="2023-01-01",
        end="2023-01-15"
    )
    processed = smap_service.process_smap_observations(
        lat=14.68,
        lng=77.60,
        observations=SAMPLE_SMAP_OBSERVATIONS,
        start="2023-01-01",
        end="2023-01-15"
    )
    database.save_cached_smap_data(
        cache_key=cache_key,
        lat=14.68,
        lng=77.60,
        start_date="2023-01-01",
        end_date="2023-01-15",
        product_version="006",
        response_data=processed
    )

    req_payload = {
        "latitude": 14.68,
        "longitude": 77.60,
        "start_date": "2023-01-01",
        "end_date": "2023-01-15",
        "use_cache": True
    }
    response = client.post("/api/nasa/smap/query", json=req_payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert data["product"] == "SPL3SMP_E.006"
    assert data["evidence_object"] is not None


def test_appeears_layer_discovery_and_csv_parser():
    """AppEEARS layer names and downloaded result CSV are mapped to real observations."""
    catalog = {
        # Albedo appears first and shares the AM group prefix; it must never
        # be mistaken for the soil-moisture science variable.
        "Soil_Moisture_Retrieval_Data_AM_albedo": {"Units": "unitless"},
        "Soil_Moisture_Retrieval_Data_AM_soil_moisture": {"Units": "m^3/m^3"},
        "Soil_Moisture_Retrieval_Data_AM_retrieval_qual_flag": {"Units": "bit field"},
        "Soil_Moisture_Retrieval_Data_PM_soil_moisture_pm": {"Units": "m^3/m^3"},
    }
    moisture_layer = smap_service._find_appeears_layer(
        catalog, ("soil_moisture",), "Soil_Moisture_Retrieval_Data_AM"
    )
    quality_layer = smap_service._find_appeears_layer(
        catalog, ("retrieval_qual_flag",), "Soil_Moisture_Retrieval_Data_AM"
    )
    assert moisture_layer == "Soil_Moisture_Retrieval_Data_AM_soil_moisture"
    assert quality_layer == "Soil_Moisture_Retrieval_Data_AM_retrieval_qual_flag"

    csv_bytes = (
        "Date,Latitude,Longitude,Category,"
        "SPL3SMP_E_006_Soil_Moisture_Retrieval_Data_AM_soil_moisture,"
        "SPL3SMP_E_006_Soil_Moisture_Retrieval_Data_AM_retrieval_qual_flag\n"
        "2023-12-04,14.68,77.60,AgriNext,0.19,8\n"
        "2023-12-05,14.68,77.60,AgriNext,0.21,8\n"
        "2023-12-06,14.68,77.60,AgriNext,0.23,7\n"
    ).encode("utf-8")
    observations = smap_service._parse_appeears_smap_csv(
        csv_bytes, moisture_layer, quality_layer
    )
    assert observations == [
        {"date": "2023-12-04", "soil_moisture": 0.19, "quality_flag": 8, "quality_description": None, "recommended_quality": True},
        {"date": "2023-12-05", "soil_moisture": 0.21, "quality_flag": 8, "quality_description": None, "recommended_quality": True},
        {"date": "2023-12-06", "soil_moisture": 0.23, "quality_flag": 7, "quality_description": None, "recommended_quality": False},
    ]


def test_appeears_live_point_workflow_downloads_and_processes_csv(monkeypatch):
    """Exercise AppEEARS login/task/status/bundle/download flow without network calls."""
    class FakeResponse:
        def __init__(self, payload=None, content=b"", status_code=200, text=""):
            self._payload = payload or {}
            self.content = content
            self.status_code = status_code
            self.text = text

        def json(self):
            return self._payload

        def raise_for_status(self):
            if self.status_code >= 400:
                raise RuntimeError(f"HTTP {self.status_code}: {self.text}")

    service = NASASMAPService()
    service.bearer_token = "test-token"
    csv_bytes = (
        "Date,Latitude,Longitude,Category,"
        "SPL3SMP_E_006_Soil_Moisture_Retrieval_Data_AM_soil_moisture,"
        "SPL3SMP_E_006_Soil_Moisture_Retrieval_Data_AM_retrieval_qual_flag\n"
        "2023-12-04,14.68,77.60,AgriNext,0.18,8\n"
        "2023-12-05,14.68,77.60,AgriNext,0.20,8\n"
    ).encode("utf-8")

    def fake_post(url, **kwargs):
        assert url.endswith("/task")
        assert kwargs["json"]["task_type"] == "point"
        assert len(kwargs["json"]["params"]["layers"]) == 2
        selected_layers = [item["layer"] for item in kwargs["json"]["params"]["layers"]]
        assert "Soil_Moisture_Retrieval_Data_AM_soil_moisture" in selected_layers
        assert "Soil_Moisture_Retrieval_Data_AM_albedo" not in selected_layers
        return FakeResponse({"task_id": "mock-task-123"}, status_code=202)

    def fake_get(url, **kwargs):
        if "/product/" in url:
            return FakeResponse({
                "Soil_Moisture_Retrieval_Data_AM_albedo": {},
                "Soil_Moisture_Retrieval_Data_AM_soil_moisture": {},
                "Soil_Moisture_Retrieval_Data_AM_retrieval_qual_flag": {},
            })
        if url.endswith("/task/mock-task-123"):
            return FakeResponse({"status": "done"})
        if url.endswith("/bundle/mock-task-123"):
            return FakeResponse({"files": [{"file_name": "AgriNext-SMAP-results.csv", "file_id": "csv-1"}]})
        if url.endswith("/bundle/mock-task-123/csv-1"):
            return FakeResponse(content=csv_bytes)
        raise AssertionError(f"Unexpected URL: {url}")

    monkeypatch.setattr("nasa.smap.requests.post", fake_post)
    monkeypatch.setattr("nasa.smap.requests.get", fake_get)
    monkeypatch.setattr("nasa.smap.time.sleep", lambda _seconds: None)
    monkeypatch.setattr("nasa.smap.database.save_cached_smap_data", lambda **_kwargs: None)

    result = service._query_appeears_api(
        lat=14.68,
        lng=77.60,
        polygon_bbox=None,
        start="2023-12-04",
        end="2023-12-05",
        cache_key="test-cache-key"
    )
    assert result["status"] == "insufficient_data"
    assert result["is_live_query"] is True
    assert result["appeears_task_id"] == "mock-task-123"
    assert result["observation_period"]["valid_samples_count"] == 2
    assert result["observation_period"]["minimum_required_samples"] == 3
    assert result["evidence_object"] is None
    assert len(result["recent_readings"]) == 2


def test_smap_processor_excludes_nonrecommended_quality_flags():
    """Non-recommended SMAP retrievals must not contribute to reported soil moisture."""
    processed = smap_service.process_smap_observations(
        lat=14.68,
        lng=77.60,
        observations=[
            {"date": "2023-12-04", "soil_moisture": 0.20, "quality_flag": 8},
            {"date": "2023-12-05", "soil_moisture": 0.40, "quality_flag": 7},
        ],
        start="2023-12-04",
        end="2023-12-05"
    )
    assert processed["status"] == "insufficient_data"
    assert processed["observation_period"]["valid_samples_count"] == 1
    assert processed["observation_period"]["minimum_required_samples"] == 3
    assert processed["evidence_object"] is None
