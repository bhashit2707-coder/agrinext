import sys
from pathlib import Path

backend_dir = Path(__file__).resolve().parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

import database


def _prepare_db(tmp_path, monkeypatch):
    monkeypatch.setattr(database, "DB_PATH", tmp_path / "phase3_jobs.sqlite")
    database.init_db()
    database.create_user("qa-user", "QA Farmer", "qa-jobs@example.test", "pbkdf2$placeholder")


def test_nasa_job_lifecycle_is_persistent_and_owner_scoped(tmp_path, monkeypatch):
    _prepare_db(tmp_path, monkeypatch)
    job = database.create_nasa_job("job-1", "qa-user", "smap", {"latitude": 14.6, "longitude": 77.6})
    assert job["status"] == "queued"
    assert job["request"]["latitude"] == 14.6
    assert database.get_nasa_job("job-1", "someone-else") is None
    assert database.claim_queued_nasa_job("job-1", "qa-user") is True
    assert database.claim_queued_nasa_job("job-1", "qa-user") is False
    database.update_nasa_job("job-1", "succeeded", result={"status": "success", "samples": 3})
    finished = database.get_nasa_job("job-1", "qa-user")
    assert finished["status"] == "succeeded"
    assert finished["result"]["samples"] == 3
    assert finished["attempts"] == 1
    assert finished["completed_at"] is not None


def test_queued_nasa_job_can_be_cancelled_but_claim_prevents_late_cancel(tmp_path, monkeypatch):
    _prepare_db(tmp_path, monkeypatch)
    database.create_nasa_job("job-2", "qa-user", "power", {"latitude": 1, "longitude": 2})
    assert database.cancel_queued_nasa_job("job-2", "qa-user") is True
    assert database.claim_queued_nasa_job("job-2", "qa-user") is False
    database.create_nasa_job("job-3", "qa-user", "power", {"latitude": 1, "longitude": 2})
    assert database.claim_queued_nasa_job("job-3", "qa-user") is True
    assert database.cancel_queued_nasa_job("job-3", "qa-user") is False


def test_interrupted_jobs_are_marked_failed_on_restart(tmp_path, monkeypatch):
    _prepare_db(tmp_path, monkeypatch)
    database.create_nasa_job("job-4", "qa-user", "gpm", {"latitude": 1, "longitude": 2})
    assert database.recover_interrupted_nasa_jobs() == 1
    recovered = database.get_nasa_job("job-4", "qa-user")
    assert recovered["status"] == "failed"
    assert "server restart" in recovered["error_message"]


def test_job_submit_status_and_cancel_routes_are_authenticated_and_private(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    import auth
    from main import app
    import api.router as api_router

    _prepare_db(tmp_path, monkeypatch)
    token = auth.create_session_for_user("qa-user")
    submitted = []
    monkeypatch.setattr(api_router._nasa_job_executor, "submit", lambda fn, *args: submitted.append((fn, args)))
    client = TestClient(app)
    client.cookies.set(auth.SESSION_COOKIE_NAME, token)

    response = client.post("/api/nasa/jobs/smap", json={"latitude": 14.6, "longitude": 77.6})
    assert response.status_code == 202
    job_id = response.json()["job_id"]
    assert len(submitted) == 1
    status_response = client.get(f"/api/nasa/jobs/{job_id}")
    assert status_response.status_code == 200
    assert status_response.json()["status"] == "queued"
    assert "request" not in status_response.json()
    cancel_response = client.delete(f"/api/nasa/jobs/{job_id}")
    assert cancel_response.status_code == 200
    assert cancel_response.json()["status"] == "cancelled"

    other = TestClient(app)
    assert other.get(f"/api/nasa/jobs/{job_id}").status_code == 401
    assert client.get("/api/nasa/jobs/not-a-job").status_code == 404


def test_active_nasa_job_count_ignores_completed_jobs(tmp_path, monkeypatch):
    _prepare_db(tmp_path, monkeypatch)
    database.create_nasa_job("job-a", "qa-user", "power", {"latitude": 1, "longitude": 2})
    database.create_nasa_job("job-b", "qa-user", "smap", {"latitude": 1, "longitude": 2})
    assert database.count_active_nasa_jobs("qa-user") == 2
    database.update_nasa_job("job-a", "succeeded", result={"status": "success"})
    assert database.count_active_nasa_jobs("qa-user") == 1
