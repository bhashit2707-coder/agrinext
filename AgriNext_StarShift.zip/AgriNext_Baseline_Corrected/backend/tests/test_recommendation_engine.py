"""
Unit and Integration Tests for AgriNext Evidence-Based Crop Rotation Recommendation Engine.
Proves that:
1. Changing actual NASA rainfall inputs directly changes Water Suitability scores.
2. Changing NASA SMAP surface soil moisture regimes directly influences water scoring.
3. Changing NASA POWER temperature inputs (heat stress) directly changes Climate Suitability scores.
4. Changing ground-truth soil profiles and legume integration directly changes Soil-Health Potential scores.
5. Overall score strictly adheres to the normalized weighted sum formula:
   Overall = (Water * W_w + Soil * W_s + Climate * W_c + Local * W_l) / 100.
6. Missing datasets reduce evidence completeness without synthetic data substitution.
7. Complete, traceable Evidence Traces are generated for each rotation strategy.
"""

import sys
import uuid
import pytest
from pathlib import Path
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
import database
import auth
import api.router as api_router
from recommendation.scoring import RecommendationScorer
from recommendation.rotation_engine import RotationEngine
from recommendation.evidence_engine import UnifiedEvidenceService

client = TestClient(app)

# Protected NASA/recommendation API tests run as an authenticated farmer.
_test_user_id = str(uuid.uuid4())
_test_user_email = f"qa-{_test_user_id}@example.test"
database.create_user(_test_user_id, "QA Test Farmer", _test_user_email, auth.hash_password("TestPassword!123"))
client.cookies.set(auth.SESSION_COOKIE_NAME, auth.create_session_for_user(_test_user_id))


def _mock_recommendation_nasa_services(monkeypatch):
    """Keep recommendation endpoint tests deterministic and offline."""
    monkeypatch.setattr(api_router.power_service, "fetch_agroclimatology", lambda **kwargs: {
        "status": "success",
        "evidence_objects": [
            {"parameter_code": "PRECTOTCORR", "parameter_name": "Mean Annual Precipitation", "actual_value": 620.0, "unit": "mm/year"},
            {"parameter_code": "T2M", "parameter_name": "Temperature Profile at 2 Meters", "actual_value": 27.5,
             "statistics": {"mean_c": 27.5, "extreme_max_c": 36.4}, "unit": "°C"}
        ]
    })
    monkeypatch.setattr(api_router.smap_service, "fetch_surface_soil_moisture", lambda **kwargs: {"status": "not_configured"})
    monkeypatch.setattr(api_router.gpm_service, "fetch_precipitation", lambda **kwargs: {"status": "not_configured"})
scorer = RecommendationScorer()
rotation_engine = RotationEngine()
evidence_service = UnifiedEvidenceService()

SAMPLE_CROPS = [
    {
        "id": "groundnut",
        "name": "Groundnut",
        "category": "Legume / Oilseed",
        "water_requirement_mm": [450, 650],
        "season": ["Kharif", "Rabi"],
        "drought_tolerance": "high",
        "flood_tolerance": "low",
        "nitrogen_impact": "fixing",
        "crop_family": "Fabaceae",
        "heat_sensitivity": {"critical_temperature_celsius": 38.0, "rating": "Moderate"}
    },
    {
        "id": "paddy",
        "name": "Paddy (Rice)",
        "category": "Cereal",
        "water_requirement_mm": [950, 1400],
        "season": ["Kharif", "Rabi"],
        "drought_tolerance": "low",
        "flood_tolerance": "high",
        "nitrogen_impact": "depleting",
        "crop_family": "Poaceae",
        "heat_sensitivity": {"critical_temperature_celsius": 36.0, "rating": "High"}
    },
    {
        "id": "bengal_gram",
        "name": "Bengal Gram (Chickpea)",
        "category": "Pulse",
        "water_requirement_mm": [250, 350],
        "season": ["Rabi"],
        "drought_tolerance": "high",
        "flood_tolerance": "low",
        "nitrogen_impact": "fixing",
        "crop_family": "Fabaceae",
        "heat_sensitivity": {"critical_temperature_celsius": 34.0, "rating": "Moderate"}
    },
    {
        "id": "sorghum",
        "name": "Sorghum (Jowar)",
        "category": "Cereal / Millet",
        "water_requirement_mm": [400, 600],
        "season": ["Kharif", "Rabi"],
        "drought_tolerance": "high",
        "flood_tolerance": "low",
        "nitrogen_impact": "depleting",
        "crop_family": "Poaceae",
        "heat_sensitivity": {"critical_temperature_celsius": 40.0, "rating": "Low"}
    }
]

def test_changing_rainfall_changes_water_suitability():
    """Prove that varying rainfall directly alters water suitability scores."""
    # Scenario A: Arid / Low rainfall (400 mm)
    score_low, meta_low = scorer.compute_water_suitability(
        crops=SAMPLE_CROPS,
        effective_annual_rainfall_mm=400.0,
        irrigation_source="Rainfed"
    )

    # Scenario B: Plentiful / High rainfall (1000 mm)
    score_high, meta_high = scorer.compute_water_suitability(
        crops=SAMPLE_CROPS,
        effective_annual_rainfall_mm=1000.0,
        irrigation_source="Rainfed"
    )

    assert score_high > score_low
    assert score_high >= 80.0
    assert meta_high["supply_to_demand_ratio"] > meta_low["supply_to_demand_ratio"]
    assert meta_low["effective_rainfall_mm"] == 400.0
    assert meta_high["effective_rainfall_mm"] == 1000.0

def test_changing_smap_soil_moisture_regime_changes_water_score():
    """Prove that NASA SMAP surface moisture regime dynamically influences the water score."""
    # Under drought-tolerant rotation (Groundnut + Bengal Gram + Sorghum)
    drought_crops = [SAMPLE_CROPS[0], SAMPLE_CROPS[2], SAMPLE_CROPS[3]]

    score_deficit, _ = scorer.compute_water_suitability(
        crops=drought_crops,
        effective_annual_rainfall_mm=600.0,
        smap_soil_moisture=0.09,
        smap_regime="deficit",
        smap_trend="stable",
        irrigation_source="Rainfed"
    )

    score_surplus, _ = scorer.compute_water_suitability(
        crops=drought_crops,
        effective_annual_rainfall_mm=600.0,
        smap_soil_moisture=0.35,
        smap_regime="surplus",
        smap_trend="stable",
        irrigation_source="Rainfed"
    )

    # For drought-adapted crops sensitive to waterlogging (groundnut, chickpea), deficit regime receives higher relative adaptation score than surplus
    assert score_deficit > score_surplus

def test_changing_temperature_changes_climate_suitability():
    """Prove that elevated NASA POWER temperatures exceeding critical limits drop climate scores."""
    # Scenario A: Moderate temperature (max 32°C, well below all crop thresholds)
    score_cool, meta_cool = scorer.compute_climate_suitability(
        crops=SAMPLE_CROPS,
        t2m_avg=26.0,
        t2m_max=32.0,
        solar_radiation_mj=18.0
    )

    # Scenario B: Extreme heat wave (max 42°C, exceeding Groundnut 38°C, Paddy 36°C, Chickpea 34°C)
    score_hot, meta_hot = scorer.compute_climate_suitability(
        crops=SAMPLE_CROPS,
        t2m_avg=32.0,
        t2m_max=42.0,
        solar_radiation_mj=18.0
    )

    assert score_cool > score_hot
    assert meta_hot["heat_penalty_applied"] > 0.0
    assert score_hot < 70.0
    assert score_cool >= 80.0

def test_changing_soil_profile_changes_soil_health_score():
    """Prove that soil texture matching and legume integration directly change soil-health scores."""
    legume_rotation = [SAMPLE_CROPS[0], SAMPLE_CROPS[2]] # Groundnut + Bengal Gram (2 legumes)
    depleter_rotation = [SAMPLE_CROPS[1], SAMPLE_CROPS[3]] # Paddy + Sorghum (0 legumes)

    # Scenario A: 2 legumes on matching Red Sandy Loam with optimal pH
    farmer_profile_good = {
        "soil_type": "Red Sandy Loam",
        "soil_ph": 6.8,
        "organic_carbon_pct": 0.45,
        "previous_crops": ["paddy"]
    }

    score_legume, meta_legume = scorer.compute_soil_health_potential(
        crops=legume_rotation,
        farmer_profile=farmer_profile_good
    )

    # Scenario B: 0 legumes on depleted soil
    farmer_profile_depleted = {
        "soil_type": "Heavy Stiff Clay",
        "soil_ph": 8.6,
        "organic_carbon_pct": 0.30,
        "previous_crops": ["sorghum"]
    }

    score_depleter, meta_depleter = scorer.compute_soil_health_potential(
        crops=depleter_rotation,
        farmer_profile=farmer_profile_depleted
    )

    assert score_legume > score_depleter
    assert meta_legume["biological_nitrogen_credit_kg_ha"] >= 70.0
    assert meta_depleter["biological_nitrogen_credit_kg_ha"] == 0.0

def test_overall_score_weighted_sum_formula():
    """Prove that Overall Score strictly equals (Water*W_w + Soil*W_s + Climate*W_c + Local*W_l)/100."""
    water = 80.0
    soil = 90.0
    climate = 70.0
    local = 60.0

    # Custom weights totaling 100
    weights = {"water": 40.0, "soil": 30.0, "climate": 20.0, "local": 10.0}
    expected = (80.0 * 0.40) + (90.0 * 0.30) + (70.0 * 0.20) + (60.0 * 0.10) # 32 + 27 + 14 + 6 = 79.0

    overall, validated = scorer.compute_overall_score(water, soil, climate, local, weights)
    assert abs(overall - expected) < 0.1
    assert sum(validated.values()) == 100.0

def test_missing_data_reduces_evidence_completeness_without_fabrication():
    """Prove that missing NASA SMAP or GPM drops completeness without fabricating data."""
    # Complete dossier
    complete_dossier = {
        "dataset_status": {
            "nasa_power": {"connected": True},
            "nasa_smap": {"connected": True},
            "nasa_gpm": {"connected": True}
        }
    }
    farmer_prof = {
        "soil_type": "Red Sandy Loam",
        "soil_ph": 7.0,
        "nitrogen_value": 150.0,
        "organic_carbon_pct": 0.55,
        "irrigation_source": "Borewell"
    }

    comp_full = scorer.compute_evidence_completeness(complete_dossier, farmer_prof)
    assert comp_full["percentage"] == 100.0
    assert comp_full["available_indicators"] == 12

    # Partial dossier (SMAP and GPM unauthenticated)
    partial_dossier = {
        "dataset_status": {
            "nasa_power": {"connected": True},
            "nasa_smap": {"connected": False},
            "nasa_gpm": {"connected": False}
        }
    }
    comp_partial = scorer.compute_evidence_completeness(partial_dossier, farmer_prof)
    assert comp_partial["percentage"] < 100.0
    assert comp_partial["available_indicators"] == 10
    assert "NASA SMAP SPL3SMP_E V6 (Requires Earthdata Login)" in comp_partial["missing_sources"]
    assert "NASA GPM IMERG V07 (Requires Earthdata Login)" in comp_partial["missing_sources"]

def test_full_strategy_generation_and_evidence_trace():
    """Verify that RotationEngine generates all required fields for each strategy."""
    mock_dossier = {
        "dossier_id": "TEST_DOSSIER_001",
        "dataset_status": {
            "nasa_power": {"connected": True},
            "nasa_smap": {"connected": True},
            "nasa_gpm": {"connected": True}
        },
        "precipitation_synthesis": {
            "gpm_satellite_annual_mm": 680.0,
            "power_reanalysis_annual_mm": 640.0
        },
        "soil_water_balance": {
            "surface_moisture_m3_m3": 0.142,
            "regime": "deficit",
            "trend": "stable"
        },
        "evidence_items": [
            {"parameter_code": "PRECTOTCORR", "actual_value": 640.0},
            {"parameter_code": "T2M", "actual_value": 27.8, "statistics": {"mean_c": 27.8, "extreme_max_c": 36.5}},
            {"parameter_code": "ALLSKY_SFC_SW_DWN", "actual_value": 18.2},
            {"parameter_code": "RH2M", "actual_value": 65.0}
        ]
    }

    farmer_profile = {
        "soil_type": "Red Sandy Loam",
        "soil_ph": 6.8,
        "nitrogen_value": 140.0,
        "organic_carbon_pct": 0.48,
        "irrigation_source": "Rainfed",
        "farming_season": "Kharif",
        "current_crop": "paddy",
        "previous_crops": ["paddy"],
        "available_crops": ["groundnut", "bengal_gram", "sorghum", "maize"],
        "preferred_crops": ["groundnut"]
    }

    result = rotation_engine.generate_recommendations(
        crops=SAMPLE_CROPS,
        crop_rules=[],
        dossier=mock_dossier,
        farmer_profile=farmer_profile
    )

    strategies = result["strategies"]
    assert len(strategies) == 3

    for strat in strategies:
        # 1. Output requirements check
        assert "id" in strat
        assert "title" in strat
        assert "crop_sequence" in strat
        assert len(strat["crop_sequence"]) == 3
        assert "season" in strat
        assert "individual_scores" in strat
        assert "overall_score" in strat
        assert "weights" in strat
        assert "supporting_nasa_evidence" in strat
        assert "supporting_local_evidence" in strat
        assert "explanation" in strat
        assert "potential_risks" in strat
        assert "data_limitations" in strat
        assert "evidence_completeness" in strat
        assert "evidence_trace" in strat

        # 2. Score bounds check (0 to 100)
        scores = strat["individual_scores"]
        assert 0.0 <= scores["water_suitability"] <= 100.0
        assert 0.0 <= scores["soil_health_potential"] <= 100.0
        assert 0.0 <= scores["climate_suitability"] <= 100.0
        assert 0.0 <= scores["local_agricultural_suitability"] <= 100.0
        assert 0.0 <= strat["overall_score"] <= 100.0

        # 3. Evidence trace dimensions
        trace = strat["evidence_trace"]
        assert "dimensions" in trace
        assert "water_suitability" in trace["dimensions"]
        assert "climate_suitability" in trace["dimensions"]
        assert "soil_health_potential" in trace["dimensions"]
        assert "local_agricultural_suitability" in trace["dimensions"]

        # 4. Critical rule: Traceable explanation for each dimension
        for dim_name, dim_data in trace["dimensions"].items():
            assert "score" in dim_data
            assert "weight" in dim_data
            assert "weighted_contribution" in dim_data
            assert "supporting_evidence" in dim_data
            assert "derived_indicators" in dim_data
            assert "traceable_explanation" in dim_data
            assert "data_limitations" in dim_data

        # 5. Non-guarantee and limitations
        assert len(strat["potential_risks"]) >= 1
        assert len(strat["data_limitations"]) >= 1

def test_api_generate_recommendations_with_custom_weights(monkeypatch):
    """Verify POST /api/recommendations/generate with custom weights through HTTP endpoint."""
    _mock_recommendation_nasa_services(monkeypatch)
    payload = {
        "state_id": "andhra_pradesh",
        "latitude": 14.68,
        "longitude": 77.60,
        "use_cache": True,
        "farmer_profile": {
            "soil_type": "Red Sandy Loam",
            "soil_ph": 7.0,
            "irrigation_source": "Rainfed",
            "farming_season": "Kharif",
            "available_crops": ["groundnut", "bengal_gram", "sorghum"]
        },
        "weights": {
            "water": 40.0,
            "soil": 30.0,
            "climate": 15.0,
            "local": 15.0
        }
    }

    response = client.post("/api/recommendations/generate", json=payload)
    assert response.status_code == 200
    data = response.json()

    assert "strategies" in data
    assert len(data["strategies"]) == 3

    # Check that weights applied match the request
    strat1 = data["strategies"][0]
    assert strat1["weights"]["water"] == 40.0
    assert strat1["weights"]["soil"] == 30.0
    assert strat1["weights"]["climate"] == 15.0
    assert strat1["weights"]["local"] == 15.0
    assert "evidence_trace" in strat1

def test_dynamic_priority_recalculation_and_reordering():
    """Prove that changing priorities immediately recalculates scores and reorders strategies."""
    mock_strategies = [
        {
            "id": "climate_resilient",
            "title": "Maximum Climate Resilience",
            "individual_scores": {"water_suitability": 95.0, "soil_health_potential": 65.0, "climate_suitability": 90.0, "local_agricultural_suitability": 75.0}
        },
        {
            "id": "soil_restoration",
            "title": "Soil Health & Nutrient Regeneration",
            "individual_scores": {"water_suitability": 60.0, "soil_health_potential": 98.0, "climate_suitability": 70.0, "local_agricultural_suitability": 80.0}
        },
        {
            "id": "economic_balanced",
            "title": "Balanced Economic & Risk Diversification",
            "individual_scores": {"water_suitability": 80.0, "soil_health_potential": 80.0, "climate_suitability": 80.0, "local_agricultural_suitability": 85.0}
        }
    ]

    # Baseline: Equal 25% weights
    # Climate: (95 + 65 + 90 + 75) * 0.25 = 81.25 -> 81.3 (Rank 1)
    # Economic: (80 + 80 + 80 + 85) * 0.25 = 81.25 -> 81.3 (Rank 2)
    # Soil: (60 + 98 + 70 + 80) * 0.25 = 77.0 (Rank 3)
    base_res = rotation_engine.recalculate_scores(mock_strategies, {"water": 25.0, "soil": 25.0, "climate": 25.0, "local": 25.0})
    assert base_res["strategies"][0]["id"] == "climate_resilient"
    assert base_res["strategies"][2]["id"] == "soil_restoration"

    # Shift priority to Soil Health (60% soil, 10% water, 15% climate, 15% local)
    soil_weights = {"water": 10.0, "soil": 60.0, "climate": 15.0, "local": 15.0}
    recalculated = rotation_engine.recalculate_scores(mock_strategies, soil_weights)

    # Verification: Soil Restoration must immediately become Rank 1
    assert recalculated["strategies"][0]["id"] == "soil_restoration"
    assert recalculated["strategies"][0]["updated_rank"] == 1
    assert recalculated["strategies"][0]["baseline_rank"] == 3
    assert recalculated["strategies"][0]["rank_change"] == 2 # Moved up +2 positions
    assert recalculated["strategies"][0]["movement_direction"] == "up"

    # Verification: Climate Resilience drops to Rank 3
    strat3 = next(s for s in recalculated["strategies"] if s["id"] == "climate_resilient")
    assert strat3["updated_rank"] == 3
    assert strat3["baseline_rank"] == 1
    assert strat3["rank_change"] == -2
    assert strat3["movement_direction"] == "down"

def test_rank_movement_explanation_generation():
    """Prove that transparent plain-language explanations are produced from mathematical deltas."""
    mock_strategies = [
        {
            "id": "climate_resilient",
            "title": "Maximum Climate Resilience",
            "individual_scores": {"water_suitability": 95.0, "soil_health_potential": 65.0, "climate_suitability": 90.0, "local_agricultural_suitability": 75.0}
        },
        {
            "id": "soil_restoration",
            "title": "Soil Health & Nutrient Regeneration",
            "individual_scores": {"water_suitability": 60.0, "soil_health_potential": 98.0, "climate_suitability": 70.0, "local_agricultural_suitability": 80.0}
        }
    ]

    soil_weights = {"water": 10.0, "soil": 60.0, "climate": 15.0, "local": 15.0}
    recalculated = rotation_engine.recalculate_scores(mock_strategies, soil_weights)

    soil_strat = recalculated["strategies"][0]
    explanation = soil_strat["movement_explanation"]

    assert "Promoted from Rank #2 to Rank #1" in explanation
    assert "Soil-Health Potential" in explanation
    assert "+35.0%" in explanation or "+35%" in explanation

def test_api_recalculate_endpoint():
    """Verify POST /api/recommendations/recalculate endpoint via HTTP."""
    payload = {
        "strategies": [
            {
                "id": "climate_resilient",
                "title": "Maximum Climate Resilience",
                "individual_scores": {"water_suitability": 92.0, "soil_health_potential": 70.0, "climate_suitability": 88.0, "local_agricultural_suitability": 80.0}
            },
            {
                "id": "soil_restoration",
                "title": "Soil Health & Nutrient Regeneration",
                "individual_scores": {"water_suitability": 65.0, "soil_health_potential": 96.0, "climate_suitability": 72.0, "local_agricultural_suitability": 84.0}
            },
            {
                "id": "economic_balanced",
                "title": "Balanced Economic & Risk Diversification",
                "individual_scores": {"water_suitability": 78.0, "soil_health_potential": 82.0, "climate_suitability": 80.0, "local_agricultural_suitability": 86.0}
            }
        ],
        "weights": {
            "water": 15.0,
            "soil": 55.0,
            "climate": 15.0,
            "local": 15.0
        }
    }

    response = client.post("/api/recommendations/recalculate", json=payload)
    assert response.status_code == 200
    data = response.json()

    assert "strategies" in data
    assert len(data["strategies"]) == 3
    assert data["strategies"][0]["id"] == "soil_restoration"
    assert data["strategies"][0]["updated_rank"] == 1
    assert "ranking_comparison" in data
    assert len(data["ranking_comparison"]["rankings"]) == 3


def test_smap_actual_moisture_severity_changes_water_score():
    """Measured SMAP moisture, not just a caller-supplied regime label, affects scoring."""
    drought_crops = [SAMPLE_CROPS[0], SAMPLE_CROPS[2], SAMPLE_CROPS[3]]
    common = {
        "crops": drought_crops,
        "effective_annual_rainfall_mm": 600.0,
        "smap_trend": "stable",
        "irrigation_source": "Rainfed",
    }

    near_threshold, near_meta = scorer.compute_water_suitability(
        **common, smap_soil_moisture=0.115, smap_regime="deficit"
    )
    severe_deficit, severe_meta = scorer.compute_water_suitability(
        **common, smap_soil_moisture=0.03, smap_regime="deficit"
    )

    assert severe_deficit > near_threshold  # all sample crops are drought tolerant
    assert near_meta["smap_moisture_m3_m3"] == 0.115
    assert severe_meta["smap_moisture_severity"] > near_meta["smap_moisture_severity"]


def test_missing_or_invalid_smap_moisture_does_not_apply_smap_adjustment():
    """A regime label without a valid measured value must not create satellite evidence."""
    drought_crops = [SAMPLE_CROPS[0], SAMPLE_CROPS[2], SAMPLE_CROPS[3]]
    common = {
        "crops": drought_crops,
        "effective_annual_rainfall_mm": 600.0,
        "smap_regime": "deficit",
        "smap_trend": "drying",
        "irrigation_source": "Rainfed",
    }

    score_missing, meta_missing = scorer.compute_water_suitability(
        **common, smap_soil_moisture=None
    )
    score_invalid, meta_invalid = scorer.compute_water_suitability(
        **common, smap_soil_moisture=-9999.0
    )
    score_without_smap, _ = scorer.compute_water_suitability(
        crops=drought_crops,
        effective_annual_rainfall_mm=600.0,
        irrigation_source="Rainfed",
    )

    assert score_missing == score_without_smap
    assert score_invalid == score_without_smap
    assert meta_missing["smap_moisture_m3_m3"] is None
    assert meta_invalid["smap_regime"] == "not_available"
    assert meta_missing["smap_adjustment_applied"] == 0.0


def test_rotation_engine_reads_real_nasa_power_temperature_statistics():
    """NASA POWER supplies mean and extreme max under one T2M evidence object."""
    dossier = {
        "dataset_status": {"nasa_smap": {"connected": False}},
        "evidence_items": [
            {"parameter_code": "PRECTOTCORR", "actual_value": 610.0, "unit": "mm/year"},
            {
                "parameter_code": "T2M",
                "actual_value": 28.1,
                "statistics": {"mean_c": 28.1, "extreme_max_c": 39.2},
                "unit": "°C",
            },
        ],
    }
    result = rotation_engine.generate_recommendations(
        crops=SAMPLE_CROPS,
        crop_rules=[],
        dossier=dossier,
        farmer_profile={"irrigation_source": "Rainfed", "farming_season": "Kharif"},
    )
    climate = result["strategies"][0]["evidence_trace"]["dimensions"]["climate_suitability"]
    evidence_values = [item["observed_value"] for item in climate["supporting_evidence"]]
    assert 28.1 in evidence_values
    assert 39.2 in evidence_values


def test_rotation_engine_refuses_to_invent_missing_environmental_baseline():
    """Missing precipitation or temperature must stop recommendations, not use defaults."""
    dossier = {
        "dataset_status": {"nasa_smap": {"connected": False}},
        "evidence_items": [{"parameter_code": "PRECTOTCORR", "actual_value": 610.0}],
    }
    with pytest.raises(ValueError, match="Missing valid environmental observations"):
        rotation_engine.generate_recommendations(
            crops=SAMPLE_CROPS,
            crop_rules=[],
            dossier=dossier,
            farmer_profile=None,
        )


def test_rotation_engine_rejects_nasa_power_placeholder_with_zero_valid_days():
    dossier = {
        "dataset_status": {"nasa_smap": {"connected": False}},
        "evidence_items": [
            {"parameter_code": "PRECTOTCORR", "actual_value": 0.0, "missing_data_info": {"valid_count": 0}},
            {"parameter_code": "T2M", "actual_value": 0.0,
             "statistics": {"mean_c": 0.0, "extreme_max_c": 0.0},
             "missing_data_info": {"valid_count": 0}},
        ],
    }
    with pytest.raises(ValueError, match="Missing valid environmental observations"):
        rotation_engine.generate_recommendations(
            crops=SAMPLE_CROPS,
            crop_rules=[],
            dossier=dossier,
            farmer_profile=None,
        )
