import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))

from recommendation.season_planner import build_multi_season_plan


def sample_crops():
    return [
        {"id": "rice", "name": "Rice", "season": ["Kharif", "Rabi"], "water_requirement_mm": [900, 1400], "growth_days": [120, 150]},
        {"id": "chickpea", "name": "Chickpea", "season": ["Rabi"], "nitrogen_impact": "fixing"},
        {"id": "cotton", "name": "Cotton", "season": ["Kharif"]},
    ]


def test_builds_kharif_rabi_and_summer_seasons():
    result = build_multi_season_plan(sample_crops())
    assert [s["id"] for s in result["seasons"]] == ["Kharif", "Rabi", "Summer"]
    assert {c["crop_id"] for c in result["seasons"][0]["candidates"]} == {"rice", "cotton"}
    assert {c["crop_id"] for c in result["seasons"][1]["candidates"]} == {"rice", "chickpea"}
    assert result["seasons"][2]["status"] == "no_catalog_options"
    assert result["seasons"][2]["candidates"] == []


def test_excludes_current_and_previous_crops():
    result = build_multi_season_plan(sample_crops(), {"current_crop": "rice", "previous_crops": ["cotton"]})
    all_ids = {c["crop_id"] for season in result["seasons"] for c in season["candidates"]}
    assert "rice" not in all_ids
    assert "cotton" not in all_ids


def test_soil_match_is_optional_and_descriptive():
    result = build_multi_season_plan(sample_crops(), {"soil_type": "Clay Loam"})
    kharif = result["seasons"][0]
    assert all("soil_type_match" in crop for crop in kharif["candidates"])
    assert "not a field-specific agronomic prescription" in " ".join(result["limitations"])
