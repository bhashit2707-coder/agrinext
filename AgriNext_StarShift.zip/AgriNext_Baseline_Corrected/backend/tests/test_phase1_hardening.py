"""Regression tests for Phase 1 AgriNext security and integration-status fixes."""
from __future__ import annotations

import importlib.util
import runpy
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys

import pytest
from fastapi.testclient import TestClient

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

import database
from main import app
from nasa.smap import NASASMAPService

client = TestClient(app)


def test_database_initializes_clean_schema_at_configured_path(tmp_path, monkeypatch):
    db_file = tmp_path / "fresh-db" / "agrinext_test.db"
    monkeypatch.setattr(database, "DB_PATH", db_file)
    assert not db_file.exists()

    database.init_db()

    assert db_file.exists()
    with sqlite3.connect(db_file) as connection:
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"users", "user_sessions", "farms", "nasa_smap_cache"}.issubset(tables)


def test_smap_default_period_is_recent_and_explicit(monkeypatch):
    service = NASASMAPService()
    service.username = ""
    service.password = ""
    service.bearer_token = ""

    result = service.fetch_surface_soil_moisture(14.68, 77.60, use_cache=False)

    assert result["status"] == "auth_required"
    requested = result["requested_period"]
    assert requested["is_default"] is True
    start = datetime.fromisoformat(requested["start_date"]).date()
    end = datetime.fromisoformat(requested["end_date"]).date()
    expected_end = datetime.now(timezone.utc).date() - timedelta(days=7)
    assert end == expected_end
    assert (end - start).days == 29
    assert requested["start_date"] != "2023-12-04"
    assert result["observation_period"]["actual_start_date"] is None


def test_smap_rejects_reversed_date_range():
    service = NASASMAPService()
    with pytest.raises(ValueError, match="on or before"):
        service.fetch_surface_soil_moisture(
            14.68, 77.60, start_date="2026-11-10", end_date="2026-11-01", use_cache=False
        )


def test_smap_rejects_invalid_date_format():
    service = NASASMAPService()
    with pytest.raises(ValueError, match="YYYY-MM-DD"):
        service.fetch_surface_soil_moisture(
            14.68, 77.60, end_date="not-a-date", use_cache=False
        )


def test_smap_success_reports_requested_and_actual_observation_period():
    service = NASASMAPService()
    observations = [
        {"date": "2026-10-01", "soil_moisture": 0.18, "quality_flag": 8},
        {"date": "2026-10-04", "soil_moisture": 0.20, "quality_flag": 8},
        {"date": "2026-10-08", "soil_moisture": 0.22, "quality_flag": 8},
    ]
    result = service.process_smap_observations(
        14.68, 77.60, observations, "2026-10-01", "2026-10-31"
    )
    assert result["status"] == "success"
    assert result["requested_period"] == {"start_date": "2026-10-01", "end_date": "2026-10-31"}
    assert result["actual_observation_period"] == {"start_date": "2026-10-01", "end_date": "2026-10-08"}
    assert result["observation_period"]["samples_count"] == 3


def test_smap_no_data_reports_requested_period_and_actual_none():
    service = NASASMAPService()
    result = service.process_smap_observations(
        14.68, 77.60,
        [{"date": "2026-10-02", "soil_moisture": -9999.0, "quality_flag": 7}],
        "2026-10-01", "2026-10-31",
    )
    assert result["status"] == "no_data"
    assert result["requested_period"]["start_date"] == "2026-10-01"
    assert result["actual_observation_period"] == {"start_date": "2026-10-02", "end_date": "2026-10-02"}
    assert result["observation_period"]["valid_samples_count"] == 0


def test_nasa_services_endpoint_distinguishes_configuration_from_live_state():
    response = client.get("/api/nasa/services")
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "not_checked"
    assert payload["status_check_scope"] == "configuration_only"
    names = {item["service"] for item in payload["services"]}
    assert "NASA POWER" in names
    assert "NASA SMAP" in names
    assert "Sentinel-2 farm-polygon NDVI processing" in names
    assert "FAO GAEZ catalogue" in names
    for service in payload["services"]:
        assert "configured" in service
        assert "reachable" in service
        assert "authenticated" in service
        assert "data_available" in service
        assert service["reachable"] is None
        assert service["data_available"] is None
        assert service["status_check_scope"] == "configuration_only"


def test_sentinel2_live_smoke_script_has_no_import_time_network_call(monkeypatch):
    import requests

    def forbidden_request(*args, **kwargs):
        raise AssertionError("Smoke test attempted a network request during import")

    monkeypatch.setattr(requests, "post", forbidden_request)
    script = BACKEND_DIR / "scripts" / "smoke_test_sentinel2_processing.py"
    assert script.exists()
    assert not (BACKEND_DIR / "test_sentinel2_processing.py").exists()
    namespace = runpy.run_path(str(script), run_name="agrinext_smoke_import_test")
    assert callable(namespace["main"])


def test_environment_template_uses_placeholders_for_secret_fields():
    template = (BACKEND_DIR / ".env.example").read_text(encoding="utf-8")
    values = {}
    for line in template.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            key, value = stripped.split("=", 1)
            values[key.strip()] = value.strip()
    for key in (
        "EARTHDATA_USERNAME", "EARTHDATA_PASSWORD", "EARTHDATA_BEARER_TOKEN",
        "SENTINEL_HUB_CLIENT_ID", "SENTINEL_HUB_CLIENT_SECRET",
    ):
        assert values.get(key)
        assert not values[key].startswith(("eyJ", "ghp_", "sk-"))
        assert "your_" in values[key]
    assert not (BACKEND_DIR / ".env").exists()



def test_multi_provider_live_smoke_script_has_no_import_time_network_call(monkeypatch):
    import requests

    def forbidden_request(*args, **kwargs):
        raise AssertionError("Live smoke test attempted a network request during import")

    monkeypatch.setattr(requests.Session, "get", forbidden_request)
    monkeypatch.setattr(requests.Session, "post", forbidden_request)
    script = BACKEND_DIR / "scripts" / "smoke_test_integrations.py"
    assert script.exists()
    namespace = runpy.run_path(str(script), run_name="agrinext_multi_provider_smoke_import_test")
    assert callable(namespace["main"])
