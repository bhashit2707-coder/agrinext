"""
Tests for AgriNext Climate What-if Scenario Simulator.
Verifies:
1. Preservation of original NASA baseline observations (POWER, SMAP, GPM).
2. Proper calculation of hypothetical anomalies (Rainfall %, Temp °C, Water availability %).
3. Accurate recalculation of crop suitability scores using RecommendationScorer.
4. Scientific disclaimers and simulated classification badges.
5. Reset to baseline fidelity.
6. Transformation assumptions and formula audit records.
7. FastAPI endpoint /api/simulation/simulate.
"""

import copy
import sys
from pathlib import Path
import pytest
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
from simulation.simulator import ClimateSimulator
from crop_knowledge.crop_service import CropKnowledgeService

client = TestClient(app)

MOCK_BASELINE_DOSSIER = {
    "dossier_id": "DOS-TEST-001",
    "location": {"lat": 14.68, "lng": 77.60},
    "precipitation_synthesis": {
        "gpm_satellite_annual_mm": 680.0,
        "power_reanalysis_annual_mm": 660.0
    },
    "soil_water_balance": {
        "surface_moisture_m3_m3": 0.22,
        "regime": "adequate",
        "trend": "stable"
    },
    "evidence_items": [
        {"parameter_code": "PRECTOTCORR", "actual_value": 670.0},
        {"parameter_code": "T2M", "actual_value": 28.0},
        {"parameter_code": "T2M_MAX", "actual_value": 36.5},
        {"parameter_code": "ALLSKY_SFC_SW_DWN", "actual_value": 19.5},
        {"parameter_code": "RH2M", "actual_value": 58.0}
    ],
    "dataset_status": {
        "nasa_smap": {"connected": True},
        "nasa_power": {"connected": True},
        "nasa_gpm": {"connected": True}
    }
}

MOCK_FARMER_PROFILE = {
    "farm_id": "farm_sim_001",
    "soil_texture": "Red Sandy Loam",
    "soil_ph": 6.8,
    "soil_organic_carbon": 0.45,
    "soil_nitrogen": 140.0,
    "soil_phosphorus": 14.0,
    "soil_potassium": 210.0,
    "irrigation_source": "Rainfed",
    "farming_season": "Kharif",
    "previous_crops": ["groundnut"]
}


@pytest.fixture
def simulator():
    return ClimateSimulator()


@pytest.fixture
def state_crops():
    crop_svc = CropKnowledgeService()
    return crop_svc.get_all_crops()


@pytest.fixture
def state_rules():
    return []


def test_baseline_preservation_immutability(simulator, state_crops, state_rules):
    """Scientific Rule: Original NASA observations must never be mutated or overwritten."""
    dossier_copy = copy.deepcopy(MOCK_BASELINE_DOSSIER)
    original_gpm = dossier_copy["precipitation_synthesis"]["gpm_satellite_annual_mm"]
    original_moisture = dossier_copy["soil_water_balance"]["surface_moisture_m3_m3"]

    result = simulator.simulate_scenario(
        baseline_dossier=dossier_copy,
        crops=state_crops,
        crop_rules=state_rules,
        farmer_profile=MOCK_FARMER_PROFILE,
        rainfall_pct_change=-25.0,
        temp_celsius_change=2.5,
        water_availability_pct_change=-30.0
    )

    # Assert original NASA baseline dossier in memory remains unaltered
    assert dossier_copy["precipitation_synthesis"]["gpm_satellite_annual_mm"] == original_gpm
    assert dossier_copy["soil_water_balance"]["surface_moisture_m3_m3"] == original_moisture
    assert result["is_simulated"] is True
    assert "HYPOTHETICAL" in result["scientific_classification"]
    assert "baseline_preservation_notice" in result


def test_drought_scenario_stress_recalculation(simulator, state_crops, state_rules):
    """
    Test scenario: Rainfall decreases by 20%, Temperature increases by 2°C, Water availability decreases by 25%.
    Crop suitability scores must be recalculated using RecommendationScorer and reflect agronomic stress.
    """
    result = simulator.simulate_scenario(
        baseline_dossier=MOCK_BASELINE_DOSSIER,
        crops=state_crops,
        crop_rules=state_rules,
        farmer_profile=MOCK_FARMER_PROFILE,
        rainfall_pct_change=-20.0,
        temp_celsius_change=2.0,
        water_availability_pct_change=-25.0
    )

    # 1. Check transformations audit
    audit = result["transformations_audit"]
    assert audit["rainfall"]["percentage_adjustment"] == -20.0
    assert audit["rainfall"]["simulated_value_mm"] == pytest.approx(680.0 * 0.8, 0.1)
    assert audit["rainfall"]["classification"] == "HYPOTHETICAL SIMULATION"

    assert audit["temperature"]["celsius_adjustment"] == 2.0
    assert audit["temperature"]["simulated_t2m_avg_c"] == pytest.approx(28.0 + 2.0, 0.1)

    assert audit["water_availability"]["water_availability_pct_change"] == -25.0

    # 2. Check matrix scores
    matrix = result["comparison_matrix"]
    assert len(matrix) == 3

    for item in matrix:
        assert "baseline_score" in item
        assert "scenario_score" in item
        assert "score_delta" in item
        assert "resilience_explanation" in item
        assert len(item["resilience_explanation"]) > 20
        # In a severe drought, water and climate stress reduces or alters scores
        assert item["baseline_scores"]["water_suitability"] >= item["scenario_scores"]["water_suitability"]

    # 3. Verify most resilient strategy is identified
    assert "most_resilient_strategy" in result
    assert result["most_resilient_strategy"]["strategy_id"] in [m["strategy_id"] for m in matrix]


def test_reset_to_baseline_zero_anomalies(simulator, state_crops, state_rules):
    """Resetting parameters to 0% rain, 0°C temp, 0% water returns exact baseline scores."""
    result = simulator.simulate_scenario(
        baseline_dossier=MOCK_BASELINE_DOSSIER,
        crops=state_crops,
        crop_rules=state_rules,
        farmer_profile=MOCK_FARMER_PROFILE,
        rainfall_pct_change=0.0,
        temp_celsius_change=0.0,
        water_availability_pct_change=0.0
    )

    matrix = result["comparison_matrix"]
    for item in matrix:
        assert item["score_delta"] == 0.0
        assert item["rank_shift"] == 0
        assert item["baseline_rank"] == item["scenario_rank"]
        assert item["baseline_score"] == item["scenario_score"]
        assert "Identical to NASA baseline observations" in item["resilience_explanation"]


def test_scientific_disclaimer_and_classification(simulator, state_crops, state_rules):
    """Verify strict adherence to scientific rules: never claiming weather forecast, labeling as simulated."""
    result = simulator.simulate_scenario(
        baseline_dossier=MOCK_BASELINE_DOSSIER,
        crops=state_crops,
        crop_rules=state_rules,
        farmer_profile=MOCK_FARMER_PROFILE,
        rainfall_pct_change=15.0,
        temp_celsius_change=-1.0,
        water_availability_pct_change=10.0
    )

    disclaimer = result["disclaimer"]
    assert "HYPOTHETICAL" in disclaimer
    assert "NOT a numerical weather forecast" in disclaimer
    assert "General Circulation Model" in disclaimer
    assert result["scientific_classification"] == "SIMULATED_HYPOTHETICAL_SCENARIO"


def test_api_simulate_endpoint():
    """Test POST /api/simulation/simulate FastAPI endpoint."""
    payload = {
        "state_id": "andhra_pradesh",
        "latitude": 14.68,
        "longitude": 77.60,
        "baseline_dossier": MOCK_BASELINE_DOSSIER,
        "farmer_profile": MOCK_FARMER_PROFILE,
        "weights": {"water": 40.0, "soil": 20.0, "climate": 20.0, "local": 20.0},
        "rainfall_pct_change": -20.0,
        "temp_celsius_change": 2.0,
        "water_availability_pct_change": -25.0
    }

    response = client.post("/api/simulation/simulate", json=payload)
    assert response.status_code == 200, response.text
    data = response.json()

    assert data["is_simulated"] is True
    assert "comparison_matrix" in data
    assert len(data["comparison_matrix"]) == 3
    assert "transformations_audit" in data
    assert data["applied_weights"]["water"] == 40.0
    assert "most_resilient_strategy" in data
