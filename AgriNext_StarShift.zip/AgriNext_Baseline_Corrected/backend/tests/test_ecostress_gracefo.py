import pytest
from geospatial.ecostress_gracefo_service import ECOSTRESSGRACEFOService, PRODUCTS

class FakeResponse:
    def raise_for_status(self): pass
    def json(self):
        return {"feed":{"entry":[{
            "title":"sample granule", "id":"G123", "time_start":"2026-01-01T00:00:00Z",
            "time_end":"2026-01-01T00:01:00Z",
            "links":[{"href":"https://example.test/data.nc","rel":"http://esipfed.org/ns/fedsearch/1.1/data#"}]
        }]}}

class FakeSession:
    def __init__(self): self.calls=[]
    def get(self, url, **kwargs):
        self.calls.append((url,kwargs))
        return FakeResponse()

def test_search_returns_cmr_metadata_and_data_links():
    session=FakeSession()
    service=ECOSTRESSGRACEFOService(session=session)
    result=service.search(16.5,80.6,"2026-01-01","2026-01-10",
                          ["ECOSTRESS_LST","GRACE_FO_TWS_MASCON"],5)
    assert result["count"] == 2
    assert result["pixel_values_extracted"] is False
    assert all(x["data_links"] == ["https://example.test/data.nc"] for x in result["items"])
    assert len(session.calls) == 2
    assert session.calls[1][1]["params"]["short_name"] == PRODUCTS["GRACE_FO_TWS_MASCON"]["short_name"]

def test_rejects_bad_coordinates_and_unknown_products():
    service=ECOSTRESSGRACEFOService(session=FakeSession())
    with pytest.raises(ValueError): service.search(100,0)
    with pytest.raises(ValueError): service.search(0,0,products=["NOT_A_PRODUCT"])

def test_rejects_invalid_date_range():
    service=ECOSTRESSGRACEFOService(session=FakeSession())
    with pytest.raises(ValueError): service.search(0,0,"2026-02-01","2026-01-01")



def test_ecostress_alexi_coverage_is_disclosed_as_conus_only():
    assert PRODUCTS["ECOSTRESS_ET_ALEXI"]["spatial_coverage"] == "CONUS only"
    assert PRODUCTS["ECOSTRESS_LST"]["spatial_coverage"].startswith("Global")



def test_grace_mascon_resolution_discloses_grid_and_native_support():
    resolution = PRODUCTS["GRACE_FO_TWS_MASCON"]["resolution"]
    assert "0.5° grid" in resolution
    assert "native mascon support" in resolution
