import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from main import app
from nasa.power import NASAPowerService
from nasa.smap import MIN_VALID_SMAP_SAMPLES, SOIL_MOISTURE_MAX_M3_M3, NASASMAPService
import api.router as api_router


def test_power_cache_ttl_rejects_expired_and_untimestamped_entries(monkeypatch):
    monkeypatch.setenv("NASA_POWER_CACHE_TTL_SECONDS", "3600")
    now = datetime(2026, 11, 15, 12, 0, tzinfo=timezone.utc)
    fresh = {"_cached_at": (now - timedelta(minutes=30)).isoformat()}
    stale = {"_cached_at": (now - timedelta(hours=2)).isoformat()}
    assert NASAPowerService._cache_is_fresh(fresh, now=now) is True
    assert NASAPowerService._cache_is_fresh(stale, now=now) is False
    assert NASAPowerService._cache_is_fresh({}, now=now) is False
    monkeypatch.setenv("NASA_POWER_CACHE_TTL_SECONDS", "not-a-number")
    assert NASAPowerService._cache_is_fresh(fresh, now=now) is True


def test_power_default_window_is_three_previous_complete_years():
    start, end = NASAPowerService().get_default_date_range()
    year = datetime.now(timezone.utc).year
    assert start == f"{year - 3}0101"
    assert end == f"{year - 1}1231"


def test_smap_threshold_and_shared_physical_range_are_explicit():
    assert MIN_VALID_SMAP_SAMPLES == 3
    assert SOIL_MOISTURE_MAX_M3_M3 == 0.50


def test_nasa_backed_routes_require_authenticated_session():
    client = TestClient(app)
    coordinate_payload = {"latitude": 14.68, "longitude": 77.60, "use_cache": True}
    routes = [
        ("/api/nasa/power/query", coordinate_payload),
        ("/api/nasa/smap/query", coordinate_payload),
        ("/api/nasa/gpm/query", coordinate_payload),
        ("/api/evidence/unified", coordinate_payload),
        ("/api/recommendations/generate", {"state_id": "andhra_pradesh", **coordinate_payload}),
    ]
    for path, payload in routes:
        response = client.post(path, json=payload)
        assert response.status_code == 401, f"{path} should require authentication"


def test_registration_endpoint_rate_limits_repeated_requests():
    client = TestClient(app, client=("198.51.100.31", 5000))
    payload = {"full_name": "QA Farmer", "email": "not-an-email", "password": "StrongPassword123!"}
    responses = [client.post("/api/auth/register", json=payload) for _ in range(21)]
    assert all(response.status_code == 422 for response in responses[:20])
    assert responses[-1].status_code == 429


def test_login_locks_identity_after_repeated_failures():
    client = TestClient(app, client=("198.51.100.32", 5001))
    payload = {"email": "missing-user@example.test", "password": "WrongPassword!"}
    responses = [client.post("/api/auth/login", json=payload) for _ in range(5)]
    assert all(response.status_code == 401 for response in responses)
    locked = client.post("/api/auth/login", json=payload)
    assert locked.status_code == 429
