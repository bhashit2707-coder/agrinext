"""
Tests for AgriNext ReportLab PDF Recommendation Report Generator.
Validates:
1. Path A: Farmer skips simulator -> Uses original NASA baseline and original recommendation scores.
2. Path B: Farmer uses simulator -> Includes both original and scenario-adjusted scores,
   with scenario assumptions clearly identified under [SIMULATED - HYPOTHETICAL].
3. Inclusion of all 16 required report sections.
4. FastAPI endpoint POST /api/reports/pdf returning valid application/pdf binary content.
"""

import sys
from pathlib import Path
import pytest
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
from reports.pdf_generator import AgriNextPDFGenerator

client = TestClient(app)

MOCK_FARM_DATA = {
    "id": "farm_rep_001",
    "farm_name": "Narayana Dryland Farm",
    "state_id": "andhra_pradesh",
    "district_id": "anantapur",
    "mandal_id": "kalyandurg",
    "latitude": 14.6805,
    "longitude": 77.6005,
    "effective_acreage": 5.24,
    "polygon_acreage": 5.24,
    "boundary_geojson": {
        "type": "Polygon",
        "coordinates": [[
            [77.598, 14.679],
            [77.603, 14.679],
            [77.604, 14.683],
            [77.599, 14.682],
            [77.598, 14.679]
        ]]
    }
}

MOCK_FARMER_PROFILE = {
    "farm_id": "farm_rep_001",
    "soil_type": "Red Sandy Loam",
    "soil_ph": 6.8,
    "organic_carbon_pct": 0.48,
    "nitrogen_value": 142.0,
    "nitrogen_rating": "Low (142 kg/ha)",
    "phosphorus_value": 14.0,
    "potassium_value": 215.0,
    "irrigation_source": "Rainfed (Borewell Backup)",
    "farming_season": "Kharif",
    "previous_crops": ["Groundnut"],
    "soil_source_type": "Farmer Ground-Truth Soil Health Card"
}

MOCK_DOSSIER = {
    "dossier_id": "DOS-REP-001",
    "precipitation_synthesis": {
        "gpm_satellite_annual_mm": 680.0,
        "power_reanalysis_annual_mm": 660.0
    },
    "soil_water_balance": {
        "surface_moisture_m3_m3": 0.22,
        "regime": "adequate",
        "trend": "stable"
    },
    "evidence_items": [
        {"parameter_code": "PRECTOTCORR", "actual_value": 680.0},
        {"parameter_code": "T2M", "actual_value": 27.5},
        {"parameter_code": "T2M_MAX", "actual_value": 36.2},
        {"parameter_code": "ALLSKY_SFC_SW_DWN", "actual_value": 19.5},
        {"parameter_code": "RH2M", "actual_value": 58.0}
    ]
}

MOCK_STRATEGIES = [
    {
        "id": "climate_resilient",
        "title": "Maximum Climate Resilience",
        "crop_sequence": ["Groundnut", "Bengal Gram", "Fallow / Sesbania Cover"],
        "season": "Kharif-Rabi-Summer",
        "overall_score": 85.5,
        "individual_scores": {
            "water_suitability": 88.0,
            "soil_health_potential": 82.0,
            "climate_suitability": 86.0,
            "local_agricultural_suitability": 86.0
        },
        "explanation": "Superior drought buffering and biological nitrogen fixation for semi-arid Anantapur.",
        "evidence_trace": {
            "dimensions": {
                "water_suitability": {
                    "score": 88.0,
                    "weight": 25.0,
                    "supporting_evidence": ["NASA GPM 680mm", "NASA SMAP Adequate"],
                    "traceable_explanation": "Low water footprint matches regional rainfall."
                },
                "soil_health_potential": {
                    "score": 82.0,
                    "weight": 25.0,
                    "supporting_evidence": ["Groundnut +38 kg N/ha", "Soil pH 6.8"],
                    "traceable_explanation": "Dual legume sequence replenishes depleted soil nitrogen."
                },
                "climate_suitability": {
                    "score": 86.0,
                    "weight": 25.0,
                    "supporting_evidence": ["NASA POWER T2M Max 36.2°C"],
                    "traceable_explanation": "Within heat tolerance limits."
                },
                "local_agricultural_suitability": {
                    "score": 86.0,
                    "weight": 25.0,
                    "supporting_evidence": ["ANGRAU Package of Practices"],
                    "traceable_explanation": "High local seed availability in Anantapur."
                }
            }
        }
    },
    {
        "id": "soil_restoration",
        "title": "Soil Health & Nutrient Regeneration",
        "crop_sequence": ["Sorghum", "Bengal Gram", "Green Gram"],
        "season": "Kharif-Rabi-Summer",
        "overall_score": 81.0,
        "individual_scores": {
            "water_suitability": 80.0,
            "soil_health_potential": 90.0,
            "climate_suitability": 78.0,
            "local_agricultural_suitability": 76.0
        },
        "explanation": "Maximizes biological nitrogen fixation and organic matter accumulation.",
        "evidence_trace": {
            "dimensions": {
                "water_suitability": {"score": 80.0, "weight": 25.0, "supporting_evidence": [], "traceable_explanation": "Moderate water demand."},
                "soil_health_potential": {"score": 90.0, "weight": 25.0, "supporting_evidence": [], "traceable_explanation": "High organic biomass."},
                "climate_suitability": {"score": 78.0, "weight": 25.0, "supporting_evidence": [], "traceable_explanation": "High thermal resilience."},
                "local_agricultural_suitability": {"score": 76.0, "weight": 25.0, "supporting_evidence": [], "traceable_explanation": "Standard dryland fit."}
            }
        }
    },
    {
        "id": "economic_balanced",
        "title": "Balanced Economic & Risk Diversification",
        "crop_sequence": ["Cotton", "Sorghum", "Green Gram"],
        "season": "Kharif-Rabi-Summer",
        "overall_score": 74.5,
        "individual_scores": {
            "water_suitability": 68.0,
            "soil_health_potential": 72.0,
            "climate_suitability": 78.0,
            "local_agricultural_suitability": 80.0
        },
        "explanation": "Blends cash crop income with risk mitigation crops.",
        "evidence_trace": {
            "dimensions": {
                "water_suitability": {"score": 68.0, "weight": 25.0, "supporting_evidence": [], "traceable_explanation": "Cotton water footprint requires irrigation."},
                "soil_health_potential": {"score": 72.0, "weight": 25.0, "supporting_evidence": [], "traceable_explanation": "Cotton depletes nutrients."},
                "climate_suitability": {"score": 78.0, "weight": 25.0, "supporting_evidence": [], "traceable_explanation": "Acceptable thermal window."},
                "local_agricultural_suitability": {"score": 80.0, "weight": 25.0, "supporting_evidence": [], "traceable_explanation": "Cotton is widely marketed."}
            }
        }
    }
]

MOCK_SIMULATION_DATA = {
    "simulation_id": "SIM-789012",
    "is_simulated": True,
    "scientific_classification": "SIMULATED_HYPOTHETICAL_SCENARIO",
    "disclaimer": "HYPOTHETICAL SENSITIVITY TEST: Gridded satellite baseline values adjusted by user-specified hypothetical stress parameters. NOT a numerical weather forecast or coupled General Circulation Model (GCM).",
    "scenario_parameters": {
        "rainfall_pct_change": -20.0,
        "temp_celsius_change": 2.0,
        "water_availability_pct_change": -25.0
    },
    "transformations_audit": {
        "rainfall": {"formula": "Simulated_Rain = Base_Rain * 0.8", "delta_mm": -136.0},
        "temperature": {"formula": "Simulated_T = Base_T + 2.0", "celsius_adjustment": 2.0},
        "water_availability": {"formula": "Simulated_Buffer = Base_Buffer * 0.75", "water_availability_pct_change": -25.0}
    },
    "comparison_matrix": [
        {
            "strategy_id": "climate_resilient",
            "title": "Maximum Climate Resilience",
            "baseline_rank": 1,
            "scenario_rank": 1,
            "baseline_score": 85.5,
            "scenario_score": 82.0,
            "score_delta": -3.5,
            "rank_shift": 0,
            "resilience_explanation": "Maintained #1 rank due to strong drought buffering genetics of groundnut and chickpea."
        },
        {
            "strategy_id": "soil_restoration",
            "title": "Soil Health & Nutrient Regeneration",
            "baseline_rank": 2,
            "scenario_rank": 2,
            "baseline_score": 81.0,
            "scenario_score": 76.5,
            "score_delta": -4.5,
            "rank_shift": 0,
            "resilience_explanation": "Deep-rooted sorghum buffered moisture stress while pulse flowering experienced minor thermal penalty."
        },
        {
            "strategy_id": "economic_balanced",
            "title": "Balanced Economic & Risk Diversification",
            "baseline_rank": 3,
            "scenario_rank": 3,
            "baseline_score": 74.5,
            "scenario_score": 65.0,
            "score_delta": -9.5,
            "rank_shift": 0,
            "resilience_explanation": "Suffered sharp 9.5 pt drop because cotton water deficit could not be cushioned under rainfed conditions."
        }
    ]
}


def test_pdf_report_path_a_farmer_skips_simulator():
    """
    Path A: Farmer skips simulator.
    Verifies:
    1. Report uses the original NASA baseline and original recommendation scores.
    2. Valid binary PDF output (%PDF header, non-empty, > 10 KB).
    3. Simulator notice states that baseline is preserved and no anomalies applied.
    """
    pdf_bytes = AgriNextPDFGenerator.generate_pdf(
        farm_data=MOCK_FARM_DATA,
        farmer_profile=MOCK_FARMER_PROFILE,
        weights={"water": 40.0, "soil": 20.0, "climate": 20.0, "local": 20.0},
        strategies=MOCK_STRATEGIES,
        dossier=MOCK_DOSSIER,
        simulation_data=None # Skipped simulator
    )

    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 10000, "PDF file size should be substantial with embedded map and tables"
    assert pdf_bytes.startswith(b"%PDF"), "Must start with standard PDF signature"


def test_pdf_report_path_b_farmer_uses_simulator():
    """
    Path B: Farmer uses simulator with hypothetical anomalies (-20% rain, +2°C temp, -25% water).
    Verifies:
    1. Includes both original NASA baseline and scenario-adjusted scores side-by-side.
    2. Scenario assumptions and disclaimers are explicitly identified.
    3. Valid binary PDF output (%PDF header, non-empty).
    """
    pdf_bytes = AgriNextPDFGenerator.generate_pdf(
        farm_data=MOCK_FARM_DATA,
        farmer_profile=MOCK_FARMER_PROFILE,
        weights={"water": 35.0, "soil": 25.0, "climate": 20.0, "local": 20.0},
        strategies=MOCK_STRATEGIES,
        dossier=MOCK_DOSSIER,
        simulation_data=MOCK_SIMULATION_DATA # Active simulation
    )

    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 10000
    assert pdf_bytes.startswith(b"%PDF")


def test_api_generate_pdf_endpoint_path_a():
    """Tests POST /api/reports/pdf when simulator is skipped."""
    payload = {
        "farm_data": MOCK_FARM_DATA,
        "farmer_profile": MOCK_FARMER_PROFILE,
        "weights": {"water": 25.0, "soil": 25.0, "climate": 25.0, "local": 25.0},
        "strategies": MOCK_STRATEGIES,
        "dossier": MOCK_DOSSIER,
        "simulation_data": None
    }

    response = client.post("/api/reports/pdf", json=payload)
    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/pdf"
    assert "attachment; filename=" in response.headers["Content-Disposition"]
    assert response.content.startswith(b"%PDF")
    assert len(response.content) > 10000


def test_api_generate_pdf_endpoint_path_b():
    """Tests POST /api/reports/pdf when simulator is active."""
    payload = {
        "farm_data": MOCK_FARM_DATA,
        "farmer_profile": MOCK_FARMER_PROFILE,
        "weights": {"water": 40.0, "soil": 20.0, "climate": 20.0, "local": 20.0},
        "strategies": MOCK_STRATEGIES,
        "dossier": MOCK_DOSSIER,
        "simulation_data": MOCK_SIMULATION_DATA
    }

    response = client.post("/api/reports/pdf", json=payload)
    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/pdf"
    assert "attachment; filename=" in response.headers["Content-Disposition"]
    assert response.content.startswith(b"%PDF")
    assert len(response.content) > 10000
