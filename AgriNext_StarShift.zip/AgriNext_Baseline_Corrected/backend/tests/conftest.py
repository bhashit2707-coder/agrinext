import pytest

@pytest.fixture(autouse=True)
def reset_auth_throttle_state():
    try:
        import sys
        backend_dir = __import__("pathlib").Path(__file__).resolve().parent.parent
        if str(backend_dir) not in sys.path:
            sys.path.insert(0, str(backend_dir))
        import api.router as api_router
        with api_router._auth_guard_lock:
            api_router._auth_attempts.clear()
            api_router._login_failures.clear()
            api_router._login_locked_until.clear()
    except Exception:
        pass
    yield
