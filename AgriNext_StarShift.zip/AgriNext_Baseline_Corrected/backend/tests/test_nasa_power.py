"""
Unit and integration tests for NASA POWER Agroclimatology Service.
Validates parameter parsing, missing value (-999) filtering,
evidence object generation, monthly aggregations, and caching.
"""

import sys
import uuid
from pathlib import Path
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
import auth
from nasa.power import NASAPowerService, PARAMETER_METADATA
import database

client = TestClient(app)

# Protected NASA/recommendation API tests run as an authenticated farmer.
_test_user_id = str(uuid.uuid4())
_test_user_email = f"qa-{_test_user_id}@example.test"
database.create_user(_test_user_id, "QA Test Farmer", _test_user_email, auth.hash_password("TestPassword!123"))
client.cookies.set(auth.SESSION_COOKIE_NAME, auth.create_session_for_user(_test_user_id))
power_service = NASAPowerService()

# Mock sample raw NASA POWER response to test processing & evidence generation offline
SAMPLE_RAW_POWER_DATA = {
    "type": "Feature",
    "geometry": {"type": "Point", "coordinates": [77.6, 14.68, 447.8]},
    "properties": {
        "parameter": {
            "T2M": {"20230101": 22.5, "20230102": 23.0, "20230103": -999.0},
            "T2M_MAX": {"20230101": 30.5, "20230102": 31.0, "20230103": -999.0},
            "T2M_MIN": {"20230101": 15.0, "20230102": 16.0, "20230103": -999.0},
            "PRECTOTCORR": {"20230101": 0.0, "20230102": 12.5, "20230103": 0.0},
            "RH2M": {"20230101": 65.0, "20230102": 72.0, "20230103": 55.0},
            "ALLSKY_SFC_SW_DWN": {"20230101": 18.5, "20230102": 16.2, "20230103": 20.1},
            "WS10M": {"20230101": 3.2, "20230102": 4.1, "20230103": 2.8}
        }
    }
}

def test_missing_values_and_processing():
    processed = power_service._process_power_response(
        raw_data=SAMPLE_RAW_POWER_DATA,
        lat=14.68,
        lng=77.60,
        start="20230101",
        end="20230103",
        is_from_cache=False,
        cached_at=None
    )

    assert processed["status"] == "success"
    assert processed["period_type"] == "caller_selected_period"
    assert processed["requested_period"] == {
        "start_date": "2023-01-01", "end_date": "2023-01-03",
        "is_default_baseline": False,
    }
    assert processed["provenance"]["period_type"] == "caller_selected_period"
    daily = processed["recent_daily_sample"]
    assert len(daily) == 3

    # On 20230103, T2M was -999.0 -> must be None
    day3 = [d for d in daily if d["date"] == "2023-01-03"][0]
    assert day3["t2m"] is None
    assert day3["t2m_max"] is None
    assert day3["precipitation_mm"] == 0.0

    # Monthly summary verification
    summaries = processed["monthly_summaries"]
    assert len(summaries) == 1
    jan = summaries[0]
    assert jan["year_month"] == "2023-01"
    # The requested period is only three days, not a complete January.
    # Keep the observed subtotal but do not label it as a complete monthly total.
    assert jan["total_precipitation_mm"] is None
    assert jan["partial_precipitation_sum_mm"] == 12.5
    assert jan["precipitation_valid_days"] == 3
    assert jan["precipitation_expected_days"] == 31
    assert jan["precipitation_complete"] is False
    assert jan["rainy_days_count"] == 1 # 12.5mm >= 1.0mm

def test_environmental_evidence_objects_structure():
    processed = power_service._process_power_response(
        raw_data=SAMPLE_RAW_POWER_DATA,
        lat=14.68,
        lng=77.60,
        start="20230101",
        end="20230103",
        is_from_cache=False,
        cached_at=None
    )

    evidence_objects = processed["evidence_objects"]
    assert len(evidence_objects) >= 5

    # Check Precipitation evidence object
    rain_ev = [ev for ev in evidence_objects if ev["parameter_code"] == "PRECTOTCORR"][0]
    assert rain_ev["dataset_name"] == "NASA POWER Agroclimatology"
    assert rain_ev["unit"] == "mm/year"
    assert "actual_value" in rain_ev
    assert "coordinates" in rain_ev
    assert rain_ev["coordinates"]["lat"] == 14.68
    assert "source_url" in rain_ev
    assert "retrieval_time" in rain_ev
    assert "spatial_resolution" in rain_ev
    assert "0.5°" in rain_ev["spatial_resolution"]
    assert "missing_data_info" in rain_ev
    assert rain_ev["missing_data_info"]["total_count"] == 3

    # Check Solar radiation evidence object
    solar_ev = [ev for ev in evidence_objects if ev["parameter_code"] == "ALLSKY_SFC_SW_DWN"][0]
    assert solar_ev["unit"] == "MJ/m^2/day"
    assert solar_ev["is_direct_satellite_observation"] is True
    assert "1.0°" in solar_ev["spatial_resolution"]

def test_cache_storage_and_hit():
    cache_key = "test_cache_key_anantapur"
    database.save_cached_power_data(
        cache_key=cache_key,
        lat=14.68,
        lng=77.60,
        start_date="20230101",
        end_date="20230103",
        parameters="T2M,PRECTOTCORR",
        response_data=SAMPLE_RAW_POWER_DATA
    )

    cached = database.get_cached_power_data(cache_key)
    assert cached is not None
    assert cached["_cache_hit"] is True
    assert "properties" in cached

def test_power_query_api_endpoint_with_cache():
    # Save into cache first
    cache_key = power_service._generate_cache_key(
        lat=14.681,
        lng=77.601,
        start="20230101",
        end="20230103",
        params=list(PARAMETER_METADATA.keys())
    )
    database.save_cached_power_data(
        cache_key=cache_key,
        lat=14.681,
        lng=77.601,
        start_date="20230101",
        end_date="20230103",
        parameters=",".join(sorted(list(PARAMETER_METADATA.keys()))),
        response_data=SAMPLE_RAW_POWER_DATA
    )

    # Now call endpoint
    req_payload = {
        "latitude": 14.681,
        "longitude": 77.601,
        "start_date": "20230101",
        "end_date": "20230103",
        "use_cache": True
    }
    response = client.post("/api/nasa/power/query", json=req_payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert data["provenance"]["cache_hit"] is True
    assert len(data["evidence_objects"]) >= 5
    assert len(data["monthly_summaries"]) >= 1



def test_power_default_date_range_is_explicitly_labelled_historical_baseline():
    start, end = power_service.get_default_date_range()
    processed = power_service._process_power_response(
        raw_data=SAMPLE_RAW_POWER_DATA,
        lat=14.68,
        lng=77.60,
        start=start,
        end=end,
        is_from_cache=False,
        cached_at=None,
    )
    assert processed["period_type"] == "historical_baseline"
    assert processed["requested_period"]["is_default_baseline"] is True
    from datetime import datetime, timezone
    current_year = datetime.now(timezone.utc).year
    assert processed["requested_period"]["start_date"] == f"{current_year - 3}-01-01"
    assert processed["requested_period"]["end_date"] == f"{current_year - 1}-12-31"


def test_missing_power_values_are_never_reported_as_zero():
    import copy
    raw = copy.deepcopy(SAMPLE_RAW_POWER_DATA)
    for date in raw["properties"]["parameter"]["PRECTOTCORR"]:
        raw["properties"]["parameter"]["PRECTOTCORR"][date] = -999.0
    for date in raw["properties"]["parameter"]["T2M"]:
        raw["properties"]["parameter"]["T2M"][date] = -999.0
    result = power_service._process_power_response(
        raw_data=raw, lat=14.68, lng=77.60, start="20230101", end="20230103",
        is_from_cache=False, cached_at=None
    )
    jan = result["monthly_summaries"][0]
    assert jan["total_precipitation_mm"] is None
    assert jan["partial_precipitation_sum_mm"] is None
    assert jan["avg_temperature_c"] is None
    normals = result["climatological_normals"]
    assert normals[0]["mean_temperature_c"] is None
    rain_evidence = next(e for e in result["evidence_objects"] if e["parameter_code"] == "PRECTOTCORR")
    temp_evidence = next(e for e in result["evidence_objects"] if e["parameter_code"] == "T2M")
    assert rain_evidence["actual_value"] is None
    assert temp_evidence["actual_value"] is None
