"""Tests for authenticated, traceable farm screening advisories."""
import sys
import uuid
from pathlib import Path

from fastapi.testclient import TestClient
import pytest

BACKEND_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_DIR))

import database
from main import app


@pytest.fixture
def alert_client(tmp_path, monkeypatch):
    monkeypatch.setattr(database, "DB_PATH", tmp_path / "alerts.db")
    database.init_db()
    client = TestClient(app)
    response = client.post("/api/auth/register", json={
        "full_name": "Alert Farmer", "email": "alerts@example.com", "password": "StrongPassword123!"
    })
    assert response.status_code == 201
    user = database.get_user_by_email("alerts@example.com")
    farm_id = str(uuid.uuid4())
    database.save_farm({
        "id": farm_id, "owner_user_id": user["id"], "farm_name": "Alert Test Farm",
        "state_id": "andhra_pradesh", "district_id": "guntur", "mandal_id": "guntur_rural",
        "latitude": 16.3, "longitude": 80.4, "polygon_acreage": 1.0, "effective_acreage": 1.0,
        "boundary_geojson": {"type": "Polygon", "coordinates": []}
    })
    return client, farm_id


def test_evaluates_observations_and_persists_traceable_alerts(alert_client):
    client, farm_id = alert_client
    response = client.post("/api/alerts/evaluate", json={
        "farm_id": farm_id, "observed_at": "2026-11-14T10:00:00+05:30", "source": "Local rain gauge",
        "rainfall_24h_mm": 130, "max_temperature_c": 41
    })
    assert response.status_code == 201, response.text
    payload = response.json()
    assert payload["alerts_created"] == 2
    assert {a["alert_type"] for a in payload["alerts"]} == {"very_heavy_rainfall", "high_temperature"}
    listed = client.get(f"/api/alerts?farm_id={farm_id}")
    assert listed.status_code == 200
    assert len(listed.json()) == 2
    assert all(a["source"] == "Local rain gauge" for a in listed.json())


def test_no_alert_for_observations_below_screening_thresholds(alert_client):
    client, farm_id = alert_client
    response = client.post("/api/alerts/evaluate", json={
        "farm_id": farm_id, "observed_at": "2026-11-14T10:00:00+05:30", "source": "Manual observation",
        "rainfall_24h_mm": 10, "max_temperature_c": 32, "soil_moisture_pct": 55
    })
    assert response.status_code == 201
    assert response.json()["alerts_created"] == 0


def test_requires_at_least_one_observation_and_valid_timestamp(alert_client):
    client, farm_id = alert_client
    base = {"farm_id": farm_id, "observed_at": "2026-11-14T10:00:00+05:30", "source": "Test"}
    assert client.post("/api/alerts/evaluate", json=base).status_code == 422
    invalid = {**base, "rainfall_24h_mm": 80, "observed_at": "not-a-date"}
    assert client.post("/api/alerts/evaluate", json=invalid).status_code == 422


def test_alerts_are_private_to_farm_owner_and_acknowledgeable(alert_client):
    client, farm_id = alert_client
    created = client.post("/api/alerts/evaluate", json={
        "farm_id": farm_id, "observed_at": "2026-11-14T10:00:00+05:30", "source": "Gauge", "rainfall_24h_mm": 70
    })
    alert_id = created.json()["alerts"][0]["id"]
    assert client.post(f"/api/alerts/{alert_id}/acknowledge").status_code == 200
    assert client.get(f"/api/alerts?farm_id={farm_id}").json()[0]["acknowledged_at"]
    other = TestClient(app)
    other.post("/api/auth/register", json={"full_name": "Other", "email": "other-alerts@example.com", "password": "StrongPassword123!"})
    assert other.get(f"/api/alerts?farm_id={farm_id}").status_code == 404
    assert other.post(f"/api/alerts/{alert_id}/acknowledge").status_code == 404


def test_anonymous_alert_access_is_rejected(alert_client):
    _, farm_id = alert_client
    anonymous = TestClient(app)
    assert anonymous.get("/api/alerts").status_code == 401
    assert anonymous.post("/api/alerts/evaluate", json={
        "farm_id": farm_id, "observed_at": "2026-11-14T10:00:00+05:30", "source": "Gauge", "rainfall_24h_mm": 80
    }).status_code == 401
