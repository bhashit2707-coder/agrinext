from pathlib import Path
import sys
from unittest.mock import Mock

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))

from geospatial.rotation_context import build_rotation_geospatial_context


def test_rotation_context_combines_sentinel_and_gaez_without_inventing_indices():
    sentinel = Mock()
    sentinel.search.return_value = {
        "source": "Copernicus Data Space Ecosystem", "dataset": "Sentinel-2 L2A",
        "count": 2, "items": [{"id": "scene-1", "datetime": "2026-11-01T00:00:00Z", "cloud_cover_percent": 8}],
        "pixel_processing_available": False, "note": "metadata only"
    }
    gaez = Mock()
    gaez.search.return_value = {
        "source": "FAO/IIASA GAEZ", "api_version": "GAEZ v4 Search API", "query": "rice, maize",
        "count": 1, "items": [{"id": "record-1", "properties": {"title": "Crop suitability"}}],
        "current_version": "GAEZ v5", "current_version_portal": "https://data.apps.fao.org/gaez/?lang=en",
        "note": "modelled context"
    }
    result = build_rotation_geospatial_context(16.5, 80.6, ["Rice", "Maize", "Rice"], sentinel, gaez, farm_id="farm-1")
    assert result["status"] == "available"
    assert result["sentinel2"]["scene_count"] == 2
    assert result["sentinel2"]["pixel_processing_available"] is False
    assert result["gaez"]["record_count"] == 1
    assert gaez.search.call_args.kwargs["query"] == "Maize, Rice"
    assert "no NDVI/NDWI" in result["planning_guidance"][2]
    assert "suitability_score" not in result["gaez"]


def test_rotation_context_keeps_partial_results_when_one_source_fails():
    sentinel = Mock()
    sentinel.search.side_effect = TimeoutError("catalog timeout")
    gaez = Mock()
    gaez.search.return_value = {"count": 0, "items": [], "api_version": "GAEZ v4 Search API"}
    result = build_rotation_geospatial_context(16.5, 80.6, ["Groundnut"], sentinel, gaez)
    assert result["status"] == "partial"
    assert result["sentinel2"]["status"] == "unavailable"
    assert "TimeoutError" in result["sentinel2"]["error"]
    assert result["gaez"]["status"] == "available"


def test_rotation_context_reports_unavailable_if_both_sources_fail():
    sentinel, gaez = Mock(), Mock()
    sentinel.search.side_effect = RuntimeError("down")
    gaez.search.side_effect = RuntimeError("down")
    result = build_rotation_geospatial_context(16.5, 80.6, [], sentinel, gaez)
    assert result["status"] == "unavailable"
    assert result["sentinel2"]["scene_count"] == 0
    assert result["gaez"]["record_count"] == 0


def test_rotation_context_passes_date_filters_and_farm_identity():
    sentinel, gaez = Mock(), Mock()
    sentinel.search.return_value = {"count": 0, "items": [], "pixel_processing_available": False}
    gaez.search.return_value = {"count": 0, "items": []}
    build_rotation_geospatial_context(16.5, 80.6, ["Cotton"], sentinel, gaez,
                                      farm_id="farm-2", start_date="2026-10-01", end_date="2026-11-01")
    assert sentinel.search.call_args.kwargs["start_date"] == "2026-10-01"
    assert sentinel.search.call_args.kwargs["end_date"] == "2026-11-01"
