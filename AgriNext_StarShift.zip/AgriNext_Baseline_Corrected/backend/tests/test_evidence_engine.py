"""
Unit and integration tests for Unified Environmental Evidence Service.
Validates multi-sensor synthesis (NASA POWER, NASA SMAP SPL3SMP_E V6, and NASA GPM IMERG V07),
dual-source precipitation comparison, soil water-balance synergy,
recommendation engine suitability scoring, and crop rotation strategy generation.
"""

import sys
import uuid
from pathlib import Path
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
import database
import auth
import api.router as api_router
from recommendation.evidence_engine import UnifiedEvidenceService
from recommendation.rotation_engine import RotationEngine

client = TestClient(app)

# Protected NASA/recommendation API tests run as an authenticated farmer.
_test_user_id = str(uuid.uuid4())
_test_user_email = f"qa-{_test_user_id}@example.test"
database.create_user(_test_user_id, "QA Test Farmer", _test_user_email, auth.hash_password("TestPassword!123"))
client.cookies.set(auth.SESSION_COOKIE_NAME, auth.create_session_for_user(_test_user_id))


def _mock_recommendation_nasa_services(monkeypatch):
    """Keep recommendation endpoint tests deterministic and offline."""
    monkeypatch.setattr(api_router.power_service, "fetch_agroclimatology", lambda **kwargs: {
        "status": "success",
        "evidence_objects": [
            {"parameter_code": "PRECTOTCORR", "parameter_name": "Mean Annual Precipitation", "actual_value": 620.0, "unit": "mm/year"},
            {"parameter_code": "T2M", "parameter_name": "Temperature Profile at 2 Meters", "actual_value": 27.5,
             "statistics": {"mean_c": 27.5, "extreme_max_c": 36.4}, "unit": "°C"}
        ]
    })
    monkeypatch.setattr(api_router.smap_service, "fetch_surface_soil_moisture", lambda **kwargs: {"status": "not_configured"})
    monkeypatch.setattr(api_router.gpm_service, "fetch_precipitation", lambda **kwargs: {"status": "not_configured"})
evidence_service = UnifiedEvidenceService()
rotation_engine = RotationEngine()

# Mock valid responses for testing synthesis offline
MOCK_POWER_DATA = {
    "status": "success",
    "evidence_objects": [
        {
            "dataset_name": "NASA POWER Agroclimatology",
            "parameter_code": "PRECTOTCORR",
            "parameter_name": "Precipitation",
            "actual_value": 620.0,
            "unit": "mm/year",
            "spatial_resolution": "0.5° (~50 km)"
        },
        {
            "dataset_name": "NASA POWER Agroclimatology",
            "parameter_code": "T2M",
            "parameter_name": "Air Temperature",
            "actual_value": 27.5,
            "statistics": {"mean_c": 27.5, "extreme_max_c": 36.4},
            "unit": "°C",
            "spatial_resolution": "0.5° (~50 km)"
        }
    ]
}

MOCK_SMAP_DEFICIT_DATA = {
    "status": "success",
    "product": "SPL3SMP_E.006",
    "regime": "deficit",
    "trend": "drying",
    "mean_moisture_m3_m3": 0.098,
    "evidence_object": {
        "dataset_name": "SMAP Enhanced L3 Radiometer Global Daily 9 km EASE-Grid Soil Moisture V006",
        "product_code": "SPL3SMP_E.006",
        "parameter_name": "Surface Volumetric Soil Moisture (0-5 cm)",
        "actual_value": 0.098,
        "unit": "m^3/m^3",
        "regime": "deficit",
        "trend_indicator": {"trend": "drying", "delta_m3_m3": -0.035},
        "spatial_resolution": "9 km x 9 km EASE-Grid 2.0 (~81 km² grid cell)"
    }
}

MOCK_GPM_DATA = {
    "status": "success",
    "product": "GPM_3IMERGDF.07",
    "annual_precipitation_mm": 670.0,
    "evidence_object": {
        "dataset_name": "GPM IMERG Final Precipitation L3 1 day 0.1 degree x 0.1 degree V07",
        "product_code": "GPM_3IMERGDF.07",
        "parameter_name": "Satellite Radar & Radiometer Precipitation",
        "actual_value": 670.0,
        "unit": "mm/year",
        "spatial_resolution": "0.1° x 0.1° (~10 km grid cell)"
    }
}

SAMPLE_CROPS = [
    {
        "id": "groundnut",
        "name": "Groundnut",
        "category": "Oilseed",
        "water_requirement_mm": [450, 650],
        "season": ["Kharif", "Rabi"],
        "drought_tolerance": "high",
        "flood_tolerance": "low",
        "nitrogen_impact": "fixing"
    },
    {
        "id": "paddy",
        "name": "Paddy (Rice)",
        "category": "Cereal",
        "water_requirement_mm": [900, 1400],
        "season": ["Kharif", "Rabi"],
        "drought_tolerance": "low",
        "flood_tolerance": "high",
        "nitrogen_impact": "depleting"
    },
    {
        "id": "red_gram",
        "name": "Red Gram (Pigeonpea)",
        "category": "Pulse",
        "water_requirement_mm": [500, 700],
        "season": ["Kharif"],
        "drought_tolerance": "high",
        "flood_tolerance": "low",
        "nitrogen_impact": "fixing"
    }
]

def test_unified_dossier_with_partial_unauthenticated_datasets():
    """Verify that unauthenticated SMAP/GPM are marked as disconnected without fake data."""
    smap_unauth = {"status": "auth_required", "connected": False, "product": "SPL3SMP_E.006"}
    gpm_unauth = {"status": "auth_required", "connected": False, "product": "GPM_3IMERGDF.07"}

    dossier = evidence_service.build_unified_dossier(
        lat=14.68,
        lng=77.60,
        power_data=MOCK_POWER_DATA,
        smap_data=smap_unauth,
        gpm_data=gpm_unauth
    )

    assert dossier["connected_datasets_count"] == 1
    assert dossier["dataset_status"]["nasa_power"]["connected"] is True
    assert dossier["dataset_status"]["nasa_smap"]["connected"] is False
    assert dossier["dataset_status"]["nasa_smap"]["requires_auth"] is True
    assert dossier["dataset_status"]["nasa_gpm"]["connected"] is False
    assert dossier["dataset_status"]["nasa_gpm"]["requires_auth"] is True

    # Spatial limitation disclaimer is present
    assert "Macro-environmental resolution disclaimer" in dossier["spatial_resolution_disclaimer"]

def test_unified_dossier_all_datasets_connected():
    """Verify dual-source precipitation and soil water balance synthesis when all 3 datasets are available."""
    dossier = evidence_service.build_unified_dossier(
        lat=14.68,
        lng=77.60,
        power_data=MOCK_POWER_DATA,
        smap_data=MOCK_SMAP_DEFICIT_DATA,
        gpm_data=MOCK_GPM_DATA
    )

    assert dossier["connected_datasets_count"] == 3
    assert len(dossier["evidence_items"]) >= 3

    # Dual-source precipitation synthesis
    precip_syn = dossier["precipitation_synthesis"]
    assert precip_syn is not None
    assert precip_syn["gpm_satellite_annual_mm"] == 670.0
    assert precip_syn["power_reanalysis_annual_mm"] == 620.0
    assert precip_syn["difference_mm"] == 50.0
    assert precip_syn["concordance"] == "High" # 50 / 620 = ~8%

    # Soil water-balance
    swb = dossier["soil_water_balance"]
    assert swb is not None
    assert swb["surface_moisture_m3_m3"] == 0.098
    assert swb["regime"] == "deficit"

def test_crop_suitability_evidence_integration():
    """Verify that SMAP moisture deficit boosts drought-hardy crops and penalizes paddy."""
    dossier = evidence_service.build_unified_dossier(
        lat=14.68,
        lng=77.60,
        power_data=MOCK_POWER_DATA,
        smap_data=MOCK_SMAP_DEFICIT_DATA,
        gpm_data=MOCK_GPM_DATA
    )

    result = evidence_service.evaluate_crop_suitability(
        crops=SAMPLE_CROPS,
        crop_rules=[],
        dossier=dossier
    )

    evaluated = result["evaluated_crops"]
    assert len(evaluated) == 3

    groundnut = [c for c in evaluated if c["crop_id"] == "groundnut"][0]
    paddy = [c for c in evaluated if c["crop_id"] == "paddy"][0]

    # Groundnut (drought-tolerant) must score significantly higher than Paddy (water-intensive)
    assert groundnut["suitability_score"] > paddy["suitability_score"]
    assert groundnut["suitability_score"] >= 80.0

    # Evidence citations must mention SMAP deficit
    citations = " ".join(groundnut["evidence_citations"])
    assert "NASA SMAP V6" in citations
    assert "deficit" in citations

    # Rotation strategies generated
    strategies = result["strategies"]
    assert len(strategies) == 3
    strat_ids = [s["id"] for s in strategies]
    assert "climate_resilient" in strat_ids
    assert "soil_restoration" in strat_ids
    assert "economic_balanced" in strat_ids

def test_unified_evidence_api_endpoint():
    """Verify POST /api/evidence/unified endpoint."""
    payload = {
        "latitude": 14.68,
        "longitude": 77.60,
        "use_cache": True
    }
    response = client.post("/api/evidence/unified", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "dossier_id" in data
    assert "dataset_status" in data
    assert "climate_risk_indicators" in data

def test_generate_recommendations_api_endpoint(monkeypatch):
    """Verify POST /api/recommendations/generate endpoint."""
    _mock_recommendation_nasa_services(monkeypatch)
    payload = {
        "state_id": "andhra_pradesh",
        "latitude": 14.68,
        "longitude": 77.60,
        "use_cache": True
    }
    response = client.post("/api/recommendations/generate", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "evaluated_crops" in data
    assert len(data["evaluated_crops"]) >= 3
    assert "strategies" in data
    assert len(data["strategies"]) == 3
