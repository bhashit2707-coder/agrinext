"""
Unit and integration tests for Farmer Profile and Soil Data Service.
Validates all 10 farmer inputs, Soil Health Card and ANGRAU district benchmarks,
classification of soil metrics, provenance separation (farmer_measured vs agricultural_benchmark),
and SQLite persistence.
"""

import sys
from pathlib import Path
from fastapi.testclient import TestClient

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app
from data_processing.farmer_profile import FarmerProfileService, FarmerProfileInput
import database
import auth
import uuid

client = TestClient(app)
farmer_service = FarmerProfileService()

def test_soil_health_card_district_benchmarks():
    """Verify Soil Health Card and ANGRAU district benchmark retrieval."""
    bm_atp = farmer_service.get_district_soil_benchmark("anantapur")
    assert bm_atp is not None
    assert bm_atp["district_name"] == "Anantapur"
    assert "Red Sandy Loam" in bm_atp["dominant_soil_type"]
    assert bm_atp["soil_ph"] == 6.8
    assert "Low" in bm_atp["nitrogen_rating"]
    assert "Medium" in bm_atp["phosphorus_rating"]
    assert "High" in bm_atp["potassium_rating"]
    assert "Soil Health Card" in bm_atp["source_reference"] or "ICAR-CRIDA" in bm_atp["source_reference"]

    bm_guntur = farmer_service.get_district_soil_benchmark("guntur")
    assert bm_guntur is not None
    assert "Black Cotton Soil" in bm_guntur["dominant_soil_type"]
    assert bm_guntur["soil_ph"] >= 7.5

def test_farmer_profile_with_direct_measurements():
    """Verify farmer profile processing with farmer-entered measurements."""
    fp_input = FarmerProfileInput(
        farm_id="farm_test_001",
        soil_type="Red Sandy Loam",
        soil_ph=6.5,
        nitrogen_kg_ha=120.0,
        phosphorus_kg_ha=14.0,
        potassium_kg_ha=310.0,
        organic_carbon_pct=0.45,
        current_crop="groundnut",
        previous_crops=["paddy", "cotton"],
        available_crops=["groundnut", "bengal_gram", "red_gram"],
        irrigation_source="Rainfed",
        farming_season="Kharif",
        preferred_crops=["groundnut"],
        soil_source_type="farmer_measured"
    )

    processed = farmer_service.process_farmer_profile(fp_input, district_id="anantapur")
    assert processed["soil_type"] == "Red Sandy Loam"
    assert processed["soil_ph"] == 6.5
    assert processed["ph_classification"] == "Neutral (6.5 - 7.5)"
    assert processed["nitrogen_rating"] == "Low (< 140 kg/ha)"
    assert processed["potassium_rating"] == "High (> 280 kg/ha)"
    assert processed["organic_carbon_rating"] == "Low (< 0.50%)"
    assert processed["soil_source_type"] == "farmer_measured"
    assert "Farmer self-reported" in processed["soil_source_reference"]

def test_farmer_profile_optional_values_marked_unknown():
    """Verify that unmeasured optional values are marked as unknown without inventing data."""
    fp_input = FarmerProfileInput(
        farm_id="farm_test_002",
        soil_type="Clay Loam",
        soil_ph=None,
        nitrogen_kg_ha=None,
        phosphorus_kg_ha=None,
        potassium_kg_ha=None,
        organic_carbon_pct=None,
        current_crop=None,
        irrigation_source="Borewell",
        farming_season="Rabi",
        soil_source_type="farmer_measured"
    )

    processed = farmer_service.process_farmer_profile(fp_input)
    assert processed["soil_ph"] is None
    assert processed["ph_classification"] == "unknown"
    assert processed["nitrogen_value"] is None
    assert processed["nitrogen_rating"] == "unknown"
    assert processed["organic_carbon_rating"] == "unknown"

def test_farmer_profile_agricultural_benchmark_fallback():
    """Verify that selecting agricultural_benchmark sources district baseline from Soil Health Card."""
    fp_input = FarmerProfileInput(
        farm_id="farm_test_003",
        soil_type="", # empty -> should adopt benchmark dominant type
        soil_ph=None,
        nitrogen_kg_ha=None,
        phosphorus_kg_ha=None,
        potassium_kg_ha=None,
        organic_carbon_pct=None,
        irrigation_source="Canal",
        farming_season="Kharif",
        soil_source_type="agricultural_benchmark"
    )

    processed = farmer_service.process_farmer_profile(fp_input, district_id="kurnool")
    assert processed["soil_source_type"] == "agricultural_benchmark"
    assert processed["soil_type"] == "Black Cotton Soil"
    assert processed["soil_ph"] == 8.1
    assert processed["nitrogen_value"] == 145.0
    assert "Soil Health Card" in processed["soil_source_reference"] or "ANGRAU" in processed["soil_source_reference"]

def test_farmer_profile_sqlite_persistence():
    """Verify saving and retrieving farmer profile in SQLite database."""
    profile_data = {
        "id": "fp_persisted_001",
        "farm_id": "farm_persisted_001",
        "soil_type": "Red Sandy Loam",
        "soil_source_type": "farmer_measured",
        "soil_source_reference": "Laboratory Test #2024-AP",
        "soil_ph": 6.8,
        "nitrogen_value": 135.0,
        "nitrogen_rating": "Low",
        "phosphorus_value": 22.0,
        "phosphorus_rating": "Medium",
        "potassium_value": 310.0,
        "potassium_rating": "High",
        "organic_carbon_pct": 0.42,
        "organic_carbon_rating": "Low",
        "current_crop": "groundnut",
        "previous_crops": ["cotton", "maize"],
        "available_crops": ["groundnut", "red_gram", "bengal_gram"],
        "irrigation_source": "Rainfed",
        "farming_season": "Kharif",
        "preferred_crops": ["groundnut"]
    }

    saved = database.save_farmer_profile(profile_data)
    assert saved is not None
    assert saved["id"] == "fp_persisted_001"
    assert saved["soil_type"] == "Red Sandy Loam"
    assert len(saved["previous_crops"]) == 2
    assert "cotton" in saved["previous_crops"]

    retrieved = database.get_farmer_profile_by_farm_id("farm_persisted_001")
    assert retrieved is not None
    assert retrieved["id"] == "fp_persisted_001"
    assert retrieved["irrigation_source"] == "Rainfed"

def test_api_soil_benchmark_endpoint():
    """Verify GET /api/soil-benchmarks/{district_id} route."""
    res = client.get("/api/soil-benchmarks/anantapur")
    assert res.status_code == 200
    data = res.json()
    assert data["district_name"] == "Anantapur"
    assert "Red Sandy Loam" in data["dominant_soil_type"]

def test_api_farmer_profile_endpoint():
    """Verify POST and GET /api/farmer-profile routes."""
    user = database.get_user_by_email("profile-test@agrinext.local")
    if not user:
        user = database.create_user(str(uuid.uuid4()), "Profile Test Farmer", "profile-test@agrinext.local", auth.hash_password("TestPassword123!"))
    client.cookies.set("agrinext_session", auth.create_session_for_user(user["id"]))
    if not database.get_farm_by_id("farm_api_test_01"):
        database.save_farm({"id": "farm_api_test_01", "owner_user_id": user["id"], "farm_name": "Profile Test Farm", "state_id": "andhra_pradesh", "district_id": "anantapur", "mandal_id": "kalyandurg", "latitude": 14.68, "longitude": 77.60, "polygon_acreage": 1, "effective_acreage": 1, "boundary_geojson": {"type": "Polygon", "coordinates": []}})

    payload = {
        "farm_id": "farm_api_test_01",
        "soil_type": "Red Sandy Loam",
        "soil_ph": 7.0,
        "nitrogen_kg_ha": 130.0,
        "irrigation_source": "Rainfed",
        "farming_season": "Kharif",
        "current_crop": "cotton",
        "previous_crops": ["paddy"],
        "available_crops": ["groundnut", "bengal_gram"],
        "preferred_crops": ["groundnut"],
        "soil_source_type": "farmer_measured"
    }

    post_res = client.post("/api/farmer-profile", json=payload)
    assert post_res.status_code == 200
    body = post_res.json()
    assert body["status"] == "saved"
    fp = body["farmer_profile"]
    assert fp["soil_type"] == "Red Sandy Loam"
    assert fp["farm_id"] == "farm_api_test_01"

    get_res = client.get("/api/farmer-profile/farm_api_test_01")
    assert get_res.status_code == 200
    retrieved = get_res.json()
    assert retrieved["farm_id"] == "farm_api_test_01"
    assert retrieved["current_crop"] == "cotton"
