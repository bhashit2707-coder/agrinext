import sys
from pathlib import Path
from unittest.mock import Mock

backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from geospatial.sentinel2_service import Sentinel2Service, STAC_SEARCH_URL
from geospatial.gaez_service import GAEZService, GAEZ_V4_API, GAEZ_V5_PORTAL


class FakeResponse:
    def __init__(self, payload):
        self.payload = payload
    def raise_for_status(self):
        return None
    def json(self):
        return self.payload


def test_sentinel2_uses_current_copernicus_stac_endpoint_and_maps_metadata():
    service = Sentinel2Service()
    feature = {
        "id": "S2A_TEST_ITEM",
        "geometry": {"type": "Point", "coordinates": [80.6, 16.5]},
        "properties": {"datetime": "2026-11-01T05:00:00Z", "eo:cloud_cover": 12.5,
                       "platform": "sentinel-2a", "instruments": [" MSI "], "processing:level": "Level-2A"},
        "assets": {"thumbnail": {"href": "https://example.test/thumb.jpg"},
                   "B04": {"href": "https://example.test/b04.tif"},
                   "unneeded": {"href": "https://example.test/other"}},
    }
    service.session.post = Mock(return_value=FakeResponse({"features": [feature]}))
    result = service.search(16.5, 80.6, "2026-10-01", "2026-11-01", max_cloud_cover=20)
    service.session.post.assert_called_once()
    args, kwargs = service.session.post.call_args
    assert args[0] == STAC_SEARCH_URL == "https://stac.dataspace.copernicus.eu/v1/search"
    assert kwargs["json"]["collections"] == ["sentinel-2-l2a"]
    assert kwargs["json"]["query"]["eo:cloud_cover"]["lte"] == 20
    assert result["count"] == 1
    assert result["items"][0]["id"] == "S2A_TEST_ITEM"
    assert "B04" in result["items"][0]["assets"]
    assert "unneeded" not in result["items"][0]["assets"]
    assert result["pixel_processing_available"] is False


def test_sentinel2_rejects_invalid_coordinates_and_cloud_cover():
    service = Sentinel2Service()
    try:
        service.search(100, 80)
        assert False, "invalid latitude should fail"
    except ValueError as exc:
        assert "Invalid latitude" in str(exc)
    try:
        service.search(16, 80, max_cloud_cover=101)
        assert False, "invalid cloud threshold should fail"
    except ValueError as exc:
        assert "cloud_cover" in str(exc)


def test_gaez_catalog_labels_v4_api_and_v5_portal_correctly():
    service = GAEZService()
    service.session.get = Mock(return_value=FakeResponse({"collections": [{"id": "crop-suitability", "title": "Crop suitability", "description": "Suitability layers", "links": []}]}))
    result = service.catalog()
    service.session.get.assert_called_once_with(f"{GAEZ_V4_API}/collections", timeout=30)
    assert result["api_version"] == "GAEZ v4 Search API"
    assert result["current_version"] == "GAEZ v5"
    assert result["current_version_portal"] == GAEZ_V5_PORTAL
    assert result["collections"][0]["id"] == "crop-suitability"


def test_gaez_collection_search_returns_catalogue_records_and_version_disclaimer():
    service = GAEZService()
    service.session.get = Mock(return_value=FakeResponse({"features": [{"id": "record-1", "properties": {"title": "Rice suitability"}}]}))
    result = service.search(query="rice", collection_id="crop-suitability", limit=5)
    service.session.get.assert_called_once_with(f"{GAEZ_V4_API}/collections/crop-suitability/items", params={"limit": 5, "q": "rice"}, timeout=30)
    assert result["count"] == 1
    assert result["items"][0]["id"] == "record-1"
    assert "not live field measurements" in result["note"]

# Sentinel-2 Processing API tests are isolated from the existing public STAC tests.
import io
import numpy as np
import rasterio
from rasterio.transform import from_origin
from rasterio.io import MemoryFile
from geospatial.sentinel2_processing import (
    Sentinel2ProcessingService,
    Sentinel2ProcessingError,
    TOKEN_URL,
    PROCESS_URL,
)


class ProcessingResponse:
    def __init__(self, payload=None, content=b"", headers=None, status_code=200):
        self._payload = payload or {}
        self.content = content
        self.headers = headers or {}
        self.status_code = status_code
        self.text = "mock response"

    def raise_for_status(self):
        if self.status_code >= 400:
            import requests
            raise requests.HTTPError(f"HTTP {self.status_code}", response=self)

    def json(self):
        return self._payload


def _mock_ndvi_geotiff():
    data = np.array(
        [
            [[0.2, 0.4], [0.6, -9999.0]],
            [[4.0, 4.0], [8.0, 4.0]],
        ],
        dtype="float32",
    )
    with MemoryFile() as memfile:
        with memfile.open(
            driver="GTiff", width=2, height=2, count=2, dtype="float32",
            crs="EPSG:4326", transform=from_origin(0, 2, 1, 1), nodata=-9999.0,
        ) as dataset:
            dataset.write(data)
        return memfile.read()


class MockProcessingSession:
    def __init__(self, raster_bytes=None):
        self.raster_bytes = raster_bytes or _mock_ndvi_geotiff()
        self.calls = []

    def post(self, url, **kwargs):
        self.calls.append((url, kwargs))
        if url == TOKEN_URL:
            return ProcessingResponse({"access_token": "test-token", "expires_in": 1800})
        if url == PROCESS_URL:
            return ProcessingResponse(
                content=self.raster_bytes,
                headers={"Content-Type": "image/tiff"},
            )
        raise AssertionError(f"Unexpected URL: {url}")


TEST_FARM_POLYGON = {
    "type": "Polygon",
    "coordinates": [[[0, 0], [2, 0], [2, 2], [0, 2], [0, 0]]],
}


def test_sentinel2_processing_authenticates_and_reuses_cached_token():
    session = MockProcessingSession()
    service = Sentinel2ProcessingService("client", "secret", session=session)
    first = service._get_access_token()
    second = service._get_access_token()
    assert first == second == "test-token"
    assert [call[0] for call in session.calls] == [TOKEN_URL]


def test_sentinel2_processing_requests_l2a_and_returns_clipped_ndvi_statistics():
    session = MockProcessingSession()
    service = Sentinel2ProcessingService("client", "secret", session=session)
    result = service.analyze_farm(TEST_FARM_POLYGON, "2026-10-01", "2026-11-01")

    assert result["status"] == "success"
    assert result["ndvi"] == {"mean": 0.3, "min": 0.2, "max": 0.4}
    assert result["valid_pixel_count"] == 2
    assert result["polygon_pixel_count"] == 4
    assert result["valid_coverage_percent"] == 50.0
    assert result["cloud_masked_pixel_percent"] == 25.0
    process_call = next(call for call in session.calls if call[0] == PROCESS_URL)
    payload = process_call[1]["json"]
    assert payload["input"]["data"][0]["type"] == "sentinel-2-l2a"
    assert payload["input"]["bounds"]["bbox"] == [0.0, 0.0, 2.0, 2.0]
    assert "B04" in payload["evalscript"] and "B08" in payload["evalscript"]


def test_sentinel2_processing_returns_no_valid_pixels_without_fake_statistics():
    session = MockProcessingSession()
    service = Sentinel2ProcessingService("client", "secret", session=session)
    # All NDVI samples are nodata, while SCL remains available.
    nodata_raster = np.array([[[-9999.0, -9999.0], [-9999.0, -9999.0]],
                              [[4.0, 4.0], [4.0, 4.0]]], dtype="float32")
    with MemoryFile() as memfile:
        with memfile.open(driver="GTiff", width=2, height=2, count=2,
                          dtype="float32", crs="EPSG:4326",
                          transform=from_origin(0, 2, 1, 1), nodata=-9999.0) as ds:
            ds.write(nodata_raster)
        session.raster_bytes = memfile.read()
    result = service.analyze_farm(TEST_FARM_POLYGON)
    assert result["status"] == "no_valid_pixels"
    assert result["ndvi"] == {"mean": None, "min": None, "max": None}
    assert result["valid_pixel_count"] == 0


def test_sentinel2_processing_rejects_unsupported_geometry_and_bad_dates():
    service = Sentinel2ProcessingService("client", "secret", session=MockProcessingSession())
    try:
        service.analyze_farm({"type": "Point", "coordinates": [80, 16]})
        assert False, "Point geometry should be rejected"
    except ValueError as exc:
        assert "Polygon" in str(exc)
    try:
        service.analyze_farm(TEST_FARM_POLYGON, "2026-11-02", "2026-11-01")
        assert False, "Reversed date range should be rejected"
    except ValueError as exc:
        assert "start_date" in str(exc)
