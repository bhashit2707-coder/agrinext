import os, sys, tempfile
from pathlib import Path
from unittest.mock import Mock
import h5py
import numpy as np

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))
from nasa.gldas import GLDASService, SHORT_NAME, VERSION
from geospatial.srtm_service import SRTMService

class FakeResponse:
    def __init__(self, payload=None): self.payload = payload or {}
    def raise_for_status(self): return None
    def json(self): return self.payload


def test_gldas_status_is_transparent_without_earthdata_credentials():
    service = GLDASService()
    service.username = service.password = service.token = ""
    result = service.query_point(16.5, 80.6)
    assert result["status"] == "auth_required"
    assert result["evidence"] is None
    assert service.get_service_status()["product"] == f"{SHORT_NAME}.{VERSION}"


def test_gldas_extracts_nearest_soil_moisture_layer_and_preserves_units(tmp_path):
    path = tmp_path / "sample.nc4"
    with h5py.File(path, "w") as f:
        f.create_dataset("lat", data=np.array([16.0, 17.0]))
        f.create_dataset("lon", data=np.array([80.0, 81.0]))
        ds = f.create_dataset("SoilMoi0_10cm_inst", data=np.array([[10.0, 20.0], [30.0, 40.0]]))
        ds.attrs["_FillValue"] = -9999.0
    result = GLDASService._extract_point(str(path), 16.6, 80.7)
    assert result["SoilMoi0_10cm_inst"]["value"] == 40.0
    assert result["SoilMoi0_10cm_inst"]["unit"] == "kg/m²"


def test_gldas_rejects_invalid_coordinates():
    service = GLDASService()
    try:
        service.query_point(100, 80)
        assert False
    except ValueError as exc:
        assert "valid WGS84" in str(exc)


def test_srtm_maps_point_elevation_and_metadata():
    service = SRTMService()
    service.session.get = Mock(return_value=FakeResponse({"status": "OK", "results": [
        {"dataset": "srtm30m", "elevation": 42.5, "location": {"lat": 16.5, "lng": 80.6}}
    ]}))
    result = service.query_points([{"latitude": 16.5, "longitude": 80.6}])
    assert result["results"][0]["elevation_m"] == 42.5
    assert result["vertical_units"] == "metres"
    assert "surface model" in result["note"]


def test_srtm_rejects_invalid_or_too_many_points():
    service = SRTMService()
    for points in ([], [{"latitude": 95, "longitude": 80}]):
        try:
            service.query_points(points)
            assert False
        except ValueError:
            pass


def test_gldas_and_srtm_routes_are_registered_and_return_service_payloads(monkeypatch):
    from fastapi.testclient import TestClient
    from main import app
    from api import router as api_router
    monkeypatch.setattr(api_router.gldas_service, "query_point", lambda lat, lon, date=None: {
        "status": "auth_required", "connected": False, "evidence": None
    })
    monkeypatch.setattr(api_router.srtm_service, "query_points", lambda points: {
        "status": "success", "results": [{"elevation_m": 25.0}]
    })
    client = TestClient(app)
    gldas = client.post("/api/nasa/gldas/query", json={"latitude": 16.5, "longitude": 80.6})
    srtm = client.post("/api/earth-observation/srtm/query", json={"points": [{"latitude": 16.5, "longitude": 80.6}]})
    assert gldas.status_code == 200 and gldas.json()["status"] == "auth_required"
    assert srtm.status_code == 200 and srtm.json()["results"][0]["elevation_m"] == 25.0
