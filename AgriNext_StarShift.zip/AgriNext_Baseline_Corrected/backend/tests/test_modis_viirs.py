import pytest
from geospatial.modis_viirs_service import MODISVIIRSService

class Response:
    def __init__(self, payload): self.payload = payload
    def raise_for_status(self): pass
    def json(self): return self.payload

class Session:
    def __init__(self, payload): self.payload = payload; self.calls = []
    def get(self, *args, **kwargs):
        self.calls.append((args, kwargs))
        return Response(self.payload)

def test_modis_viirs_searches_real_cmr_product_ids_and_marks_metadata_only():
    session = Session({"feed": {"entry": [{
        "id": "G123", "title": "MOD13Q1.A2026305.h27v06",
        "time_start": "2026-11-01T00:00:00.000Z",
        "links": [{"href": "https://example.nasa.gov/data.hdf", "rel": "http://esipfed.org/ns/fedsearch/1.1/data#"}]
    }]}})
    result = MODISVIIRSService(session=session).search(
        16.5, 80.6, "2026-11-01", "2026-11-14",
        products=["MODIS_NDVI_EVI"], limit=5)
    assert result["count"] == 1
    assert result["items"][0]["short_name"] == "MOD13Q1"
    assert result["items"][0]["data_links"] == ["https://example.nasa.gov/data.hdf"]
    assert result["pixel_values_extracted"] is False
    assert session.calls[0][1]["params"]["point"] == "80.6,16.5"

def test_modis_viirs_rejects_invalid_input():
    service = MODISVIIRSService(session=Session({"feed": {"entry": []}}))
    with pytest.raises(ValueError): service.search(91, 80)
    with pytest.raises(ValueError): service.search(16, 80, "2026-02-01", "2026-01-01")
    with pytest.raises(ValueError): service.search(16, 80, products=["NOT_A_PRODUCT"])
