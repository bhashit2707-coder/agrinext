"""Regression tests for data-integrity fixes introduced after the QA audit."""
import math
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))

import database
from recommendation.scoring import RecommendationScorer


def test_every_new_sqlite_connection_enables_foreign_keys():
    conn = database.get_connection()
    try:
        assert conn.execute("PRAGMA foreign_keys").fetchone()[0] == 1
    finally:
        conn.close()


def test_water_scorer_rejects_missing_or_invalid_rainfall():
    scorer = RecommendationScorer()
    for invalid in (None, float("nan"), float("inf"), -1):
        try:
            scorer.compute_water_suitability([], invalid)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Expected invalid rainfall {invalid!r} to be rejected")


def test_water_scorer_handles_missing_irrigation_and_tolerances_with_notes():
    scorer = RecommendationScorer()
    score, metadata = scorer.compute_water_suitability(
        [{"water_requirement_mm": [400, 600], "drought_tolerance": None}],
        effective_annual_rainfall_mm=500,
        irrigation_source=None,
    )
    assert math.isfinite(score)
    assert any("Irrigation source unavailable" in note for note in metadata["validation_notes"])
    assert any("drought tolerance" in note for note in metadata["validation_notes"])


def test_climate_scorer_rejects_missing_or_nonfinite_temperatures():
    scorer = RecommendationScorer()
    for avg, maximum in ((None, 30), (25, None), (float("nan"), 30), (25, float("inf"))):
        try:
            scorer.compute_climate_suitability([], avg, maximum)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Expected invalid temperatures {(avg, maximum)!r} to be rejected")


def test_gpm_does_not_reuse_non_success_cache(monkeypatch):
    from nasa.gpm import NASAGPMService
    service = NASAGPMService()
    monkeypatch.setattr(database, "get_cached_gpm_data", lambda _key: {"status": "unavailable"})
    monkeypatch.setattr(service, "_query_ges_disc_api", lambda **_kwargs: {"status": "success", "observations": []})
    result = service.fetch_precipitation(
        lat=14.68, lng=77.60, start_date="2023-01-01", end_date="2023-01-31", use_cache=True
    )
    assert result["status"] == "auth_required" or result["status"] == "success"
    assert result.get("status") != "unavailable"


def test_delete_farm_removes_all_farm_owned_rows_atomically(tmp_path, monkeypatch):
    from datetime import datetime, timezone
    import json
    monkeypatch.setattr(database, "DB_PATH", tmp_path / "farm-delete.sqlite")
    database.init_db()
    now = datetime.now(timezone.utc).isoformat()
    user_id, farm_id = "user-test", "farm-test"
    with database.get_connection() as conn:
        conn.execute(
            "INSERT INTO users (id, full_name, email, password_hash, created_at) VALUES (?, ?, ?, ?, ?)",
            (user_id, "Test Farmer", "farm-delete@example.test", "hash", now),
        )
        conn.execute("""INSERT INTO farms (
            id, owner_user_id, farm_name, state_id, district_id, mandal_id, latitude, longitude,
            polygon_acreage, effective_acreage, boundary_geojson, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (farm_id, user_id, "Test Farm", "andhra_pradesh", "d", "m", 15.0, 80.0,
             1.0, 1.0, json.dumps({"type": "Polygon", "coordinates": []}), now, now))
        conn.execute("INSERT INTO farm_environmental_evidence VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            ("ev1", farm_id, 15.0, 80.0, "POWER", "rain", "mm", "{}", now))
        conn.execute("""INSERT INTO farmer_profiles (
            id, owner_user_id, farm_id, soil_type, soil_source_type, irrigation_source, farming_season, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            ("profile1", user_id, farm_id, "loam", "manual", "Rainfed", "Kharif", now, now))
        conn.execute("""INSERT INTO soil_reports (
            id, owner_user_id, farm_id, original_filename, stored_filename, content_type,
            file_size, extraction_status, extracted_metrics_json, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            ("soil1", user_id, farm_id, "a.pdf", "a.pdf", "application/pdf", 1, "done", "{}", now))
        conn.execute("""INSERT INTO farm_alerts (
            id, owner_user_id, farm_id, alert_type, severity, title, message, observed_value,
            threshold_value, unit, source, observed_at, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            ("alert1", user_id, farm_id, "rain", "low", "title", "message", 1, 2, "mm", "test", now, now))
        conn.execute("""INSERT INTO crop_rotation_records (
            id, owner_user_id, farm_id, crop_name, season, crop_year, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            ("rotation1", user_id, farm_id, "rice", "Kharif", 2025, now, now))
        conn.execute("""INSERT INTO farm_activity_log (
            id, owner_user_id, farm_id, activity_type, description, metadata_json, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
            ("activity1", user_id, farm_id, "created", "created farm", "{}", now))

    assert database.delete_farm(farm_id) is True
    with database.get_connection() as conn:
        assert conn.execute("SELECT COUNT(*) FROM farms WHERE id = ?", (farm_id,)).fetchone()[0] == 0
        for table in ("farm_environmental_evidence", "farmer_profiles", "soil_reports",
                      "farm_alerts", "crop_rotation_records", "farm_activity_log"):
            assert conn.execute(f"SELECT COUNT(*) FROM {table} WHERE farm_id = ?", (farm_id,)).fetchone()[0] == 0
