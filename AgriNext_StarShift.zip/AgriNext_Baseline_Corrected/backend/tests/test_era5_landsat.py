import pytest
from climate.era5_service import ERA5Service
from geospatial.landsat_service import LandsatService

class Response:
    def __init__(self, payload): self.payload=payload
    def raise_for_status(self): pass
    def json(self): return self.payload
class Session:
    def __init__(self, payload): self.payload=payload; self.calls=[]
    def get(self,*a,**kw): self.calls.append((a,kw)); return Response(self.payload)
    def post(self,*a,**kw): self.calls.append((a,kw)); return Response(self.payload)

def test_era5_returns_hourly_model_data_and_units():
    session=Session({"timezone":"UTC","elevation":22,"hourly_units":{"temperature_2m":"°C","precipitation":"mm"},"hourly":{"time":["2026-01-01T00:00"],"temperature_2m":[25.1],"precipitation":[0.2],"soil_moisture_0_to_7cm":[0.21]}})
    result=ERA5Service(session=session).query_point(16.5,80.6,"2026-01-01","2026-01-01")
    assert result["status"]=="success" and result["dataset"]=="ERA5"
    assert result["hourly"]["soil_moisture_0_to_7cm"]==[0.21]
    assert result["units"]["temperature_2m"]=="°C"

def test_era5_rejects_long_ranges_and_bad_coordinates():
    service=ERA5Service(session=Session({}))
    with pytest.raises(ValueError): service.query_point(91,80.6)
    with pytest.raises(ValueError): service.query_point(16.5,80.6,"2026-01-01","2026-02-10")

def test_landsat_maps_scene_metadata_and_spectral_assets():
    payload={"features":[{"id":"LC09_TEST","properties":{"datetime":"2026-01-01T05:00:00Z","platform":"landsat-9","eo:cloud_cover":12.5},"assets":{"red":{"href":"https://example.test/red.tif"},"nir08":{"href":"https://example.test/nir.tif"},"qa_pixel":{"href":"https://example.test/qa.tif"}}}]}
    session=Session(payload)
    result=LandsatService(session=session).search(16.5,80.6,"2026-01-01","2026-01-31",max_cloud_cover=20)
    assert result["count"]==1 and result["items"][0]["platform"]=="landsat-9"
    assert "nir08" in result["items"][0]["assets"]
    assert session.calls[0][1]["json"]["collections"]==["landsat-c2-l2"]

def test_landsat_rejects_invalid_search():
    service=LandsatService(session=Session({"features":[]}))
    with pytest.raises(ValueError): service.search(100,80)
    with pytest.raises(ValueError): service.search(16,80,start_date="2026-02-01",end_date="2026-01-01")
