"""
AgriNext Backend Integration and Unit Tests.
Verifies API endpoints, state data configuration loading, and NASA service schemas.
"""

import sys
from pathlib import Path
from fastapi.testclient import TestClient

# Add backend directory to sys.path
backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from main import app

client = TestClient(app)

def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert "AgriNext" in response.json()["message"]

def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "Andhra Pradesh" in data["region_scope"]

def test_get_states():
    response = client.get("/api/states")
    assert response.status_code == 200
    data = response.json()
    assert data["default_state"] == "andhra_pradesh"
    assert len(data["supported_states"]) >= 1

def test_get_andhra_pradesh_districts():
    response = client.get("/api/states/andhra_pradesh/districts")
    assert response.status_code == 200
    districts = response.json()
    assert len(districts) >= 10
    names = [d["name"] for d in districts]
    assert "Ananthapuramu" in names
    assert "Guntur" in names

def test_get_andhra_pradesh_crops():
    response = client.get("/api/states/andhra_pradesh/crops")
    assert response.status_code == 200
    crops = response.json()
    assert len(crops) >= 5
    crop_ids = [c["id"] for c in crops]
    assert "paddy" in crop_ids
    assert "groundnut" in crop_ids

def test_get_andhra_pradesh_crop_rules():
    response = client.get("/api/states/andhra_pradesh/crop-rules")
    assert response.status_code == 200
    data = response.json()
    assert data["state_id"] == "andhra_pradesh"
    assert len(data["agronomic_rules"]) >= 3

def test_get_nasa_services_metadata():
    response = client.get("/api/nasa/services")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "not_checked"
    assert data["status_check_scope"] == "configuration_only"
    service_names = [s["service"] for s in data["services"]]
    assert all({"configured", "reachable", "authenticated", "data_available"} <= set(s) for s in data["services"])
    assert "NASA POWER" in service_names
    assert "NASA SMAP" in service_names
    assert "NASA GPM" in service_names

def test_get_recommendation_archetypes():
    response = client.get("/api/recommendations/archetypes")
    assert response.status_code == 200
    strategies = response.json()
    assert len(strategies) == 3
    archetype_ids = [s["id"] for s in strategies]
    assert "climate_resilient" in archetype_ids
    assert "soil_restoration" in archetype_ids
    assert "economic_balanced" in archetype_ids
