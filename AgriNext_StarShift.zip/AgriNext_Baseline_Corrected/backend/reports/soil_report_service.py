"""Conservative text extraction for uploaded soil health reports."""
import re
from typing import Any, Dict

PATTERNS = {
    "soil_ph": r"\bp\s*h\b\s*[:=\-]?\s*(\d{1,2}(?:\.\d+)?)",
    "nitrogen_kg_ha": r"\b(?:available\s+)?nitrogen\b[^0-9]{0,30}(\d+(?:\.\d+)?)",
    "phosphorus_kg_ha": r"\b(?:available\s+)?phosph(?:orus)?\b[^0-9]{0,30}(\d+(?:\.\d+)?)",
    "potassium_kg_ha": r"\b(?:available\s+)?potassium\b[^0-9]{0,30}(\d+(?:\.\d+)?)",
    "organic_carbon_pct": r"\borganic\s+carbon\b[^0-9]{0,30}(\d+(?:\.\d+)?)\s*%?",
}

def extract_soil_metrics(text: str) -> Dict[str, Any]:
    normalized = re.sub(r"\s+", " ", text or "")
    found: Dict[str, Any] = {}
    for key, pattern in PATTERNS.items():
        match = re.search(pattern, normalized, re.IGNORECASE)
        if match:
            value = float(match.group(1))
            if key == "soil_ph" and not 0 <= value <= 14:
                continue
            if key == "organic_carbon_pct" and value > 20:
                continue
            found[key] = value
    return found

def classify_metrics(metrics: Dict[str, Any]) -> Dict[str, str]:
    result = {}
    ph = metrics.get("soil_ph")
    if ph is not None:
        result["soil_ph"] = "Acidic" if ph < 6.5 else "Neutral" if ph <= 7.5 else "Alkaline"
    for key, low, high, label in [("nitrogen_kg_ha",140,280,"nitrogen"),("phosphorus_kg_ha",10,25,"phosphorus"),("potassium_kg_ha",120,280,"potassium")]:
        value = metrics.get(key)
        if value is not None:
            result[label] = "Low" if value < low else "Medium" if value <= high else "High"
    oc = metrics.get("organic_carbon_pct")
    if oc is not None:
        result["organic_carbon"] = "Low" if oc < .5 else "Medium" if oc <= .75 else "High"
    return result
