"""
Climate What-If Scenario Simulator for AgriNext.
Applies user-defined hypothetical climate anomalies to derived agro-climatic indicators:
- Rainfall percentage change (Δ Rainfall %)
- Temperature change (Δ Temperature °C)
- Water availability percentage change (Δ Water %)

CRITICAL SCIENTIFIC RULES:
1. The original NASA baseline observations (POWER, SMAP, GPM) are NEVER overwritten.
2. Scenario values are strictly classified and labeled as [SIMULATED - HYPOTHETICAL].
3. Never claimed as a numerical weather forecast or general circulation climate model.
4. All mathematical transformations and assumptions are fully recorded for scientific audit.
5. Crop suitability is recalculated using the identical verified RecommendationScorer formulas.
"""

from typing import Dict, Any, List, Optional, Tuple
import logging

from recommendation.scoring import RecommendationScorer

logger = logging.getLogger("agrinext.simulation")

class ClimateSimulator:
    """Simulates hypothetical climate stress scenarios against actual NASA baseline observations."""

    SCIENTIFIC_DISCLAIMER = (
        "HYPOTHETICAL SENSITIVITY TEST: Gridded satellite baseline values (NASA POWER, SMAP, GPM) "
        "have been adjusted by user-specified hypothetical stress parameters. "
        "This tool is an agronomic sensitivity test, NOT a numerical weather forecast or "
        "coupled physical General Circulation Model (GCM). Original satellite baseline observations "
        "remain immutable and preserved."
    )

    def __init__(self):
        self.scorer = RecommendationScorer()

    def simulate_scenario(
        self,
        baseline_dossier: Dict[str, Any],
        crops: List[Dict[str, Any]],
        crop_rules: List[Dict[str, Any]],
        farmer_profile: Optional[Dict[str, Any]] = None,
        weights: Optional[Dict[str, float]] = None,
        rainfall_pct_change: float = 0.0,
        temp_celsius_change: float = 0.0,
        water_availability_pct_change: float = 0.0,
        baseline_strategies: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Executes a climate what-if simulation:
        1. Extracts immutable baseline indicators from NASA dossier.
        2. Applies hypothetical adjustments to derived environmental parameters.
        3. Recalculates water, climate, soil, and local suitability scores using RecommendationScorer.
        4. Compares baseline and scenario-adjusted rankings and scores.
        5. Records all transformation formulas and scientific assumptions.
        """
        # Validate weights
        active_weights = self.scorer.validate_weights(weights or self.scorer.DEFAULT_WEIGHTS)
        baseline_weights = self.scorer.DEFAULT_WEIGHTS

        # 1. Extract NASA baseline environmental values
        precip_info = baseline_dossier.get("precipitation_synthesis", {})
        swb_info = baseline_dossier.get("soil_water_balance", {})

        baseline_annual_rainfall = 650.0
        if precip_info and precip_info.get("gpm_satellite_annual_mm"):
            baseline_annual_rainfall = float(precip_info["gpm_satellite_annual_mm"])
        elif precip_info and precip_info.get("power_reanalysis_annual_mm"):
            baseline_annual_rainfall = float(precip_info["power_reanalysis_annual_mm"])
        else:
            for ev in baseline_dossier.get("evidence_items", []):
                if ev.get("parameter_code") == "PRECTOTCORR":
                    baseline_annual_rainfall = float(ev.get("actual_value", 650.0))
                    break

        baseline_t2m_avg = 27.5
        baseline_t2m_max = 35.0
        baseline_solar_mj = None
        baseline_humidity_pct = None

        for ev in baseline_dossier.get("evidence_items", []):
            code = ev.get("parameter_code", "")
            val = float(ev.get("actual_value", 0.0))
            if code == "T2M":
                baseline_t2m_avg = val
            elif code == "T2M_MAX":
                baseline_t2m_max = val
            elif code == "ALLSKY_SFC_SW_DWN":
                baseline_solar_mj = val
            elif code == "RH2M":
                baseline_humidity_pct = val

        irrigation_source = farmer_profile.get("irrigation_source", "Rainfed") if farmer_profile else "Rainfed"
        farming_season = farmer_profile.get("farming_season", "Kharif") if farmer_profile else "Kharif"
        previous_crops = farmer_profile.get("previous_crops", []) if farmer_profile else []

        smap_status = baseline_dossier.get("dataset_status", {}).get("nasa_smap", {}).get("connected", False)
        baseline_smap_moisture = swb_info.get("surface_moisture_m3_m3") if smap_status and swb_info else None
        baseline_smap_regime = swb_info.get("regime") if smap_status and swb_info else None
        baseline_smap_trend = swb_info.get("trend") if smap_status and swb_info else None

        # 2. Derive Simulated Environmental Indicators (Without overwriting baseline)
        simulated_annual_rainfall = max(0.0, round(baseline_annual_rainfall * (1.0 + (rainfall_pct_change / 100.0)), 1))
        simulated_t2m_avg = round(baseline_t2m_avg + temp_celsius_change, 1)
        simulated_t2m_max = round(baseline_t2m_max + temp_celsius_change, 1)

        # Modulate SMAP moisture regime under simulated stress
        simulated_smap_moisture = baseline_smap_moisture
        simulated_smap_regime = baseline_smap_regime
        simulated_smap_trend = baseline_smap_trend

        has_anomaly = (rainfall_pct_change != 0.0 or temp_celsius_change != 0.0 or water_availability_pct_change != 0.0)

        if has_anomaly:
            if rainfall_pct_change < 0:
                simulated_smap_trend = "drying"
            elif rainfall_pct_change > 0:
                simulated_smap_trend = "wetting"

            if baseline_smap_moisture is not None:
                # Scale surface moisture with rainfall & water availability factor
                moisture_factor = 1.0 + ((rainfall_pct_change + water_availability_pct_change) / 200.0)
                simulated_smap_moisture = max(0.02, min(0.45, round(baseline_smap_moisture * moisture_factor, 3)))
                if simulated_smap_moisture < 0.12 or rainfall_pct_change <= -15.0:
                    simulated_smap_regime = "deficit"
                elif simulated_smap_moisture > 0.28 or rainfall_pct_change >= 20.0:
                    simulated_smap_regime = "surplus"
                else:
                    simulated_smap_regime = "adequate"

        # Irrigation buffer modification
        simulated_water_factor = 1.0 + (water_availability_pct_change / 100.0)

        # Transformation assumptions audit
        transformations_audit = {
            "rainfall": {
                "baseline_source": "NASA POWER / GPM Calibrated Baseline",
                "baseline_value_mm": baseline_annual_rainfall,
                "percentage_adjustment": rainfall_pct_change,
                "simulated_value_mm": simulated_annual_rainfall,
                "delta_mm": round(simulated_annual_rainfall - baseline_annual_rainfall, 1),
                "formula": "Simulated_Rain = Baseline_Rain * (1 + delta_rainfall_pct / 100)",
                "classification": "HYPOTHETICAL SIMULATION"
            },
            "temperature": {
                "baseline_source": "NASA POWER Diurnal 2m Reanalysis",
                "baseline_t2m_avg_c": baseline_t2m_avg,
                "baseline_t2m_max_c": baseline_t2m_max,
                "celsius_adjustment": temp_celsius_change,
                "simulated_t2m_avg_c": simulated_t2m_avg,
                "simulated_t2m_max_c": simulated_t2m_max,
                "formula": "Simulated_T = Baseline_T + delta_celsius",
                "classification": "HYPOTHETICAL SIMULATION"
            },
            "water_availability": {
                "baseline_source": f"Farmer Infrastructure ({irrigation_source}) + NASA SMAP V6",
                "water_availability_pct_change": water_availability_pct_change,
                "simulated_smap_moisture_m3_m3": simulated_smap_moisture,
                "simulated_smap_regime": simulated_smap_regime,
                "formula": "Simulated_Buffer = Base_Buffer * (1 + delta_water_pct / 100)",
                "classification": "HYPOTHETICAL SIMULATION"
            }
        }

        # 3. Assemble Strategy Archetypes
        # Use existing baseline strategies or build archetype crop lists
        archetype_crop_lists = self._resolve_archetype_crop_lists(crops)

        # 4. Compute Scores for both Baseline and Simulated Scenario
        baseline_results = []
        scenario_results = []

        for strat_id, strat_title, crop_list in archetype_crop_lists:
            # Baseline scoring
            b_w_score, b_w_meta = self.scorer.compute_water_suitability(
                crops=crop_list,
                effective_annual_rainfall_mm=baseline_annual_rainfall,
                smap_soil_moisture=baseline_smap_moisture,
                smap_regime=baseline_smap_regime,
                smap_trend=baseline_smap_trend,
                irrigation_source=irrigation_source
            )
            b_c_score, b_c_meta = self.scorer.compute_climate_suitability(
                crops=crop_list,
                t2m_avg=baseline_t2m_avg,
                t2m_max=baseline_t2m_max,
                solar_radiation_mj=baseline_solar_mj,
                relative_humidity_pct=baseline_humidity_pct
            )
            b_s_score, b_s_meta = self.scorer.compute_soil_health_potential(
                crops=crop_list,
                farmer_profile=farmer_profile,
                previous_crops=previous_crops
            )
            b_l_score, b_l_meta = self.scorer.compute_local_suitability(
                crops=crop_list,
                farmer_profile=farmer_profile,
                target_season=farming_season
            )
            b_overall, _ = self.scorer.compute_overall_score(
                water_score=b_w_score,
                soil_score=b_s_score,
                climate_score=b_c_score,
                local_score=b_l_score,
                weights=active_weights
            )

            # Scenario scoring using SIMULATED values
            # Adjust irrigation buffer for water availability change
            sim_w_score, sim_w_meta = self.scorer.compute_water_suitability(
                crops=crop_list,
                effective_annual_rainfall_mm=simulated_annual_rainfall,
                smap_soil_moisture=simulated_smap_moisture,
                smap_regime=simulated_smap_regime,
                smap_trend=simulated_smap_trend,
                irrigation_source=irrigation_source
            )
            # Apply water availability percentage change to water score
            if water_availability_pct_change != 0.0:
                water_adjustment = (water_availability_pct_change / 100.0) * 12.0
                sim_w_score = max(5.0, min(100.0, round(sim_w_score + water_adjustment, 1)))

            sim_c_score, sim_c_meta = self.scorer.compute_climate_suitability(
                crops=crop_list,
                t2m_avg=simulated_t2m_avg,
                t2m_max=simulated_t2m_max,
                solar_radiation_mj=baseline_solar_mj,
                relative_humidity_pct=baseline_humidity_pct
            )
            sim_s_score, _ = self.scorer.compute_soil_health_potential(
                crops=crop_list,
                farmer_profile=farmer_profile,
                previous_crops=previous_crops
            )
            sim_l_score, _ = self.scorer.compute_local_suitability(
                crops=crop_list,
                farmer_profile=farmer_profile,
                target_season=farming_season
            )
            sim_overall, _ = self.scorer.compute_overall_score(
                water_score=sim_w_score,
                soil_score=sim_s_score,
                climate_score=sim_c_score,
                local_score=sim_l_score,
                weights=active_weights
            )

            crop_names = [c.get("name", "Crop") for c in crop_list]
            seq_desc = " → ".join(crop_names)

            baseline_results.append({
                "id": strat_id,
                "title": strat_title,
                "sequence": seq_desc,
                "overall_score": b_overall,
                "individual_scores": {
                    "water_suitability": b_w_score,
                    "soil_health_potential": b_s_score,
                    "climate_suitability": b_c_score,
                    "local_agricultural_suitability": b_l_score
                }
            })

            scenario_results.append({
                "id": strat_id,
                "title": strat_title,
                "sequence": seq_desc,
                "overall_score": sim_overall,
                "individual_scores": {
                    "water_suitability": sim_w_score,
                    "soil_health_potential": sim_s_score,
                    "climate_suitability": sim_c_score,
                    "local_agricultural_suitability": sim_l_score
                },
                "simulated_metadata": {
                    "water": sim_w_meta,
                    "climate": sim_c_meta
                }
            })

        # Assign ranks
        baseline_results.sort(key=lambda x: x["overall_score"], reverse=True)
        for idx, item in enumerate(baseline_results, start=1):
            item["baseline_rank"] = idx

        scenario_results.sort(key=lambda x: x["overall_score"], reverse=True)
        for idx, item in enumerate(scenario_results, start=1):
            item["scenario_rank"] = idx

        # 5. Build Comprehensive Comparison Matrix & Resilience Explanations
        comparison_matrix = []
        for scen_item in scenario_results:
            sid = scen_item["id"]
            base_item = next(b for b in baseline_results if b["id"] == sid)

            b_rank = base_item["baseline_rank"]
            s_rank = scen_item["scenario_rank"]
            b_score = base_item["overall_score"]
            s_score = scen_item["overall_score"]
            score_delta = round(s_score - b_score, 1)
            rank_shift = b_rank - s_rank

            # Generate agronomic resilience explanation
            resilience_explanation = self._generate_resilience_explanation(
                strategy_title=scen_item["title"],
                sid=sid,
                score_delta=score_delta,
                rank_shift=rank_shift,
                baseline_rank=b_rank,
                scenario_rank=s_rank,
                base_scores=base_item["individual_scores"],
                sim_scores=scen_item["individual_scores"],
                rainfall_pct_change=rainfall_pct_change,
                temp_celsius_change=temp_celsius_change,
                water_availability_pct_change=water_availability_pct_change
            )

            comparison_matrix.append({
                "strategy_id": sid,
                "title": scen_item["title"],
                "sequence": scen_item["sequence"],
                "baseline_rank": b_rank,
                "scenario_rank": s_rank,
                "baseline_score": b_score,
                "scenario_score": s_score,
                "score_delta": score_delta,
                "rank_shift": rank_shift,
                "shift_direction": "up" if rank_shift > 0 else "down" if rank_shift < 0 else "unchanged",
                "resilience_explanation": resilience_explanation,
                "baseline_scores": base_item["individual_scores"],
                "scenario_scores": scen_item["individual_scores"]
            })

        # Determine most resilient strategy under this scenario
        # Most resilient = least negative score delta or highest scenario score
        most_resilient = max(comparison_matrix, key=lambda x: x["score_delta"])

        return {
            "simulation_id": f"SIM-{abs(hash((rainfall_pct_change, temp_celsius_change, water_availability_pct_change))) % 1000000:06d}",
            "scientific_classification": "SIMULATED_HYPOTHETICAL_SCENARIO",
            "is_simulated": True,
            "disclaimer": self.SCIENTIFIC_DISCLAIMER,
            "scenario_parameters": {
                "rainfall_pct_change": rainfall_pct_change,
                "temp_celsius_change": temp_celsius_change,
                "water_availability_pct_change": water_availability_pct_change
            },
            "transformations_audit": transformations_audit,
            "comparison_matrix": comparison_matrix,
            "most_resilient_strategy": {
                "strategy_id": most_resilient["strategy_id"],
                "title": most_resilient["title"],
                "scenario_score": most_resilient["scenario_score"],
                "score_delta": most_resilient["score_delta"]
            },
            "applied_weights": active_weights,
            "baseline_preservation_notice": (
                "Verified NASA Earth observations (POWER, SMAP, GPM) are preserved in their original state. "
                "If this simulation is dismissed, recommendations revert to the unadjusted NASA baseline."
            )
        }

    def _resolve_archetype_crop_lists(self, crops: List[Dict[str, Any]]) -> List[Tuple[str, str, List[Dict[str, Any]]]]:
        """Resolves the 3 standard strategy crop sequences from state crops."""
        # Find representative crops
        groundnut = next((c for c in crops if "groundnut" in c.get("id", "").lower()), {"id": "groundnut", "name": "Groundnut", "drought_tolerance": "high", "water_requirement_mm": [450, 650], "nitrogen_impact": "fixing"})
        bengal_gram = next((c for c in crops if "bengal_gram" in c.get("id", "").lower() or "chickpea" in c.get("id", "").lower()), {"id": "bengal_gram", "name": "Bengal Gram", "drought_tolerance": "high", "water_requirement_mm": [250, 350], "nitrogen_impact": "fixing"})
        sorghum = next((c for c in crops if "sorghum" in c.get("id", "").lower() or "jowar" in c.get("id", "").lower()), {"id": "sorghum", "name": "Sorghum", "drought_tolerance": "high", "water_requirement_mm": [400, 600], "nitrogen_impact": "depleting"})
        cotton = next((c for c in crops if "cotton" in c.get("id", "").lower()), {"id": "cotton", "name": "Cotton", "drought_tolerance": "moderate", "water_requirement_mm": [700, 1100], "nitrogen_impact": "depleting"})
        green_gram = next((c for c in crops if "green_gram" in c.get("id", "").lower() or "moong" in c.get("id", "").lower()), {"id": "green_gram", "name": "Green Gram", "drought_tolerance": "moderate", "water_requirement_mm": [300, 400], "nitrogen_impact": "fixing"})

        fallow_cover = {
            "id": "fallow_green_manure",
            "name": "Fallow / Sesbania Cover",
            "drought_tolerance": "high",
            "water_requirement_mm": [100, 200],
            "nitrogen_impact": "fixing"
        }

        return [
            ("climate_resilient", "Maximum Climate Resilience", [groundnut, bengal_gram, fallow_cover]),
            ("soil_restoration", "Soil Health & Nutrient Regeneration", [sorghum, bengal_gram, green_gram]),
            ("economic_balanced", "Balanced Economic & Risk Diversification", [cotton, sorghum, green_gram])
        ]

    def _generate_resilience_explanation(
        self,
        strategy_title: str,
        sid: str,
        score_delta: float,
        rank_shift: int,
        baseline_rank: int,
        scenario_rank: int,
        base_scores: Dict[str, float],
        sim_scores: Dict[str, float],
        rainfall_pct_change: float,
        temp_celsius_change: float,
        water_availability_pct_change: float
    ) -> str:
        """Constructs explainable agronomic rationale for score and ranking movements under simulated stress."""
        sign = "+" if score_delta >= 0 else ""
        water_diff = round(sim_scores["water_suitability"] - base_scores["water_suitability"], 1)
        climate_diff = round(sim_scores["climate_suitability"] - base_scores["climate_suitability"], 1)

        # Baseline scenario check
        if rainfall_pct_change == 0 and temp_celsius_change == 0 and water_availability_pct_change == 0:
            return f"Identical to NASA baseline observations (Overall: {sim_scores.get('water_suitability', 0):.1f} water, {sim_scores.get('climate_suitability', 0):.1f} climate). No hypothetical anomaly applied."

        stress_descriptions = []
        if rainfall_pct_change < 0:
            stress_descriptions.append(f"{abs(rainfall_pct_change):.0f}% rainfall reduction")
        elif rainfall_pct_change > 0:
            stress_descriptions.append(f"+{rainfall_pct_change:.0f}% rainfall surplus")

        if temp_celsius_change > 0:
            stress_descriptions.append(f"+{temp_celsius_change:.1f}°C thermal stress")
        elif temp_celsius_change < 0:
            stress_descriptions.append(f"{temp_celsius_change:.1f}°C temperature reduction")

        if water_availability_pct_change < 0:
            stress_descriptions.append(f"{abs(water_availability_pct_change):.0f}% irrigation buffer curtailment")

        stress_summary = ", ".join(stress_descriptions) if stress_descriptions else "scenario parameters"

        if sid == "climate_resilient":
            if score_delta >= -5.0:
                buffering = (
                    f"Under simulated {stress_summary}, this strategy demonstrated high drought buffering (Water score {water_diff:+.1f} pts). "
                    f"Low evapotranspirative demand of groundnut and chickpea prevented severe yield penalties."
                )
            else:
                buffering = f"Compounded heat and moisture stress reduced suitability by {score_delta:.1f} pts, but drought-tolerant genetics cushioned total crop failure."

        elif sid == "soil_restoration":
            if temp_celsius_change > 2.0:
                buffering = (
                    f"Thermal stress compound (Climate score {climate_diff:+.1f} pts) impacted summer pulse flowering windows, "
                    f"though high biological nitrogen fixation potential (+35 kg/ha) kept soil health index resilient."
                )
            else:
                buffering = f"Deep-rooted sorghum and legume nitrogen credits buffered moisture fluctuations (Water score {water_diff:+.1f} pts)."

        else: # economic_balanced
            if rainfall_pct_change <= -15.0 or water_availability_pct_change <= -20.0:
                buffering = (
                    f"High water demand crops (e.g. Cotton) suffered substantial penalties under moisture deficit "
                    f"(Water suitability dropped by {abs(water_diff):.1f} pts), causing overall suitability to drop by {abs(score_delta):.1f} pts."
                )
            else:
                buffering = f"Balanced cash flow buffer remained viable with a net score adjustment of {sign}{score_delta:.1f} pts."

        rank_clause = ""
        if rank_shift > 0:
            rank_clause = f" Promoted from #{baseline_rank} to #{scenario_rank} as its climate-buffering resilience surpassed competing rotations."
        elif rank_shift < 0:
            rank_clause = f" Shifted from #{baseline_rank} to #{scenario_rank} due to higher vulnerability under simulated stress conditions."
        else:
            rank_clause = f" Maintained #{scenario_rank} ranking across baseline and simulated scenarios."

        return f"{buffering}{rank_clause}"
