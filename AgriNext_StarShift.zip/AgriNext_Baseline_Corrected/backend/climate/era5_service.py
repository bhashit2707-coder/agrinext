"""ERA5 historical point time-series via Open-Meteo Archive API.
Reanalysis estimates, not farm sensor observations."""
from datetime import date, timedelta
from typing import Any, Dict, Optional
import requests

class ERA5Service:
    ENDPOINT = "https://archive-api.open-meteo.com/v1/archive"
    MODEL = "era5"
    VARIABLES = ["temperature_2m", "precipitation", "et0_fao_evapotranspiration", "soil_moisture_0_to_7cm", "soil_moisture_7_to_28cm", "soil_moisture_28_to_100cm", "soil_moisture_100_to_255cm"]
    def __init__(self, timeout: int = 30, session=None):
        self.timeout, self.session = timeout, session or requests.Session()
    def get_service_status(self) -> Dict[str, Any]:
        return {"service": "ERA5 historical reanalysis", "status": "ready", "provider": "Open-Meteo Historical Weather API", "model": self.MODEL, "temporal_resolution": "hourly", "spatial_resolution": "approximately 0.25° (~25 km)", "variables": self.VARIABLES, "note": "Reanalysis/model estimates, not direct farm sensor measurements. ERA5 global reanalysis is approximately 0.25° resolution."}
    def query_point(self, latitude: float, longitude: float, start_date: Optional[str] = None, end_date: Optional[str] = None) -> Dict[str, Any]:
        if not -90 <= latitude <= 90 or not -180 <= longitude <= 180: raise ValueError("Latitude or longitude is outside valid WGS84 bounds")
        end = date.fromisoformat(end_date) if end_date else date.today() - timedelta(days=7)
        start = date.fromisoformat(start_date) if start_date else end - timedelta(days=6)
        if start > end: raise ValueError("start_date must be on or before end_date")
        if (end-start).days > 31: raise ValueError("ERA5 point query is limited to 32 calendar days per request")
        params = {"latitude": latitude, "longitude": longitude, "start_date": start.isoformat(), "end_date": end.isoformat(), "hourly": ",".join(self.VARIABLES), "models": self.MODEL, "timezone": "UTC"}
        response = self.session.get(self.ENDPOINT, params=params, timeout=self.timeout); response.raise_for_status()
        payload = response.json(); hourly = payload.get("hourly") or {}; times = hourly.get("time") or []
        series = {k: hourly.get(k, []) for k in self.VARIABLES if k in hourly}
        if not times: return {"status": "no_data", "connected": True, "model": self.MODEL, "coordinates": {"latitude": latitude, "longitude": longitude}, "hourly": {"time": [], **series}, "message": "The archive returned no hourly records for this period."}
        return {"status": "success", "connected": True, "provider": "Open-Meteo Historical Weather API", "dataset": "ERA5", "model": self.MODEL, "coordinates": {"latitude": latitude, "longitude": longitude}, "period": {"start": start.isoformat(), "end": end.isoformat()}, "timezone": payload.get("timezone", "UTC"), "elevation_m": payload.get("elevation"), "hourly": {"time": times, **series}, "units": payload.get("hourly_units", {}), "source_url": self.ENDPOINT, "note": "ERA5 reanalysis estimates on a model grid; not local sensor readings. Soil moisture variables are volumetric m³/m³; ET0 is reference evapotranspiration, not actual evapotranspiration."}
