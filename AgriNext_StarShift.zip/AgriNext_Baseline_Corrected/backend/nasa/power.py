"""
NASA POWER (Prediction of Worldwide Energy Resources) Agroclimatology Service.
Retrieves real gridded daily environmental datasets from the official NASA POWER API.
Base URL: https://power.larc.nasa.gov/api/temporal/daily/point

Scientific Transparency Notes:
- NASA POWER is a gridded environmental data product, not an in-situ farm sensor.
- Meteorological variables (T2M, PRECTOTCORR, RH2M, WS10M) are derived from the NASA GMAO
  MERRA-2 assimilation model at 0.5° x 0.5° (~50km) resolution.
- Solar irradiance (ALLSKY_SFC_SW_DWN) is derived from satellite observations (NASA CERES
  and FLASHFlux) at 1.0° x 1.0° (~100km) resolution.
- Historical data represents multi-year climatological baseline evidence, not a forecast.
"""

import hashlib
import calendar
import os
import json
import logging
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple
import requests
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

import database

logger = logging.getLogger("agrinext.nasa.power")

FILL_VALUE_THRESHOLD = -900.0

PARAMETERS = [
    "T2M",
    "T2M_MAX",
    "T2M_MIN",
    "PRECTOTCORR",
    "RH2M",
    "ALLSKY_SFC_SW_DWN",
    "WS10M"
]

PARAMETER_METADATA = {
    "T2M": {
        "name": "Temperature at 2 Meters",
        "unit": "°C",
        "source": "NASA GMAO MERRA-2 Assimilation Model",
        "spatial_resolution": "0.5° x 0.5° (~50 km)",
        "is_satellite": False,
        "is_reanalysis": True,
        "description": "Daily average air temperature at 2 meters above surface level."
    },
    "T2M_MAX": {
        "name": "Maximum Temperature at 2 Meters",
        "unit": "°C",
        "source": "NASA GMAO MERRA-2 Assimilation Model",
        "spatial_resolution": "0.5° x 0.5° (~50 km)",
        "is_satellite": False,
        "is_reanalysis": True,
        "description": "Daily maximum air temperature at 2 meters above surface level."
    },
    "T2M_MIN": {
        "name": "Minimum Temperature at 2 Meters",
        "unit": "°C",
        "source": "NASA GMAO MERRA-2 Assimilation Model",
        "spatial_resolution": "0.5° x 0.5° (~50 km)",
        "is_satellite": False,
        "is_reanalysis": True,
        "description": "Daily minimum air temperature at 2 meters above surface level."
    },
    "PRECTOTCORR": {
        "name": "Precipitation Corrected",
        "unit": "mm/day",
        "source": "NASA GMAO MERRA-2 Assimilation Model",
        "spatial_resolution": "0.5° x 0.5° (~50 km)",
        "is_satellite": False,
        "is_reanalysis": True,
        "description": "Daily total corrected precipitation."
    },
    "RH2M": {
        "name": "Relative Humidity at 2 Meters",
        "unit": "%",
        "source": "NASA GMAO MERRA-2 Assimilation Model",
        "spatial_resolution": "0.5° x 0.5° (~50 km)",
        "is_satellite": False,
        "is_reanalysis": True,
        "description": "Daily average relative humidity at 2 meters above ground."
    },
    "ALLSKY_SFC_SW_DWN": {
        "name": "All Sky Surface Downward Shortwave Irradiance",
        "unit": "MJ/m^2/day",
        "source": "NASA CERES & FLASHFlux Satellite Observations",
        "spatial_resolution": "1.0° x 1.0° (~100 km)",
        "is_satellite": True,
        "is_reanalysis": False,
        "description": "Daily total solar radiation incident on a horizontal surface."
    },
    "WS10M": {
        "name": "Wind Speed at 10 Meters",
        "unit": "m/s",
        "source": "NASA GMAO MERRA-2 Assimilation Model",
        "spatial_resolution": "0.5° x 0.5° (~50 km)",
        "is_satellite": False,
        "is_reanalysis": True,
        "description": "Daily average wind speed measured at 10 meters height."
    }
}

MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

class NASAPowerService:
    """Production service to query and process NASA POWER agroclimatology data."""

    BASE_URL = "https://power.larc.nasa.gov/api/temporal/daily/point"

    def __init__(self, timeout_sec: int = 30):
        self.timeout_sec = timeout_sec
        self.session = self._create_retry_session()

    def _create_retry_session(self) -> requests.Session:
        session = requests.Session()
        retries = Retry(
            total=3,
            backoff_factor=1.0,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"]
        )
        adapter = HTTPAdapter(max_retries=retries)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        return session

    def get_service_status(self) -> Dict[str, Any]:
        """Returns service metadata and readiness status."""
        return {
            "service": "NASA POWER",
            "status": "ready",
            "api_endpoint": self.BASE_URL,
            "community": "AG",
            "parameters": list(PARAMETER_METADATA.keys()),
            "metadata": {
                "meteorology_model": "GMAO MERRA-2 (0.5° x 0.5°)",
                "solar_radiation": "CERES / FLASHFlux (1.0° x 1.0°)",
                "provider": "NASA Langley Research Center POWER Project",
                "documentation": "https://power.larc.nasa.gov/docs/services/api/temporal/daily/"
            }
        }

    def _generate_cache_key(self, lat: float, lng: float, start: str, end: str, params: List[str]) -> str:
        # Round coords to 3 decimals (~100m, well within 0.5 deg grid)
        lat_r = round(lat, 3)
        lng_r = round(lng, 3)
        params_str = ",".join(sorted(params))
        raw = f"{lat_r}_{lng_r}_{start}_{end}_{params_str}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def get_default_date_range(self) -> Tuple[str, str]:
        """Return the previous three complete calendar years as a rolling baseline."""
        current_year = datetime.now(timezone.utc).year
        start_year = current_year - 3
        end_year = current_year - 1
        return (f"{start_year}0101", f"{end_year}1231")

    @staticmethod
    def _cache_is_fresh(cached_data: Dict[str, Any], now: Optional[datetime] = None) -> bool:
        """Cached POWER responses without a valid timestamp are treated as stale."""
        try:
            ttl_seconds = max(0, int(os.getenv("NASA_POWER_CACHE_TTL_SECONDS", "86400")))
        except (TypeError, ValueError):
            ttl_seconds = 86400
        cached_at = cached_data.get("_cached_at")
        if not cached_at or ttl_seconds == 0:
            return False
        try:
            cached_time = datetime.fromisoformat(str(cached_at).replace("Z", "+00:00"))
            if cached_time.tzinfo is None:
                cached_time = cached_time.replace(tzinfo=timezone.utc)
            current_time = now or datetime.now(timezone.utc)
            if current_time.tzinfo is None:
                current_time = current_time.replace(tzinfo=timezone.utc)
            age = (current_time - cached_time).total_seconds()
            return 0 <= age <= ttl_seconds
        except (TypeError, ValueError, OverflowError):
            return False

    def fetch_agroclimatology(
        self,
        lat: float,
        lng: float,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        use_cache: bool = True
    ) -> Dict[str, Any]:
        """
        Fetches real daily agroclimatology from NASA POWER API,
        computes daily/monthly summaries and extracts formal Environmental Evidence Objects.
        """
        if not (-90.0 <= lat <= 90.0 and -180.0 <= lng <= 180.0):
            raise ValueError(f"Invalid geographic coordinates: lat={lat}, lng={lng}")

        # Determine date range (format: YYYYMMDD)
        def_start, def_end = self.get_default_date_range()
        start = (start_date or def_start).replace("-", "")
        end = (end_date or def_end).replace("-", "")

        cache_key = self._generate_cache_key(lat, lng, start, end, PARAMETERS)

        raw_data = None
        is_from_cache = False
        cached_at = None

        if use_cache:
            cached_data = database.get_cached_power_data(cache_key)
            if cached_data and self._cache_is_fresh(cached_data):
                raw_data = cached_data
                is_from_cache = True
                cached_at = cached_data.get("_cached_at")
                logger.info("NASA POWER cache hit for key=%s", cache_key[:12])
            elif cached_data:
                logger.info("NASA POWER cache expired or missing timestamp for key=%s", cache_key[:12])

        if not raw_data:
            # Query official NASA POWER API
            query_params = {
                "parameters": ",".join(PARAMETERS),
                "community": "AG",
                "longitude": lng,
                "latitude": lat,
                "start": start,
                "end": end,
                "format": "JSON",
                "time-standard": "UTC"
            }

            try:
                logger.info(f"Querying NASA POWER API for lat={lat}, lng={lng}, range={start}-{end}")
                resp = self.session.get(self.BASE_URL, params=query_params, timeout=self.timeout_sec)
                
                if resp.status_code != 200:
                    raise RuntimeError(
                        f"NASA POWER API returned HTTP {resp.status_code}: {resp.text}"
                    )

                raw_data = resp.json()

                # Save response to persistent SQLite cache
                if use_cache:
                    database.save_cached_power_data(
                        cache_key=cache_key,
                        lat=lat,
                        lng=lng,
                        start_date=start,
                        end_date=end,
                        parameters=",".join(PARAMETERS),
                        response_data=raw_data
                    )
            except requests.exceptions.RequestException as e:
                logger.error(f"NASA POWER API network error: {e}")
                raise RuntimeError(
                    f"Unable to connect to NASA POWER service at {self.BASE_URL}: {str(e)}"
                )

        # Parse and process dataset
        return self._process_power_response(
            raw_data=raw_data,
            lat=lat,
            lng=lng,
            start=start,
            end=end,
            is_from_cache=is_from_cache,
            cached_at=cached_at
        )

    def _process_power_response(
        self,
        raw_data: Dict[str, Any],
        lat: float,
        lng: float,
        start: str,
        end: str,
        is_from_cache: bool,
        cached_at: Optional[str]
    ) -> Dict[str, Any]:
        """
        Parses raw NASA POWER response, cleans invalid values,
        aggregates daily & monthly metrics, and generates Evidence Objects.
        """
        properties = raw_data.get("properties", {})
        param_dict = properties.get("parameter", {})
        geometry = raw_data.get("geometry", {})
        elevation = geometry.get("coordinates", [lng, lat, 0.0])[2] if len(geometry.get("coordinates", [])) > 2 else None

        # Validate parameter availability
        for p in PARAMETERS:
            if p not in param_dict:
                raise ValueError(f"Missing expected parameter '{p}' in NASA POWER response")

        # 1. Build Daily Records and collect valid values
        all_dates = sorted(list(param_dict["T2M"].keys()))
        daily_records: List[Dict[str, Any]] = []
        param_clean_values: Dict[str, Dict[str, Optional[float]]] = {p: {} for p in PARAMETERS}
        missing_stats: Dict[str, Dict[str, Any]] = {}

        for p in PARAMETERS:
            vals = param_dict[p]
            missing_cnt = 0
            valid_cnt = 0
            for d, v in vals.items():
                if v is None or v <= FILL_VALUE_THRESHOLD:
                    param_clean_values[p][d] = None
                    missing_cnt += 1
                else:
                    param_clean_values[p][d] = float(v)
                    valid_cnt += 1
            
            missing_stats[p] = {
                "missing_count": missing_cnt,
                "valid_count": valid_cnt,
                "total_count": len(vals),
                "missing_percentage": round((missing_cnt / len(vals)) * 100.0, 2) if len(vals) > 0 else 0.0
            }

        # Build chronological daily records
        for d in all_dates:
            # Format date as YYYY-MM-DD
            d_formatted = f"{d[0:4]}-{d[4:6]}-{d[6:8]}"
            daily_records.append({
                "date": d_formatted,
                "date_code": d,
                "t2m": param_clean_values["T2M"].get(d),
                "t2m_max": param_clean_values["T2M_MAX"].get(d),
                "t2m_min": param_clean_values["T2M_MIN"].get(d),
                "precipitation_mm": param_clean_values["PRECTOTCORR"].get(d),
                "relative_humidity": param_clean_values["RH2M"].get(d),
                "solar_radiation_mj": param_clean_values["ALLSKY_SFC_SW_DWN"].get(d),
                "wind_speed_ms": param_clean_values["WS10M"].get(d)
            })

        # 2. Build Monthly Summaries
        monthly_groups: Dict[str, List[Dict[str, Any]]] = {}
        for r in daily_records:
            ym = r["date"][0:7] # "YYYY-MM"
            if ym not in monthly_groups:
                monthly_groups[ym] = []
            monthly_groups[ym].append(r)

        monthly_summaries: List[Dict[str, Any]] = []
        for ym in sorted(monthly_groups.keys()):
            group = monthly_groups[ym]
            year = int(ym[0:4])
            month = int(ym[5:7])

            # Rainfall metrics
            rain_vals = [r["precipitation_mm"] for r in group if r["precipitation_mm"] is not None]
            expected_days = calendar.monthrange(year, month)[1]
            rain_valid_days = len(rain_vals)
            rain_coverage_pct = round((rain_valid_days / expected_days) * 100.0, 1)
            # A monthly total is only published when every calendar day is present.
            # Partial sums are retained separately and explicitly labelled.
            total_rain = sum(rain_vals) if rain_valid_days == expected_days else None
            rainy_days = sum(1 for v in rain_vals if v >= 1.0)
            heavy_rain_days = sum(1 for v in rain_vals if v >= 35.0)

            # Temperature metrics
            t2m_vals = [r["t2m"] for r in group if r["t2m"] is not None]
            t2m_max_vals = [r["t2m_max"] for r in group if r["t2m_max"] is not None]
            t2m_min_vals = [r["t2m_min"] for r in group if r["t2m_min"] is not None]
            avg_t2m = (sum(t2m_vals) / len(t2m_vals)) if t2m_vals else None
            max_t2m = max(t2m_max_vals) if t2m_max_vals else None
            min_t2m = min(t2m_min_vals) if t2m_min_vals else None

            # Humidity metrics
            rh_vals = [r["relative_humidity"] for r in group if r["relative_humidity"] is not None]
            avg_rh = (sum(rh_vals) / len(rh_vals)) if rh_vals else None

            # Solar radiation metrics
            solar_vals = [r["solar_radiation_mj"] for r in group if r["solar_radiation_mj"] is not None]
            avg_solar = (sum(solar_vals) / len(solar_vals)) if solar_vals else None

            # Wind speed
            wind_vals = [r["wind_speed_ms"] for r in group if r["wind_speed_ms"] is not None]
            avg_wind = (sum(wind_vals) / len(wind_vals)) if wind_vals else None

            monthly_summaries.append({
                "year_month": ym,
                "year": year,
                "month": month,
                "month_name": MONTH_NAMES[month - 1],
                "total_precipitation_mm": round(total_rain, 1) if total_rain is not None else None,
                "partial_precipitation_sum_mm": round(sum(rain_vals), 1) if rain_vals else None,
                "precipitation_valid_days": rain_valid_days,
                "precipitation_expected_days": expected_days,
                "precipitation_coverage_pct": rain_coverage_pct,
                "precipitation_complete": rain_valid_days == expected_days,
                "rainy_days_count": rainy_days,
                "heavy_rain_days_count": heavy_rain_days,
                "avg_temperature_c": round(avg_t2m, 2) if avg_t2m is not None else None,
                "max_temperature_c": round(max_t2m, 2) if max_t2m is not None else None,
                "min_temperature_c": round(min_t2m, 2) if min_t2m is not None else None,
                "avg_relative_humidity": round(avg_rh, 1) if avg_rh is not None else None,
                "avg_solar_radiation_mj": round(avg_solar, 2) if avg_solar is not None else None,
                "avg_wind_speed_ms": round(avg_wind, 2) if avg_wind is not None else None
            })

        # 3. Compute 12-Month Climatological Normals across the multi-year sample
        climatological_normals = []
        for m in range(1, 13):
            m_summaries = [s for s in monthly_summaries if s["month"] == m]
            if m_summaries:
                rain_list = [s["total_precipitation_mm"] for s in m_summaries if s["total_precipitation_mm"] is not None]
                norm_rain = (sum(rain_list) / len(rain_list)) if rain_list else None
                t2m_list = [s["avg_temperature_c"] for s in m_summaries if s["avg_temperature_c"] is not None]
                norm_t2m = (sum(t2m_list) / len(t2m_list)) if t2m_list else None
                rh_list = [s["avg_relative_humidity"] for s in m_summaries if s["avg_relative_humidity"] is not None]
                norm_rh = (sum(rh_list) / len(rh_list)) if rh_list else None
                solar_list = [s["avg_solar_radiation_mj"] for s in m_summaries if s["avg_solar_radiation_mj"] is not None]
                norm_solar = (sum(solar_list) / len(solar_list)) if solar_list else None

                climatological_normals.append({
                    "month": m,
                    "month_name": MONTH_NAMES[m - 1],
                    "mean_rainfall_mm": round(norm_rain, 1) if norm_rain is not None else None,
                    "mean_temperature_c": round(norm_t2m, 1) if norm_t2m is not None else None,
                    "mean_humidity_pct": round(norm_rh, 1) if norm_rh is not None else None,
                    "mean_solar_mj": round(norm_solar, 1) if norm_solar is not None else None
                })

        # 4. Generate Environmental Evidence Objects (Critical Requirement)
        evidence_objects = self._generate_evidence_objects(
            lat=lat,
            lng=lng,
            start=start,
            end=end,
            elevation=elevation,
            daily_records=daily_records,
            monthly_summaries=monthly_summaries,
            missing_stats=missing_stats,
            is_from_cache=is_from_cache
        )

        default_start, default_end = self.get_default_date_range()
        period_type = (
            "historical_baseline"
            if (start, end) == (default_start, default_end)
            else "caller_selected_period"
        )
        return {
            "status": "success",
            "source": "NASA POWER Agroclimatology API",
            "period_type": period_type,
            "requested_period": {
                "start_date": f"{start[0:4]}-{start[4:6]}-{start[6:8]}",
                "end_date": f"{end[0:4]}-{end[4:6]}-{end[6:8]}",
                "is_default_baseline": period_type == "historical_baseline",
            },
            "farm_centroid": {"lat": lat, "lng": lng, "elevation_meters": elevation},
            "observation_period": {
                "start_date": f"{start[0:4]}-{start[4:6]}-{start[6:8]}",
                "end_date": f"{end[0:4]}-{end[4:6]}-{end[6:8]}",
                "total_days": len(daily_records)
            },
            "provenance": {
                "period_type": period_type,
                "provider": "NASA Langley Research Center POWER Project",
                "endpoint_url": self.BASE_URL,
                "retrieved_at": cached_at if is_from_cache else datetime.now(timezone.utc).isoformat(),
                "cache_hit": is_from_cache,
                "meteorology_model": "NASA GMAO MERRA-2 (0.5° x 0.5° gridded reanalysis)",
                "solar_model": "NASA CERES / FLASHFlux (1.0° x 1.0° satellite radiance)",
                "disclaimer": "NASA POWER data is a gridded environmental product combining model reanalysis and satellite observations. It provides multi-year climatological baseline evidence, not a forecast or on-farm physical sensor."
            },
            "evidence_objects": evidence_objects,
            "monthly_summaries": monthly_summaries,
            "climatological_normals": climatological_normals,
            "recent_daily_sample": daily_records[-30:] # Last 30 days for immediate inspection
        }

    def _generate_evidence_objects(
        self,
        lat: float,
        lng: float,
        start: str,
        end: str,
        elevation: Optional[float],
        daily_records: List[Dict[str, Any]],
        monthly_summaries: List[Dict[str, Any]],
        missing_stats: Dict[str, Dict[str, Any]],
        is_from_cache: bool
    ) -> List[Dict[str, Any]]:
        """
        Creates formal environmental evidence objects for every indicator.
        Adheres strictly to the MOST IMPORTANT traceability requirement.
        """
        retrieval_time = datetime.now(timezone.utc).isoformat()
        total_days = len(daily_records)
        years_count = max(1.0, total_days / 365.25)

        # 1. Annual Rainfall Evidence
        all_rain = [r["precipitation_mm"] for r in daily_records if r["precipitation_mm"] is not None]
        precipitation_complete = bool(daily_records) and len(all_rain) == len(daily_records)
        total_rain = sum(all_rain) if precipitation_complete else None
        annual_avg_rain = round(total_rain / years_count, 1) if total_rain is not None else None

        # Monsoon (June-September Kharif) vs Post-Monsoon (Oct-Dec Rabi) in Andhra Pradesh
        kharif_rain = sum(
            r["precipitation_mm"] for r in daily_records
            if r["precipitation_mm"] is not None and int(r["date"][5:7]) in [6, 7, 8, 9]
        ) if precipitation_complete else 0.0
        rabi_rain = sum(
            r["precipitation_mm"] for r in daily_records
            if r["precipitation_mm"] is not None and int(r["date"][5:7]) in [10, 11, 12]
        ) if precipitation_complete else 0.0

        # Temperature stats
        all_t2m = [r["t2m"] for r in daily_records if r["t2m"] is not None]
        all_t2m_max = [r["t2m_max"] for r in daily_records if r["t2m_max"] is not None]
        all_t2m_min = [r["t2m_min"] for r in daily_records if r["t2m_min"] is not None]

        # Solar stats
        all_solar = [r["solar_radiation_mj"] for r in daily_records if r["solar_radiation_mj"] is not None]

        # Relative humidity stats
        all_rh = [r["relative_humidity"] for r in daily_records if r["relative_humidity"] is not None]

        # Wind stats
        all_ws = [r["wind_speed_ms"] for r in daily_records if r["wind_speed_ms"] is not None]

        evidence_list = [
            # Indicator 1: Precipitation (Annual Normal)
            {
                "evidence_id": f"POWER_RAIN_ANNUAL_{round(lat, 3)}_{round(lng, 3)}",
                "dataset_name": "NASA POWER Agroclimatology",
                "parameter_code": "PRECTOTCORR",
                "parameter_name": "Mean Annual Precipitation",
                "derived_statistic": "3-Year Mean Annual Cumulative Rainfall",
                "actual_value": annual_avg_rain,
                "unit": "mm/year",
                "seasonal_breakdown": {
                    "kharif_monsoon_avg_mm": round(kharif_rain / years_count, 1) if precipitation_complete else None,
                    "rabi_northeast_monsoon_avg_mm": round(rabi_rain / years_count, 1) if precipitation_complete else None,
                    "dry_season_avg_mm": round((total_rain - kharif_rain - rabi_rain) / years_count, 1) if total_rain is not None else None
                },
                "coordinates": {"lat": lat, "lng": lng, "elevation_meters": elevation},
                "observation_period": {
                    "start_date": f"{start[0:4]}-{start[4:6]}-{start[6:8]}",
                    "end_date": f"{end[0:4]}-{end[4:6]}-{end[6:8]}",
                    "total_days_sampled": total_days
                },
                "source_url": self.BASE_URL,
                "retrieval_time": retrieval_time,
                "spatial_resolution": PARAMETER_METADATA["PRECTOTCORR"]["spatial_resolution"],
                "underlying_source_product": PARAMETER_METADATA["PRECTOTCORR"]["source"],
                "is_direct_satellite_observation": PARAMETER_METADATA["PRECTOTCORR"]["is_satellite"],
                "missing_data_info": missing_stats["PRECTOTCORR"],
                "agronomic_significance": "Determines rainfed vs irrigated feasibility and high vs low water-footprint crop suitability."
            },

            # Indicator 2: Thermal Profile (Mean, Max Extreme, Min Extreme)
            {
                "evidence_id": f"POWER_TEMP_PROFILE_{round(lat, 3)}_{round(lng, 3)}",
                "dataset_name": "NASA POWER Agroclimatology",
                "parameter_code": "T2M",
                "parameter_name": "Temperature Profile at 2 Meters",
                "derived_statistic": "3-Year Thermal Regimes (Mean, Extreme Max, Extreme Min)",
                "actual_value": round(sum(all_t2m) / len(all_t2m), 2) if all_t2m else None,
                "unit": "°C",
                "statistics": {
                    "mean_c": round(sum(all_t2m) / len(all_t2m), 2) if all_t2m else None,
                    "extreme_max_c": round(max(all_t2m_max), 2) if all_t2m_max else None,
                    "extreme_min_c": round(min(all_t2m_min), 2) if all_t2m_min else None
                },
                "coordinates": {"lat": lat, "lng": lng, "elevation_meters": elevation},
                "observation_period": {
                    "start_date": f"{start[0:4]}-{start[4:6]}-{start[6:8]}",
                    "end_date": f"{end[0:4]}-{end[4:6]}-{end[6:8]}",
                    "total_days_sampled": total_days
                },
                "source_url": self.BASE_URL,
                "retrieval_time": retrieval_time,
                "spatial_resolution": PARAMETER_METADATA["T2M"]["spatial_resolution"],
                "underlying_source_product": PARAMETER_METADATA["T2M"]["source"],
                "is_direct_satellite_observation": PARAMETER_METADATA["T2M"]["is_satellite"],
                "missing_data_info": missing_stats["T2M"],
                "agronomic_significance": "Verifies heat stress thresholds during summer/Kharif flowering and chilling risks during Rabi vegetative stages."
            },

            # Indicator 3: Solar Radiation (Photosynthetic Availability)
            {
                "evidence_id": f"POWER_SOLAR_RAD_{round(lat, 3)}_{round(lng, 3)}",
                "dataset_name": "NASA POWER Agroclimatology",
                "parameter_code": "ALLSKY_SFC_SW_DWN",
                "parameter_name": "All Sky Surface Solar Irradiance",
                "derived_statistic": "3-Year Mean Daily Insolation",
                "actual_value": round(sum(all_solar) / len(all_solar), 2) if all_solar else 0.0,
                "unit": "MJ/m^2/day",
                "statistics": {
                    "daily_mean_mj": round(sum(all_solar) / len(all_solar), 2) if all_solar else 0.0,
                    "peak_insolation_mj": round(max(all_solar), 2) if all_solar else 0.0,
                    "minimum_insolation_mj": round(min(all_solar), 2) if all_solar else 0.0
                },
                "coordinates": {"lat": lat, "lng": lng, "elevation_meters": elevation},
                "observation_period": {
                    "start_date": f"{start[0:4]}-{start[4:6]}-{start[6:8]}",
                    "end_date": f"{end[0:4]}-{end[4:6]}-{end[6:8]}",
                    "total_days_sampled": total_days
                },
                "source_url": self.BASE_URL,
                "retrieval_time": retrieval_time,
                "spatial_resolution": PARAMETER_METADATA["ALLSKY_SFC_SW_DWN"]["spatial_resolution"],
                "underlying_source_product": PARAMETER_METADATA["ALLSKY_SFC_SW_DWN"]["source"],
                "is_direct_satellite_observation": PARAMETER_METADATA["ALLSKY_SFC_SW_DWN"]["is_satellite"],
                "missing_data_info": missing_stats["ALLSKY_SFC_SW_DWN"],
                "agronomic_significance": "Quantifies photosynthetically active radiation (PAR) driving crop biomass accumulation and photosynthesis."
            },

            # Indicator 4: Relative Humidity (Pest & Evaporative Demand)
            {
                "evidence_id": f"POWER_HUMIDITY_{round(lat, 3)}_{round(lng, 3)}",
                "dataset_name": "NASA POWER Agroclimatology",
                "parameter_code": "RH2M",
                "parameter_name": "Relative Humidity at 2 Meters",
                "derived_statistic": "3-Year Mean Relative Humidity",
                "actual_value": round(sum(all_rh) / len(all_rh), 1) if all_rh else 0.0,
                "unit": "%",
                "statistics": {
                    "mean_pct": round(sum(all_rh) / len(all_rh), 1) if all_rh else 0.0,
                    "monsoon_mean_pct": round(
                        sum(r["relative_humidity"] for r in daily_records if r["relative_humidity"] is not None and int(r["date"][5:7]) in [7, 8, 9]) /
                        max(1, sum(1 for r in daily_records if r["relative_humidity"] is not None and int(r["date"][5:7]) in [7, 8, 9])),
                        1
                    )
                },
                "coordinates": {"lat": lat, "lng": lng, "elevation_meters": elevation},
                "observation_period": {
                    "start_date": f"{start[0:4]}-{start[4:6]}-{start[6:8]}",
                    "end_date": f"{end[0:4]}-{end[4:6]}-{end[6:8]}",
                    "total_days_sampled": total_days
                },
                "source_url": self.BASE_URL,
                "retrieval_time": retrieval_time,
                "spatial_resolution": PARAMETER_METADATA["RH2M"]["spatial_resolution"],
                "underlying_source_product": PARAMETER_METADATA["RH2M"]["source"],
                "is_direct_satellite_observation": PARAMETER_METADATA["RH2M"]["is_satellite"],
                "missing_data_info": missing_stats["RH2M"],
                "agronomic_significance": "Indicates atmospheric evaporative demand and fungal disease / pest flare-up probability."
            },

            # Indicator 5: Wind Speed at 10 Meters
            {
                "evidence_id": f"POWER_WIND_{round(lat, 3)}_{round(lng, 3)}",
                "dataset_name": "NASA POWER Agroclimatology",
                "parameter_code": "WS10M",
                "parameter_name": "Wind Speed at 10 Meters",
                "derived_statistic": "3-Year Mean Wind Velocity",
                "actual_value": round(sum(all_ws) / len(all_ws), 2) if all_ws else 0.0,
                "unit": "m/s",
                "statistics": {
                    "mean_ms": round(sum(all_ws) / len(all_ws), 2) if all_ws else 0.0,
                    "peak_gust_ms": round(max(all_ws), 2) if all_ws else 0.0
                },
                "coordinates": {"lat": lat, "lng": lng, "elevation_meters": elevation},
                "observation_period": {
                    "start_date": f"{start[0:4]}-{start[4:6]}-{start[6:8]}",
                    "end_date": f"{end[0:4]}-{end[4:6]}-{end[6:8]}",
                    "total_days_sampled": total_days
                },
                "source_url": self.BASE_URL,
                "retrieval_time": retrieval_time,
                "spatial_resolution": PARAMETER_METADATA["WS10M"]["spatial_resolution"],
                "underlying_source_product": PARAMETER_METADATA["WS10M"]["source"],
                "is_direct_satellite_observation": PARAMETER_METADATA["WS10M"]["is_satellite"],
                "missing_data_info": missing_stats["WS10M"],
                "agronomic_significance": "Affects crop lodging risk, micro-sprinkler efficiency, and desiccation rates."
            }
        ]

        return evidence_list
