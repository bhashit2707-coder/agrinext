"""
NASA GPM (Global Precipitation Measurement) IMERG Service.
Product: GPM IMERG Final Precipitation L3 1 day 0.1 degree x 0.1 degree V07 (GPM_3IMERGDF).
Official Documentation: https://gpm.nasa.gov/data/directory
Archive: NASA GES DISC (Goddard Earth Sciences Data and Information Services Center)

Spatial Limitations:
- Native spatial resolution is 0.1° x 0.1° (~10 km grid cell, ~100 sq km).
- A farm parcel is orders of magnitude smaller than one grid cell.
- This product represents satellite radar/radiometer calibrated rainfall over the 10 km grid box.
- Never claim GPM IMERG measures individual rain gauge conditions on each acre.
"""

import os
import hashlib
import tempfile
from pathlib import Path
import json
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional
from collections import defaultdict
import requests
import h5py
import numpy as np
from dotenv import load_dotenv

import database

load_dotenv()
logger = logging.getLogger("agrinext.nasa.gpm")

PRODUCT_SHORT_NAME = "GPM_3IMERGDF"
PRODUCT_VERSION = "07"
PRODUCT_TITLE = "GPM IMERG Final Precipitation L3 1 day 0.1 degree x 0.1 degree V07"
FILL_VALUE = -9999.0
CMR_BASE_URL = "https://cmr.earthdata.nasa.gov/search"

class NASAGPMService:
    """Service to interface with NASA GPM IMERG Version 07 Final Run dataset."""

    def __init__(self, timeout_sec: int = 30):
        self.timeout_sec = timeout_sec
        self.username = os.getenv("EARTHDATA_USERNAME", "").strip()
        self.password = os.getenv("EARTHDATA_PASSWORD", "").strip()
        self.bearer_token = os.getenv("EARTHDATA_BEARER_TOKEN", "").strip()
        self.metadata = {
            "dataset_name": PRODUCT_TITLE,
            "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
            "version": "07 (Final Run)",
            "provider": "NASA GES DISC / Precipitation Processing System (PPS)",
            "spatial_resolution": "0.1° x 0.1° (~10 km grid cell)",
            "primary_variable": "precipitation",
            "units": "mm/day",
            "satellite_instruments": [
                "Dual-frequency Precipitation Radar (DPR: Ku/Ka-band)",
                "GPM Microwave Imager (GMI)",
                "Partner constellation radiometers (SSMIS, AMSR2, ATMS)"
            ],
            "gauge_calibration": "Monthly Global Precipitation Climatology Centre (GPCC) gauge analysis",
            "documentation": "https://gpm.nasa.gov/data/directory",
            "spatial_limitation_warning": (
                "Native resolution is 0.1° (~10 km grid cell). It reflects satellite microwave and radar estimates "
                "across the grid box, not an in-situ rain gauge on each acre. "
                "Never claim this product provides independently measured conditions for each acre."
            )
        }

    def get_service_status(self) -> Dict[str, Any]:
        """Returns service metadata and Earthdata login status."""
        has_auth = bool((self.username and self.password) or self.bearer_token)
        return {
            "service": "NASA GPM",
            "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
            "title": PRODUCT_TITLE,
            "status": "ready" if has_auth else "auth_required",
            "auth_configured": has_auth,
            "metadata": self.metadata,
            "auth_instructions": (
                "To enable live GES DISC GPM data extraction, provide your NASA Earthdata login "
                "in backend/.env. Unconfigured systems report status transparently without data fabrication."
            )
        }

    def _generate_cache_key(
        self,
        lat: float,
        lng: float,
        start: str,
        end: str,
        polygon_bbox: Optional[Dict[str, float]] = None
    ) -> str:
        # 10km grid -> round to 2 decimals
        bbox_str = ""
        if polygon_bbox:
            bbox_str = f"_{round(polygon_bbox.get('min_lng', 0), 2)}_{round(polygon_bbox.get('min_lat', 0), 2)}"
        raw = f"gpm_v07_monthly2_{round(lat, 2)}_{round(lng, 2)}_{start}_{end}{bbox_str}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def fetch_precipitation(
        self,
        lat: float,
        lng: float,
        polygon_bbox: Optional[Dict[str, float]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        use_cache: bool = True
    ) -> Dict[str, Any]:
        """
        Retrieves GPM IMERG V07 daily Final Run precipitation estimates.
        Enforces Rule: If credentials or network are unavailable, show as unconfigured/unavailable.
        Never substitute simulated data and label it as NASA data.
        """
        if not (-90.0 <= lat <= 90.0 and -180.0 <= lng <= 180.0):
            raise ValueError(f"Invalid coordinates: lat={lat}, lng={lng}")

        # IMERG Final Run is released with ~3.5 month latency. Default to a recent,
        # complete 31-day window safely behind that latency instead of attempting years
        # of granule downloads during every recommendation request.
        default_end = (datetime.now(timezone.utc).date() - timedelta(days=120))
        if start_date and end_date:
            start, end = start_date, end_date
        elif end_date:
            end = end_date
            start = (datetime.strptime(end, "%Y-%m-%d").date() - timedelta(days=30)).isoformat()
        elif start_date:
            start = start_date
            end = (datetime.strptime(start, "%Y-%m-%d").date() + timedelta(days=30)).isoformat()
        else:
            end = default_end.isoformat()
            start = (default_end - timedelta(days=30)).isoformat()
        cache_key = self._generate_cache_key(lat, lng, start, end, polygon_bbox)

        # 1. Check persistent SQLite cache
        if use_cache:
            cached = database.get_cached_gpm_data(cache_key)
            if cached and cached.get("status") == "success":
                logger.info(f"GPM cache hit for key={cache_key[:12]}")
                return cached

        # 2. Check Authentication credentials
        has_auth = bool((self.username and self.password) or self.bearer_token)
        if not has_auth:
            return {
                "status": "auth_required",
                "connected": False,
                "dataset_name": PRODUCT_TITLE,
                "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
                "spatial_resolution": self.metadata["spatial_resolution"],
                "spatial_limitations": self.metadata["spatial_limitation_warning"],
                "message": (
                    "NASA Earthdata credentials not configured in backend/.env. "
                    "In adherence with AgriNext Scientific Rules, simulated data will never be substituted. "
                    "Configure EARTHDATA_USERNAME and EARTHDATA_PASSWORD to activate live GES DISC V07 extraction."
                ),
                "documentation_url": "https://gpm.nasa.gov/data/directory",
                "coordinates": {"lat": lat, "lng": lng},
                "polygon_bbox": polygon_bbox,
                "evidence_object": None
            }

        # 3. Live NASA GES DISC / CMR query
        try:
            return self._query_ges_disc_api(
                lat=lat,
                lng=lng,
                polygon_bbox=polygon_bbox,
                start=start,
                end=end,
                cache_key=cache_key
            )
        except Exception as e:
            logger.error(f"GPM GES DISC extraction error: {e}")
            return {
                "status": "unavailable",
                "connected": False,
                "dataset_name": PRODUCT_TITLE,
                "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
                "error_details": str(e),
                "message": "Live GPM extraction from NASA GES DISC currently unreachable. Check credentials or network connectivity.",
                "documentation_url": "https://gpm.nasa.gov/data/directory",
                "spatial_resolution": self.metadata["spatial_resolution"],
                "spatial_limitations": self.metadata["spatial_limitation_warning"],
                "evidence_object": None
            }

    def _query_ges_disc_api(
        self,
        lat: float,
        lng: float,
        polygon_bbox: Optional[Dict[str, float]],
        start: str,
        end: str,
        cache_key: str
    ) -> Dict[str, Any]:
        """Search CMR, download daily IMERG V07 granules, and extract farm-grid rainfall."""
        start_dt = datetime.strptime(start, "%Y-%m-%d")
        end_dt = datetime.strptime(end, "%Y-%m-%d")
        if end_dt < start_dt:
            raise ValueError("end_date must be on or after start_date")
        requested_days = (end_dt - start_dt).days + 1
        if requested_days > 31:
            raise ValueError("GPM live query is limited to 31 days per request to control download size")

        cmr_params = {
            "short_name": PRODUCT_SHORT_NAME,
            "version": PRODUCT_VERSION,
            "page_size": min(requested_days + 10, 200),
            "temporal": f"{start}T00:00:00Z,{end}T23:59:59Z",
            # CMR granule searches are ascending by provider/start date by default.
            # Do not send sort_order: it is not a supported CMR granule parameter.
        }
        if polygon_bbox:
            cmr_params["bounding_box"] = (
                f"{polygon_bbox.get('min_lng', lng - 0.05)},{polygon_bbox.get('min_lat', lat - 0.05)},"
                f"{polygon_bbox.get('max_lng', lng + 0.05)},{polygon_bbox.get('max_lat', lat + 0.05)}"
            )
        else:
            cmr_params["point"] = f"{lng},{lat}"

        headers = {"Authorization": f"Bearer {self.bearer_token}"} if self.bearer_token else {}
        cmr_res = requests.get(
            f"{CMR_BASE_URL}/granules.json", params=cmr_params,
            headers=headers, timeout=self.timeout_sec
        )
        cmr_res.raise_for_status()
        granules = cmr_res.json().get("feed", {}).get("entry", [])
        if not granules:
            result = self.process_gpm_observations(
                lat, lng, [], start, end, polygon_bbox, is_live=True, granule_metadata=[]
            )
            result["status"] = "no_data"
            result["connected"] = True
            result["message"] = "NASA CMR returned no GPM IMERG granules for the requested location and dates."
            return result

        session = requests.Session()
        if not self.bearer_token and self.username and self.password:
            session.auth = (self.username, self.password)
        day_map = {}
        cursor = start_dt
        while cursor <= end_dt:
            day_map[cursor.strftime("%Y-%m-%d")] = None
            cursor += timedelta(days=1)
        downloaded = 0
        for granule in granules:
            granule_date = (granule.get("time_start") or "")[:10]
            if not granule_date:
                continue
            if granule_date < start or granule_date > end:
                continue
            links = granule.get("links", [])
            data_links = [
                item.get("href") for item in links
                if item.get("href") and not item.get("inherited")
                and item.get("rel", "").endswith("/data#")
                and item.get("href", "").lower().split("?")[0].endswith((".nc4", ".h5", ".hdf5", ".nc"))
            ]
            if not data_links:
                # Some CMR records use a data URL without the canonical rel suffix.
                data_links = [
                    item.get("href") for item in links
                    if item.get("href") and not item.get("inherited")
                    and item.get("href", "").lower().split("?")[0].endswith((".nc4", ".h5", ".hdf5", ".nc"))
                ]
            if not data_links:
                logger.warning("No downloadable data link found for GPM granule date=%s", granule_date)
                continue

            response = session.get(data_links[0], headers=headers, timeout=self.timeout_sec, stream=True)
            response.raise_for_status()
            # Windows does not allow h5py/HDF5 to reopen a NamedTemporaryFile
            # while its handle is still open. Close the downloaded file first,
            # then let HDF5 read it, and always remove the temporary file.
            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile(suffix=".nc4", delete=False) as tmp:
                    tmp_path = tmp.name
                    for chunk in response.iter_content(chunk_size=1024 * 1024):
                        if chunk:
                            tmp.write(chunk)
                    tmp.flush()
                precipitation = self._extract_granule_precipitation(
                    tmp_path, lat, lng, polygon_bbox
                )
            finally:
                response.close()
                if tmp_path and os.path.exists(tmp_path):
                    os.remove(tmp_path)
            day_map[granule_date] = precipitation
            downloaded += 1

        observations = [
            {"date": day, "precipitation_mm": value}
            for day, value in day_map.items()
        ]
        result = self.process_gpm_observations(
            lat=lat, lng=lng, observations=observations,
            start=start, end=end, polygon_bbox=polygon_bbox,
            is_live=True, granule_metadata=granules
        )
        result["granules_found"] = len(granules)
        result["granules_downloaded"] = downloaded
        result["requested_days"] = requested_days
        result["source_variable"] = "Grid/precipitation"
        result["source_units"] = "mm/day"
        if result.get("status") == "success":
            database.save_cached_gpm_data(
                cache_key=cache_key, lat=lat, lng=lng,
                start_date=start, end_date=end,
                product_version=PRODUCT_VERSION, response_data=result
            )
        return result

    @staticmethod
    def _extract_granule_precipitation(
        file_path: str,
        lat: float,
        lng: float,
        polygon_bbox: Optional[Dict[str, float]] = None
    ) -> Optional[float]:
        """Read daily IMERG V07 precipitation (mm/day) at the nearest grid cell or farm bbox."""
        with h5py.File(file_path, "r") as data:
            root = data.get("Grid", data)
            variable = root.get("precipitation")
            if variable is None:
                # Retain compatibility with earlier V07 file encodings.
                variable = root.get("precipitationCal")
            if variable is None:
                raise ValueError("GPM granule is missing Grid/precipitation variable")

            latitudes = np.asarray(root["lat"][:]).reshape(-1)
            longitudes = np.asarray(root["lon"][:]).reshape(-1)
            if latitudes.ndim != 1 or longitudes.ndim != 1:
                raise ValueError("Unexpected GPM latitude/longitude coordinate dimensions")

            if polygon_bbox:
                lat_mask = (latitudes >= polygon_bbox.get("min_lat", lat)) & (latitudes <= polygon_bbox.get("max_lat", lat))
                west = polygon_bbox.get("min_lng", lng)
                east = polygon_bbox.get("max_lng", lng)
                lon_mask = ((longitudes >= west) & (longitudes <= east)) if west <= east else ((longitudes >= west) | (longitudes <= east))
                lat_indices = np.where(lat_mask)[0]
                lon_indices = np.where(lon_mask)[0]
            else:
                lat_indices = np.array([int(np.argmin(np.abs(latitudes - lat)))])
                # Handle longitude coordinates represented as 0..360.
                target_lng = lng % 360 if np.nanmax(longitudes) > 180 else lng
                lon_indices = np.array([int(np.argmin(np.abs(longitudes - target_lng)))])

            if len(lat_indices) == 0 or len(lon_indices) == 0:
                lat_indices = np.array([int(np.argmin(np.abs(latitudes - lat)))])
                target_lng = lng % 360 if np.nanmax(longitudes) > 180 else lng
                lon_indices = np.array([int(np.argmin(np.abs(longitudes - target_lng)))])

            # Support both [time, lat, lon] and [time, lon, lat] layouts.
            if variable.ndim == 3:
                grid_values = np.asarray(variable[0, :, :], dtype=float)
            elif variable.ndim == 2:
                grid_values = np.asarray(variable[:, :], dtype=float)
            else:
                raise ValueError(
                f"Unexpected GPM precipitation dimensions: {variable.shape}"
                )
            if grid_values.shape == (len(latitudes), len(longitudes)):
            # Array layout: [lat, lon]
                values = grid_values[np.ix_(lat_indices, lon_indices)]
            elif grid_values.shape == (len(longitudes), len(latitudes)):
            # Array layout: [lon, lat]
                values = grid_values[np.ix_(lon_indices, lat_indices)]
            else:
                raise ValueError(
                    f"GPM grid shape {grid_values.shape} does not match "
                    f"latitude ({len(latitudes)}) and longitude ({len(longitudes)})"
                    )

            scale = float(variable.attrs.get("scale_factor", 1.0))
            offset = float(variable.attrs.get("add_offset", 0.0))
            fill = variable.attrs.get("_FillValue", variable.attrs.get("missing_value", FILL_VALUE))
            fill = float(np.asarray(fill).reshape(-1)[0])
            values = values * scale + offset
            valid = values[np.isfinite(values) & (values >= 0) & (values != fill)]
            if valid.size == 0:
                return None
            return round(float(np.mean(valid)), 3)

    def process_gpm_observations(
        self,
        lat: float,
        lng: float,
        observations: List[Dict[str, Any]],
        start: str,
        end: str,
        polygon_bbox: Optional[Dict[str, float]] = None,
        is_live: bool = False,
        granule_metadata: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Processes GPM IMERG observations, calculates units & monthly aggregates,
        and constructs the formal Environmental Evidence Object.
        If observations list is empty, reports no_data status honestly without fabricating data.
        """
        valid_vals = [
            float(o["precipitation_mm"])
            for o in observations
            if o.get("precipitation_mm") is not None
            and float(o["precipitation_mm"]) >= 0.0
            and float(o["precipitation_mm"]) != FILL_VALUE
        ]

        valid_observation_dates = sorted(
            str(item.get("date"))[:10]
            for item in observations
            if item.get("date")
            and item.get("precipitation_mm") is not None
            and float(item.get("precipitation_mm")) >= 0.0
            and float(item.get("precipitation_mm")) != FILL_VALUE
        )
        requested_period = {"start_date": start, "end_date": end}
        actual_observation_period = {
            "start_date": valid_observation_dates[0] if valid_observation_dates else None,
            "end_date": valid_observation_dates[-1] if valid_observation_dates else None,
        }

        if not valid_vals:
            return {
                "status": "no_data",
                "connected": True,
                "is_live_query": is_live,
                "dataset": PRODUCT_TITLE,
                "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
                "requested_period": requested_period,
                "actual_observation_period": actual_observation_period,
                "observation_period": {
                    "requested_start_date": start, "requested_end_date": end,
                    "actual_start_date": None, "actual_end_date": None,
                    "total_days": len(observations), "valid_days": 0,
                },
                "spatial_resolution": self.metadata["spatial_resolution"],
                "spatial_limitations": self.metadata["spatial_limitation_warning"],
                "message": f"No valid precipitation observations found in GPM IMERG V07 for requested period {start} to {end}.",
                "coordinates": {"lat": lat, "lng": lng},
                "polygon_bbox": polygon_bbox,
                "granule_matches": len(granule_metadata) if granule_metadata else 0,
                "evidence_object": None,
                "monthly_rainfall": []
            }

        total_days = len(observations)
        missing_count = sum(
            1 for o in observations
            if o.get("precipitation_mm") is None
            or float(o.get("precipitation_mm", FILL_VALUE)) == FILL_VALUE
            or float(o.get("precipitation_mm", -1)) < 0.0
        )
        valid_days = len(valid_vals)
        missing_pct = round((missing_count / max(1, total_days)) * 100.0, 1)

        total_precip_mm = sum(valid_vals)
        # Annualized cumulative precipitation
        years = max(1.0 / 365.25, valid_days / 365.25)
        annual_gpm_rain = round(total_precip_mm / years, 1)

        # Monthly aggregation is a calendar-month total, not an annualized value.
        # Keep year-month keys so multi-year requests do not merge separate Julys.
        month_buckets: Dict[str, Dict[str, Any]] = {}
        for observation in observations:
            raw_value = observation.get("precipitation_mm")
            if raw_value is None:
                continue
            precipitation = float(raw_value)
            if precipitation < 0 or precipitation == FILL_VALUE:
                continue
            raw_date = str(observation.get("date", ""))
            try:
                observation_date = datetime.strptime(raw_date[:10], "%Y-%m-%d")
            except (TypeError, ValueError):
                continue
            year_month = observation_date.strftime("%Y-%m")
            bucket = month_buckets.setdefault(year_month, {
                "month": observation_date.strftime("%b"),
                "month_label": observation_date.strftime("%b %Y"),
                "year_month": year_month,
                "gpm_rain_mm": 0.0,
                "observed_days": 0,
            })
            bucket["gpm_rain_mm"] += precipitation
            bucket["observed_days"] += 1

        monthly_rainfall = [
            {
                **bucket,
                "gpm_rain_mm": round(bucket["gpm_rain_mm"], 1),
            }
            for _, bucket in sorted(month_buckets.items())
        ]

        # Heaviest single day rain
        max_daily_rain = round(max(valid_vals), 1)

        evidence_object = {
            "evidence_id": f"GPM_IMERG_V07_{round(lat, 3)}_{round(lng, 3)}",
            "dataset_name": PRODUCT_TITLE,
            "product_code": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
            "parameter_name": "Satellite Radar & Radiometer Precipitation (Final Run)",
            "derived_statistic": f"Mean Annual Cumulative Satellite Rainfall ({start} to {end})",
            "actual_value": annual_gpm_rain,
            "unit": "mm/year",
            "coordinates": {"lat": lat, "lng": lng},
            "polygon_bbox": polygon_bbox,
            "area_sampling_used": polygon_bbox is not None,
            "requested_period": requested_period,
            "actual_observation_period": actual_observation_period,
            "observation_period": {
                "requested_start_date": start,
                "requested_end_date": end,
                "actual_start_date": actual_observation_period["start_date"],
                "actual_end_date": actual_observation_period["end_date"],
                "total_days": total_days,
                "valid_days": valid_days
            },
            "source_url": "https://gpm.nasa.gov/data/directory",
            "retrieval_time": datetime.now(timezone.utc).isoformat(),
            "spatial_resolution": self.metadata["spatial_resolution"],
            "underlying_sensor": "GPM Dual-frequency Precipitation Radar (Ku/Ka-band) & GMI Microwave Imager",
            "gauge_calibration": "Calibrated with monthly GPCC surface rain gauge analysis",
            "statistics": {
                "total_period_precipitation_mm": round(total_precip_mm, 1),
                "annualized_precipitation_estimate_mm": annual_gpm_rain,
                "annual_mean_precipitation_mm": annual_gpm_rain,
                "max_single_day_rain_mm": max_daily_rain
            },
            "missing_data_info": {
                "missing_count": missing_count,
                "valid_count": valid_days,
                "total_count": total_days,
                "missing_percentage": missing_pct
            },
            "spatial_limitations": self.metadata["spatial_limitation_warning"],
            "agronomic_significance": (
                "Validates convective cloudburst volumes and verifies rain distribution during sowing windows."
            )
        }

        return {
            "status": "success",
            "connected": True,
            "is_live_query": is_live,
            "dataset": PRODUCT_TITLE,
            "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
            "requested_period": requested_period,
            "actual_observation_period": actual_observation_period,
            "observation_period": evidence_object["observation_period"],
            "source_units": "mm/day",
            "annual_precipitation_mm": annual_gpm_rain,
            "period_precipitation_mm": round(total_precip_mm, 1),
            "annualized_estimate": total_days < 365,
            "spatial_resolution": self.metadata["spatial_resolution"],
            "spatial_limitations": self.metadata["spatial_limitation_warning"],
            "evidence_object": evidence_object,
            "monthly_rainfall": monthly_rainfall,
            "max_daily_rain_mm": max_daily_rain,
            "quality_summary": evidence_object["missing_data_info"]
        }

    def compare_with_power(
        self,
        gpm_annual_rain: float,
        power_annual_rain: float
    ) -> Dict[str, Any]:
        """
        Compares GPM IMERG satellite rainfall with NASA POWER model reanalysis precipitation.
        Explains scientific causes of differences instead of assuming both datasets must match.
        """
        diff_mm = round(gpm_annual_rain - power_annual_rain, 1)
        pct_diff = round((diff_mm / power_annual_rain) * 100.0, 1) if power_annual_rain > 0 else 0.0

        concordance = "High" if abs(pct_diff) < 10.0 else "Moderate" if abs(pct_diff) < 20.0 else "Divergent"

        return {
            "comparison_summary": {
                "gpm_annual_rainfall_mm": gpm_annual_rain,
                "power_annual_rainfall_mm": power_annual_rain,
                "difference_mm": diff_mm,
                "percentage_variance": pct_diff,
                "concordance": concordance
            },
            "scientific_explanation_of_differences": [
                {
                    "factor": "Physical Measurement vs Numerical Reanalysis",
                    "explanation": (
                        "NASA GPM IMERG is a satellite constellation retrieval using active microwave radiometry (GMI) "
                        "and dual-frequency precipitation radar (DPR Ku/Ka-band), calibrated with monthly GPCC rain gauges. "
                        "In contrast, NASA POWER precipitation derives from the GMAO MERRA-2 global atmospheric assimilation model."
                    )
                },
                {
                    "factor": "Spatial Grid Differences (0.1° vs 0.5°)",
                    "explanation": (
                        "GPM IMERG has a higher spatial resolution (~10 km) compared to MERRA-2 (~50 km). "
                        "GPM captures localized, high-intensity convective thunderstorm cells during the South-West "
                        "monsoon that are spatially averaged out across the broader 50 km MERRA-2 grid."
                    )
                },
                {
                    "factor": "Light Rain & Orographic Attenuation",
                    "explanation": (
                        "Satellite radar can sometimes under-detect very light drizzle (<0.5 mm/hr) due to ground "
                        "clutter and radar beam attenuation, whereas numerical atmospheric models can over-predict "
                        "the frequency of light drizzle days."
                    )
                }
            ],
            "agronomic_recommendation": (
                "Use NASA POWER for long-term multi-decade water-balance budgeting; "
                "use GPM IMERG to assess peak monsoon cloudburst intensity, localized heavy rain risk, and dry-spell durations."
            )
        }
