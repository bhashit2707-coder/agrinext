"""
NASA SMAP (Soil Moisture Active Passive) Data Service.
Product: SPL3SMP_E Version 6 (SMAP Enhanced L3 Radiometer Daily 9 km EASE-Grid Soil Moisture).
Official Documentation: https://nsidc.org/data/spl3smp_e/versions/6
Archive: NSIDC DAAC / NASA AppEEARS (https://appeears.earthdatacloud.nasa.gov/)

Spatial Limitations:
- Native spatial resolution is 9 km x 9 km (EASE-Grid 2.0), covering ~81 sq km.
- A farm parcel (typically 2 to 10 acres) is orders of magnitude smaller than a single grid cell.
- This product represents the integrated macro surface moisture (0-5 cm) across the 9 km cell.
- Never claim SMAP provides an independently measured condition for each isolated acre.
"""

import os
import hashlib
import csv
import io
import logging
import re
import time
from datetime import date, datetime, timedelta, timezone
from typing import Dict, Any, List, Optional
import requests
from dotenv import load_dotenv

import database

load_dotenv()
logger = logging.getLogger("agrinext.nasa.smap")

PRODUCT_SHORT_NAME = "SPL3SMP_E"
PRODUCT_VERSION = "006"
PRODUCT_TITLE = "SMAP Enhanced L3 Radiometer Global Daily 9 km EASE-Grid Soil Moisture V006"
FILL_VALUE = -9999.0
# AppEEARS V006 descriptive QA output identifies flag 8 as recommended quality.
# Flag 7 in the supplied live sample means retrieval was skipped / not successful.
RECOMMENDED_QUALITY_FLAG = 8
SOIL_MOISTURE_MIN_M3_M3 = 0.0
SOIL_MOISTURE_MAX_M3_M3 = 0.50
MIN_VALID_SMAP_SAMPLES = 3
APPEEARS_BASE_URL = "https://appeears.earthdatacloud.nasa.gov/api"

class NASASMAPService:
    """Service to interface with NASA SMAP SPL3SMP_E Version 6 product."""

    def __init__(self, timeout_sec: int = 30):
        self.timeout_sec = timeout_sec
        self.username = os.getenv("EARTHDATA_USERNAME", "").strip()
        self.password = os.getenv("EARTHDATA_PASSWORD", "").strip()
        self.bearer_token = os.getenv("EARTHDATA_BEARER_TOKEN", "").strip()
        self.metadata = {
            "dataset_name": PRODUCT_TITLE,
            "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
            "version": "6",
            "provider": "NASA NSIDC DAAC / NASA Earthdata AppEEARS",
            "spatial_resolution": "9 km x 9 km EASE-Grid 2.0 (~81 km² grid cell)",
            "primary_layer": "Soil_Moisture_Retrieval_Data_AM_soil_moisture",
            "units": "m^3/m^3 (volumetric fraction)",
            "valid_range": "0.00 to 0.50 m^3/m^3",
            "fill_value": FILL_VALUE,
            "documentation": "https://nsidc.org/data/spl3smp_e/versions/6",
            "spatial_limitation_warning": (
                "A typical farm parcel (2-10 acres) is much smaller than one 9 km SMAP grid cell (~81 km²). "
                "SMAP provides macro-environmental surface soil moisture for the cell, not on-farm sensor readings. "
                "Never claim this product provides independently measured conditions for each acre."
            )
        }

    def get_service_status(self) -> Dict[str, Any]:
        """Returns service capability, configuration, and Earthdata authentication status."""
        has_auth = bool((self.username and self.password) or self.bearer_token)
        return {
            "service": "NASA SMAP",
            "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
            "title": PRODUCT_TITLE,
            "status": "ready" if has_auth else "auth_required",
            "auth_configured": has_auth,
            "metadata": self.metadata,
            "auth_instructions": (
                "To enable live AppEEARS SMAP extractions, create a free NASA Earthdata account at "
                "https://urs.earthdata.nasa.gov/ and add EARTHDATA_USERNAME and EARTHDATA_PASSWORD "
                "in backend/.env. If unconfigured, the system reports status transparently without fabricating data."
            )
        }

    def _generate_cache_key(
        self,
        lat: float,
        lng: float,
        start: str,
        end: str,
        polygon_bbox: Optional[Dict[str, float]] = None
    ) -> str:
        # 9km grid -> round to 2 decimals (~1km precision)
        bbox_str = ""
        if polygon_bbox:
            bbox_str = f"_{round(polygon_bbox.get('min_lng', 0), 2)}_{round(polygon_bbox.get('min_lat', 0), 2)}"
        raw = f"smap_v6_{round(lat, 2)}_{round(lng, 2)}_{start}_{end}{bbox_str}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def fetch_surface_soil_moisture(
        self,
        lat: float,
        lng: float,
        polygon_bbox: Optional[Dict[str, float]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        use_cache: bool = True
    ) -> Dict[str, Any]:
        """
        Retrieves SMAP SPL3SMP_E V006 surface soil moisture for the selected farm.
        Uses area sampling (bounding box) where supported.
        Enforces Rule: If credentials or network are unavailable, show as unconfigured/unavailable.
        Never substitute simulated data and label it as NASA data.
        """
        if not (-90.0 <= lat <= 90.0 and -180.0 <= lng <= 180.0):
            raise ValueError(f"Invalid coordinates: lat={lat}, lng={lng}")

        # Daily SMAP data has publication latency. Use a conservative recent
        # 30-day window ending 7 days before today unless the caller supplies dates.
        # This is a request window, not a promise that observations exist for every day.
        today_utc = datetime.now(timezone.utc).date()
        default_end = today_utc - timedelta(days=7)
        end = end_date or default_end.isoformat()
        try:
            end_value = date.fromisoformat(end)
            start = start_date or (end_value - timedelta(days=29)).isoformat()
            start_value = date.fromisoformat(start)
        except ValueError as exc:
            raise ValueError("SMAP start_date and end_date must use YYYY-MM-DD format") from exc
        if start_value > end_value:
            raise ValueError("SMAP start_date must be on or before end_date")
        requested_period = {
            "start_date": start,
            "end_date": end,
            "is_default": start_date is None and end_date is None,
        }
        cache_key = self._generate_cache_key(lat, lng, start, end, polygon_bbox)

        # 1. Check persistent SQLite cache
        if use_cache:
            cached = database.get_cached_smap_data(cache_key)
            if cached and cached.get("status") == "success":
                logger.info(f"SMAP cache hit for key={cache_key[:12]}")
                legacy_period = cached.get("observation_period") or {}
                actual_period = cached.get("actual_observation_period") or {"start_date": None, "end_date": None}
                cached["requested_period"] = requested_period
                cached["actual_observation_period"] = actual_period
                cached["observation_period"] = {
                    "requested_start_date": start,
                    "requested_end_date": end,
                    "actual_start_date": actual_period.get("start_date"),
                    "actual_end_date": actual_period.get("end_date"),
                    "samples_count": legacy_period.get("samples_count"),
                    "valid_samples_count": legacy_period.get("valid_samples_count"),
                }
                return cached
            elif cached:
                # Older versions cached no_data responses after metadata-only discovery.
                # Do not let those entries suppress the new real extraction workflow.
                logger.info("Ignoring non-success SMAP cache entry and attempting fresh extraction.")

        # 2. Check Authentication credentials
        has_auth = bool((self.username and self.password) or self.bearer_token)
        if not has_auth:
            # Rule compliance: Report transparently as unconfigured/auth_required without data fabrication
            return {
                "status": "auth_required",
                "connected": False,
                "dataset_name": PRODUCT_TITLE,
                "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
                "requested_period": requested_period,
                "observation_period": {"requested_start_date": start, "requested_end_date": end, "actual_start_date": None, "actual_end_date": None, "samples_count": 0, "valid_samples_count": 0},
                "spatial_resolution": self.metadata["spatial_resolution"],
                "spatial_limitations": self.metadata["spatial_limitation_warning"],
                "message": (
                    "NASA Earthdata credentials not configured in backend/.env. "
                    "In adherence with AgriNext Scientific Rules, simulated data will never be substituted. "
                    "Configure EARTHDATA_USERNAME and EARTHDATA_PASSWORD to activate live AppEEARS V006 extraction."
                ),
                "documentation_url": "https://nsidc.org/data/spl3smp_e/versions/6",
                "coordinates": {"lat": lat, "lng": lng},
                "polygon_bbox": polygon_bbox,
                "evidence_object": None
            }

        # 3. Live AppEEARS API Extraction
        try:
            result = self._query_appeears_api(
                lat=lat,
                lng=lng,
                polygon_bbox=polygon_bbox,
                start=start,
                end=end,
                cache_key=cache_key
            )
            result["requested_period"] = requested_period
            if result.get("evidence_object"):
                result["evidence_object"]["requested_period"] = requested_period
            return result
        except Exception as e:
            logger.error(f"SMAP AppEEARS extraction error: {e}")
            return {
                "status": "unavailable",
                "connected": False,
                "dataset_name": PRODUCT_TITLE,
                "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
                "error_details": str(e),
                "message": (
                    "Live SMAP extraction from NASA AppEEARS currently unreachable. "
                    "Check network connectivity or Earthdata Login authorization."
                ),
                "documentation_url": "https://nsidc.org/data/spl3smp_e/versions/6",
                "spatial_resolution": self.metadata["spatial_resolution"],
                "spatial_limitations": self.metadata["spatial_limitation_warning"],
                "evidence_object": None
            }

    def _query_appeears_api(
        self,
        lat: float,
        lng: float,
        polygon_bbox: Optional[Dict[str, float]],
        start: str,
        end: str,
        cache_key: str
    ) -> Dict[str, Any]:
        """Submit a real AppEEARS point-sample task and process its downloaded CSV.

        AppEEARS point samples use the farm centroid. A bounding box is retained as
        context only; it is not represented as polygon/area sampling by this method.
        """
        token = self.bearer_token
        if not token and self.username and self.password:
            auth_resp = requests.post(
                f"{APPEEARS_BASE_URL}/login",
                auth=(self.username, self.password),
                timeout=self.timeout_sec
            )
            if auth_resp.status_code != 200:
                raise RuntimeError(
                    f"AppEEARS authentication failed (HTTP {auth_resp.status_code}). "
                    "Verify the Earthdata account and AppEEARS authorization."
                )
            token = auth_resp.json().get("token")
        if not token:
            raise RuntimeError("AppEEARS did not return an authentication token.")

        auth_header = token if str(token).lower().startswith("bearer ") else f"Bearer {token}"
        headers = {"Authorization": auth_header}

        # Discover the product's currently published layers instead of assuming
        # that a layer name from a different product version is still available.
        layer_resp = requests.get(
            f"{APPEEARS_BASE_URL}/product/{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
            headers=headers,
            timeout=self.timeout_sec
        )
        layer_resp.raise_for_status()
        layer_catalog = layer_resp.json()
        moisture_layer = self._find_appeears_layer(
            layer_catalog, ("soil_moisture",), "Soil_Moisture_Retrieval_Data_AM"
        )
        quality_layer = self._find_appeears_layer(
            layer_catalog, ("retrieval_qual_flag",), "Soil_Moisture_Retrieval_Data_AM"
        )
        if not moisture_layer:
            raise RuntimeError(
                f"SMAP soil-moisture AM layer was not found in AppEEARS product "
                f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}."
            )
        if not quality_layer:
            raise RuntimeError(
                "SMAP AM retrieval quality-flag layer was not found in AppEEARS. "
                "Refusing to calculate quality-qualified evidence without its QA layer."
            )

        # AppEEARS API expects MM-DD-YYYY date strings.
        start_appeears = datetime.strptime(start, "%Y-%m-%d").strftime("%m-%d-%Y")
        end_appeears = datetime.strptime(end, "%Y-%m-%d").strftime("%m-%d-%Y")
        task_name = f"AgriNext-SMAP-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        task_payload = {
            "task_name": task_name,
            "task_type": "point",
            "params": {
                "dates": [{"startDate": start_appeears, "endDate": end_appeears}],
                "layers": [
                    {"product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}", "layer": moisture_layer},
                    {"product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}", "layer": quality_layer}
                ],
                "coordinates": [{
                    "id": "agrinext-farm",
                    "category": "AgriNext farm centroid",
                    "latitude": float(lat),
                    "longitude": float(lng)
                }]
            }
        }
        submit_resp = requests.post(
            f"{APPEEARS_BASE_URL}/task",
            json=task_payload,
            headers={**headers, "Content-Type": "application/json"},
            timeout=self.timeout_sec
        )
        if submit_resp.status_code not in (200, 202):
            raise RuntimeError(
                f"AppEEARS task submission failed (HTTP {submit_resp.status_code}): "
                f"{submit_resp.text[:500]}"
            )
        task_id = submit_resp.json().get("task_id")
        if not task_id:
            raise RuntimeError("AppEEARS task submission response did not include task_id.")

        poll_interval = max(1, int(os.getenv("APPEEARS_POLL_INTERVAL_SEC", "5")))
        max_wait = max(poll_interval, int(os.getenv("APPEEARS_MAX_WAIT_SEC", "600")))
        deadline = time.monotonic() + max_wait
        task_status = "submitted"
        task_details: Dict[str, Any] = {}
        while time.monotonic() < deadline:
            status_resp = requests.get(
                f"{APPEEARS_BASE_URL}/task/{task_id}",
                headers=headers,
                timeout=self.timeout_sec
            )
            status_resp.raise_for_status()
            task_details = status_resp.json()
            task_status = str(task_details.get("status", "")).lower()
            if task_status == "done":
                break
            if task_status in {"error", "failed", "cancelled", "canceled"}:
                raise RuntimeError(
                    f"AppEEARS task {task_id} ended with status '{task_status}': "
                    f"{task_details.get('error', task_details.get('message', 'No details'))}"
                )
            time.sleep(poll_interval)
        else:
            raise TimeoutError(
                f"AppEEARS task {task_id} did not finish within {max_wait} seconds "
                f"(last status: {task_status or 'unknown'})."
            )

        bundle_resp = requests.get(
            f"{APPEEARS_BASE_URL}/bundle/{task_id}",
            headers=headers,
            timeout=self.timeout_sec
        )
        bundle_resp.raise_for_status()
        bundle_files = bundle_resp.json().get("files", [])
        csv_file = next(
            (item for item in bundle_files
             if str(item.get("file_name", "")).lower().endswith(".csv")
             and "result" in str(item.get("file_name", "")).lower()),
            None
        )
        if csv_file is None:
            csv_file = next(
                (item for item in bundle_files
                 if str(item.get("file_name", "")).lower().endswith(".csv")),
                None
            )
        if csv_file is None:
            available = [item.get("file_name") for item in bundle_files]
            raise RuntimeError(f"AppEEARS task completed but no CSV result was found. Bundle files: {available}")

        file_id = csv_file.get("file_id")
        if not file_id:
            raise RuntimeError("AppEEARS CSV bundle entry did not contain file_id.")
        download_resp = requests.get(
            f"{APPEEARS_BASE_URL}/bundle/{task_id}/{file_id}",
            headers=headers,
            timeout=max(self.timeout_sec, 120)
        )
        download_resp.raise_for_status()
        observations = self._parse_appeears_smap_csv(
            download_resp.content,
            moisture_layer=moisture_layer,
            quality_layer=quality_layer
        )

        result = self.process_smap_observations(
            lat=lat,
            lng=lng,
            observations=observations,
            start=start,
            end=end,
            polygon_bbox=polygon_bbox,
            is_live=True,
            granule_metadata=[]
        )
        result["sampling_method"] = "AppEEARS point sample at farm centroid"
        result["area_sampling_used"] = False
        result["appeears_task_id"] = task_id
        result["appeears_layers"] = {"soil_moisture": moisture_layer, "quality_flag": quality_layer}
        result["spatial_sampling_note"] = (
            "This result is a point sample at the supplied farm coordinates. "
            "The optional bounding box is retained as context and was not submitted as an area polygon."
        )
        if result.get("evidence_object"):
            result["evidence_object"]["area_sampling_used"] = False
            result["evidence_object"]["sampling_method"] = result["sampling_method"]
            result["evidence_object"]["spatial_sampling_note"] = result["spatial_sampling_note"]

        # Cache only successful observations. Never persist transient no_data/error results.
        if result.get("status") == "success":
            database.save_cached_smap_data(
                cache_key=cache_key,
                lat=lat,
                lng=lng,
                start_date=start,
                end_date=end,
                product_version=PRODUCT_VERSION,
                response_data=result
            )
        return result

    @staticmethod
    def _find_appeears_layer(layer_catalog: Dict[str, Any], tokens: tuple, group_name: str) -> Optional[str]:
        """Find the requested AM science/QA layer, matching the variable suffix.

        The group name itself contains the words ``Soil_Moisture``. A broad
        substring search for ``soil_moisture`` therefore also matches unrelated
        variables such as ``..._albedo``. Match the variable portion after the
        AM group name instead, so albedo can never be selected as soil moisture.
        """
        if not isinstance(layer_catalog, dict):
            return None

        def norm(value: str) -> str:
            return "".join(ch.lower() for ch in str(value) if ch.isalnum())

        group_norm = norm(group_name)
        wanted = tuple(norm(token) for token in tokens)
        candidates = []
        for raw_name in layer_catalog.keys():
            name = str(raw_name)
            name_norm = norm(name)
            group_pos = name_norm.find(group_norm)
            if group_pos < 0:
                continue
            variable_suffix = name_norm[group_pos + len(group_norm):].strip("_")
            # Require each requested token in the variable suffix, not in the
            # shared group prefix. For soil moisture, this rejects the albedo
            # layer even though its full name contains "Soil_Moisture".
            if all(token in variable_suffix for token in wanted):
                candidates.append(name)

        # Prefer the canonical base variable over algorithm-specific variants.
        candidates.sort(key=lambda value: ("dca" in norm(value), len(value)))
        return candidates[0] if candidates else None

    @staticmethod
    def _parse_appeears_smap_csv(
        csv_content: bytes,
        moisture_layer: str,
        quality_layer: str
    ) -> List[Dict[str, Any]]:
        """Convert AppEEARS point-sample results CSV into processor observations."""
        text = csv_content.decode("utf-8-sig", errors="replace")
        reader = csv.DictReader(io.StringIO(text))
        if not reader.fieldnames:
            raise RuntimeError("AppEEARS returned an empty or unreadable CSV file.")

        def normalized(value: str) -> str:
            return "".join(ch.lower() for ch in str(value) if ch.isalnum())

        headers = {normalized(name): name for name in reader.fieldnames}
        moisture_key = normalized(moisture_layer)
        quality_key = normalized(quality_layer)
        moisture_col = next((original for key, original in headers.items() if moisture_key in key or key.endswith(moisture_key)), None)
        quality_col = next((original for key, original in headers.items() if quality_key in key or key.endswith(quality_key)), None)
        # Some AppEEARS result headers prepend the product identifier and/or use
        # the leaf variable name. Keep matching constrained to the AM group.
        if moisture_col is None:
            moisture_col = next((original for key, original in headers.items()
                                 if "soilmoisture" in key and "retrievaldatam" in key), None)
        if quality_col is None:
            quality_col = next((original for key, original in headers.items()
                                if "retrievalqualflag" in key and "retrievaldatam" in key), None)
        date_col = next((original for key, original in headers.items() if key == "date"), None)
        if moisture_col is None:
            raise RuntimeError(f"SMAP soil-moisture column not found in AppEEARS CSV. Columns: {reader.fieldnames}")
        if quality_col is None:
            raise RuntimeError(f"SMAP retrieval quality-flag column not found in AppEEARS CSV. Columns: {reader.fieldnames}")

        observations: List[Dict[str, Any]] = []
        for row in reader:
            raw_value = (row.get(moisture_col) or "").strip()
            raw_quality = (row.get(quality_col) or "").strip()
            # AppEEARS adds a human-readable description column for bit-field QA.
            # Preserve it so the processing layer can audit the interpretation.
            quality_description_col = next(
                (original for key, original in headers.items()
                 if quality_key in key and key.endswith("recommendedqualitydescription")),
                None
            )
            quality_description = (
                (row.get(quality_description_col) or "").strip()
                if quality_description_col else None
            )
            if not raw_value:
                value = None
            else:
                try:
                    value = float(raw_value)
                except ValueError:
                    value = None
            try:
                quality = int(float(raw_quality)) if raw_quality else None
            except ValueError:
                quality = None
            raw_date = (row.get(date_col) or "").strip() if date_col else ""
            if raw_date:
                try:
                    parsed_date = datetime.fromisoformat(raw_date.replace("Z", "+00:00")).date().isoformat()
                except ValueError:
                    try:
                        parsed_date = datetime.strptime(raw_date[:10], "%Y-%m-%d").date().isoformat()
                    except ValueError:
                        parsed_date = raw_date
            else:
                parsed_date = None
            observations.append({
                "date": parsed_date,
                "soil_moisture": value,
                "quality_flag": quality,
                "quality_description": quality_description,
                "recommended_quality": (
                    quality == RECOMMENDED_QUALITY_FLAG
                    or bool(quality_description and "has recommended quality" in quality_description.lower())
                ),
            })
        return observations

    def process_smap_observations(
        self,
        lat: float,
        lng: float,
        observations: List[Dict[str, Any]],
        start: str,
        end: str,
        polygon_bbox: Optional[Dict[str, float]] = None,
        is_live: bool = False,
        granule_metadata: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Processes SMAP observations, computes regimes & trends,
        and constructs the formal Environmental Evidence Object.
        If observations list is empty, reports no_data status honestly without fabricating data.
        """
        dated_observations = sorted(
            str(item.get("date"))[:10]
            for item in observations
            if item.get("date") and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(item.get("date"))[:10])
        )
        actual_observation_period = {
            "start_date": dated_observations[0] if dated_observations else None,
            "end_date": dated_observations[-1] if dated_observations else None,
        }
        requested_period = {"start_date": start, "end_date": end}

        valid_vals = [
            float(o["soil_moisture"])
            for o in observations
            if o.get("soil_moisture") is not None
            and SOIL_MOISTURE_MIN_M3_M3 <= float(o["soil_moisture"]) <= SOIL_MOISTURE_MAX_M3_M3
            and float(o["soil_moisture"]) != FILL_VALUE
            and o.get("recommended_quality", o.get("quality_flag") == RECOMMENDED_QUALITY_FLAG)
        ]

        if not valid_vals:
            return {
                "status": "no_data",
                "connected": True,
                "is_live_query": is_live,
                "dataset": PRODUCT_TITLE,
                "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
                "requested_period": requested_period,
                "actual_observation_period": actual_observation_period,
                "observation_period": {"requested_start_date": start, "requested_end_date": end, "actual_start_date": actual_observation_period["start_date"], "actual_end_date": actual_observation_period["end_date"], "samples_count": len(observations), "valid_samples_count": 0},
                "spatial_resolution": self.metadata["spatial_resolution"],
                "spatial_limitations": self.metadata["spatial_limitation_warning"],
                "message": f"No valid surface soil moisture observations found in SMAP V6 for requested period {start} to {end}.",
                "coordinates": {"lat": lat, "lng": lng},
                "polygon_bbox": polygon_bbox,
                "granule_matches": len(granule_metadata) if granule_metadata else 0,
                "evidence_object": None,
                "recent_readings": []
            }

        total_count = len(observations)
        missing_count = sum(
            1 for o in observations
            if o.get("soil_moisture") is None
            or float(o.get("soil_moisture", FILL_VALUE)) == FILL_VALUE
            or float(o.get("soil_moisture", -1)) < SOIL_MOISTURE_MIN_M3_M3
            or float(o.get("soil_moisture", 1.0)) > SOIL_MOISTURE_MAX_M3_M3
            or not o.get("recommended_quality", o.get("quality_flag") == RECOMMENDED_QUALITY_FLAG)
        )
        valid_count = len(valid_vals)

        # A single retrieval is not a reliable period summary. Require at least
        # three quality-approved observations before producing evidence.
        if valid_count < MIN_VALID_SMAP_SAMPLES:
            return {
                "status": "insufficient_data",
                "connected": True,
                "is_live_query": is_live,
                "dataset": PRODUCT_TITLE,
                "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
                "requested_period": requested_period,
                "actual_observation_period": actual_observation_period,
                "observation_period": {
                    "requested_start_date": start,
                    "requested_end_date": end,
                    "actual_start_date": actual_observation_period["start_date"],
                    "actual_end_date": actual_observation_period["end_date"],
                    "samples_count": len(observations),
                    "valid_samples_count": valid_count,
                    "minimum_required_samples": MIN_VALID_SMAP_SAMPLES,
                },
                "confidence": {"level": "insufficient", "basis": "fewer than the minimum required valid observations"},
                "message": f"Only {valid_count} valid SMAP observations were available; at least {MIN_VALID_SMAP_SAMPLES} are required. No soil-moisture evidence was produced.",
                "coordinates": {"lat": lat, "lng": lng},
                "polygon_bbox": polygon_bbox,
                "evidence_object": None,
                "recent_readings": observations[-30:],
            }

        # AppEEARS V006 output for this product reports flag 8 as recommended
        # quality (confirmed by the returned Recommended_Quality_Description).
        recommended_count = sum(
            1 for o in observations
            if o.get("recommended_quality", o.get("quality_flag") == RECOMMENDED_QUALITY_FLAG)
            and o.get("soil_moisture") is not None
            and SOIL_MOISTURE_MIN_M3_M3 <= float(o["soil_moisture"]) <= SOIL_MOISTURE_MAX_M3_M3
        )
        recommended_pct = round((recommended_count / max(1, valid_count)) * 100.0, 1)
        missing_pct = round((missing_count / max(1, total_count)) * 100.0, 1)

        avg_moisture = sum(valid_vals) / len(valid_vals)
        min_moisture = min(valid_vals)
        max_moisture = max(valid_vals)

        # Regime classification
        if avg_moisture < 0.12:
            regime = "deficit"
            regime_desc = "Surface soil moisture (0–5 cm) indicates moisture stress. Drought-tolerant crops may be required."
        elif avg_moisture <= 0.25:
            regime = "adequate"
            regime_desc = "Optimal soil moisture availability for rainfed pulses, cereals, and oilseeds."
        else:
            regime = "surplus"
            regime_desc = "High surface moisture. Good water-retention; watch for waterlogging in heavy soils."

        # Trend detection:
        # If dataset covers 28+ days, compare recent 14-day window against prior baseline.
        # For shorter sample periods (>= 6 days), compare recent half against prior half.
        if len(valid_vals) >= 28:
            baseline_vals = valid_vals[:-14]
            recent_vals = valid_vals[-14:]
            baseline_avg = sum(baseline_vals) / len(baseline_vals)
            recent_avg = sum(recent_vals) / len(recent_vals)
            diff = recent_avg - baseline_avg
        elif len(valid_vals) >= 6:
            half = len(valid_vals) // 2
            baseline_vals = valid_vals[:half]
            recent_vals = valid_vals[half:]
            baseline_avg = sum(baseline_vals) / len(baseline_vals)
            recent_avg = sum(recent_vals) / len(recent_vals)
            diff = recent_avg - baseline_avg
        else:
            baseline_avg = avg_moisture
            recent_avg = avg_moisture
            diff = 0.0

        if diff < -0.02:
            trend = "drying"
            trend_desc = "Soil surface is actively drying compared to observation baseline."
        elif diff > 0.02:
            trend = "wetting"
            trend_desc = "Soil surface is wetting up due to recent precipitation or irrigation."
        else:
            trend = "stable"
            trend_desc = "Soil moisture remains consistent with observation baseline."

        evidence_object = {
            "evidence_id": f"SMAP_SM_V6_{round(lat, 3)}_{round(lng, 3)}",
            "dataset_name": PRODUCT_TITLE,
            "product_code": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
            "parameter_name": "Surface Volumetric Soil Moisture (0-5 cm)",
            "derived_statistic": f"Mean Volumetric Surface Soil Moisture ({start} to {end})",
            "actual_value": round(avg_moisture, 3),
            "unit": "m^3/m^3",
            "regime": regime,
            "regime_description": regime_desc,
            "trend_indicator": {
                "trend": trend,
                "delta_m3_m3": round(diff, 4),
                "recent_14day_mean": round(recent_avg, 3),
                "seasonal_baseline_mean": round(avg_moisture, 3),
                "interpretation": trend_desc
            },
            "statistics": {
                "mean": round(avg_moisture, 3),
                "min": round(min_moisture, 3),
                "max": round(max_moisture, 3)
            },
            "coordinates": {"lat": lat, "lng": lng},
            "polygon_bbox": polygon_bbox,
            "area_sampling_used": polygon_bbox is not None,
            "requested_period": requested_period,
            "actual_observation_period": actual_observation_period,
            "observation_period": {
                "requested_start_date": start,
                "requested_end_date": end,
                "actual_start_date": actual_observation_period["start_date"],
                "actual_end_date": actual_observation_period["end_date"],
                "samples_count": total_count,
                "valid_samples_count": valid_count
            },
            "source_url": "https://nsidc.org/data/spl3smp_e/versions/6",
            "retrieval_time": datetime.now(timezone.utc).isoformat(),
            "spatial_resolution": self.metadata["spatial_resolution"],
            "underlying_sensor": "SMAP L-band (1.4 GHz) Radiometer (Conical scanning reflector)",
            "confidence": {
                "level": "low" if valid_count < 6 else ("medium" if valid_count < 14 else "high"),
                "basis": "heuristic based on count of quality-approved observations; not a statistical confidence interval",
            },
            "quality_flag_summary": {
                "recommended_quality_pct": recommended_pct,
                "missing_count": missing_count,
                "valid_count": valid_count,
                "missing_percentage": missing_pct,
                "fill_value": FILL_VALUE
            },
            "spatial_limitations": self.metadata["spatial_limitation_warning"],
            "agronomic_significance": (
                "Critical for pre-sowing germination decisions and identifying moisture stress in Rabi season "
                "transitions after Kharif harvest."
            )
        }

        return {
            "status": "success",
            "connected": True,
            "is_live_query": is_live,
            "dataset": PRODUCT_TITLE,
            "product": f"{PRODUCT_SHORT_NAME}.{PRODUCT_VERSION}",
            "requested_period": requested_period,
            "actual_observation_period": actual_observation_period,
            "observation_period": evidence_object["observation_period"],
            "spatial_resolution": self.metadata["spatial_resolution"],
            "spatial_limitations": self.metadata["spatial_limitation_warning"],
            "evidence_object": evidence_object,
            "regime": regime,
            "trend": trend,
            "mean_moisture_m3_m3": round(avg_moisture, 3),
            "quality_summary": evidence_object["quality_flag_summary"],
            "confidence": evidence_object["confidence"],
            "recent_readings": observations[-30:] if observations else []
        }
