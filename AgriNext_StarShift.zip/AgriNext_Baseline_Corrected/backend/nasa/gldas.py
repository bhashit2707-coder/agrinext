"""NASA GLDAS-2.1 Noah monthly point extraction via GES DISC/CMR.

GLDAS is a land-surface model output, not an in-situ soil sensor. Soil moisture
values are modelled water storage by depth layer (kg m-2), not volumetric %.
"""
import os, tempfile, logging
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, Optional
import requests
import h5py
import numpy as np
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger("agrinext.nasa.gldas")
CMR = "https://cmr.earthdata.nasa.gov/search"
SHORT_NAME = "GLDAS_NOAH025_M"
VERSION = "2.1"
VARIABLES = {
    "SoilMoi0_10cm_inst": {"label": "Soil moisture 0–10 cm", "unit": "kg/m²", "kind": "soil_water_storage"},
    "SoilMoi10_40cm_inst": {"label": "Soil moisture 10–40 cm", "unit": "kg/m²", "kind": "soil_water_storage"},
    "SoilMoi40_100cm_inst": {"label": "Soil moisture 40–100 cm", "unit": "kg/m²", "kind": "soil_water_storage"},
    "SoilMoi100_200cm_inst": {"label": "Soil moisture 100–200 cm", "unit": "kg/m²", "kind": "soil_water_storage"},
    "CanopInt_inst": {"label": "Canopy water storage", "unit": "kg/m²", "kind": "water_storage"},
    "Evap_tavg": {"label": "Evapotranspiration rate", "unit": "kg/m²/s", "kind": "mean_flux"},
}

class GLDASService:
    def __init__(self, timeout: int = 45):
        self.timeout = timeout
        self.username = os.getenv("EARTHDATA_USERNAME", "").strip()
        self.password = os.getenv("EARTHDATA_PASSWORD", "").strip()
        self.token = os.getenv("EARTHDATA_BEARER_TOKEN", "").strip()

    def get_service_status(self) -> Dict[str, Any]:
        configured = bool(self.token or (self.username and self.password))
        return {"service": "NASA GLDAS", "product": f"{SHORT_NAME}.{VERSION}",
                "status": "ready" if configured else "auth_required", "auth_configured": configured,
                "temporal_resolution": "monthly", "spatial_resolution": "0.25° (~25 km)",
                "variables": VARIABLES,
                "documentation": "https://ldas.gsfc.nasa.gov/gldas/gldas-get-data",
                "note": "GLDAS is modelled land-surface output. Soil moisture is water storage by depth layer in kg/m², not an in-situ measurement or volumetric percentage."}

    def query_point(self, latitude: float, longitude: float, date: Optional[str] = None) -> Dict[str, Any]:
        if not -90 <= latitude <= 90 or not -180 <= longitude <= 180:
            raise ValueError("Latitude or longitude is outside valid WGS84 bounds")
        if not (self.token or (self.username and self.password)):
            return {"status": "auth_required", "connected": False, "product": f"{SHORT_NAME}.{VERSION}",
                    "message": "Configure NASA Earthdata credentials in backend/.env to download GLDAS from GES DISC. No substitute values are generated.",
                    "evidence": None, "documentation": "https://ldas.gsfc.nasa.gov/gldas/gldas-get-data"}
        if date:
            requested = datetime.strptime(date, "%Y-%m-%d").date()
            temporal = f"{requested.replace(day=1).isoformat()}T00:00:00Z,{date}T23:59:59Z"
        else:
            # GLDAS is typically released with about a month of latency.
            end = datetime.now(timezone.utc).date() - timedelta(days=45)
            start = end.replace(day=1)
            temporal = f"{start.isoformat()}T00:00:00Z,{end.isoformat()}T23:59:59Z"
        headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        cmr = requests.get(f"{CMR}/granules.json", params={"short_name": SHORT_NAME, "version": VERSION,
                            "page_size": 20, "sort_key": "-start_date", "temporal": temporal,
                            "point": f"{longitude},{latitude}"}, headers=headers, timeout=self.timeout)
        cmr.raise_for_status()
        entries = cmr.json().get("feed", {}).get("entry", [])
        if not entries:
            return {"status": "no_data", "connected": True, "product": f"{SHORT_NAME}.{VERSION}",
                    "message": "GES DISC returned no GLDAS monthly granule for the requested location and period.", "evidence": None}
        granule = entries[0]
        links = granule.get("links", [])
        data_links = [x.get("href") for x in links if x.get("href") and not x.get("inherited") and
                      (x.get("rel", "").endswith("/data#") or x.get("href", "").lower().split("?")[0].endswith((".nc4", ".nc")))]
        if not data_links:
            return {"status": "unavailable", "connected": True, "product": f"{SHORT_NAME}.{VERSION}",
                    "message": "CMR found a granule but did not provide a downloadable NetCDF link.", "granule_id": granule.get("id"), "evidence": None}
        session = requests.Session()
        if not self.token:
            session.auth = (self.username, self.password)
        response = session.get(data_links[0], headers=headers, timeout=self.timeout, stream=True)
        response.raise_for_status()
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(suffix=".nc4", delete=False) as tmp:
                tmp_path = tmp.name
                for chunk in response.iter_content(1024 * 1024):
                    if chunk: tmp.write(chunk)
            values = self._extract_point(tmp_path, latitude, longitude)
        finally:
            response.close()
            if tmp_path and os.path.exists(tmp_path): os.remove(tmp_path)
        return {"status": "success" if values else "no_variables", "connected": True,
                "product": f"{SHORT_NAME}.{VERSION}", "granule_id": granule.get("id"),
                "observation_period": {"start": granule.get("time_start"), "end": granule.get("time_end")},
                "coordinates": {"latitude": latitude, "longitude": longitude},
                "spatial_resolution": "0.25° (~25 km)", "variables": values,
                "source": "NASA GES DISC GLDAS-2.1 Noah monthly", "evidence": values or None,
                "note": "Modelled land-surface estimates, not farm sensor measurements. Soil moisture values are kg/m² by depth layer; do not interpret as volumetric soil moisture."}

    @staticmethod
    def _extract_point(path: str, latitude: float, longitude: float) -> Dict[str, Any]:
        with h5py.File(path, "r") as f:
            def find(name):
                if name in f: return f[name]
                found = []
                f.visititems(lambda n, obj: found.append(obj) if isinstance(obj, h5py.Dataset) and n.split("/")[-1] == name else None)
                return found[0] if found else None
            lat_ds, lon_ds = find("lat"), find("lon")
            if lat_ds is None or lon_ds is None:
                raise ValueError("GLDAS granule is missing latitude/longitude coordinate arrays")
            lats, lons = np.asarray(lat_ds[:]).reshape(-1), np.asarray(lon_ds[:]).reshape(-1)
            iy = int(np.argmin(np.abs(lats - latitude)))
            target_lon = longitude % 360 if np.nanmax(lons) > 180 else longitude
            ix = int(np.argmin(np.abs(lons - target_lon)))
            out = {}
            for name, meta in VARIABLES.items():
                ds = find(name)
                if ds is None: continue
                arr = np.asarray(ds[...], dtype=float)
                while arr.ndim > 2: arr = arr[0]
                if arr.shape == (len(lats), len(lons)): raw = float(arr[iy, ix])
                elif arr.shape == (len(lons), len(lats)): raw = float(arr[ix, iy])
                else: continue
                fill = ds.attrs.get("_FillValue", ds.attrs.get("missing_value", -9999))
                if np.isclose(raw, float(np.asarray(fill).reshape(-1)[0])) or not np.isfinite(raw): continue
                scale = float(np.asarray(ds.attrs.get("scale_factor", 1)).reshape(-1)[0])
                offset = float(np.asarray(ds.attrs.get("add_offset", 0)).reshape(-1)[0])
                out[name] = {**meta, "value": raw * scale + offset}
            return out
