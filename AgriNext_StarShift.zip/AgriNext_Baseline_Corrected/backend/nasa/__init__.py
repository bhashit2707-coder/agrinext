"""
NASA Earth Observation Data Services for AgriNext.
Provides interfaces for NASA POWER (Agroclimatology), NASA SMAP (Soil Moisture),
and NASA GPM (Global Precipitation Measurement).
"""
