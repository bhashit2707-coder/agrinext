export interface SupportedState {
  id: string;
  name: string;
  country: string;
  climate_zones: string[];
  center_coordinates: {
    lat: number;
    lng: number;
  };
  config_path: string;
  active: boolean;
}

export interface StateRegistryResponse {
  version: string;
  default_state: string;
  supported_states: SupportedState[];
}

export interface District {
  id: string;
  name: string;
  region?: string;
  lgd_code?: number;
  lat: number | null;
  lng: number | null;
  rainfall_zone?: string;
  mandal_count?: number;
  village_count?: number;
}

export interface Mandal {
  id: string;
  district_id: string;
  name: string;
  lgd_code?: number;
  lat: number | null;
  lng: number | null;
  bbox?: number[];
  village_count?: number;
  is_urban?: boolean;
}

export interface Village {
  id: string;
  mandal_id: string;
  district_id?: string;
  village_id?: string;
  village_name?: string;
  name: string;
  lgd_code?: number | null;
  gram_panchayat?: string;
  is_revenue_village?: boolean;
  lat: number | null;
  lng: number | null;
}

export interface LocationProvenanceMetadata {
  metadata_version: string;
  state: string;
  state_lgd_code: number;
  provenance_statement: string;
  primary_sources: Array<{
    organization: string;
    dataset_name: string;
    portal_url?: string;
    direct_urls?: string[];
    publication_snapshot_date?: string;
    retrieval_timestamp: string;
    reference_benchmark_date?: string;
    administrative_effective_date?: string;
    license?: string;
  }>;
  record_counts: {
    districts_count: number;
    mandals_count: number;
    total_villages_count: number;
    revenue_villages_with_official_lgd: number;
    non_revenue_cadastral_tracts: number;
  };
  exclusions_and_special_notes: string[];
  source_checksums?: Record<string, string>;
}

export interface Crop {
  id: string;
  name: string;
  telugu_name?: string;
  category: string;
  water_requirement_mm: [number, number];
  soil_type_suitability: string[];
  season: string[];
  growth_days: [number, number];
  nitrogen_impact: 'fixing' | 'depleting' | 'neutral';
  drought_tolerance: 'low' | 'moderate' | 'high';
  flood_tolerance: 'low' | 'moderate' | 'high';
}

export interface CropRule {
  rule_id: string;
  name: string;
  description: string;
  condition: Record<string, any>;
  benefit_score_multiplier: number;
}

export interface NASAServiceMetadata {
  service: string;
  status: string;
  configured?: boolean;
  authentication_required?: boolean;
  credentials_configured?: boolean | null;
  reachable?: boolean | null;
  authenticated?: boolean | null;
  data_available?: boolean | null;
  status_check_scope?: string;
  status_checked_at?: string;
  metadata?: {
    source?: string;
    resolution?: string;
    provider?: string;
    spatial_resolution?: string;
    dataset_name?: string;
    units?: string;
    parameters?: Array<{
      code: string;
      name: string;
      units: string;
    }>;
  };
  title?: string;
  provider?: string;
  note?: string;
}

export interface StrategyArchetype {
  id: string;
  title: string;
  description: string;
}

export interface BackendHealth {
  status: string;
  service: string;
  version: string;
  region_scope: string;
}

export interface GeoJSONPolygonGeometry {
  type: 'Polygon';
  coordinates: number[][][]; // Linear rings with [lng, lat]
}

export interface PolygonAnalysisResponse {
  status: string;
  polygon_acreage: number;
  manual_acreage: number | null;
  effective_acreage: number;
  centroid: { lat: number; lng: number };
  bounding_box: {
    min_lng: number;
    min_lat: number;
    max_lng: number;
    max_lat: number;
  };
  vertex_count: number;
  discrepancy_warning: string | null;
  nasa_targets: {
    power_point_target: { lat: number; lng: number; description: string };
    area_target: { bbox: any; supports_polygon_clip: boolean; description: string };
  };
}

export interface FarmProfile {
  id?: string;
  farm_name: string;
  state_id: string;
  district_id: string;
  mandal_id: string;
  village_id?: string;
  village_name?: string;
  village_lgd?: number | null;
  district_lgd?: number | null;
  mandal_lgd?: number | null;
  latitude: number;
  longitude: number;
  polygon_acreage: number;
  manual_acreage?: number | null;
  effective_acreage: number;
  acreage_discrepancy_warning?: string | null;
  boundary_geojson: GeoJSONPolygonGeometry | any;
  created_at?: string;
  updated_at?: string;
}

// --- NASA POWER Agroclimatology Types ---

export interface NASAPowerDailyRecord {
  date: string; // YYYY-MM-DD
  date_code: string; // YYYYMMDD
  t2m: number | null;
  t2m_max: number | null;
  t2m_min: number | null;
  precipitation_mm: number | null;
  relative_humidity: number | null;
  solar_radiation_mj: number | null;
  wind_speed_ms: number | null;
}

export interface NASAPowerMonthlySummary {
  year_month: string; // YYYY-MM
  year: number;
  month: number;
  month_name: string;
  total_precipitation_mm: number;
  rainy_days_count: number;
  heavy_rain_days_count: number;
  avg_temperature_c: number | null;
  max_temperature_c: number | null;
  min_temperature_c: number | null;
  avg_relative_humidity: number | null;
  avg_solar_radiation_mj: number | null;
  avg_wind_speed_ms: number | null;
}

export interface ClimatologicalNormal {
  month: number;
  month_name: string;
  mean_rainfall_mm: number;
  mean_temperature_c: number;
  mean_humidity_pct: number;
  mean_solar_mj: number;
}

export interface EnvironmentalEvidenceObject {
  evidence_id: string;
  dataset_name: string;
  parameter_code: string;
  parameter_name: string;
  derived_statistic: string;
  actual_value: number;
  unit: string;
  seasonal_breakdown?: Record<string, number>;
  statistics?: Record<string, number>;
  coordinates: {
    lat: number;
    lng: number;
    elevation_meters?: number | null;
  };
  observation_period: {
    start_date: string;
    end_date: string;
    total_days_sampled: number;
  };
  source_url: string;
  retrieval_time: string;
  spatial_resolution: string;
  underlying_source_product: string;
  is_direct_satellite_observation: boolean;
  missing_data_info: {
    missing_count: number;
    valid_count: number;
    total_count: number;
    missing_percentage: number;
  };
  agronomic_significance: string;
}

export interface NASAPowerResponse {
  status: string;
  source: string;
  farm_centroid: {
    lat: number;
    lng: number;
    elevation_meters: number | null;
  };
  observation_period: {
    start_date: string;
    end_date: string;
    total_days: number;
  };
  provenance: {
    provider: string;
    endpoint_url: string;
    retrieved_at: string;
    cache_hit: boolean;
    meteorology_model: string;
    solar_model: string;
    disclaimer: string;
  };
  evidence_objects: EnvironmentalEvidenceObject[];
  monthly_summaries: NASAPowerMonthlySummary[];
  climatological_normals: ClimatologicalNormal[];
  recent_daily_sample: NASAPowerDailyRecord[];
}

// --- NASA SMAP Types (SPL3SMP_E Version 6) ---

export interface NASASMAPResponse {
  status: 'success' | 'auth_required' | 'unavailable' | 'no_data';
  connected: boolean;
  is_live_query?: boolean;
  dataset: string;
  product: string;
  spatial_resolution: string;
  spatial_limitations?: string;
  message?: string;
  documentation_url?: string;
  coordinates?: { lat: number; lng: number };
  evidence_object?: EnvironmentalEvidenceObject | any | null;
  regime?: 'deficit' | 'adequate' | 'surplus';
  trend?: 'drying' | 'wetting' | 'stable';
  mean_moisture_m3_m3?: number;
  quality_summary?: {
    recommended_quality_pct: number;
    missing_count: number;
    valid_count: number;
    missing_percentage: number;
    fill_value: number;
  };
  recent_readings?: Array<{
    date: string;
    soil_moisture: number | null;
    quality_flag?: number;
  }>;
}

// --- NASA GPM IMERG Types (Version 07 Final Run) ---

export interface NASAGPMResponse {
  status: 'success' | 'auth_required' | 'unavailable' | 'no_data';
  connected: boolean;
  is_live_query?: boolean;
  dataset: string;
  product: string;
  annual_precipitation_mm?: number;
  max_daily_rain_mm?: number;
  spatial_resolution: string;
  spatial_limitations?: string;
  message?: string;
  documentation_url?: string;
  evidence_object?: EnvironmentalEvidenceObject | any | null;
  monthly_rainfall?: Array<{
    month: string;
    month_label: string;
    year_month: string;
    gpm_rain_mm: number;
    observed_days: number;
  }>;
  quality_summary?: {
    missing_count: number;
    valid_count: number;
    total_count: number;
    missing_percentage: number;
  };
  power_comparison?: {
    comparison_summary: {
      gpm_annual_rainfall_mm: number;
      power_annual_rainfall_mm: number;
      difference_mm: number;
      percentage_variance: number;
      concordance: 'High' | 'Moderate' | 'Divergent';
    };
    scientific_explanation_of_differences: Array<{
      factor: string;
      explanation: string;
    }>;
    agronomic_recommendation: string;
  };
}

// --- Unified Environmental Evidence Dossier & Recommendation Types ---

export interface UnifiedEvidenceDossier {
  dossier_id: string;
  generated_at: string;
  coordinates: { lat: number; lng: number };
  farm_id?: string | null;
  connected_datasets_count: number;
  total_datasets_tracked: number;
  dataset_status: {
    nasa_power: { name: string; status: string; connected: boolean; evidence_count: number; grid_resolution: string };
    nasa_smap: { name: string; status: string; connected: boolean; evidence_count: number; grid_resolution: string; requires_auth?: boolean };
    nasa_gpm: { name: string; status: string; connected: boolean; evidence_count: number; grid_resolution: string; requires_auth?: boolean };
  };
  evidence_items: EnvironmentalEvidenceObject[];
  evidence_count: number;
  precipitation_synthesis?: {
    gpm_satellite_annual_mm: number;
    power_reanalysis_annual_mm: number;
    difference_mm: number;
    variance_percentage: number;
    concordance: 'High' | 'Moderate' | 'Divergent';
    reconciliation_rationale: string;
  } | null;
  soil_water_balance?: {
    surface_moisture_m3_m3: number;
    regime: string;
    trend: string;
    effective_annual_rainfall_mm: number;
    moisture_retention_assessment: string;
  } | null;
  climate_risk_indicators: {
    drought_risk_index: number;
    waterlogging_risk_index: number;
    sowing_moisture_confidence: 'High' | 'Moderate' | 'Low';
  };
  spatial_resolution_disclaimer: string;
}

export interface EvaluatedCrop {
  crop_id: string;
  crop_name: string;
  category: string;
  suitability_score: number;
  season: string[];
  nitrogen_impact?: string;
  drought_tolerance?: string;
  evidence_citations: string[];
}

export interface StrategyEvidenceDimension {
  score: number;
  weight: number;
  weighted_contribution: number;
  supporting_evidence: Array<{
    source: string;
    parameter: string;
    observed_value: any;
    unit: string;
    observation_period: string;
  }>;
  derived_indicators: Record<string, any>;
  traceable_explanation: string;
  data_limitations: string;
}

export interface StrategyEvidenceTrace {
  strategy_id: string;
  strategy_title: string;
  crop_sequence_summary: string;
  overall_score: number;
  weights: { water: number; soil: number; climate: number; local: number };
  individual_scores: {
    water_suitability: number;
    soil_health_potential: number;
    climate_suitability: number;
    local_agricultural_suitability: number;
  };
  dimensions: {
    water_suitability: StrategyEvidenceDimension;
    climate_suitability: StrategyEvidenceDimension;
    soil_health_potential: StrategyEvidenceDimension;
    local_agricultural_suitability: StrategyEvidenceDimension;
  };
  evidence_completeness: {
    percentage: number;
    available_indicators: number;
    total_indicators_tracked: number;
    connected_sources: string[];
    missing_sources: string[];
    missing_data_policy: string;
  };
  potential_risks: string[];
  data_limitations: string[];
}

export interface RotationStrategy {
  id: string;
  title: string;
  description: string;
  season?: string;
  crop_sequence: Array<{
    season: string;
    crop: string;
    role: string;
  }>;
  rotation: Array<{
    season: string;
    crop: string;
    role: string;
  }>;
  individual_scores: {
    water_suitability: number;
    soil_health_potential: number;
    climate_suitability: number;
    local_agricultural_suitability: number;
  };
  overall_score: number;
  baseline_rank?: number;
  baseline_score?: number;
  updated_rank?: number;
  current_rank?: number;
  rank_change?: number;
  movement_direction?: 'up' | 'down' | 'unchanged';
  movement_explanation?: string;
  baseline_weights?: {
    water: number;
    soil: number;
    climate: number;
    local: number;
  };
  weights: {
    water: number;
    soil: number;
    climate: number;
    local: number;
  };
  supporting_nasa_evidence?: Array<any>;
  supporting_local_evidence?: Array<any>;
  explanation: string;
  environmental_rationale: string;
  potential_risks: string[];
  data_limitations: string[];
  evidence_completeness: {
    percentage: number;
    available_indicators: number;
    total_indicators_tracked: number;
    connected_sources: string[];
    missing_sources: string[];
    missing_data_policy: string;
  };
  evidence_trace: StrategyEvidenceTrace;
}

export interface RankingComparisonItem {
  strategy_id: string;
  title: string;
  baseline_rank: number;
  baseline_score: number;
  updated_rank: number;
  updated_score: number;
  rank_change: number;
  movement_direction: 'up' | 'down' | 'unchanged';
  movement_explanation: string;
}

export interface RecommendationResponse {
  dossier_id: string;
  evaluated_crops: EvaluatedCrop[];
  strategies: RotationStrategy[];
  applied_weights?: {
    water: number;
    soil: number;
    climate: number;
    local: number;
  };
  baseline_weights?: {
    water: number;
    soil: number;
    climate: number;
    local: number;
  };
  ranking_comparison?: {
    baseline_weights: { water: number; soil: number; climate: number; local: number };
    applied_weights: { water: number; soil: number; climate: number; local: number };
    rankings: RankingComparisonItem[];
  };
  seasonal_plan?: {
    status: string;
    planning_horizon: string;
    excluded_recent_crops: string[];
    method: string;
    limitations: string[];
    seasons: Array<{
      id: string;
      months: string;
      status: string;
      candidate_count: number;
      message: string;
      candidates: Array<{
        crop_id: string;
        crop_name: string;
        telugu_name?: string;
        crop_family?: string;
        nitrogen_impact?: string;
        growth_days?: number[];
        water_requirement_mm?: { minimum_mm: number; maximum_mm: number } | null;
        soil_type_match?: boolean | null;
        selection_basis: string;
      }>;
    }>;
  };
  geospatial_rotation_context?: {
    status: string;
    sentinel2: { status: string; scene_count: number; items: Array<{ id?: string; datetime?: string; cloud_cover_percent?: number; platform?: string }>; note?: string; error?: string; pixel_processing_available?: boolean };
    gaez: { status: string; query?: string; record_count: number; items: Array<{ id?: string; properties?: { title?: string; description?: string } }>; collections?: Array<{ id?: string; title?: string; description?: string }>; api_version?: string; current_version?: string; current_version_portal?: string; note?: string; error?: string };
    planning_guidance: string[];
  };
  provenance_summary: {
    datasets_utilized: string[];
    datasets_missing_or_unauthenticated: string[];
  };
}

export interface RecalculateScoresRequest {
  strategies: RotationStrategy[];
  weights: { water: number; soil: number; climate: number; local: number };
  baseline_weights?: { water: number; soil: number; climate: number; local: number };
}

export interface RecalculateScoresResponse {
  strategies: RotationStrategy[];
  applied_weights: { water: number; soil: number; climate: number; local: number };
  baseline_weights: { water: number; soil: number; climate: number; local: number };
  ranking_comparison: {
    baseline_weights: { water: number; soil: number; climate: number; local: number };
    applied_weights: { water: number; soil: number; climate: number; local: number };
    rankings: RankingComparisonItem[];
  };
}

// --- Farmer Profile & Ground-Truth Soil Types ---

export interface FarmerProfileInput {
  farm_id?: string | null;
  soil_type: string;
  soil_ph?: number | null;
  nitrogen_kg_ha?: number | null;
  nitrogen_rating?: string | null;
  phosphorus_kg_ha?: number | null;
  phosphorus_rating?: string | null;
  potassium_kg_ha?: number | null;
  potassium_rating?: string | null;
  organic_carbon_pct?: number | null;
  current_crop?: string | null;
  previous_crops: string[];
  available_crops: string[];
  irrigation_source: string;
  farming_season: string;
  preferred_crops: string[];
  soil_source_type: 'farmer_measured' | 'agricultural_benchmark';
  soil_source_reference?: string | null;
}

export interface FarmerProfile {
  id?: string;
  farm_id?: string | null;
  soil_type: string;
  soil_source_type: string;
  soil_source_reference?: string;
  soil_ph?: number | null;
  ph_classification?: string;
  nitrogen_value?: number | null;
  nitrogen_rating?: string;
  phosphorus_value?: number | null;
  phosphorus_rating?: string;
  potassium_value?: number | null;
  potassium_rating?: string;
  organic_carbon_pct?: number | null;
  organic_carbon_rating?: string;
  current_crop?: string | null;
  previous_crops: string[];
  available_crops: string[];
  irrigation_source: string;
  farming_season: string;
  preferred_crops: string[];
  provenance_notice?: string;
  created_at?: string;
  updated_at?: string;
}

export interface DistrictSoilBenchmark {
  district_id: string;
  district_name: string;
  region: string;
  dominant_soil_type: string;
  secondary_soil_type?: string;
  soil_orders?: string[];
  soil_ph: number;
  ph_classification: string;
  electrical_conductivity_ds_m?: number;
  organic_carbon_pct: number;
  organic_carbon_rating: string;
  available_nitrogen_kg_ha: number;
  nitrogen_rating: string;
  available_phosphorus_kg_ha: number;
  phosphorus_rating: string;
  available_potassium_kg_ha: number;
  potassium_rating: string;
  drainage_class?: string;
  source_reference: string;
}

// --- Verified Crop Knowledge Catalog Types (ANGRAU / ICAR) ---

export interface CropKnowledgeProfile {
  id: string;
  crop_name: string;
  telugu_name?: string;
  scientific_name?: string;
  crop_family: string;
  category: string;
  growing_season: string[];
  crop_duration_days: [number, number];
  water_requirement_mm: [number, number];
  water_requirement_status?: string;
  soil_suitability: {
    suitable_soil_types: string[];
    unsuitable_soil_types?: string[];
    optimal_ph_range: [number, number];
    drainage_requirement: string;
  };
  nutrient_requirements: {
    recommended_npk_kg_ha?: {
      nitrogen: number;
      phosphorus: number;
      potassium: number;
    };
    gypsum_recommendation_kg_ha?: number;
    nitrogen_impact: 'fixing' | 'depleting' | 'neutral' | string;
    biological_nitrogen_fixation_kg_ha?: number;
    micronutrient_sensitivities?: string[];
  };
  heat_sensitivity: {
    rating: string;
    critical_temperature_celsius?: number;
    impact: string;
  };
  water_stress_sensitivity: {
    rating: string;
    critical_growth_stages: string[];
    drought_adaptation: string;
  };
  rotation_compatibility: {
    beneficial_predecessors: string[];
    incompatible_predecessors: string[];
    rotational_benefits: string;
    pest_cycle_breaks: string;
  };
  local_cultivation_evidence: string;
  source_and_reference_date: {
    primary_authority: string;
    publication: string;
    reference_year: string;
    secondary_reference?: string;
  };
}

// --- Climate What-If Scenario Simulator Types ---

export interface ClimateScenarioParameters {
  rainfall_pct_change: number;
  temp_celsius_change: number;
  water_availability_pct_change: number;
}

export interface ClimateTransformationsAudit {
  rainfall: {
    baseline_source: string;
    baseline_value_mm: number;
    percentage_adjustment: number;
    simulated_value_mm: number;
    delta_mm: number;
    formula: string;
    classification: string;
  };
  temperature: {
    baseline_source: string;
    baseline_t2m_avg_c: number;
    baseline_t2m_max_c: number;
    celsius_adjustment: number;
    simulated_t2m_avg_c: number;
    simulated_t2m_max_c: number;
    formula: string;
    classification: string;
  };
  water_availability: {
    baseline_source: string;
    water_availability_pct_change: number;
    simulated_smap_moisture_m3_m3: number | null;
    simulated_smap_regime: string | null;
    formula: string;
    classification: string;
  };
}

export interface ScenarioComparisonItem {
  strategy_id: string;
  title: string;
  sequence: string;
  baseline_rank: number;
  scenario_rank: number;
  baseline_score: number;
  scenario_score: number;
  score_delta: number;
  rank_shift: number;
  shift_direction: 'up' | 'down' | 'unchanged';
  resilience_explanation: string;
  baseline_scores: {
    water_suitability: number;
    soil_health_potential: number;
    climate_suitability: number;
    local_agricultural_suitability: number;
  };
  scenario_scores: {
    water_suitability: number;
    soil_health_potential: number;
    climate_suitability: number;
    local_agricultural_suitability: number;
  };
}

export interface ClimateSimulationResponse {
  simulation_id: string;
  scientific_classification: string;
  is_simulated: boolean;
  disclaimer: string;
  scenario_parameters: ClimateScenarioParameters;
  transformations_audit: ClimateTransformationsAudit;
  comparison_matrix: ScenarioComparisonItem[];
  most_resilient_strategy: {
    strategy_id: string;
    title: string;
    scenario_score: number;
    score_delta: number;
  };
  applied_weights: Record<string, number>;
  baseline_preservation_notice: string;
}

export interface ClimateSimulationRequest {
  state_id?: string;
  latitude: number;
  longitude: number;
  farm_id?: string | null;
  farmer_profile?: any;
  weights?: Record<string, number> | null;
  baseline_dossier?: any;
  rainfall_pct_change: number;
  temp_celsius_change: number;
  water_availability_pct_change: number;
}

// --- Navigation & User Profile Types ---

export type AppRoute = '/' | '/dashboard' | '/login' | '/profile' | '/farms' | '/rotation-history' | '/earth-observation';

export type UserRole = 'farmer' | 'agronomist' | 'extension_officer' | 'researcher';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: UserRole;
  designation: string;
  organization?: string;
  state_id: string;
  district_id: string;
  mandal_id?: string;
  land_holding_category?: string;
  primary_farm_id?: string;
  verified: boolean;
  member_since: string;
  avatar_initials?: string;
}

export interface LoginCredentials {
  identifier: string;
  password: string;
  farmerName?: string;
  phone?: string;
  district?: string;
  mandal?: string;
  landHoldingCategory?: string;
  role: UserRole;
  rememberMe: boolean;
}

