import React, { useState } from 'react';
import { Header } from '../components/Header';
import { API_BASE_URL } from '../configuration/api';
import { Satellite, Globe2, ExternalLink, Droplets, Mountain, CloudSun, Layers } from 'lucide-react';

async function postJson(path: string, body: unknown) {
  const response = await fetch(`${API_BASE_URL}${path}`, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  if (!response.ok) throw new Error(`${response.status}: ${await response.text()}`);
  return response.json();
}
async function getJson(path: string) {
  const response = await fetch(`${API_BASE_URL}${path}`, { credentials: 'include' });
  if (!response.ok) throw new Error(`${response.status}: ${await response.text()}`);
  return response.json();
}

export const EarthObservationPage: React.FC = () => {
  const [lat, setLat] = useState('16.5062');
  const [lon, setLon] = useState('80.6480');
  const today = new Date();
  const endDefault = today.toISOString().slice(0, 10);
  const startDate = new Date(today);
  startDate.setDate(startDate.getDate() - 45);
  const startDefault = startDate.toISOString().slice(0, 10);
  const [start, setStart] = useState(startDefault);
  const [end, setEnd] = useState(endDefault);
  const [cloud, setCloud] = useState('30');
  const [sentinel, setSentinel] = useState<any>(null);
  const [gaez, setGaez] = useState<any>(null);
  const [gldas, setGldas] = useState<any>(null);
  const [srtm, setSrtm] = useState<any>(null);
  const [era5, setEra5] = useState<any>(null);
  const [landsat, setLandsat] = useState<any>(null);
  const [modisViirs, setModisViirs] = useState<any>(null);
  const [ecostressGracefo, setEcostressGracefo] = useState<any>(null);
  const [query, setQuery] = useState('crop suitability');
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');

  const runSentinel = async () => {
    setBusy('sentinel'); setError('');
    try { setSentinel(await postJson('/api/earth-observation/sentinel-2/search', { latitude: Number(lat), longitude: Number(lon), start_date: start, end_date: end, max_cloud_cover: Number(cloud), limit: 10 })); }
    catch (e: any) { setError(e.message); } finally { setBusy(''); }
  };
  const runGaez = async () => {
    setBusy('gaez'); setError('');
    try { setGaez(await postJson('/api/gaez/search', { query, limit: 10 })); }
    catch (e: any) { setError(e.message); } finally { setBusy(''); }
  };
  const runGldas = async () => {
    setBusy('gldas'); setError('');
    try { setGldas(await postJson('/api/nasa/gldas/query', { latitude: Number(lat), longitude: Number(lon) })); }
    catch (e: any) { setError(e.message); } finally { setBusy(''); }
  };
  const runSrtm = async () => {
    setBusy('srtm'); setError('');
    try { setSrtm(await postJson('/api/earth-observation/srtm/query', { points: [{ latitude: Number(lat), longitude: Number(lon) }] })); }
    catch (e: any) { setError(e.message); } finally { setBusy(''); }
  };
  const runEra5 = async () => {
    setBusy('era5'); setError('');
    try { const latestAllowed = new Date(end); latestAllowed.setDate(latestAllowed.getDate() - 31); const minDate = latestAllowed.toISOString().slice(0, 10); const boundedStart = start < minDate ? minDate : start; setEra5(await postJson('/api/climate/era5/query', { latitude: Number(lat), longitude: Number(lon), start_date: boundedStart, end_date: end })); }
    catch (e: any) { setError(e.message); } finally { setBusy(''); }
  };
  const runLandsat = async () => {
    setBusy('landsat'); setError('');
    try { setLandsat(await postJson('/api/earth-observation/landsat/search', { latitude: Number(lat), longitude: Number(lon), start_date: start, end_date: end, max_cloud_cover: Number(cloud), limit: 10 })); }
    catch (e: any) { setError(e.message); } finally { setBusy(''); }
  };
  const runModisViirs = async () => {
    setBusy('modisviirs'); setError('');
    try {
      setModisViirs(await postJson('/api/earth-observation/modis-viirs/search', {
        latitude: Number(lat), longitude: Number(lon), start_date: start, end_date: end,
        products: ['MODIS_NDVI_EVI', 'MODIS_LST', 'MODIS_ET', 'VIIRS_NDVI_EVI', 'VIIRS_LST'], limit: 10
      }));
    } catch (e: any) { setError(e.message); } finally { setBusy(''); }
  };
  const runEcostressGracefo = async () => {
    setBusy('ecostressgracefo'); setError('');
    try {
      setEcostressGracefo(await postJson('/api/earth-observation/ecostress-gracefo/search', {
        latitude: Number(lat), longitude: Number(lon), start_date: start, end_date: end,
        products: ['ECOSTRESS_LST', 'ECOSTRESS_CLOUD', 'ECOSTRESS_NDVI_ALBEDO', 'ECOSTRESS_ET_ALEXI', 'GRACE_FO_TWS_MASCON'], limit: 10
      }));
    } catch (e: any) { setError(e.message); } finally { setBusy(''); }
  };
  const loadGaezCatalog = async () => {
    setBusy('catalog'); setError('');
    try { setGaez(await getJson('/api/gaez/catalog')); }
    catch (e: any) { setError(e.message); } finally { setBusy(''); }
  };

  return <div className="min-h-screen bg-slate-50"><Header currentRoute="/earth-observation" />
    <main className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      <div><p className="text-xs font-bold uppercase tracking-widest text-emerald-700">Additional geospatial sources</p><h1 className="text-2xl font-black text-slate-900">Earth Observation & Terrain Data</h1><p className="text-sm text-slate-600 mt-1">Explore Sentinel-2, Landsat, MODIS, VIIRS, ECOSTRESS, GRACE-FO, FAO GAEZ, NASA GLDAS, ERA5 and SRTM sources for farm context.</p></div>
      <div className="grid lg:grid-cols-2 gap-5">
        <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
          <div className="flex items-center gap-2"><Satellite className="text-emerald-700"/><h2 className="font-bold text-lg">Sentinel-2 L2A catalogue</h2></div>
          <p className="text-xs text-slate-500">Search Copernicus scenes near a farm coordinate, filtered by date and cloud cover.</p>
          <div className="grid grid-cols-2 gap-3">{[['Latitude',lat,setLat],['Longitude',lon,setLon],['Start date',start,setStart],['End date',end,setEnd],['Max cloud cover %',cloud,setCloud]].map(([label,value,setter]: any) => <label key={label} className="text-xs font-semibold text-slate-600">{label}<input value={value} onChange={e=>setter(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm" /></label>)}</div>
          <button onClick={runSentinel} disabled={!!busy} className="rounded-xl bg-emerald-700 text-white px-4 py-2 text-sm font-bold disabled:opacity-50">{busy==='sentinel'?'Searching…':'Search Sentinel-2 scenes'}</button>
          {sentinel && <div className="rounded-xl bg-slate-50 border p-3 text-xs space-y-2"><b>{sentinel.count} scenes found</b><p>{sentinel.note}</p>{sentinel.items?.map((item:any)=><div key={item.id} className="border-t pt-2"><b>{item.datetime || item.id}</b><p>Cloud cover: {item.cloud_cover_percent ?? 'Unknown'}% · {item.platform || 'Sentinel-2'}</p></div>)}</div>}
        </section>
        <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
          <div className="flex items-center gap-2"><Globe2 className="text-blue-700"/><h2 className="font-bold text-lg">FAO GAEZ crop suitability</h2></div>
          <p className="text-xs text-slate-500">Search the machine-readable GAEZ catalogue. GAEZ assessments provide modelled suitability and attainable-yield context, not real-time field measurements.</p>
          <label className="text-xs font-semibold text-slate-600">Search topic or crop<input value={query} onChange={e=>setQuery(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm" placeholder="e.g. rice suitability" /></label>
          <div className="flex flex-wrap gap-2"><button onClick={runGaez} disabled={!!busy} className="rounded-xl bg-blue-700 text-white px-4 py-2 text-sm font-bold disabled:opacity-50">{busy==='gaez'?'Searching…':'Search GAEZ catalogue'}</button><button onClick={loadGaezCatalog} disabled={!!busy} className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-bold">Load collections</button></div>
          {gaez && <div className="rounded-xl bg-slate-50 border p-3 text-xs space-y-2"><b>{gaez.count ?? gaez.collections?.length ?? 0} catalogue results</b><p>{gaez.note}</p>{gaez.collections?.slice(0,8).map((item:any)=><div className="border-t pt-2" key={item.id}><b>{item.title || item.id}</b><p>{item.description}</p></div>)}{gaez.items?.slice(0,8).map((item:any)=><div className="border-t pt-2" key={item.id}><b>{item.id || item.properties?.title}</b><p>{item.properties?.description || item.properties?.title}</p></div>)}<a className="inline-flex items-center gap-1 text-blue-700 font-bold" href={gaez.current_version_portal || 'https://data.apps.fao.org/gaez/?lang=en'} target="_blank" rel="noreferrer">Open current GAEZ v5 portal <ExternalLink size={12}/></a></div>}
        </section>
      </div>
      <div className="grid lg:grid-cols-2 gap-5">
        <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
          <div className="flex items-center gap-2"><Droplets className="text-cyan-700"/><h2 className="font-bold text-lg">NASA GLDAS land-surface model</h2></div>
          <p className="text-xs text-slate-500">GLDAS-2.1 Noah monthly model output. Soil-water storage is reported by depth layer in kg/m²; this is modelled data, not a direct sensor reading.</p>
          <button onClick={runGldas} disabled={!!busy} className="rounded-xl bg-cyan-700 text-white px-4 py-2 text-sm font-bold disabled:opacity-50">{busy==='gldas'?'Querying NASA…':'Query GLDAS at these coordinates'}</button>
          {gldas && <div className="rounded-xl bg-slate-50 border p-3 text-xs space-y-2"><b>{gldas.status}</b><p>{gldas.message || gldas.note}</p>{Object.entries(gldas.variables || {}).map(([key, value]:any)=><div className="border-t pt-2" key={key}><b>{value.label}</b><p>{value.value} {value.unit}</p></div>)}</div>}
        </section>
        <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
          <div className="flex items-center gap-2"><Mountain className="text-amber-700"/><h2 className="font-bold text-lg">SRTM terrain elevation</h2></div>
          <p className="text-xs text-slate-500">Query approximately 30 m SRTM elevation at the selected coordinate. Useful for terrain context and relative elevation; not a precision land survey.</p>
          <button onClick={runSrtm} disabled={!!busy} className="rounded-xl bg-amber-700 text-white px-4 py-2 text-sm font-bold disabled:opacity-50">{busy==='srtm'?'Querying elevation…':'Get SRTM elevation'}</button>
          {srtm && <div className="rounded-xl bg-slate-50 border p-3 text-xs space-y-2"><b>{srtm.status}</b><p>{srtm.note}</p>{srtm.results?.map((item:any,i:number)=><div className="border-t pt-2" key={i}><b>{item.elevation_m ?? 'No data'} m</b><p>{item.dataset} · {item.latitude}, {item.longitude}</p></div>)}</div>}
        </section>
      </div>
      <div className="grid lg:grid-cols-2 gap-5">
        <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
          <div className="flex items-center gap-2"><CloudSun className="text-indigo-700"/><h2 className="font-bold text-lg">ERA5 historical reanalysis</h2></div>
          <p className="text-xs text-slate-500">Hourly temperature, precipitation, reference evapotranspiration (ET₀) and soil-moisture layers from the ERA5 reanalysis model. Model estimates, not farm sensor readings. Select a date range of up to 32 days.</p>
          <button onClick={runEra5} disabled={!!busy} className="rounded-xl bg-indigo-700 text-white px-4 py-2 text-sm font-bold disabled:opacity-50">{busy==='era5'?'Querying archive…':'Query ERA5 time series'}</button>
          {era5 && <div className="rounded-xl bg-slate-50 border p-3 text-xs space-y-2"><b>{era5.status} · {era5.dataset || era5.model}</b><p>{era5.note || era5.message}</p><p>Period: {era5.period?.start || '—'} to {era5.period?.end || '—'} · {era5.hourly?.time?.length || 0} hourly records</p>{Object.entries(era5.units || {}).map(([key,unit]:any)=><div className="border-t pt-1" key={key}>{key}: {unit}</div>)}</div>}
        </section>
        <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
          <div className="flex items-center gap-2"><Layers className="text-lime-700"/><h2 className="font-bold text-lg">Landsat Collection 2 Level-2</h2></div>
          <p className="text-xs text-slate-500">Search Landsat 8/9 surface-reflectance scenes by farm coordinates, date and cloud cover. Metadata and spectral asset links are returned; pixel processing is not yet included.</p>
          <button onClick={runLandsat} disabled={!!busy} className="rounded-xl bg-lime-700 text-white px-4 py-2 text-sm font-bold disabled:opacity-50">{busy==='landsat'?'Searching scenes…':'Search Landsat scenes'}</button>
          {landsat && <div className="rounded-xl bg-slate-50 border p-3 text-xs space-y-2"><b>{landsat.count} scenes found</b><p>{landsat.note}</p>{landsat.items?.slice(0,8).map((item:any)=><div className="border-t pt-2" key={item.id}><b>{item.datetime || item.id}</b><p>{item.platform || 'Landsat'} · Cloud: {item.cloud_cover_percent ?? 'Unknown'}%</p>{item.assets?.thumbnail?.href && <a className="text-blue-700 font-bold" href={item.assets.thumbnail.href} target="_blank" rel="noreferrer">Open thumbnail</a>}</div>)}</div>}
        </section>
      </div>
      <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
        <div className="flex items-center gap-2"><Satellite className="text-fuchsia-700"/><h2 className="font-bold text-lg">NASA MODIS & VIIRS satellite products</h2></div>
        <p className="text-xs text-slate-500">Search NASA CMR for MODIS and VIIRS granules covering the selected coordinate and date range: vegetation indices, land-surface temperature and evapotranspiration. Catalogue results are not extracted farm-pixel measurements.</p>
        <button onClick={runModisViirs} disabled={!!busy} className="rounded-xl bg-fuchsia-700 text-white px-4 py-2 text-sm font-bold disabled:opacity-50">{busy==='modisviirs'?'Searching NASA CMR…':'Search MODIS & VIIRS granules'}</button>
        {modisViirs && <div className="rounded-xl bg-slate-50 border p-3 text-xs space-y-2">
          <b>{modisViirs.count} granules discovered · {modisViirs.source}</b><p>{modisViirs.note}</p>
          {modisViirs.items?.slice(0,20).map((item:any,i:number)=><div className="border-t pt-2" key={item.granule_id || i}>
            <b>{item.short_name} · {item.start_time || item.title}</b>
            <p>{item.description} · {item.platform} · {item.resolution} · {item.cadence}</p>
            <p className="break-all text-slate-500">{item.granule_id}</p>
            {item.data_links?.map((href:string,j:number)=><a key={j} className="mr-3 text-blue-700 font-bold" href={href} target="_blank" rel="noreferrer">Data link {j+1}</a>)}
          </div>)}
        </div>}
      </section>
      <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
        <div className="flex items-center gap-2"><Satellite className="text-violet-700"/><h2 className="font-bold text-lg">NASA ECOSTRESS & GRACE-FO</h2></div>
        <p className="text-xs text-slate-500">ECOSTRESS provides intermittent high-resolution surface temperature, cloud-mask, ancillary NDVI/albedo and evapotranspiration products. GRACE/GRACE-FO provides monthly regional terrestrial water-storage anomalies; its spatial scale is too coarse for an individual farm.</p>
        <button onClick={runEcostressGracefo} disabled={!!busy} className="rounded-xl bg-violet-700 text-white px-4 py-2 text-sm font-bold disabled:opacity-50">{busy==='ecostressgracefo'?'Searching NASA CMR…':'Search ECOSTRESS & GRACE-FO granules'}</button>
        {ecostressGracefo && <div className="rounded-xl bg-slate-50 border p-3 text-xs space-y-2">
          <b>{ecostressGracefo.count} granules discovered · {ecostressGracefo.source}</b><p>{ecostressGracefo.note}</p>
          {ecostressGracefo.items?.slice(0,20).map((item:any,i:number)=><div className="border-t pt-2" key={item.granule_id || i}>
            <b>{item.short_name} · {item.start_time || item.title}</b>
            <p>{item.description} · {item.mission} · {item.resolution} · {item.cadence}</p>
            <p className="break-all text-slate-500">{item.granule_id}</p>
            {item.data_links?.map((href:string,j:number)=><a key={j} className="mr-3 text-blue-700 font-bold" href={href} target="_blank" rel="noreferrer">Data link {j+1}</a>)}
          </div>)}
        </div>}
      </section>
      {error && <div className="rounded-xl bg-rose-50 border border-rose-200 p-3 text-sm text-rose-700">{error}</div>}
      <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900"><b>Data limitations:</b> GLDAS is a modelled land-surface product and requires NASA Earthdata credentials; SRTM elevation uses a third-party SRTM-backed elevation API. Sentinel-2 and Landsat integrations currently search public scene metadata; it does not yet calculate NDVI/NDWI or render processed farm imagery. The live catalogue search endpoint is GAEZ v4; the interface links to the current GAEZ v5 portal rather than mislabelling v4 records as v5.</div>
    </main>
  </div>;
};
