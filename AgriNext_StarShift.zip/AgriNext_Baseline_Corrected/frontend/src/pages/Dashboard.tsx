import React, { useEffect, useState } from 'react';
import { Header } from '../components/Header';
import { StatusCard } from '../components/StatusCard';
import { WorkflowStepper } from '../components/WorkflowStepper';
import { FarmLocationModule } from '../components/FarmLocationModule';
import { NASAPowerModule } from '../components/NASAPowerModule';
import { NASASMAPModule } from '../components/NASASMAPModule';
import { NASAGPMModule } from '../components/NASAGPMModule';
import { FarmerProfileModule } from '../components/FarmerProfileModule';
import { CropKnowledgeModule } from '../components/CropKnowledgeModule';
import { UnifiedEvidenceModule } from '../components/UnifiedEvidenceModule';
import { ClimateSimulatorModule } from '../components/ClimateSimulatorModule';
import { StateDataViewer } from '../components/StateDataViewer';
import { DeveloperGuide } from '../components/DeveloperGuide';
import { FarmAlertCenter } from '../components/FarmAlertCenter';
import { apiService } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useNavigation } from '../context/NavigationContext';
import { CheckCircle2, MapPin } from 'lucide-react';
import type {
  BackendHealth,
  NASAServiceMetadata,
  SupportedState,
  District,
  Crop,
  CropRule,
  StrategyArchetype,
  FarmProfile,
  FarmerProfile,
  EnvironmentalEvidenceObject
} from '../types';

const DEFAULT_CENTROID = { lat: 14.6805, lng: 77.6005 };

export const Dashboard: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const { navigate } = useNavigation();

  const [health, setHealth] = useState<BackendHealth | null>(null);
  const [nasaServices, setNasaServices] = useState<NASAServiceMetadata[]>([]);
  const [states, setStates] = useState<SupportedState[]>([]);
  const [districts, setDistricts] = useState<District[]>([]);
  const [crops, setCrops] = useState<Crop[]>([]);
  const [cropRules, setCropRules] = useState<CropRule[]>([]);
  const [strategies, setStrategies] = useState<StrategyArchetype[]>([]);
  const [activeFarm, setActiveFarm] = useState<FarmProfile | null>(null);
  const [farmerProfile, setFarmerProfile] = useState<FarmerProfile | null>(null);
  const [evidenceList, setEvidenceList] = useState<EnvironmentalEvidenceObject[]>([]);
  const [sharedDossier, setSharedDossier] = useState<any>(null);
  const [sharedWeights, setSharedWeights] = useState<{ water: number; soil: number; climate: number; local: number }>({
    water: 25,
    soil: 25,
    climate: 25,
    local: 25
  });
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadInitialData() {
      try {
        setLoading(true);
        setError(null);

        // Fetch backend health, states, and services in parallel
        const [healthRes, nasaRes, statesRes, districtsRes, cropsRes, rulesRes, stratRes] = await Promise.all([
          apiService.getHealth(),
          apiService.getNASAServices(),
          apiService.getStates(),
          apiService.getDistricts('andhra_pradesh'),
          apiService.getCrops('andhra_pradesh'),
          apiService.getCropRules('andhra_pradesh'),
          apiService.getStrategyArchetypes()
        ]);

        setHealth(healthRes);
        setNasaServices(nasaRes.services);
        setStates(statesRes.supported_states);
        setDistricts(districtsRes);
        setCrops(cropsRes);
        setCropRules(rulesRes.agronomic_rules);
        setStrategies(stratRes);
      } catch (err: any) {
        console.error('Failed to load initial AgriNext data:', err);
        setError(err.message || 'Unable to connect to AgriNext backend API.');
      } finally {
        setLoading(false);
      }
    }

    loadInitialData();
  }, []);

  const handleEvidenceAccumulated = React.useCallback((newEvidence: any) => {
    if (Array.isArray(newEvidence)) {
      setEvidenceList((prev) => [...prev, ...newEvidence]);
    } else if (newEvidence && typeof newEvidence === 'object') {
      setEvidenceList((prev) => [...prev, newEvidence]);
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col font-sans">
      <Header backendHealthy={health !== null && !error} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Step 1 Completion / Farmer Information Banner */}
        {currentUser && (
          <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4 border border-emerald-800 shadow-md">
            <div className="flex items-center space-x-3.5">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-green-700 flex items-center justify-center font-black text-sm text-white shadow-md shadow-emerald-950/50">
                {currentUser.avatar_initials || 'AP'}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-800/80 text-emerald-300 font-bold border border-emerald-600 flex items-center space-x-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>Step 1 Completed</span>
                  </span>
                  <h2 className="font-bold text-sm sm:text-base text-white">
                    {currentUser.name}
                  </h2>
                </div>
                <p className="text-xs text-emerald-200/90 mt-1 flex flex-wrap items-center gap-1.5">
                  <span>{currentUser.designation}</span>
                  <span>•</span>
                  <span className="capitalize font-medium text-emerald-300">
                    {currentUser.district_id ? currentUser.district_id.replace(/_/g, ' ') : 'Andhra Pradesh'}
                  </span>
                  <span>•</span>
                  <span className="text-amber-300 font-semibold flex items-center space-x-1">
                    <MapPin className="w-3 h-3 inline" />
                    <span>Next: Step 2: Add Farm Location & Land Area below</span>
                  </span>
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-xs">
              <button
                type="button"
                onClick={() => navigate('/rotation-history')}
                className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold transition-all shadow-2xs"
              >
                Crop History
              </button>
              <button
                type="button"
                onClick={() => navigate('/farms')}
                className="px-3.5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold transition-all shadow-2xs"
              >
                My Farms
              </button>
              <button
                type="button"
                onClick={() => navigate('/profile')}
                className="px-3.5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold transition-all shadow-2xs"
              >
                Farmer Profile Dossier
              </button>
              <button
                type="button"
                onClick={() => {
                  logout();
                  navigate('/login');
                }}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-rose-950/80 text-slate-300 hover:text-rose-300 font-medium transition-colors"
                title="Sign out and return to Step 1 Login"
              >
                Sign Out
              </button>
            </div>
          </div>
        )}

        {/* System Health and NASA Service Status (POWER, SMAP, GPM) */}
        <StatusCard
          health={health}
          nasaServices={nasaServices}
          loading={loading}
          error={error}
        />

        {/* 11-Step Core Workflow Stepper */}
        <WorkflowStepper activeStep={farmerProfile ? 6 : evidenceList.length > 0 ? 5 : activeFarm ? 4 : 2} />

        {/* Farm weather and soil observation advisories */}
        <FarmAlertCenter farmId={activeFarm?.id || null} />

        {/* Farm Location, Drawing & Acreage Module (Steps 1, 2, 3) */}
        <FarmLocationModule
          states={states}
          districts={districts}
          onFarmSelected={(farm) => setActiveFarm(farm)}
        />

        {/* NASA POWER Agroclimatology Observations Module */}
        <NASAPowerModule
          activeFarm={activeFarm}
          defaultCoords={DEFAULT_CENTROID}
          onEvidenceLoaded={handleEvidenceAccumulated}
        />

        {/* DATASET A: NASA SMAP SPL3SMP_E Version 6 Surface Soil Moisture Module */}
        <NASASMAPModule
          activeFarm={activeFarm}
          defaultCoords={DEFAULT_CENTROID}
          onEvidenceLoaded={handleEvidenceAccumulated}
        />

        {/* DATASET B: NASA GPM IMERG Version 07 Final Run Precipitation Module */}
        <NASAGPMModule
          activeFarm={activeFarm}
          defaultCoords={DEFAULT_CENTROID}
          onEvidenceLoaded={handleEvidenceAccumulated}
        />

        {/* Module 5: Farmer Profile & Soil Ground-Truth Module (pH, NPK, OC, Crops, Irrigation) */}
        <FarmerProfileModule
          activeFarm={activeFarm}
          crops={crops}
          onProfileUpdated={(prof) => setFarmerProfile(prof)}
        />

        {/* Verified ANGRAU & ICAR Crop Knowledge Catalog Module */}
        <CropKnowledgeModule />

        {/* Unified Environmental Evidence Service & Recommendation Engine (Steps 6-9) */}
        <UnifiedEvidenceModule
          activeFarm={activeFarm}
          defaultCoords={DEFAULT_CENTROID}
          farmerProfile={farmerProfile}
          onDossierLoaded={setSharedDossier}
          onWeightsChanged={setSharedWeights}
        />

        {/* Climate What-if Scenario Simulator (Step 10) */}
        <ClimateSimulatorModule
          activeFarm={activeFarm}
          defaultCoords={DEFAULT_CENTROID}
          farmerProfile={farmerProfile}
          baselineDossier={sharedDossier}
          appliedWeights={sharedWeights}
        />

        {/* State Data Foundations (Config-Driven) */}
        <StateDataViewer
          districts={districts}
          crops={crops}
          cropRules={cropRules}
          strategies={strategies}
        />

        {/* Developer Guide and Architecture Brief */}
        <DeveloperGuide />
      </main>

      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500">
        AgriNext Decision Support System • Powered by NASA Earth Observations (POWER, SMAP, GPM) • Andhra Pradesh Pilot
      </footer>
    </div>
  );
};
