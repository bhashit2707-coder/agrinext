import React, { useState, useEffect } from 'react';
import {
  Sprout,
  Lock,
  Mail,
  User,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle2,
  Info,
  ArrowRight,
} from 'lucide-react';
import { Header } from '../components/Header';
import { useNavigation } from '../context/NavigationContext';
import { useAuth } from '../context/AuthContext';
import { apiService } from '../services/api';
import type { BackendHealth } from '../types';


export const LoginPage: React.FC = () => {
  const { navigate, redirectParam } = useNavigation();
  const { login, register, isAuthenticated, currentUser, authIntegrationNotice } = useAuth();
  const [isRegistering, setIsRegistering] = useState(false);

  const [backendHealthy, setBackendHealthy] = useState<boolean>(true);

  // Step 1: Farmer Information Fields
  const [farmerName, setFarmerName] = useState<string>('');
  const [identifier, setIdentifier] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [showForgotModal, setShowForgotModal] = useState<boolean>(false);

  // Form validation states
  const [farmerNameError, setFarmerNameError] = useState<string | null>(null);
  const [identifierError, setIdentifierError] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  // Check backend health on mount
  useEffect(() => {
    let isMounted = true;
    apiService
      .getHealth()
      .then((health: BackendHealth) => {
        if (isMounted) setBackendHealthy(health.status === 'healthy');
      })
      .catch(() => {
        if (isMounted) setBackendHealthy(false);
      });
    return () => {
      isMounted = false;
    };
  }, []);

  const validateFields = (): boolean => {
    let isValid = true;

    if (isRegistering && !farmerName.trim()) {
      setFarmerNameError('Full name is required for registration.');
      isValid = false;
    } else {
      setFarmerNameError(null);
    }

    const cleanId = identifier.trim();
    if (!cleanId) {
      setIdentifierError('Email address is required.');
      isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanId)) {
      setIdentifierError('Enter a valid email address.');
      isValid = false;
    } else {
      setIdentifierError(null);
    }

    if (!password) {
      setPasswordError('Password or Security PIN is required.');
      isValid = false;
    } else if (password.length < 10) {
      setPasswordError('Password must be at least 10 characters long.');
      isValid = false;
    } else {
      setPasswordError(null);
    }

    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeneralError(null);
    setSuccessMessage(null);

    if (!validateFields()) {
      return;
    }

    setLoading(true);
    try {
      const result = isRegistering
        ? await register({ fullName: farmerName, email: identifier, password })
        : await login({
            identifier, password, role: 'farmer', rememberMe: false
          });

      if (!result.success) {
        setGeneralError(result.error || 'Authentication failed. Please verify credentials.');
      } else {
        setSuccessMessage(isRegistering ? 'Your farmer account has been created securely.' : 'Sign-in successful. Proceeding to your farm workspace...');
        const destination = redirectParam && redirectParam.startsWith('/') ? redirectParam : '/';
        setTimeout(() => {
          navigate(destination);
        }, 500);
      }
    } catch (err: any) {
      setGeneralError(err.message || 'An unexpected error occurred during login.');
    } finally {
      setLoading(false);
    }
  };



  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col font-sans">
      <Header backendHealthy={backendHealthy} currentRoute="/login" />

      <main className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-xl w-full space-y-5">
          {/* Main Card Container */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xl p-6 sm:p-8 space-y-6">
            {/* Step 1 Flow Badge & Header */}
            <div className="text-center space-y-2">
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                <span>Step 1 of 11: Enter Farmer Information</span>
              </div>

              <div className="pt-1">
                <div className="inline-flex w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-green-700 items-center justify-center shadow-lg shadow-emerald-900/20 mb-2">
                  <Sprout className="w-7 h-7 text-white" />
                </div>
                <h1 className="text-2xl font-black text-slate-800 tracking-tight">
                  {isRegistering ? 'Create Farmer Account' : 'Farmer Sign In'}
                </h1>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  AgriNext Decision Support System begins with entering your farmer details. Next: <b>Step 2 (Add Farm Location and Land Area)</b>.
                </p>
              </div>
            </div>

            {/* Next Step Transition Banner */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold">
                  1
                </span>
                <span className="font-semibold text-slate-800">Step 1: Enter Farmer Info</span>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400" />
              <div className="flex items-center space-x-2 opacity-80">
                <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center text-[10px] font-bold">
                  2
                </span>
                <span className="font-medium text-slate-600">Step 2: Add Location & Area</span>
              </div>
            </div>

            {/* Already Authenticated Banner */}
            {isAuthenticated && currentUser && (
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 space-y-2">
                <div className="flex items-center space-x-2 font-bold text-emerald-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Currently Signed In as {currentUser.name}</span>
                </div>
                <p className="text-emerald-700">
                  Step 1 is verified. You can proceed directly to Step 2 on the Dashboard or view your saved farm profile.
                </p>
                <div className="flex items-center space-x-2 pt-1">
                  <button
                    type="button"
                    onClick={() => navigate(redirectParam || '/')}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors"
                  >
                    <span>Proceed to Step 2: Farm Location</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate('/profile')}
                    className="px-3 py-1.5 rounded-lg bg-white border border-emerald-300 text-emerald-800 hover:bg-emerald-100 font-semibold text-xs transition-colors"
                  >
                    View Profile Dossier
                  </button>
                </div>
              </div>
            )}

            {/* Step 1 Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {isRegistering && (
                <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 flex items-center justify-between">
                  <span>Farmer / Operator Full Name</span>
                  <span className="text-slate-400 text-[11px]">Required</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={farmerName}
                    onChange={(e) => {
                      setFarmerName(e.target.value);
                      if (farmerNameError) setFarmerNameError(null);
                    }}
                    placeholder="e.g. Ramesh Babu"
                    className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border bg-white focus:outline-hidden focus:ring-2 transition-all ${
                      farmerNameError
                        ? 'border-rose-300 bg-rose-50/20 text-rose-900 focus:ring-rose-400'
                        : 'border-slate-300 text-slate-800 focus:ring-emerald-500 focus:border-emerald-500'
                    }`}
                  />
                </div>
                {farmerNameError && (
                  <p className="text-[11px] text-rose-600 flex items-center space-x-1">
                    <AlertCircle className="w-3 h-3 shrink-0" />
                    <span>{farmerNameError}</span>
                  </p>
                )}
              </div>

              )}

              {/* Account email */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 flex items-center justify-between">
                  <span>Email Address</span>
                  <span className="text-slate-400 text-[11px]">Required</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input type="email" autoComplete="email" value={identifier}
                    onChange={(e) => { setIdentifier(e.target.value); if (identifierError) setIdentifierError(null); }}
                    placeholder="you@example.com"
                    className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border bg-white focus:outline-hidden focus:ring-2 transition-all ${identifierError ? 'border-rose-300 bg-rose-50/20 text-rose-900 focus:ring-rose-400' : 'border-slate-300 text-slate-800 focus:ring-emerald-500 focus:border-emerald-500'}`}
                  />
                </div>
                {identifierError && <p className="text-[11px] text-rose-600 flex items-center space-x-1"><AlertCircle className="w-3 h-3 shrink-0" /><span>{identifierError}</span></p>}
              </div>

              {/* Password / Access PIN Input */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700">
                    Account Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowForgotModal(true)}
                    className="text-[11px] text-emerald-600 hover:text-emerald-700 font-medium"
                  >
                    Assistance?
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (passwordError) setPasswordError(null);
                    }}
                    placeholder="Enter at least 10 characters"
                    className={`w-full pl-9 pr-10 py-2 text-xs rounded-xl border bg-white focus:outline-hidden focus:ring-2 transition-all ${
                      passwordError
                        ? 'border-rose-300 bg-rose-50/20 text-rose-900 focus:ring-rose-400'
                        : 'border-slate-300 text-slate-800 focus:ring-emerald-500 focus:border-emerald-500'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {passwordError && (
                  <p className="text-[11px] text-rose-600 flex items-center space-x-1">
                    <AlertCircle className="w-3 h-3 shrink-0" />
                    <span>{passwordError}</span>
                  </p>
                )}
              </div>

              {/* Status & Error Messages */}
              {generalError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{generalError}</span>
                </div>
              )}

              {successMessage && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{successMessage}</span>
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-md shadow-emerald-900/20"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>{isRegistering ? "Creating Account..." : "Signing In..."}</span>
                  </>
                ) : (
                  <>
                    <span>{isRegistering ? "Create Secure Farmer Account" : "Sign In & Continue"}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            <div className="text-center text-xs text-slate-600">
              {isRegistering ? 'Already have an account?' : 'New to AgriNext?'}{' '}
              <button type="button" onClick={() => { const next = !isRegistering; setIsRegistering(next); setFarmerName(''); setIdentifier(''); setPassword(''); setGeneralError(null); setSuccessMessage(null); }} className="font-bold text-emerald-700 hover:text-emerald-800">
                {isRegistering ? 'Sign in' : 'Create farmer account'}
              </button>
              {isRegistering && <p className="mt-2 text-[11px] text-slate-500">Public registration creates a farmer account. Staff and researcher roles require administrator provisioning.</p>}
            </div>

            {/* Architecture Provenance Notice */}
            <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200 text-[11px] text-amber-950 flex items-start space-x-2">
              <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Provenance Notice: </span>
                {authIntegrationNotice.details}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl border border-slate-200">
            <div className="flex items-center space-x-2 text-slate-800 font-bold text-base">
              <Info className="w-5 h-5 text-emerald-600" />
              <h3>Farmer Support & Credentials</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Self-service password reset is not implemented yet. Contact your AgriNext administrator for account assistance.
            </p>
            <button
              type="button"
              onClick={() => setShowForgotModal(false)}
              className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500">
        AgriNext Decision Support System • Powered by NASA Earth Observations (POWER, SMAP, GPM) • Andhra Pradesh Pilot
      </footer>
    </div>
  );
};
