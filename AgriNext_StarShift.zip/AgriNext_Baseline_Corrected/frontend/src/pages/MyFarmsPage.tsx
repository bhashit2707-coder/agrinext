import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowLeft, MapPin, Plus, RefreshCw, Search, Sprout, Trash2, Ruler, CalendarDays } from 'lucide-react';
import { Header } from '../components/Header';
import { useNavigation } from '../context/NavigationContext';
import { apiService } from '../services/api';
import type { FarmProfile } from '../types';

export const MyFarmsPage: React.FC = () => {
  const { navigate } = useNavigation();
  const [farms, setFarms] = useState<FarmProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const loadFarms = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setFarms(await apiService.getFarms());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load your farms.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void loadFarms(); }, [loadFarms]);

  const visibleFarms = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return farms;
    return farms.filter((farm) => [farm.farm_name, farm.district_id, farm.mandal_id, farm.village_name || '']
      .some((value) => value.toLowerCase().includes(term)));
  }, [farms, query]);

  const totalAcres = farms.reduce((sum, farm) => sum + (Number(farm.effective_acreage) || 0), 0);

  const removeFarm = async (farm: FarmProfile) => {
    if (!farm.id || !window.confirm(`Delete “${farm.farm_name}”? This cannot be undone.`)) return;
    setDeletingId(farm.id);
    try {
      await apiService.deleteFarm(farm.id);
      setFarms((current) => current.filter((item) => item.id !== farm.id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Farm could not be deleted.');
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col font-sans">
      <Header />
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-7 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <button onClick={() => navigate('/dashboard')} className="mb-3 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-emerald-700">
              <ArrowLeft className="w-3.5 h-3.5" /> Back to dashboard
            </button>
            <h1 className="text-2xl font-black text-slate-900">My Farms</h1>
            <p className="text-sm text-slate-500 mt-1">Manage your saved farm plots and land records.</p>
          </div>
          <button onClick={() => navigate('/dashboard')} className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white shadow-sm hover:bg-emerald-700">
            <Plus className="w-4 h-4" /> Add / Edit Farm
          </button>
        </div>

        <section className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs text-slate-500">Registered farms</p><p className="mt-1 text-2xl font-black text-slate-900">{farms.length}</p></div>
          <div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs text-slate-500">Total recorded land</p><p className="mt-1 text-2xl font-black text-emerald-700">{totalAcres.toFixed(2)} <span className="text-sm font-semibold">acres</span></p></div>
          <div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs text-slate-500">Data ownership</p><p className="mt-1 text-base font-bold text-slate-900">Your account only</p><p className="text-[11px] text-slate-400 mt-1">Farm records are account-protected.</p></div>
        </section>

        <div className="flex flex-wrap gap-2 items-center">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search farm, district, mandal or village..." className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
          </div>
          <button onClick={() => void loadFarms()} disabled={loading} className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-50">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </button>
        </div>

        {error && <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">{error}</div>}
        {loading ? <div className="rounded-2xl bg-white p-10 text-center text-sm text-slate-500">Loading your farm records…</div>
          : visibleFarms.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center">
              <Sprout className="mx-auto h-10 w-10 text-emerald-500" />
              <h2 className="mt-3 text-lg font-bold text-slate-800">{farms.length ? 'No matching farms' : 'No farms added yet'}</h2>
              <p className="mt-1 text-sm text-slate-500">{farms.length ? 'Try another search term.' : 'Add your first farm boundary to begin managing your land.'}</p>
              {!farms.length && <button onClick={() => navigate('/dashboard')} className="mt-4 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-700">Add your first farm</button>}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {visibleFarms.map((farm) => (
                <article key={farm.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                  <div className="flex items-start justify-between gap-3">
                    <div><h2 className="font-bold text-slate-900">{farm.farm_name}</h2><p className="mt-1 text-xs capitalize text-slate-500">{farm.district_id.replace(/_/g, ' ')} · {farm.mandal_id.replace(/_/g, ' ')}</p></div>
                    <button onClick={() => void removeFarm(farm)} disabled={deletingId === farm.id} aria-label={`Delete ${farm.farm_name}`} className="rounded-lg p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-600 disabled:opacity-40"><Trash2 className="h-4 w-4" /></button>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-3">
                    <div className="rounded-xl bg-emerald-50 p-3"><div className="flex items-center gap-1.5 text-[11px] text-emerald-700"><Ruler className="h-3.5 w-3.5" /> Land area</div><p className="mt-1 text-lg font-black text-emerald-900">{Number(farm.effective_acreage || 0).toFixed(2)} ac</p></div>
                    <div className="rounded-xl bg-slate-50 p-3"><div className="flex items-center gap-1.5 text-[11px] text-slate-500"><MapPin className="h-3.5 w-3.5" /> Location</div><p className="mt-1 text-sm font-bold text-slate-800">{farm.village_name || 'Village not set'}</p></div>
                  </div>
                  <div className="mt-3 flex items-center justify-between gap-2 text-[11px] text-slate-400"><span>{farm.latitude.toFixed(4)}, {farm.longitude.toFixed(4)}</span><span className="inline-flex items-center gap-1"><CalendarDays className="h-3 w-3" />{farm.updated_at ? new Date(farm.updated_at).toLocaleDateString() : 'Saved farm'}</span></div>
                  {farm.acreage_discrepancy_warning && <p className="mt-3 rounded-lg bg-amber-50 p-2 text-[11px] text-amber-800">{farm.acreage_discrepancy_warning}</p>}
                  <button onClick={() => navigate('/dashboard')} className="mt-4 w-full rounded-xl border border-emerald-200 px-3 py-2 text-xs font-bold text-emerald-700 hover:bg-emerald-50">Open in Farm Builder</button>
                </article>
              ))}
            </div>
          )}
      </main>
    </div>
  );
};
