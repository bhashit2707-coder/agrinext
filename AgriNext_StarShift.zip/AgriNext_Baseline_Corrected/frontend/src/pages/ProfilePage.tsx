import React, { useState, useEffect, useCallback } from 'react';
import {
  User,
  Sprout,
  MapPin,
  TestTube2,
  Calendar,
  Droplets,
  Satellite,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  LogOut,
  ArrowLeft,
  ExternalLink,
  Layers,
  BadgeCheck,
  Info
} from 'lucide-react';
import { Header } from '../components/Header';
import { useNavigation } from '../context/NavigationContext';
import { useAuth } from '../context/AuthContext';
import { apiService } from '../services/api';
import { SoilReportUpload } from '../components/SoilReportUpload';
import type {
  FarmProfile,
  FarmerProfile,
  NASAServiceMetadata
} from '../types';

export const ProfilePage: React.FC = () => {
  const { navigate } = useNavigation();
  const { currentUser, isAuthenticated, logout, authIntegrationNotice } = useAuth();

  const [farms, setFarms] = useState<FarmProfile[]>([]);
  const [selectedFarm, setSelectedFarm] = useState<FarmProfile | null>(null);
  const [farmerProfile, setFarmerProfile] = useState<FarmerProfile | null>(null);
  const [nasaServices, setNasaServices] = useState<NASAServiceMetadata[]>([]);
  const [backendHealthy, setBackendHealthy] = useState<boolean>(true);

  const [loading, setLoading] = useState<boolean>(true);
  const [loadingProfile, setLoadingProfile] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const loadSoilProfile = useCallback(async (farmId: string) => {
    setLoadingProfile(true);
    try {
      const profile = await apiService.getFarmerProfile(farmId);
      setFarmerProfile(profile);
    } catch (err) {
      console.warn(`No specific ground-truth soil profile found for farm ${farmId}:`, err);
      setFarmerProfile(null);
    } finally {
      setLoadingProfile(false);
    }
  }, []);

  // Load farms, backend health, and NASA service metadata
  const loadProfileData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [healthRes, farmsRes, nasaRes] = await Promise.all([
        apiService.getHealth().catch(() => null),
        apiService.getFarms().catch(() => []),
        apiService.getNASAServices().catch(() => ({ services: [] }))
      ]);

      setBackendHealthy(healthRes !== null && healthRes.status === 'healthy');
      setFarms(farmsRes || []);
      setNasaServices(nasaRes?.services || []);

      if (farmsRes && farmsRes.length > 0) {
        // Find user's primary farm or use first available farm
        const primary = currentUser?.primary_farm_id
          ? farmsRes.find((f: FarmProfile) => f.id === currentUser.primary_farm_id) || farmsRes[0]
          : farmsRes[0];

        setSelectedFarm(primary);
        if (primary.id) {
          await loadSoilProfile(primary.id);
        }
      }
    } catch (err: any) {
      console.error('Failed to load profile data:', err);
      setError(err.message || 'Unable to retrieve user farm profile records.');
    } finally {
      setLoading(false);
    }
  }, [currentUser?.primary_farm_id, loadSoilProfile]);

  useEffect(() => {
    loadProfileData();
  }, [loadProfileData]);

  const handleSelectFarm = async (farm: FarmProfile) => {
    setSelectedFarm(farm);
    if (farm.id) {
      await loadSoilProfile(farm.id);
    } else {
      setFarmerProfile(null);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col font-sans">
      <Header backendHealthy={backendHealthy} currentRoute="/profile" />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Top Breadcrumb & Page Actions */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={() => navigate('/')}
              className="p-2 rounded-xl bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300 shadow-2xs transition-colors"
              title="Return to Dashboard"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  User Details & Parcel Records
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500 font-mono">SQLite Ground-Truth Storage</span>
              </div>
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                Farmer & Parcel Profile Dossier
              </h1>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={loadProfileData}
              disabled={loading}
              className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 hover:border-slate-300 text-slate-700 font-semibold text-xs flex items-center space-x-2 shadow-2xs transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh Records</span>
            </button>

            {isAuthenticated ? (
              <button
                type="button"
                onClick={handleLogout}
                className="px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold text-xs flex items-center space-x-1.5 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => navigate('/login?redirect=/profile')}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-sm"
              >
                <User className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
            )}
          </div>
        </div>

        {/* Global Error Banner */}
        {error && (
          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
            <button
              type="button"
              onClick={loadProfileData}
              className="px-3 py-1 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-900 font-bold text-xs transition-colors"
            >
              Retry
            </button>
          </div>
        )}

        {/* Backend Auth Integration Notice */}
        <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 text-xs text-amber-950 flex items-start space-x-3 shadow-2xs">
          <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <div className="font-bold flex items-center space-x-2">
              <span>Zero-Fabrication Architecture Notice</span>
              <span className="px-2 py-0.2 rounded-full bg-amber-200 text-amber-900 text-[10px]">
                Architectural Boundary
              </span>
            </div>
            <p className="text-amber-900 leading-relaxed">
              {authIntegrationNotice.details}
            </p>
            <p className="text-amber-800 text-[11px]">
              • <b>Ground-Truth Soil & Parcel Data:</b> Stored persistently in local SQLite (<code>agrinext.db</code>) via verified ANGRAU/Soil Health Card parameters.
            </p>
          </div>
        </div>

        {/* 1. User Account Overview Card */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-5">
            <div className="flex items-center space-x-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-green-700 flex items-center justify-center text-white text-xl font-black shadow-lg shadow-emerald-900/20">
                {currentUser?.avatar_initials || 'AP'}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-xl font-bold text-slate-800">
                    {currentUser?.name || 'Andhra Pradesh Agricultural Pilot Participant'}
                  </h2>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 flex items-center space-x-1">
                    <BadgeCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Verified Pilot</span>
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  {currentUser?.designation || 'Registered Farmer & Landowner'} • {currentUser?.organization || 'AP Rythu Bharosa Kendra'}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs">
              <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-600">
                <span className="text-slate-400">Jurisdiction: </span>
                <span className="font-semibold text-slate-800">Andhra Pradesh Pilot</span>
              </div>
              <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-600">
                <span className="text-slate-400">Account ID: </span>
                <span className="font-mono font-semibold text-slate-800">{currentUser?.id || 'usr_pilot_guest'}</span>
              </div>
            </div>
          </div>

          {/* User Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50/80 border border-slate-200/70 space-y-1">
              <span className="text-slate-400 font-medium">Registered Email / ID</span>
              <p className="font-semibold text-slate-800 font-mono break-all">
                {currentUser?.email || 'ramesh.farmer@agrinext.in'}
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50/80 border border-slate-200/70 space-y-1">
              <span className="text-slate-400 font-medium">Primary District & Mandal</span>
              <p className="font-semibold text-slate-800">
                Anantapur • Anantapur Rural
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50/80 border border-slate-200/70 space-y-1">
              <span className="text-slate-400 font-medium">System Role & Access</span>
              <p className="font-semibold text-emerald-700 capitalize flex items-center space-x-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>{currentUser?.role || 'Farmer'} (Decision Engine Enabled)</span>
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50/80 border border-slate-200/70 space-y-1">
              <span className="text-slate-400 font-medium">Agricultural Authority</span>
              <p className="font-semibold text-slate-800">
                ANGRAU RARS & ICAR-CRIDA
              </p>
            </div>
          </div>
        </div>

        {/* 2. Registered Farm Plots & Parcels Section */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">
                  Module 1 & 2
                </span>
                <h2 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
                  <MapPin className="w-5 h-5 text-blue-600" />
                  <span>Linked Farm Plots ({farms.length})</span>
                </h2>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Persistent farm polygon boundaries, geodesic acreage declarations, and centroid query coordinates.
              </p>
            </div>

            <button
              type="button"
              onClick={() => navigate('/')}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-2xs"
            >
              <Sprout className="w-3.5 h-3.5" />
              <span>Map New Plot in Dashboard</span>
            </button>
          </div>

          {loading ? (
            <div className="p-8 text-center space-y-3">
              <div className="w-8 h-8 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-xs text-slate-500">Loading registered farm parcel data...</p>
            </div>
          ) : farms.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300 space-y-3">
              <MapPin className="w-10 h-10 text-slate-400 mx-auto" />
              <h3 className="text-sm font-bold text-slate-700">No Farm Plots Registered</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                No parcel boundaries have been drawn or saved yet. Open the Dashboard to draw a polygon on the Leaflet satellite map.
              </p>
              <button
                type="button"
                onClick={() => navigate('/')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-colors"
              >
                Go to Dashboard
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Farm Selector Chips */}
              <div className="flex flex-wrap gap-2">
                {farms.map((farm) => {
                  const isSelected = selectedFarm?.id === farm.id;
                  return (
                    <button
                      key={farm.id || farm.farm_name}
                      type="button"
                      onClick={() => handleSelectFarm(farm)}
                      className={`px-4 py-2.5 rounded-xl border text-xs font-semibold flex items-center space-x-2 transition-all ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-50/80 text-emerald-900 shadow-2xs'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <Layers className={`w-3.5 h-3.5 ${isSelected ? 'text-emerald-600' : 'text-slate-400'}`} />
                      <span>{farm.farm_name}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-white border border-slate-200">
                        {farm.effective_acreage.toFixed(2)} ac
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Selected Farm Detailed Card */}
              {selectedFarm && (
                <div className="p-5 rounded-2xl bg-slate-50/90 border border-slate-200 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200/80 pb-3">
                    <div>
                      <h3 className="text-base font-bold text-slate-800">
                        {selectedFarm.farm_name}
                      </h3>
                      <p className="text-xs text-slate-500">
                        Plot ID: <span className="font-mono text-slate-700">{selectedFarm.id}</span>
                      </p>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => navigate('/')}
                        className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 hover:border-slate-400 text-slate-700 font-semibold text-xs flex items-center space-x-1.5 transition-colors"
                      >
                        <span>Open in Decision Dashboard</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="p-3 bg-white rounded-xl border border-slate-200/80 space-y-0.5">
                      <span className="text-slate-400 text-[11px]">Geodesic Acreage</span>
                      <p className="font-bold text-slate-800 text-sm">
                        {selectedFarm.effective_acreage.toFixed(3)} acres
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {(selectedFarm.effective_acreage * 0.404686).toFixed(3)} hectares
                      </p>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-slate-200/80 space-y-0.5">
                      <span className="text-slate-400 text-[11px]">Centroid Coordinates</span>
                      <p className="font-mono font-bold text-slate-800">
                        {selectedFarm.latitude.toFixed(4)}° N
                      </p>
                      <p className="font-mono text-[10px] text-slate-500">
                        {selectedFarm.longitude.toFixed(4)}° E
                      </p>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-slate-200/80 space-y-0.5">
                      <span className="text-slate-400 text-[11px]">District & Mandal</span>
                      <p className="font-bold text-slate-800 capitalize">
                        {selectedFarm.district_id.replace(/_/g, ' ')}
                      </p>
                      <p className="text-[10px] text-slate-500 capitalize">
                        {selectedFarm.mandal_id.replace(/_/g, ' ')}
                      </p>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-slate-200/80 space-y-0.5">
                      <span className="text-slate-400 text-[11px]">Boundary Integrity</span>
                      <p className="font-bold text-emerald-700 flex items-center space-x-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Closed Polygon</span>
                      </p>
                      <p className="text-[10px] text-slate-500">
                        {selectedFarm.acreage_discrepancy_warning ? 'Review Discrepancy' : 'Verified via Turf.js'}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* 3. Soil Ground-Truth & Nutrient Profile Section (Module 5) */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
                  Module 5 Data
                </span>
                <h2 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
                  <TestTube2 className="w-5 h-5 text-amber-600" />
                  <span>Ground-Truth Soil Health & Nutrient Card</span>
                </h2>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Parcel-specific laboratory soil testing or district Soil Health Card benchmarks.
              </p>
            </div>

            <button
              type="button"
              onClick={() => navigate('/')}
              className="px-3.5 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 font-bold text-xs flex items-center space-x-1.5 transition-colors"
            >
              <TestTube2 className="w-3.5 h-3.5 text-amber-700" />
              <span>Update Soil Readings in Dashboard</span>
            </button>
          </div>

          <SoilReportUpload farmId={selectedFarm?.id} />

          {loadingProfile ? (
            <div className="p-8 text-center space-y-2">
              <div className="w-7 h-7 border-3 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-xs text-slate-500">Loading soil ground-truth measurements...</p>
            </div>
          ) : !farmerProfile ? (
            <div className="p-6 rounded-2xl bg-amber-50/50 border border-amber-200/70 text-xs text-amber-900 space-y-2">
              <div className="flex items-center space-x-2 font-bold text-amber-950">
                <Info className="w-4 h-4 text-amber-600" />
                <span>No Soil Ground-Truth Profile Recorded for this Farm Yet</span>
              </div>
              <p className="text-amber-800">
                This farm currently defaults to regional agricultural benchmark assumptions. You can enter measured soil pH, N-P-K, and organic carbon readings in Module 5 of the Dashboard.
              </p>
            </div>
          ) : (
            <div className="space-y-5">
              {/* Provenance Badge */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-800">Source Provenance: </span>
                  <span className="capitalize">{farmerProfile.soil_source_type.replace(/_/g, ' ')}</span>
                  {farmerProfile.soil_source_reference && (
                    <span className="text-slate-500 text-[11px]"> — {farmerProfile.soil_source_reference}</span>
                  )}
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                  Ground-Truth
                </span>
              </div>

              {/* Chemical Soil Health Cards Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="text-slate-400">Soil Reaction (pH)</span>
                  <p className="text-lg font-black text-slate-800">
                    {farmerProfile.soil_ph !== null && farmerProfile.soil_ph !== undefined ? farmerProfile.soil_ph : '—'}
                  </p>
                  <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                    {farmerProfile.ph_classification || 'Neutral'}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="text-slate-400">Nitrogen (N)</span>
                  <p className="text-lg font-black text-slate-800">
                    {farmerProfile.nitrogen_value !== null && farmerProfile.nitrogen_value !== undefined
                      ? `${farmerProfile.nitrogen_value} kg/ha`
                      : '—'}
                  </p>
                  <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-semibold bg-rose-100 text-rose-800">
                    {farmerProfile.nitrogen_rating || 'Low (< 140)'}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="text-slate-400">Phosphorus (P)</span>
                  <p className="text-lg font-black text-slate-800">
                    {farmerProfile.phosphorus_value !== null && farmerProfile.phosphorus_value !== undefined
                      ? `${farmerProfile.phosphorus_value} kg/ha`
                      : '—'}
                  </p>
                  <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-semibold bg-blue-100 text-blue-800">
                    {farmerProfile.phosphorus_rating || 'Medium'}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="text-slate-400">Potassium (K)</span>
                  <p className="text-lg font-black text-slate-800">
                    {farmerProfile.potassium_value !== null && farmerProfile.potassium_value !== undefined
                      ? `${farmerProfile.potassium_value} kg/ha`
                      : '—'}
                  </p>
                  <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                    {farmerProfile.potassium_rating || 'High'}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="text-slate-400">Organic Carbon (OC)</span>
                  <p className="text-lg font-black text-slate-800">
                    {farmerProfile.organic_carbon_pct !== null && farmerProfile.organic_carbon_pct !== undefined
                      ? `${farmerProfile.organic_carbon_pct}%`
                      : '—'}
                  </p>
                  <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-semibold bg-amber-100 text-amber-800">
                    {farmerProfile.organic_carbon_rating || 'Medium'}
                  </span>
                </div>
              </div>

              {/* Cropping and Water History Details */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <span className="font-bold text-slate-700 flex items-center space-x-1.5">
                    <Droplets className="w-4 h-4 text-cyan-600" />
                    <span>Irrigation & Season</span>
                  </span>
                  <div className="space-y-1 pt-1">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Irrigation Source:</span>
                      <span className="font-semibold text-slate-800">{farmerProfile.irrigation_source}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Farming Season:</span>
                      <span className="font-semibold text-slate-800">{farmerProfile.farming_season}</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <span className="font-bold text-slate-700 flex items-center space-x-1.5">
                    <Calendar className="w-4 h-4 text-amber-600" />
                    <span>Prior Crop History</span>
                  </span>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {farmerProfile.previous_crops && farmerProfile.previous_crops.length > 0 ? (
                      farmerProfile.previous_crops.map((c) => (
                        <span
                          key={c}
                          className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-700 capitalize font-medium text-[11px]"
                        >
                          {c.replace(/_/g, ' ')}
                        </span>
                      ))
                    ) : (
                      <span className="text-slate-400">None specified</span>
                    )}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <span className="font-bold text-slate-700 flex items-center space-x-1.5">
                    <Sprout className="w-4 h-4 text-emerald-600" />
                    <span>Preferred Rotation Candidates</span>
                  </span>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {farmerProfile.preferred_crops && farmerProfile.preferred_crops.length > 0 ? (
                      farmerProfile.preferred_crops.map((c) => (
                        <span
                          key={c}
                          className="px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 capitalize font-medium text-[11px]"
                        >
                          {c.replace(/_/g, ' ')}
                        </span>
                      ))
                    ) : (
                      <span className="text-slate-400">No preference declared</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 4. NASA Earth Observations & External Services Audit */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center space-x-2">
              <Satellite className="w-5 h-5 text-cyan-600" />
              <h2 className="text-lg font-bold text-slate-800">
                NASA Earth Observations Service Linkages
              </h2>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {nasaServices.length > 0 ? `${nasaServices.length} Monitored Services` : 'NASA Datasets'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800">NASA POWER</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  {nasaServices.find((s) => s.service.toLowerCase().includes('power'))?.status || 'Ready'}
                </span>
              </div>
              <p className="text-slate-500 text-[11px]">
                Agroclimatology Daily & Monthly API (Solar, T2M, RH, Rain) at ~0.5° resolution.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800">NASA SMAP</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-100 text-cyan-800">
                  {nasaServices.find((s) => s.service.toLowerCase().includes('smap'))?.status || 'SPL3SMP_E V006'}
                </span>
              </div>
              <p className="text-slate-500 text-[11px]">
                Surface Soil Moisture (9 km grid) via AppEEARS / Earthdata integration.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800">NASA GPM IMERG</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800">
                  {nasaServices.find((s) => s.service.toLowerCase().includes('gpm'))?.status || 'V07 Final Run'}
                </span>
              </div>
              <p className="text-slate-500 text-[11px]">
                Calibrated precipitation satellite telemetry (~10 km grid) via GES DISC archive.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500">
        AgriNext Decision Support System • Powered by NASA Earth Observations (POWER, SMAP, GPM) • Andhra Pradesh Pilot
      </footer>
    </div>
  );
};
