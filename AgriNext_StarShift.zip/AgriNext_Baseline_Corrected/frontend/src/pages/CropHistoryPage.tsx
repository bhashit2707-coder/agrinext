import React, { useEffect, useState } from 'react';
import { ArrowLeft, ClipboardList, Plus, Trash2, Sprout, History } from 'lucide-react';
import { Header } from '../components/Header';
import { useNavigation } from '../context/NavigationContext';
import { apiService } from '../services/api';
import type { FarmProfile } from '../types';

type RotationRecord = { id: string; farm_id: string; crop_name: string; season: string; crop_year: number; planting_date?: string | null; harvest_date?: string | null; yield_value?: number | null; yield_unit?: string | null; notes?: string | null; created_at: string };
type Activity = { id: string; activity_type: string; description: string; created_at: string };

export const CropHistoryPage: React.FC = () => {
  const { navigate } = useNavigation();
  const [farms, setFarms] = useState<FarmProfile[]>([]);
  const [farmId, setFarmId] = useState('');
  const [records, setRecords] = useState<RotationRecord[]>([]);
  const [activity, setActivity] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({ crop_name: '', season: 'Kharif', crop_year: new Date().getFullYear(), planting_date: '', harvest_date: '', yield_value: '', yield_unit: 'kg/acre', notes: '' });

  useEffect(() => { apiService.getFarms().then((items) => { setFarms(items); if (items[0]?.id) setFarmId(items[0].id); }).catch((e) => setError(e.message)).finally(() => setLoading(false)); }, []);
  useEffect(() => { if (!farmId) { setRecords([]); setActivity([]); return; } Promise.all([apiService.getRotationHistory(farmId), apiService.getFarmActivity(farmId)]).then(([r,a]) => { setRecords(r); setActivity(a); }).catch((e) => setError(e.message)); }, [farmId]);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); if (!farmId) return; setSaving(true); setError('');
    try { const saved = await apiService.addRotationHistory(farmId, { farm_id: farmId, crop_name: form.crop_name.trim(), season: form.season, crop_year: Number(form.crop_year), planting_date: form.planting_date || undefined, harvest_date: form.harvest_date || undefined, yield_value: form.yield_value === '' ? undefined : Number(form.yield_value), yield_unit: form.yield_unit || undefined, notes: form.notes || undefined }); setRecords((old) => [saved, ...old]); setForm((old) => ({ ...old, crop_name: '', planting_date: '', harvest_date: '', yield_value: '', notes: '' })); setActivity(await apiService.getFarmActivity(farmId)); }
    catch (e) { setError(e instanceof Error ? e.message : 'Unable to save crop history.'); } finally { setSaving(false); }
  };
  const remove = async (record: RotationRecord) => { if (!window.confirm(`Delete ${record.crop_name} (${record.season} ${record.crop_year})?`)) return; try { await apiService.deleteRotationHistory(record.id); setRecords((old) => old.filter((x) => x.id !== record.id)); setActivity(await apiService.getFarmActivity(farmId)); } catch (e) { setError(e instanceof Error ? e.message : 'Unable to delete record.'); } };

  return <div className="min-h-screen bg-slate-100/70 flex flex-col font-sans"><Header /><main className="max-w-7xl w-full mx-auto flex-1 px-4 sm:px-6 py-7 space-y-6">
    <div><button onClick={() => navigate('/dashboard')} className="mb-3 inline-flex items-center gap-2 text-xs font-semibold text-slate-500"><ArrowLeft className="w-4 h-4"/> Back to dashboard</button><h1 className="text-2xl font-black text-slate-900">Crop Rotation History & Farm Activities</h1><p className="text-sm text-slate-500 mt-1">Record crops grown each season and review your farm's activity timeline.</p></div>
    {error && <div role="alert" className="rounded-xl bg-rose-50 border border-rose-200 p-3 text-sm text-rose-700">{error}</div>}
    {loading ? <div className="rounded-xl bg-white p-8">Loading farms…</div> : farms.length === 0 ? <div className="rounded-2xl bg-white border border-dashed p-8 text-center"><Sprout className="mx-auto text-emerald-600"/><p className="mt-2 font-semibold">Add a farm before recording crop history.</p><button onClick={() => navigate('/farms')} className="mt-3 rounded-lg bg-emerald-600 text-white px-4 py-2">Open My Farms</button></div> : <>
      <div className="rounded-2xl bg-white border border-slate-200 p-4"><label className="text-xs font-bold text-slate-600">Select farm</label><select value={farmId} onChange={(e) => setFarmId(e.target.value)} className="mt-2 w-full md:max-w-md rounded-xl border border-slate-200 p-3 text-sm">{farms.map((f) => <option key={f.id} value={f.id}>{f.farm_name} — {f.district_id}</option>)}</select></div>
      <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-5 items-start"><form onSubmit={submit} className="rounded-2xl bg-white border border-slate-200 p-5 space-y-3"><div className="flex items-center gap-2 font-bold text-slate-900"><Plus className="w-4 h-4 text-emerald-600"/> Add crop record</div>
        <label className="block text-xs font-semibold text-slate-600">Crop name<input required maxLength={100} value={form.crop_name} onChange={(e) => setForm({...form,crop_name:e.target.value})} placeholder="e.g. Paddy" className="mt-1 w-full rounded-lg border p-2.5 text-sm"/></label>
        <div className="grid grid-cols-2 gap-3"><label className="text-xs font-semibold text-slate-600">Season<select value={form.season} onChange={(e) => setForm({...form,season:e.target.value})} className="mt-1 w-full rounded-lg border p-2.5 text-sm">{['Kharif','Rabi','Summer','Perennial'].map((x)=><option key={x}>{x}</option>)}</select></label><label className="text-xs font-semibold text-slate-600">Year<input type="number" min="2000" max="2100" value={form.crop_year} onChange={(e)=>setForm({...form,crop_year:Number(e.target.value)})} className="mt-1 w-full rounded-lg border p-2.5 text-sm"/></label></div>
        <div className="grid grid-cols-2 gap-3"><label className="text-xs font-semibold text-slate-600">Planting date<input type="date" value={form.planting_date} onChange={(e)=>setForm({...form,planting_date:e.target.value})} className="mt-1 w-full rounded-lg border p-2.5 text-sm"/></label><label className="text-xs font-semibold text-slate-600">Harvest date<input type="date" value={form.harvest_date} onChange={(e)=>setForm({...form,harvest_date:e.target.value})} className="mt-1 w-full rounded-lg border p-2.5 text-sm"/></label></div>
        <div className="grid grid-cols-2 gap-3"><label className="text-xs font-semibold text-slate-600">Yield (optional)<input type="number" min="0" step="any" value={form.yield_value} onChange={(e)=>setForm({...form,yield_value:e.target.value})} className="mt-1 w-full rounded-lg border p-2.5 text-sm"/></label><label className="text-xs font-semibold text-slate-600">Yield unit<input value={form.yield_unit} onChange={(e)=>setForm({...form,yield_unit:e.target.value})} className="mt-1 w-full rounded-lg border p-2.5 text-sm"/></label></div>
        <label className="block text-xs font-semibold text-slate-600">Notes<textarea rows={3} maxLength={2000} value={form.notes} onChange={(e)=>setForm({...form,notes:e.target.value})} className="mt-1 w-full rounded-lg border p-2.5 text-sm" placeholder="Irrigation, pest observations, inputs…"/></label>
        <button disabled={saving || !farmId} className="w-full rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold py-3 text-sm">{saving ? 'Saving…' : 'Save crop record'}</button></form>
        <section className="rounded-2xl bg-white border border-slate-200 p-5"><div className="flex items-center gap-2 font-bold"><ClipboardList className="w-4 h-4 text-emerald-600"/> Rotation history <span className="ml-auto text-xs text-slate-400">{records.length} records</span></div>{records.length===0 ? <p className="py-10 text-center text-sm text-slate-500">No crop history recorded for this farm yet.</p> : <div className="mt-4 space-y-3">{records.map((r)=><article key={r.id} className="rounded-xl border border-slate-200 p-3"><div className="flex items-start justify-between gap-2"><div><h3 className="font-bold text-slate-900">{r.crop_name}</h3><p className="text-xs text-emerald-700 font-semibold">{r.season} {r.crop_year}</p></div><button onClick={()=>void remove(r)} aria-label="Delete crop record" className="p-2 text-slate-400 hover:text-rose-600"><Trash2 className="w-4 h-4"/></button></div><p className="mt-2 text-xs text-slate-500">{r.planting_date || 'Planting date not recorded'} → {r.harvest_date || 'Harvest date not recorded'}{r.yield_value != null ? ` · Yield ${r.yield_value} ${r.yield_unit || ''}` : ''}</p>{r.notes && <p className="mt-2 text-sm text-slate-600">{r.notes}</p>}</article>)}</div>}</section></div>
      <section className="rounded-2xl bg-white border border-slate-200 p-5"><div className="flex items-center gap-2 font-bold"><History className="w-4 h-4 text-emerald-600"/> Farm activity timeline</div>{activity.length===0 ? <p className="mt-3 text-sm text-slate-500">No activities recorded yet.</p> : <ol className="mt-4 border-l-2 border-emerald-100 pl-4 space-y-4">{activity.map((a)=><li key={a.id}><p className="text-sm font-semibold text-slate-800">{a.description}</p><p className="text-[11px] text-slate-400 mt-1">{new Date(a.created_at).toLocaleString()}</p></li>)}</ol>}</section>
    </>}
  </main></div>;
};
