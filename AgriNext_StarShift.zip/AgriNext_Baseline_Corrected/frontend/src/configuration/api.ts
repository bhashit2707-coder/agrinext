/**
 * AgriNext Frontend Configuration.
 * Configures API target endpoints and default geographic settings.
 */

const configuredApiUrl = import.meta.env.VITE_API_URL?.trim();
if (import.meta.env.PROD && !configuredApiUrl) {
  throw new Error('VITE_API_URL must be configured for production builds.');
}
export const API_BASE_URL = configuredApiUrl || 'http://localhost:8000';

export const APP_CONFIG = {
  appName: 'AgriNext',
  subtitle: 'NASA-Powered Climate-Resilient Crop Rotation DSS',
  defaultState: 'andhra_pradesh',
  initialCoordinates: {
    lat: 15.9129,
    lng: 79.7400,
    zoom: 7
  },
  nasaDataSources: {
    power: 'NASA POWER Agroclimatology (Solar, Temp, RH, Rain)',
    smap: 'NASA SMAP (Surface Soil Moisture, 0–5 cm)',
    gpm: 'NASA GPM IMERG (High-Resolution Precipitation)'
  }
};
