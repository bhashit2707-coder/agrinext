import React from 'react';
import { NavigationProvider, useNavigation } from './context/NavigationContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { NotificationProvider } from './context/NotificationContext';
import { Dashboard } from './pages/Dashboard';
import { LoginPage } from './pages/LoginPage';
import { ProfilePage } from './pages/ProfilePage';
import { MyFarmsPage } from './pages/MyFarmsPage';
import { EarthObservationPage } from './pages/EarthObservationPage';
import { CropHistoryPage } from './pages/CropHistoryPage';
import { Header } from './components/Header';
import { AlertCircle, ArrowLeft } from 'lucide-react';

const AppRouter: React.FC = () => {
  const { currentRoute, navigate } = useNavigation();
  const { isAuthenticated } = useAuth();

  // If unauthenticated, the website starts with Step 1: Login (Enter Farmer Information)
  if (!isAuthenticated && (currentRoute === '/' || currentRoute === '/dashboard')) {
    return <LoginPage />;
  }

  switch (currentRoute) {
    case '/':
    case '/dashboard':
      return <Dashboard />;

    case '/login':
      return <LoginPage />;

    case '/profile':
      return isAuthenticated ? <ProfilePage /> : <LoginPage />;

    case '/farms':
      return isAuthenticated ? <MyFarmsPage /> : <LoginPage />;

    case '/earth-observation':
      return isAuthenticated ? <EarthObservationPage /> : <LoginPage />;

    case '/rotation-history':
      return isAuthenticated ? <CropHistoryPage /> : <LoginPage />;

    default:
      return (
        <div className="min-h-screen bg-slate-100/70 flex flex-col font-sans">
          <Header currentRoute="/" />
          <main className="flex-1 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl border border-slate-200/90 shadow-lg p-8 max-w-md w-full text-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold text-slate-800">Page Not Found</h2>
              <p className="text-xs text-slate-500">
                The requested URL route does not exist in the AgriNext Decision Support System.
              </p>
              <button
                type="button"
                onClick={() => navigate('/')}
                className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors shadow-sm"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Home</span>
              </button>
            </div>
          </main>
        </div>
      );
  }
};

export function App() {
  return (
    <NotificationProvider>
      <NavigationProvider>
        <AuthProvider>
          <AppRouter />
        </AuthProvider>
      </NavigationProvider>
    </NotificationProvider>
  );
}

export default App;
