import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from 'recharts';
import {
  Satellite,
  CloudRain,
  Thermometer,
  Sun,
  Wind,
  ShieldCheck,
  RefreshCw,
  Info,
  AlertCircle
} from 'lucide-react';
import { apiService } from '../services/api';
import type { NASAPowerResponse, FarmProfile } from '../types';

interface NASAPowerModuleProps {
  activeFarm: FarmProfile | null;
  defaultCoords: { lat: number; lng: number };
  onEvidenceLoaded?: (evidence: NASAPowerResponse['evidence_objects']) => void;
}

export const NASAPowerModule: React.FC<NASAPowerModuleProps> = ({
  activeFarm,
  defaultCoords,
  onEvidenceLoaded
}) => {
  const [data, setData] = useState<NASAPowerResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'rainfall' | 'temperature' | 'solar' | 'humidity' | 'evidence'>('rainfall');

  const targetCoords = activeFarm
    ? { lat: activeFarm.latitude, lng: activeFarm.longitude }
    : defaultCoords;

  const handleFetchData = async (forceRefresh: boolean = false) => {
    setLoading(true);
    setError(null);
    try {
      const response = await apiService.queryNASAPower({
        latitude: targetCoords.lat,
        longitude: targetCoords.lng,
        farm_id: activeFarm?.id,
        use_cache: !forceRefresh
      });
      setData(response);
      if (onEvidenceLoaded && response.evidence_objects) {
        onEvidenceLoaded(response.evidence_objects);
      }
    } catch (err: any) {
      console.error('NASA POWER API error:', err);
      setError(err.message || 'Failed to retrieve NASA POWER agroclimatology data.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-5">
      {/* Module Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-cyan-100 text-cyan-800">
              Step 4
            </span>
            <h2 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
              <Satellite className="w-5 h-5 text-cyan-600" />
              <span>NASA POWER Agroclimatology Observations</span>
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real multi-year Earth observation dataset queried dynamically for the farm centroid.
          </p>
        </div>

        {/* Action Button & Coords Pill */}
        <div className="flex items-center space-x-3">
          <div className="bg-slate-100 px-3 py-1.5 rounded-xl text-xs font-mono text-slate-600 border border-slate-200">
            Centroid: <b className="text-slate-900">{targetCoords.lat.toFixed(4)}°N, {targetCoords.lng.toFixed(4)}°E</b>
          </div>

          <button
            type="button"
            onClick={() => handleFetchData(false)}
            disabled={loading}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 disabled:opacity-50 text-white font-bold text-xs flex items-center space-x-2 transition-all shadow-md shadow-cyan-900/20"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? 'Querying NASA API...' : data ? 'Refresh NASA Data' : 'Fetch NASA Observations'}</span>
          </button>
        </div>
      </div>

      {/* Scientific Transparency Notice */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs text-slate-600 flex items-start space-x-3">
        <Info className="w-4 h-4 text-cyan-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-slate-800">
            Scientific Provenance & Grid Resolution Transparency:
          </p>
          <p className="text-[11px] leading-relaxed text-slate-500">
            NASA POWER is a global gridded agroclimatological product, not an on-farm sensor.
            Meteorological parameters (rain, temperature, humidity, wind) derive from the <b>GMAO MERRA-2</b> assimilation model (0.5° grid ~50 km).
            Solar radiation derives from <b>NASA CERES / FLASHFlux</b> satellite radiometers (1.0° grid ~100 km).
            This multi-year baseline provides statistical evidence for crop rotation resilience, not a 10-day weather forecast.
          </p>
        </div>
      </div>

      {/* Error Banner */}
      {error && (
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 text-xs text-rose-800 flex items-start space-x-3">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">NASA POWER API Notice</p>
            <p className="mt-0.5">{error}</p>
            <p className="text-[11px] text-rose-600 mt-1">
              Rule Adherence: AgriNext never replaces a failed request with fake NASA values.
            </p>
          </div>
        </div>
      )}

      {/* Initial Empty State prompt */}
      {!data && !loading && !error && (
        <div className="text-center py-12 px-4 border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50/50 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-cyan-50 border border-cyan-200 text-cyan-600 flex items-center justify-center mx-auto">
            <Satellite className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800">Ready to Query NASA Earth Observations</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
              Click <b>"Fetch NASA Observations"</b> above to retrieve 3 full years of real solar radiation, rainfall, temperatures, and relative humidity for this farm location.
            </p>
          </div>
        </div>
      )}

      {/* Loaded Dataset View */}
      {data && (
        <div className="space-y-5">
          {/* Provenance & Cache Status Pill */}
          <div className="flex flex-wrap items-center justify-between text-xs bg-slate-900 text-slate-200 px-4 py-2.5 rounded-xl border border-slate-800 gap-2">
            <div className="flex items-center space-x-3">
              <span className="flex items-center space-x-1.5 text-cyan-400 font-semibold">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Verified NASA POWER API Response</span>
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">
                Period: <b className="text-white">{data.observation_period.start_date}</b> to <b className="text-white">{data.observation_period.end_date}</b> ({data.observation_period.total_days} days)
              </span>
            </div>

            <div className="flex items-center space-x-2 text-[11px]">
              <span className={`px-2 py-0.5 rounded font-mono font-semibold ${data.provenance.cache_hit ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-cyan-950 text-cyan-300 border border-cyan-800'}`}>
                {data.provenance.cache_hit ? 'SQLite Cache Hit' : 'Live NASA HTTP 200'}
              </span>
              {data.farm_centroid.elevation_meters && (
                <span className="text-slate-400">
                  Elevation: <b className="text-slate-200">{data.farm_centroid.elevation_meters} m</b>
                </span>
              )}
            </div>
          </div>

          {/* Quick Indicator KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {data.evidence_objects.slice(0, 4).map((ev) => (
              <div key={ev.evidence_id} className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/60">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block truncate">
                  {ev.parameter_name}
                </span>
                <div className="flex items-baseline space-x-1.5 mt-1">
                  <span className="text-xl font-extrabold text-slate-900">{ev.actual_value}</span>
                  <span className="text-xs font-semibold text-cyan-700">{ev.unit}</span>
                </div>
                <span className="text-[10px] text-slate-400 block mt-1">
                  Res: {ev.spatial_resolution.split(' ')[0]}
                </span>
              </div>
            ))}
          </div>

          {/* Chart Controls Tabs */}
          <div className="flex flex-wrap items-center justify-between border-b border-slate-200 gap-2">
            <div className="flex space-x-1 overflow-x-auto pb-2">
              <button
                type="button"
                onClick={() => setActiveTab('rainfall')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                  activeTab === 'rainfall'
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <CloudRain className="w-3.5 h-3.5" />
                <span>Precipitation (Rainfall)</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('temperature')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                  activeTab === 'temperature'
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Thermometer className="w-3.5 h-3.5" />
                <span>Temperature Profile</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('solar')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                  activeTab === 'solar'
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Sun className="w-3.5 h-3.5" />
                <span>Solar Radiation</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('humidity')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                  activeTab === 'humidity'
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Wind className="w-3.5 h-3.5" />
                <span>Humidity & Wind</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('evidence')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                  activeTab === 'evidence'
                    ? 'bg-emerald-700 text-white shadow-sm'
                    : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Evidence Dossier ({data.evidence_objects.length})</span>
              </button>
            </div>

            <span className="text-[11px] text-slate-400 pb-2">
              Showing 36 Monthly Aggregates (2021–2023)
            </span>
          </div>

          {/* Tab 1: Precipitation Bar Chart */}
          {activeTab === 'rainfall' && (
            <div className="space-y-3">
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.monthly_summaries}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis
                      dataKey="year_month"
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      tickFormatter={(val: string) => val.slice(2)}
                    />
                    <YAxis
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      unit=" mm"
                    />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px', color: '#fff' }}
                      formatter={(value: any) => [`${value} mm`, 'Monthly Total Rainfall']}
                      labelFormatter={(label: any) => `Month: ${label}`}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                    <Bar
                      dataKey="total_precipitation_mm"
                      name="Monthly Rainfall (mm)"
                      fill="#0284c7"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[11px] text-slate-500 text-center">
                Precipitation data source: NASA GMAO MERRA-2 Reanalysis (0.5° grid). Highlights monsoon peaks (Jun-Sep Kharif and Oct-Nov North-East retreat).
              </p>
            </div>
          )}

          {/* Tab 2: Temperature Regimes Chart */}
          {activeTab === 'temperature' && (
            <div className="space-y-3">
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.monthly_summaries}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis
                      dataKey="year_month"
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      tickFormatter={(val: string) => val.slice(2)}
                    />
                    <YAxis
                      domain={[10, 45]}
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      unit="°C"
                    />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px', color: '#fff' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                    <Line
                      type="monotone"
                      dataKey="max_temperature_c"
                      name="Max Temp (°C)"
                      stroke="#ef4444"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="avg_temperature_c"
                      name="Mean Temp (°C)"
                      stroke="#f59e0b"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="min_temperature_c"
                      name="Min Temp (°C)"
                      stroke="#3b82f6"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[11px] text-slate-500 text-center">
                Temperature profile at 2 meters (MERRA-2). Crucial for identifying heat stress thresholds (&gt;38°C) and chill sensitivity in Rabi rotations.
              </p>
            </div>
          )}

          {/* Tab 3: Solar Radiation Chart */}
          {activeTab === 'solar' && (
            <div className="space-y-3">
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.monthly_summaries}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis
                      dataKey="year_month"
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      tickFormatter={(val: string) => val.slice(2)}
                    />
                    <YAxis
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      unit=" MJ"
                    />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px', color: '#fff' }}
                      formatter={(val: any) => [`${val} MJ/m²/day`, 'Solar Insolation']}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                    <Line
                      type="monotone"
                      dataKey="avg_solar_radiation_mj"
                      name="Daily Solar Irradiance (MJ/m²/day)"
                      stroke="#eab308"
                      strokeWidth={2.5}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[11px] text-slate-500 text-center">
                Direct satellite observation: NASA CERES & FLASHFlux radiometers (1.0° grid). Measures Photosynthetically Active Radiation driving crop photosynthesis.
              </p>
            </div>
          )}

          {/* Tab 4: Humidity & Wind Chart */}
          {activeTab === 'humidity' && (
            <div className="space-y-3">
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.monthly_summaries}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis
                      dataKey="year_month"
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      tickFormatter={(val: string) => val.slice(2)}
                    />
                    <YAxis
                      yAxisId="left"
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      unit="%"
                      domain={[30, 90]}
                    />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      unit=" m/s"
                      domain={[0, 10]}
                    />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px', color: '#fff' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey="avg_relative_humidity"
                      name="Relative Humidity (%)"
                      stroke="#06b6d4"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="avg_wind_speed_ms"
                      name="Wind Speed (m/s)"
                      stroke="#8b5cf6"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[11px] text-slate-500 text-center">
                Atmospheric evaporative demand: High relative humidity combined with warmth triggers fungal blast/blight alerts in paddy and groundnut.
              </p>
            </div>
          )}

          {/* Tab 5: Formal Environmental Evidence Dossier Table */}
          {activeTab === 'evidence' && (
            <div className="space-y-3">
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Indicator</th>
                      <th className="py-2.5 px-3">Observed Value</th>
                      <th className="py-2.5 px-3">Underlying Source</th>
                      <th className="py-2.5 px-3">Resolution</th>
                      <th className="py-2.5 px-3">Missing Data</th>
                      <th className="py-2.5 px-3">Agronomic Impact</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white">
                    {data.evidence_objects.map((ev) => (
                      <tr key={ev.evidence_id} className="hover:bg-slate-50/70">
                        <td className="py-2.5 px-3 font-bold text-slate-800">
                          {ev.parameter_name}
                          <span className="block font-mono text-[10px] text-slate-400 font-normal">
                            {ev.parameter_code}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono font-bold text-emerald-700">
                          {ev.actual_value} {ev.unit}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600 text-[11px]">
                          {ev.underlying_source_product}
                          <span className="block text-[10px] text-slate-400">
                            {ev.is_direct_satellite_observation ? 'Direct Satellite Radiometer' : 'Assimilated Reanalysis'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-600 text-[11px]">
                          {ev.spatial_resolution}
                        </td>
                        <td className="py-2.5 px-3 text-[11px]">
                          <span className="text-emerald-700 font-medium">
                            {ev.missing_data_info.missing_percentage}% ({ev.missing_data_info.missing_count}/{ev.missing_data_info.total_count})
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-600 text-[11px] max-w-xs">
                          {ev.agronomic_significance}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs flex items-center justify-between">
                <span className="font-semibold">
                  ✓ 5 Traceable Evidence Objects successfully formatted & passed to AgriNext Recommendation Engine.
                </span>
                <span className="font-mono text-[11px] text-emerald-700">
                  Audit URL: {data.provenance.endpoint_url}
                </span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
