import React, { useState } from 'react';
import {
  Cpu,
  ShieldCheck,
  AlertTriangle,
  Droplets,
  Sun,
  RefreshCw,
  Sparkles,
  Layers,
  ChevronDown,
  ChevronUp,
  TestTube2,
  BookOpen,
  Sliders,
  FileText,
  FileDown,
  Columns
} from 'lucide-react';
import { apiService } from '../services/api';
import { RotationComparisonView } from './RotationComparisonView';
import { PDFReportModal } from './PDFReportModal';
import type {
  UnifiedEvidenceDossier,
  RecommendationResponse,
  FarmProfile,
  FarmerProfile
} from '../types';

interface UnifiedEvidenceModuleProps {
  activeFarm: FarmProfile | null;
  defaultCoords: { lat: number; lng: number };
  farmerProfile?: FarmerProfile | null;
  onDossierLoaded?: (dossier: UnifiedEvidenceDossier) => void;
  onWeightsChanged?: (weights: { water: number; soil: number; climate: number; local: number }) => void;
}

const formatObservationPeriod = (period: any): string => {
  if (!period) return '';
  if (typeof period === 'string') return period;
  if (typeof period === 'object') {
    if (period.start_date && period.end_date) {
      const days = period.total_days_sampled ? ` (${period.total_days_sampled} days)` : '';
      return `${period.start_date} to ${period.end_date}${days}`;
    }
    try {
      return JSON.stringify(period);
    } catch {
      return '';
    }
  }
  return String(period);
};

const renderEvidenceItem = (ev: any, i: number) => {
  if (!ev) return null;
  if (typeof ev === 'string') {
    return <div key={i} className="text-slate-600">• {ev}</div>;
  }
  const periodStr = formatObservationPeriod(ev.observation_period);
  return (
    <div key={i} className="text-slate-600">
      • <b>{ev.source || 'Observation'}:</b> {ev.parameter || ''}
      {ev.observed_value !== undefined && ev.observed_value !== null && (
        <> = <span className="font-mono text-slate-800 font-bold">{ev.observed_value} {ev.unit || ''}</span></>
      )}
      {periodStr && <span className="text-slate-500"> ({periodStr})</span>}
    </div>
  );
};

export const UnifiedEvidenceModule: React.FC<UnifiedEvidenceModuleProps> = ({
  activeFarm,
  defaultCoords,
  farmerProfile,
  onDossierLoaded,
  onWeightsChanged
}) => {
  const [dossier, setDossier] = useState<UnifiedEvidenceDossier | null>(null);
  const [recommendations, setRecommendations] = useState<RecommendationResponse | null>(null);
  const [loadingDossier, setLoadingDossier] = useState<boolean>(false);
  const [loadingRecs, setLoadingRecs] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedTraceStrategyId, setExpandedTraceStrategyId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'comparison' | 'cards'>('comparison');
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);

  // User-customizable multi-criteria weights (must total 100)
  const [weights, setWeights] = useState<{ water: number; soil: number; climate: number; local: number }>({
    water: 25,
    soil: 25,
    climate: 25,
    local: 25
  });

  const baselineWeights = { water: 25, soil: 25, climate: 25, local: 25 };

  const targetCoords = activeFarm
    ? { lat: activeFarm.latitude, lng: activeFarm.longitude }
    : defaultCoords;

  // Immediate recalculation using exact mathematical formula:
  // Overall = (Water * Water_Weight + Soil * Soil_Weight + Climate * Climate_Weight + Local * Local_Weight) / 100
  const triggerImmediateRecalculation = async (newWeights: { water: number; soil: number; climate: number; local: number }) => {
    if (!recommendations || recommendations.strategies.length === 0) return;

    // 1. Instant client-side recalculation (zero lag)
    const updatedStrategies = recommendations.strategies.map((strat) => {
      const scores = strat.individual_scores || {
        water_suitability: 75,
        soil_health_potential: 75,
        climate_suitability: 75,
        local_agricultural_suitability: 75
      };

      const bScore = strat.baseline_score !== undefined
        ? strat.baseline_score
        : Math.round(
            ((scores.water_suitability * baselineWeights.water) +
             (scores.soil_health_potential * baselineWeights.soil) +
             (scores.climate_suitability * baselineWeights.climate) +
             (scores.local_agricultural_suitability * baselineWeights.local)) / 10
          ) / 10;

      const uScore = Math.round(
        ((scores.water_suitability * newWeights.water) +
         (scores.soil_health_potential * newWeights.soil) +
         (scores.climate_suitability * newWeights.climate) +
         (scores.local_agricultural_suitability * newWeights.local)) / 10
      ) / 10;

      return {
        ...strat,
        baseline_score: bScore,
        overall_score: uScore,
        weights: newWeights
      };
    });

    // Compute baseline ranks
    const byBaseline = [...updatedStrategies].sort((a, b) => (b.baseline_score ?? 0) - (a.baseline_score ?? 0));
    byBaseline.forEach((s, idx) => {
      s.baseline_rank = idx + 1;
    });

    // Reorder strategies immediately by descending updated score (Requirement 4)
    const sorted = [...updatedStrategies].sort((a, b) => b.overall_score - a.overall_score);
    sorted.forEach((s, idx) => {
      const uRank = idx + 1;
      const bRank = s.baseline_rank ?? uRank;
      s.updated_rank = uRank;
      s.current_rank = uRank;
      s.rank_change = bRank - uRank;
      s.movement_direction = s.rank_change > 0 ? 'up' : s.rank_change < 0 ? 'down' : 'unchanged';

      const diff = (s.overall_score - (s.baseline_score ?? s.overall_score)).toFixed(1);
      const sign = parseFloat(diff) >= 0 ? '+' : '';

      if (s.rank_change > 0) {
        s.movement_explanation = `Promoted from Rank #${bRank} to Rank #${uRank} (${sign}${diff} pts): Shift in farmer priorities favored its strongest dimensions (${Math.max(
          s.individual_scores.water_suitability,
          s.individual_scores.soil_health_potential,
          s.individual_scores.climate_suitability,
          s.individual_scores.local_agricultural_suitability
        )}/100).`;
      } else if (s.rank_change < 0) {
        s.movement_explanation = `Shifted from Rank #${bRank} to Rank #${uRank} (${sign}${diff} pts): Reduced weight on its core advantage allowed alternative rotations to advance.`;
      } else {
        s.movement_explanation = uRank === 1
          ? `Maintained top ranking (#1, ${s.overall_score.toFixed(1)}/100): Balanced high scores keep this sequence at the top of the leaderboard.`
          : `Maintained Rank #${uRank} (${s.overall_score.toFixed(1)}/100): Consistent performance keeps this rotation stable under current priorities.`;
      }
    });

    setRecommendations((prev) => (prev ? {
      ...prev,
      strategies: sorted,
      applied_weights: newWeights
    } : null));

    // 2. Call backend endpoint to synchronize full evidence traces and verified agronomic explanations
    try {
      const resp = await apiService.recalculateScores({
        strategies: recommendations.strategies,
        weights: newWeights,
        baseline_weights: baselineWeights
      });
      if (resp && resp.strategies) {
        setRecommendations((prev) => (prev ? {
          ...prev,
          strategies: resp.strategies,
          applied_weights: resp.applied_weights,
          baseline_weights: resp.baseline_weights,
          ranking_comparison: resp.ranking_comparison
        } : null));
      }
    } catch (recalcErr) {
      console.warn('Backend recalculation sync note:', recalcErr);
    }
  };

  const handleWeightChange = (key: 'water' | 'soil' | 'climate' | 'local', val: number) => {
    const newWeights = { ...weights, [key]: val };
    setWeights(newWeights);
    onWeightsChanged?.(newWeights);
    const sum = newWeights.water + newWeights.soil + newWeights.climate + newWeights.local;
    if (sum === 100) {
      triggerImmediateRecalculation(newWeights);
    }
  };

  const applyPreset = (presetWeights: { water: number; soil: number; climate: number; local: number }) => {
    setWeights(presetWeights);
    onWeightsChanged?.(presetWeights);
    triggerImmediateRecalculation(presetWeights);
  };

  const autoBalanceWeights = () => {
    const total = weights.water + weights.soil + weights.climate + weights.local;
    if (total === 0) {
      applyPreset({ water: 25, soil: 25, climate: 25, local: 25 });
      return;
    }
    const factor = 100 / total;
    const w = Math.round(weights.water * factor);
    const s = Math.round(weights.soil * factor);
    const c = Math.round(weights.climate * factor);
    const l = 100 - (w + s + c);
    applyPreset({ water: w, soil: s, climate: c, local: l });
  };

  const resetWeights = () => {
    applyPreset({ water: 25, soil: 25, climate: 25, local: 25 });
  };

  const handleAssembleDossier = async () => {
    setLoadingDossier(true);
    setError(null);
    try {
      const response = await apiService.getUnifiedEvidence({
        latitude: targetCoords.lat,
        longitude: targetCoords.lng,
        farm_id: activeFarm?.id,
        use_cache: true,
        farmer_profile: farmerProfile || undefined
      });
      setDossier(response);
      onDossierLoaded?.(response);
    } catch (err: any) {
      console.error('Unified evidence assembly error:', err);
      setError(err.message || 'Failed to assemble unified environmental evidence dossier.');
    } finally {
      setLoadingDossier(false);
    }
  };

  const handleGenerateRecommendations = async () => {
    setLoadingRecs(true);
    setError(null);
    try {
      const recs = await apiService.generateRecommendations({
        state_id: activeFarm?.state_id || 'andhra_pradesh',
        latitude: targetCoords.lat,
        longitude: targetCoords.lng,
        farm_id: activeFarm?.id,
        use_cache: true,
        farmer_profile: farmerProfile || undefined,
        weights: weights,
        include_geospatial_context: true
      });
      setRecommendations(recs);
      if (recs.strategies.length > 0 && !expandedTraceStrategyId) {
        setExpandedTraceStrategyId(recs.strategies[0].id);
      }
    } catch (err: any) {
      console.error('Recommendation generation error:', err);
      setError(err.message || 'Failed to generate evidence-backed recommendations.');
    } finally {
      setLoadingRecs(false);
    }
  };

  // Helper to format evidence citations with distinct visual tags
  const renderCitationPill = (cite: string, index: number) => {
    let tag = 'Evidence';
    let tagColor = 'bg-slate-100 text-slate-700 border-slate-200';
    let cleanText = cite;

    if (cite.startsWith('[NASA Observation]')) {
      tag = 'NASA Satellite';
      tagColor = 'bg-blue-50 text-blue-800 border-blue-200';
      cleanText = cite.replace('[NASA Observation]', '').trim();
    } else if (cite.startsWith('[Farmer Ground-Truth Soil]')) {
      tag = 'Farmer Ground-Truth';
      tagColor = 'bg-amber-50 text-amber-800 border-amber-200';
      cleanText = cite.replace('[Farmer Ground-Truth Soil]', '').trim();
    } else if (cite.startsWith('[ANGRAU Crop Knowledge]')) {
      tag = 'ANGRAU Agronomy';
      tagColor = 'bg-emerald-50 text-emerald-800 border-emerald-200';
      cleanText = cite.replace('[ANGRAU Crop Knowledge]', '').trim();
    }

    return (
      <div key={index} className="flex items-start space-x-2 text-[11px] leading-tight">
        <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold shrink-0 border uppercase tracking-wider ${tagColor}`}>
          {tag}
        </span>
        <span className="text-slate-700">{cleanText}</span>
      </div>
    );
  };

  const totalWeights = weights.water + weights.soil + weights.climate + weights.local;

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-6">
      {/* Module Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800">
              Core Engine
            </span>
            <h2 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
              <Cpu className="w-5 h-5 text-purple-600" />
              <span>Evidence-Based Crop Rotation Recommendation Engine</span>
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Synthesizes NASA Earth observation evidence, farmer soil ground truth, ANGRAU crop calendars, and priority weights into 3 distinct strategies.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-3">
          <button
            type="button"
            onClick={handleAssembleDossier}
            disabled={loadingDossier}
            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center space-x-2 transition-all border border-slate-200"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingDossier ? 'animate-spin' : ''}`} />
            <span>{loadingDossier ? 'Synthesizing...' : 'Assemble Evidence Dossier'}</span>
          </button>

          <button
            type="button"
            onClick={handleGenerateRecommendations}
            disabled={loadingRecs}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-bold text-xs flex items-center space-x-2 transition-all shadow-md shadow-purple-900/20"
          >
            <Sparkles className={`w-3.5 h-3.5 ${loadingRecs ? 'animate-spin' : ''}`} />
            <span>{loadingRecs ? 'Computing Recommendations...' : 'Generate 3 Strategies'}</span>
          </button>
        </div>
      </div>

      {/* Tri-Partite Scientific Provenance Banner */}
      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-600 space-y-2">
        <div className="flex items-start space-x-2">
          <ShieldCheck className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="font-semibold text-slate-800">Critical Evidence Rule: </span>
            Every suitability score is mathematically traceable to verified observations. NASA Earth observations directly influence the relevant dimensions without arbitrary jumps.
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 pt-1 text-[11px]">
          <div className="p-2 bg-blue-50/70 rounded-lg border border-blue-200">
            <span className="font-bold text-blue-900 block">1. NASA Earth Observations</span>
            <span className="text-blue-800">Regional climate: POWER (precip, temp, humidity, solar), SMAP (soil moisture), GPM (satellite rain).</span>
          </div>
          <div className="p-2 bg-amber-50/70 rounded-lg border border-amber-200">
            <span className="font-bold text-amber-900 block">2. Farmer Ground-Truth Soil</span>
            <span className="text-amber-800">Parcel soil type, pH, NPK, OC, and irrigation (Soil Health Card portal & farmer measured). NASA does not measure soil fertility.</span>
          </div>
          <div className="p-2 bg-emerald-50/70 rounded-lg border border-emerald-200">
            <span className="font-bold text-emerald-950 block">3. ANGRAU Crop Knowledge</span>
            <span className="text-emerald-800">Official Package of Practices 2023-24: Biological N-fixation (+35 kg/ha), critical thermal limits, pest cycle breaks.</span>
          </div>
        </div>
      </div>

      {/* Multi-Attribute Priority Weights Controls */}
      <div className="p-4 rounded-xl bg-slate-50/90 border border-slate-200/80 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-purple-600" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
              Farmer Priority Weights (Must Total 100)
            </h3>
          </div>
          <div className="flex items-center space-x-2">
            <span
              className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                totalWeights === 100
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-red-100 text-red-800 border border-red-300'
              }`}
            >
              Sum: {totalWeights} / 100
            </span>
            {totalWeights !== 100 && (
              <button
                type="button"
                onClick={autoBalanceWeights}
                className="text-[11px] bg-purple-100 text-purple-800 hover:bg-purple-200 px-2 py-0.5 rounded font-bold transition-all cursor-pointer"
              >
                Auto-Balance to 100
              </button>
            )}
            <button
              type="button"
              onClick={resetWeights}
              className="text-[11px] text-purple-700 hover:underline font-semibold cursor-pointer"
            >
              Reset (25% Each)
            </button>
          </div>
        </div>

        {/* Priority Strategy Presets Bar */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mr-1">
            Quick Presets:
          </span>
          <button
            type="button"
            onClick={() => applyPreset({ water: 25, soil: 25, climate: 25, local: 25 })}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
              weights.water === 25 && weights.soil === 25 && weights.climate === 25 && weights.local === 25
                ? 'bg-purple-700 text-white border-purple-700 shadow-2xs'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Equal Balanced (25/25/25/25)
          </button>
          <button
            type="button"
            onClick={() => applyPreset({ water: 45, soil: 20, climate: 20, local: 15 })}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
              weights.water === 45 && weights.soil === 20 && weights.climate === 20 && weights.local === 15
                ? 'bg-blue-700 text-white border-blue-700 shadow-2xs'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50'
            }`}
          >
            💧 Water Efficiency Focus (45/20/20/15)
          </button>
          <button
            type="button"
            onClick={() => applyPreset({ water: 15, soil: 55, climate: 15, local: 15 })}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
              weights.water === 15 && weights.soil === 55 && weights.climate === 15 && weights.local === 15
                ? 'bg-amber-700 text-white border-amber-700 shadow-2xs'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-amber-50'
            }`}
          >
            🌱 Soil-Health Regeneration (15/55/15/15)
          </button>
          <button
            type="button"
            onClick={() => applyPreset({ water: 35, soil: 15, climate: 35, local: 15 })}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
              weights.water === 35 && weights.soil === 15 && weights.climate === 35 && weights.local === 15
                ? 'bg-purple-800 text-white border-purple-800 shadow-2xs'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-purple-50'
            }`}
          >
            ☀️ Climate Resilience (35/15/35/15)
          </button>
          <button
            type="button"
            onClick={() => applyPreset({ water: 20, soil: 20, climate: 20, local: 40 })}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
              weights.water === 20 && weights.soil === 20 && weights.climate === 20 && weights.local === 40
                ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-emerald-50'
            }`}
          >
            🌾 Local Agronomy (20/20/20/40)
          </button>
        </div>

        {/* 4 Interactive Sliders with Numeric Input */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-1">
          {/* Water Weight */}
          <div className="p-2.5 bg-white rounded-lg border border-slate-200 space-y-1 shadow-2xs">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-blue-800 flex items-center space-x-1">
                <Droplets className="w-3.5 h-3.5 text-blue-600" />
                <span>Water Efficiency</span>
              </span>
              <div className="flex items-center space-x-1">
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={weights.water}
                  onChange={(e) => handleWeightChange('water', Math.max(0, Math.min(100, parseInt(e.target.value) || 0)))}
                  className="w-12 text-right font-mono font-bold text-xs bg-slate-50 border border-slate-200 rounded px-1 py-0.5"
                />
                <span className="font-mono text-xs font-bold text-slate-600">%</span>
              </div>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={weights.water}
              onChange={(e) => handleWeightChange('water', parseInt(e.target.value) || 0)}
              className="w-full accent-blue-600 cursor-pointer"
            />
          </div>

          {/* Soil Weight */}
          <div className="p-2.5 bg-white rounded-lg border border-slate-200 space-y-1 shadow-2xs">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-amber-800 flex items-center space-x-1">
                <TestTube2 className="w-3.5 h-3.5 text-amber-600" />
                <span>Soil-Health Potential</span>
              </span>
              <div className="flex items-center space-x-1">
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={weights.soil}
                  onChange={(e) => handleWeightChange('soil', Math.max(0, Math.min(100, parseInt(e.target.value) || 0)))}
                  className="w-12 text-right font-mono font-bold text-xs bg-slate-50 border border-slate-200 rounded px-1 py-0.5"
                />
                <span className="font-mono text-xs font-bold text-slate-600">%</span>
              </div>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={weights.soil}
              onChange={(e) => handleWeightChange('soil', parseInt(e.target.value) || 0)}
              className="w-full accent-amber-600 cursor-pointer"
            />
          </div>

          {/* Climate Weight */}
          <div className="p-2.5 bg-white rounded-lg border border-slate-200 space-y-1 shadow-2xs">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-purple-800 flex items-center space-x-1">
                <Sun className="w-3.5 h-3.5 text-purple-600" />
                <span>Climate Resilience</span>
              </span>
              <div className="flex items-center space-x-1">
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={weights.climate}
                  onChange={(e) => handleWeightChange('climate', Math.max(0, Math.min(100, parseInt(e.target.value) || 0)))}
                  className="w-12 text-right font-mono font-bold text-xs bg-slate-50 border border-slate-200 rounded px-1 py-0.5"
                />
                <span className="font-mono text-xs font-bold text-slate-600">%</span>
              </div>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={weights.climate}
              onChange={(e) => handleWeightChange('climate', parseInt(e.target.value) || 0)}
              className="w-full accent-purple-600 cursor-pointer"
            />
          </div>

          {/* Local Agronomy Weight */}
          <div className="p-2.5 bg-white rounded-lg border border-slate-200 space-y-1 shadow-2xs">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-emerald-800 flex items-center space-x-1">
                <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                <span>Local Agronomy</span>
              </span>
              <div className="flex items-center space-x-1">
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={weights.local}
                  onChange={(e) => handleWeightChange('local', Math.max(0, Math.min(100, parseInt(e.target.value) || 0)))}
                  className="w-12 text-right font-mono font-bold text-xs bg-slate-50 border border-slate-200 rounded px-1 py-0.5"
                />
                <span className="font-mono text-xs font-bold text-slate-600">%</span>
              </div>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={weights.local}
              onChange={(e) => handleWeightChange('local', parseInt(e.target.value) || 0)}
              className="w-full accent-emerald-600 cursor-pointer"
            />
          </div>
        </div>

        <div className="flex items-center justify-between text-[11px] pt-1">
          <p className="text-slate-500 italic">
            Mathematical Formula: Overall = (Water × {weights.water}% + Soil × {weights.soil}% + Climate × {weights.climate}% + Local × {weights.local}%) / 100
          </p>
          {recommendations && (
            <span className="text-purple-700 font-semibold flex items-center space-x-1">
              <Sparkles className="w-3 h-3 text-purple-600" />
              <span>Scores and rankings recalculate immediately as weights change</span>
            </span>
          )}
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs">
          <b>Error:</b> {error}
        </div>
      )}

      {/* Unified Dossier Summary */}
      {dossier && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3.5">
            {/* POWER Status */}
            <div className="p-3.5 rounded-xl border border-cyan-100 bg-cyan-50/40">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-cyan-900">NASA POWER</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  {dossier.dataset_status.nasa_power.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">Grid: {dossier.dataset_status.nasa_power.grid_resolution}</p>
              <p className="text-xs font-mono mt-1 text-slate-700">{dossier.dataset_status.nasa_power.evidence_count} evidence parameters</p>
            </div>

            {/* SMAP Status */}
            <div className="p-3.5 rounded-xl border border-amber-100 bg-amber-50/40">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-amber-900">NASA SMAP V6</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${dossier.dataset_status.nasa_smap.connected ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                  {dossier.dataset_status.nasa_smap.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">Grid: {dossier.dataset_status.nasa_smap.grid_resolution}</p>
              <p className="text-xs font-mono mt-1 text-slate-700">
                {dossier.dataset_status.nasa_smap.connected ? 'Surface soil moisture (0-5cm)' : 'Requires Earthdata Login'}
              </p>
            </div>

            {/* GPM Status */}
            <div className="p-3.5 rounded-xl border border-blue-100 bg-blue-50/40">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-blue-900">NASA GPM IMERG</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${dossier.dataset_status.nasa_gpm.connected ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'}`}>
                  {dossier.dataset_status.nasa_gpm.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">Grid: {dossier.dataset_status.nasa_gpm.grid_resolution}</p>
              <p className="text-xs font-mono mt-1 text-slate-700">
                {dossier.dataset_status.nasa_gpm.connected ? 'Satellite precipitation' : 'Requires Earthdata Login'}
              </p>
            </div>

            {/* Farmer Ground-Truth Status */}
            <div className="p-3.5 rounded-xl border border-amber-200 bg-amber-50/50">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-amber-950 flex items-center space-x-1">
                  <TestTube2 className="w-3.5 h-3.5 text-amber-700" />
                  <span>Ground-Truth Soil</span>
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                  {farmerProfile ? 'Connected' : 'Baseline'}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 font-semibold truncate">
                {farmerProfile?.soil_type || 'Red Sandy Loam (AP Default)'}
              </p>
              <p className="text-xs font-mono mt-1 text-slate-700">
                pH {farmerProfile?.soil_ph ?? '6.8'} • {farmerProfile?.irrigation_source || 'Rainfed'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 3 Distinct Evidence-Backed Rotation Strategies Output */}
      {recommendations && (
        <div className="space-y-6 pt-3 border-t border-slate-100">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <span>Three Distinct Evidence-Backed Crop Rotation Strategies</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Each strategy calculates transparent 0–100 scores across water, soil, climate, and local dimensions with full evidence traces.
            </p>
          </div>

          {/* View Mode & PDF Action Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold text-slate-700">Display View:</span>
              <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-white shadow-2xs">
                <button
                  type="button"
                  onClick={() => setViewMode('comparison')}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                    viewMode === 'comparison'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Columns className="w-3.5 h-3.5" />
                  <span>Side-by-Side Comparison Screen</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('cards')}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                    viewMode === 'cards'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Strategy Cards & Audit Trace</span>
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsReportModalOpen(true)}
              className="px-3.5 py-1.5 rounded-lg bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold flex items-center space-x-1.5 transition-all shadow-xs cursor-pointer"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span>Export / Print PDF Report</span>
            </button>
          </div>

          {recommendations.seasonal_plan && (
            <section className="rounded-2xl border border-emerald-200 bg-emerald-50/50 p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-emerald-800">Annual crop calendar</p>
                  <h3 className="text-sm font-bold text-slate-900">Kharif · Rabi · Summer planning</h3>
                </div>
                <span className="rounded-full bg-white border border-emerald-200 px-2.5 py-1 text-[10px] font-bold text-emerald-900">Catalogue-based options</span>
              </div>
              <div className="grid md:grid-cols-3 gap-3">
                {recommendations.seasonal_plan.seasons.map((season) => (
                  <div key={season.id} className="rounded-xl bg-white border border-slate-200 p-3 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-sm font-bold text-slate-900">{season.id}</h4>
                      <span className="text-[10px] text-slate-500">{season.months}</span>
                    </div>
                    <p className="text-[10px] font-semibold text-emerald-800">{season.candidate_count} catalogue options</p>
                    {season.candidates.length > 0 ? (
                      <ul className="space-y-1.5">
                        {season.candidates.slice(0, 5).map((crop) => (
                          <li key={crop.crop_id} className="text-[11px] text-slate-700 border-t border-slate-100 pt-1.5">
                            <span className="font-semibold">{crop.crop_name}</span>
                            {crop.water_requirement_mm && <span className="block text-[10px] text-slate-500">Water requirement: {crop.water_requirement_mm.minimum_mm}–{crop.water_requirement_mm.maximum_mm} mm</span>}
                            {crop.growth_days && <span className="block text-[10px] text-slate-500">Duration: {crop.growth_days[0]}–{crop.growth_days[1]} days</span>}
                          </li>
                        ))}
                      </ul>
                    ) : <p className="text-[11px] text-amber-800">No verified crop entries for this season in the current catalogue.</p>}
                    <p className="text-[10px] text-slate-500">{season.message}</p>
                  </div>
                ))}
              </div>
              <div className="rounded-lg bg-white/80 border border-emerald-100 p-3">
                <p className="text-[10px] font-bold text-slate-700">Planning limitations</p>
                <ul className="list-disc pl-4 mt-1 space-y-1 text-[10px] text-slate-600">
                  {recommendations.seasonal_plan.limitations.map((limitation, index) => <li key={index}>{limitation}</li>)}
                </ul>
              </div>
            </section>
          )}

          {recommendations.geospatial_rotation_context && (
            <section className="rounded-2xl border border-cyan-200 bg-cyan-50/60 p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div><p className="text-[10px] font-bold uppercase tracking-widest text-cyan-800">Geospatial planning context</p><h3 className="text-sm font-bold text-slate-900">Sentinel-2 vegetation monitoring + FAO GAEZ crop context</h3></div>
                <span className="rounded-full bg-white border border-cyan-200 px-2.5 py-1 text-[10px] font-bold text-cyan-900">{recommendations.geospatial_rotation_context.status}</span>
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                <div className="rounded-xl bg-white border border-slate-200 p-3 space-y-1">
                  <p className="text-xs font-bold text-slate-800">Sentinel-2 L2A scenes</p>
                  <p className="text-2xl font-black text-emerald-700">{recommendations.geospatial_rotation_context.sentinel2.scene_count}</p>
                  <p className="text-[11px] text-slate-600">Candidate scenes found · scene metadata only; NDVI/NDWI is not calculated.</p>
                  {recommendations.geospatial_rotation_context.sentinel2.items.slice(0,3).map((scene, index) => <p key={scene.id || index} className="text-[10px] text-slate-500">{scene.datetime || scene.id || 'Scene'} · Cloud {scene.cloud_cover_percent ?? 'unknown'}%</p>)}
                  {recommendations.geospatial_rotation_context.sentinel2.error && <p className="text-[10px] text-amber-700">{recommendations.geospatial_rotation_context.sentinel2.error}</p>}
                </div>
                <div className="rounded-xl bg-white border border-slate-200 p-3 space-y-1">
                  <p className="text-xs font-bold text-slate-800">FAO GAEZ crop records</p>
                  <p className="text-2xl font-black text-blue-700">{recommendations.geospatial_rotation_context.gaez.record_count}</p>
                  <p className="text-[11px] text-slate-600">Catalogue matches · {recommendations.geospatial_rotation_context.gaez.api_version || 'GAEZ catalogue'}</p>
                  {recommendations.geospatial_rotation_context.gaez.items.slice(0,3).map((item, index) => <p key={item.id || index} className="text-[10px] text-slate-500">{item.properties?.title || item.id || 'Catalogue record'}</p>)}
                  {recommendations.geospatial_rotation_context.gaez.error && <p className="text-[10px] text-amber-700">{recommendations.geospatial_rotation_context.gaez.error}</p>}
                  {recommendations.geospatial_rotation_context.gaez.current_version_portal && <a className="text-[10px] font-bold text-blue-700 underline" href={recommendations.geospatial_rotation_context.gaez.current_version_portal} target="_blank" rel="noreferrer">Open GAEZ v5 portal</a>}
                </div>
              </div>
              <p className="text-[10px] text-slate-600">These sources provide planning context only. They do not change crop scores: Sentinel-2 pixel indices and validated, crop-specific GAEZ layer extraction are not yet available.</p>
            </section>
          )}

          {/* Screen 1: Side-by-Side Comparison Screen (Requirement: Comparison screen showing all three rotation strategies side by side) */}
          {viewMode === 'comparison' && (
            <RotationComparisonView
              strategies={recommendations.strategies}
              rankingComparison={recommendations.ranking_comparison}
              chosenWeights={weights}
              baselineWeights={baselineWeights}
              onOpenReport={() => setIsReportModalOpen(true)}
              onSelectStrategyForTrace={(id) => {
                setExpandedTraceStrategyId(id);
                setViewMode('cards');
              }}
            />
          )}

          {/* Screen 2: Detailed Strategy Cards & Full Evidence Trace Inspector */}
          {viewMode === 'cards' && (
            <div className="space-y-6">
              {/* Strategy Cards */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {recommendations.strategies.map((strat) => {
              const isTraceExpanded = expandedTraceStrategyId === strat.id;
              const scores = strat.individual_scores || {
                water_suitability: 85,
                soil_health_potential: 80,
                climate_suitability: 85,
                local_agricultural_suitability: 85
              };

              return (
                <div
                  key={strat.id}
                  className="p-4 rounded-xl border border-slate-200 bg-white hover:border-purple-300 transition-all flex flex-col justify-between space-y-4 shadow-xs"
                >
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-100">
                          Strategy Archetype
                        </span>
                        <h4 className="text-sm font-bold text-slate-900 mt-1">{strat.title}</h4>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 font-semibold uppercase block">Overall</span>
                        <span className="text-xl font-bold font-mono text-purple-700">
                          {strat.overall_score}
                          <span className="text-xs font-normal text-slate-400">/100</span>
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">{strat.description}</p>

                    {/* 4 Dimension Score Meters */}
                    <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
                      <div className="p-2 rounded-lg bg-blue-50/70 border border-blue-200/80">
                        <div className="flex items-center justify-between text-[11px] mb-0.5">
                          <span className="text-blue-900 font-semibold flex items-center space-x-1">
                            <Droplets className="w-3 h-3 text-blue-600" />
                            <span>Water</span>
                          </span>
                          <span className="font-mono font-bold text-blue-900">{scores.water_suitability}</span>
                        </div>
                        <div className="w-full bg-blue-200/50 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-blue-600 h-full rounded-full" style={{ width: `${scores.water_suitability}%` }} />
                        </div>
                        <span className="text-[9px] text-blue-700/80 mt-0.5 block">Weight: {strat.weights?.water || 25}%</span>
                      </div>

                      <div className="p-2 rounded-lg bg-amber-50/70 border border-amber-200/80">
                        <div className="flex items-center justify-between text-[11px] mb-0.5">
                          <span className="text-amber-950 font-semibold flex items-center space-x-1">
                            <TestTube2 className="w-3 h-3 text-amber-700" />
                            <span>Soil</span>
                          </span>
                          <span className="font-mono font-bold text-amber-950">{scores.soil_health_potential}</span>
                        </div>
                        <div className="w-full bg-amber-200/50 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-amber-600 h-full rounded-full" style={{ width: `${scores.soil_health_potential}%` }} />
                        </div>
                        <span className="text-[9px] text-amber-800/80 mt-0.5 block">Weight: {strat.weights?.soil || 25}%</span>
                      </div>

                      <div className="p-2 rounded-lg bg-purple-50/70 border border-purple-200/80">
                        <div className="flex items-center justify-between text-[11px] mb-0.5">
                          <span className="text-purple-900 font-semibold flex items-center space-x-1">
                            <Sun className="w-3 h-3 text-purple-600" />
                            <span>Climate</span>
                          </span>
                          <span className="font-mono font-bold text-purple-900">{scores.climate_suitability}</span>
                        </div>
                        <div className="w-full bg-purple-200/50 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-purple-600 h-full rounded-full" style={{ width: `${scores.climate_suitability}%` }} />
                        </div>
                        <span className="text-[9px] text-purple-700/80 mt-0.5 block">Weight: {strat.weights?.climate || 25}%</span>
                      </div>

                      <div className="p-2 rounded-lg bg-emerald-50/70 border border-emerald-200/80">
                        <div className="flex items-center justify-between text-[11px] mb-0.5">
                          <span className="text-emerald-950 font-semibold flex items-center space-x-1">
                            <BookOpen className="w-3 h-3 text-emerald-600" />
                            <span>Local</span>
                          </span>
                          <span className="font-mono font-bold text-emerald-950">{scores.local_agricultural_suitability}</span>
                        </div>
                        <div className="w-full bg-emerald-200/50 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-emerald-600 h-full rounded-full" style={{ width: `${scores.local_agricultural_suitability}%` }} />
                        </div>
                        <span className="text-[9px] text-emerald-800/80 mt-0.5 block">Weight: {strat.weights?.local || 25}%</span>
                      </div>
                    </div>

                    {/* 3-Season Sequence */}
                    <div className="space-y-1.5 pt-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                        3-Season Crop Sequence:
                      </span>
                      {(strat.rotation || strat.crop_sequence || []).map((step: any, idx: number) => {
                        const cropName = typeof step === 'string' ? step : (step.crop || step.crop_name || 'Crop');
                        const role = typeof step === 'object' && step ? step.role : '';
                        const seasonLabel = typeof step === 'object' && step && step.season
                          ? String(step.season).split(' ')[0]
                          : (idx === 0 ? 'Kharif' : idx === 1 ? 'Rabi' : 'Summer');

                        return (
                          <div key={idx} className="p-2 bg-slate-50 rounded-lg border border-slate-200 text-xs flex items-center justify-between">
                            <div>
                              <span className="font-bold text-slate-800 block">{cropName}</span>
                              {role && <span className="text-[10px] text-slate-500">{role}</span>}
                            </div>
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white border border-slate-200 text-purple-800">
                              {seasonLabel}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Completeness Badge */}
                    {strat.evidence_completeness && (
                      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                        <span>Evidence Completeness:</span>
                        <span className="font-mono font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                          {strat.evidence_completeness.percentage}% ({strat.evidence_completeness.available_indicators}/{strat.evidence_completeness.total_indicators_tracked} indicators)
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Toggle Evidence Trace Button */}
                  <div className="pt-2 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setExpandedTraceStrategyId(isTraceExpanded ? null : strat.id)}
                      className="w-full py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all"
                    >
                      <FileText className="w-3.5 h-3.5 text-purple-600" />
                      <span>{isTraceExpanded ? 'Hide Traceable Evidence' : 'Inspect Traceable Evidence'}</span>
                      {isTraceExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Full Evidence Trace Inspector for Selected Strategy */}
          {expandedTraceStrategyId && (
            <div className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200/90 space-y-4">
              {(() => {
                const activeStrat = recommendations.strategies.find((s) => s.id === expandedTraceStrategyId);
                if (!activeStrat || !activeStrat.evidence_trace) return null;
                const trace = activeStrat.evidence_trace;

                return (
                  <div className="space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 uppercase">
                            Audit Trace
                          </span>
                          <h4 className="text-sm font-bold text-slate-900">
                            Mathematical Evidence Trace: {activeStrat.title}
                          </h4>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Transparent audit record formatted for farmer consultation and PDF report export.
                        </p>
                      </div>

                      <div className="text-xs font-mono font-bold bg-white px-3 py-1.5 rounded-lg border border-slate-200 text-slate-800">
                        Overall: {trace.overall_score} / 100
                      </div>
                    </div>

                    {/* 4 Dimensions Detailed Breakdown */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                      {/* Water Dimension */}
                      {trace.dimensions?.water_suitability && (
                        <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-blue-900 flex items-center space-x-1.5">
                              <Droplets className="w-4 h-4 text-blue-600" />
                              <span>Water Suitability ({trace.dimensions.water_suitability.score}/100)</span>
                            </span>
                            <span className="text-[10px] font-mono font-semibold text-slate-500">
                              Contribution: {trace.dimensions.water_suitability.weighted_contribution} pts
                            </span>
                          </div>
                          <p className="text-xs text-slate-700 leading-relaxed">
                            {trace.dimensions.water_suitability.traceable_explanation}
                          </p>
                          <div className="space-y-1 bg-slate-50 p-2 rounded-lg border border-slate-100 text-[11px]">
                            <span className="font-bold text-slate-700 block">Supporting Evidence:</span>
                            {trace.dimensions.water_suitability.supporting_evidence?.map((ev: any, i: number) => renderEvidenceItem(ev, i))}
                          </div>
                          <p className="text-[10px] text-slate-400 italic pt-1">
                            Limitation: {trace.dimensions.water_suitability.data_limitations}
                          </p>
                        </div>
                      )}

                      {/* Climate Dimension */}
                      {trace.dimensions?.climate_suitability && (
                        <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-purple-900 flex items-center space-x-1.5">
                              <Sun className="w-4 h-4 text-purple-600" />
                              <span>Climate Suitability ({trace.dimensions.climate_suitability.score}/100)</span>
                            </span>
                            <span className="text-[10px] font-mono font-semibold text-slate-500">
                              Contribution: {trace.dimensions.climate_suitability.weighted_contribution} pts
                            </span>
                          </div>
                          <p className="text-xs text-slate-700 leading-relaxed">
                            {trace.dimensions.climate_suitability.traceable_explanation}
                          </p>
                          <div className="space-y-1 bg-slate-50 p-2 rounded-lg border border-slate-100 text-[11px]">
                            <span className="font-bold text-slate-700 block">Supporting Evidence:</span>
                            {trace.dimensions.climate_suitability.supporting_evidence?.map((ev: any, i: number) => renderEvidenceItem(ev, i))}
                          </div>
                          <p className="text-[10px] text-slate-400 italic pt-1">
                            Limitation: {trace.dimensions.climate_suitability.data_limitations}
                          </p>
                        </div>
                      )}

                      {/* Soil Health Dimension */}
                      {trace.dimensions?.soil_health_potential && (
                        <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-amber-950 flex items-center space-x-1.5">
                              <TestTube2 className="w-4 h-4 text-amber-700" />
                              <span>Soil-Health Potential ({trace.dimensions.soil_health_potential.score}/100)</span>
                            </span>
                            <span className="text-[10px] font-mono font-semibold text-slate-500">
                              Contribution: {trace.dimensions.soil_health_potential.weighted_contribution} pts
                            </span>
                          </div>
                          <p className="text-xs text-slate-700 leading-relaxed">
                            {trace.dimensions.soil_health_potential.traceable_explanation}
                          </p>
                          <div className="space-y-1 bg-slate-50 p-2 rounded-lg border border-slate-100 text-[11px]">
                            <span className="font-bold text-slate-700 block">Supporting Evidence:</span>
                            {trace.dimensions.soil_health_potential.supporting_evidence?.map((ev: any, i: number) => renderEvidenceItem(ev, i))}
                          </div>
                          <p className="text-[10px] text-amber-800/80 italic pt-1">
                            Note: {trace.dimensions.soil_health_potential.data_limitations}
                          </p>
                        </div>
                      )}

                      {/* Local Agronomy Dimension */}
                      {trace.dimensions?.local_agricultural_suitability && (
                        <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-emerald-950 flex items-center space-x-1.5">
                              <BookOpen className="w-4 h-4 text-emerald-600" />
                              <span>Local Agronomy Suitability ({trace.dimensions.local_agricultural_suitability.score}/100)</span>
                            </span>
                            <span className="text-[10px] font-mono font-semibold text-slate-500">
                              Contribution: {trace.dimensions.local_agricultural_suitability.weighted_contribution} pts
                            </span>
                          </div>
                          <p className="text-xs text-slate-700 leading-relaxed">
                            {trace.dimensions.local_agricultural_suitability.traceable_explanation}
                          </p>
                          <div className="space-y-1 bg-slate-50 p-2 rounded-lg border border-slate-100 text-[11px]">
                            <span className="font-bold text-slate-700 block">Supporting Evidence:</span>
                            {trace.dimensions.local_agricultural_suitability.supporting_evidence?.map((ev: any, i: number) => renderEvidenceItem(ev, i))}
                          </div>
                          <p className="text-[10px] text-slate-400 italic pt-1">
                            Limitation: {trace.dimensions.local_agricultural_suitability.data_limitations}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Potential Risks & Non-Guarantee Banner */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                      <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200/80 space-y-1">
                        <span className="text-xs font-bold text-amber-950 flex items-center space-x-1">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
                          <span>Identified Agronomic & Climatic Risks:</span>
                        </span>
                        <ul className="text-[11px] text-amber-900 space-y-0.5 list-disc list-inside">
                          {(Array.isArray(activeStrat.potential_risks) ? activeStrat.potential_risks : [String(activeStrat.potential_risks || 'Standard seasonal rainfall variability')]).map((risk: any, i: number) => (
                            <li key={i}>{typeof risk === 'string' ? risk : JSON.stringify(risk)}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-100/80 border border-slate-200 space-y-1 text-[11px] text-slate-600">
                        <span className="font-bold text-slate-800 block">Data Limitations & Policy:</span>
                        <p>
                          Recommendations provide evidence-based advisory support and do not guarantee yield outcomes.
                          Missing satellite observations are excluded without synthetic data substitution.
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
          </div>
          )}

          {/* Evaluated Crops Leaderboard */}
          <div className="space-y-3 pt-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Single-Crop Suitability Leaderboard (NASA Climate × Ground-Truth Soil)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
              {recommendations.evaluated_crops.slice(0, 3).map((crop) => (
                <div key={crop.crop_id} className="p-4 rounded-xl border border-slate-200 bg-white hover:border-purple-300 transition-all space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase">{crop.category}</span>
                    <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800 font-mono">
                      {crop.suitability_score}% Match
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-slate-900">{crop.crop_name}</h4>
                  <div className="text-[11px] text-slate-600 space-y-1.5 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="font-bold text-slate-700 block mb-1">Synthesized Decision Evidence:</span>
                    {crop.evidence_citations.map((cite, i) => renderCitationPill(cite, i))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PDF Report Export Modal (Preserves Chosen Priority Weights) */}
      <PDFReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        farm={activeFarm}
        farmerProfile={farmerProfile}
        chosenWeights={weights}
        baselineWeights={baselineWeights}
        strategies={recommendations ? recommendations.strategies : []}
        rankingComparison={recommendations?.ranking_comparison}
        dossier={dossier}
      />
    </div>
  );
};
