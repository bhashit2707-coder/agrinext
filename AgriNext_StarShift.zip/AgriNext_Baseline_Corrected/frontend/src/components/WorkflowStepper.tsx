import React from 'react';
import {
  UserCheck,
  MapPin,
  PencilRuler,
  Satellite,
  TestTube2,
  Layers,
  Scale,
  Sliders,
  RefreshCw,
  TrendingUp,
  FileDown
} from 'lucide-react';

const STEPS = [
  { id: 1, title: 'Farmer Login', icon: UserCheck, desc: 'Enter Farmer Information' },
  { id: 2, title: 'Location & Area', icon: MapPin, desc: 'Add location and land area' },
  { id: 3, title: 'Draw Boundary', icon: PencilRuler, desc: 'Leaflet Draw polygon' },
  { id: 4, title: 'NASA Data', icon: Satellite, desc: 'POWER, SMAP & GPM' },
  { id: 5, title: 'Soil & Crops', icon: TestTube2, desc: 'pH, NPK, crop history' },
  { id: 6, title: '3 Strategies', icon: Layers, desc: 'Resilient, Soil, Economic' },
  { id: 7, title: 'Compare', icon: Scale, desc: 'Multi-criteria tradeoff' },
  { id: 8, title: 'Priorities', icon: Sliders, desc: 'Water, profit, soil weights' },
  { id: 9, title: 'Recalculate', icon: RefreshCw, desc: 'Dynamically reweight' },
  { id: 10, title: 'Climate What-If', icon: TrendingUp, desc: 'Simulate rainfall drop' },
  { id: 11, title: 'PDF Report', icon: FileDown, desc: 'Evidence-based audit' }
];

export const WorkflowStepper: React.FC<{ activeStep?: number }> = ({ activeStep = 1 }) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-base font-semibold text-slate-800">
            Core 11-Step Recommendation Workflow
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Architected to guarantee mathematical traceability to verified Earth observation data.
          </p>
        </div>
        <span className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200">
          Step {activeStep} of 11
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-11 gap-2.5">
        {STEPS.map((step) => {
          const Icon = step.icon;
          const isCurrent = step.id === activeStep;
          const isPast = step.id < activeStep;

          return (
            <div
              key={step.id}
              className={`p-3 rounded-xl border transition-all flex flex-col justify-between ${
                isCurrent
                  ? 'bg-emerald-50 border-emerald-400 shadow-sm ring-1 ring-emerald-400/50'
                  : isPast
                  ? 'bg-slate-50/80 border-slate-200'
                  : 'bg-white border-slate-100 opacity-80'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      isCurrent
                        ? 'bg-emerald-600 text-white'
                        : isPast
                        ? 'bg-slate-300 text-slate-700'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {step.id}
                  </span>
                  <Icon
                    className={`w-4 h-4 ${
                      isCurrent ? 'text-emerald-700' : 'text-slate-400'
                    }`}
                  />
                </div>
                <p className="text-xs font-semibold text-slate-800 leading-tight">
                  {step.title}
                </p>
              </div>
              <p className="text-[10px] text-slate-500 mt-1 line-clamp-1">
                {step.desc}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
