import React, { useEffect, useState } from 'react';
import { FileUp, FileText, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { apiService } from '../services/api';

type Props = { farmId?: string };

export const SoilReportUpload: React.FC<Props> = ({ farmId }) => {
  const [file, setFile] = useState<File | null>(null);
  const [reports, setReports] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const refresh = async () => {
    if (!farmId) return;
    try { setReports(await apiService.getSoilReports(farmId)); } catch { setReports([]); }
  };
  useEffect(() => { void refresh(); }, [farmId]);

  const upload = async () => {
    if (!farmId || !file) return;
    setBusy(true); setError(null); setMessage(null);
    try {
      const result = await apiService.uploadSoilReport(farmId, file);
      const count = Object.keys(result.report?.extracted_metrics || {}).length;
      setMessage(count ? `Report uploaded. ${count} value(s) extracted for your review.` : 'Report uploaded. Enter the laboratory values manually; automatic extraction was not available for this file.');
      setFile(null);
      await refresh();
    } catch (e: any) { setError(e.message || 'Upload failed.'); }
    finally { setBusy(false); }
  };

  return <section className="rounded-2xl border border-emerald-200 bg-emerald-50/50 p-4 space-y-3">
    <div className="flex items-center gap-2 text-sm font-bold text-emerald-950"><FileUp className="h-4 w-4" /> Upload Soil Health Report</div>
    <p className="text-xs text-slate-600">Attach a laboratory report or Soil Health Card (PDF, JPG or PNG; maximum 10 MB). Text-based PDFs may have pH, N, P, K and organic-carbon values suggested automatically. Review every extracted value before saving it to your soil profile.</p>
    <div className="flex flex-wrap gap-2 items-center">
      <input type="file" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" onChange={e => setFile(e.target.files?.[0] || null)} className="block max-w-full text-xs file:mr-3 file:rounded-lg file:border-0 file:bg-white file:px-3 file:py-2 file:text-xs file:font-semibold file:text-emerald-800" />
      <button type="button" disabled={!farmId || !file || busy} onClick={upload} className="rounded-lg bg-emerald-700 px-4 py-2 text-xs font-bold text-white disabled:opacity-50">{busy ? <Loader2 className="inline h-3 w-3 animate-spin" /> : 'Upload report'}</button>
    </div>
    {message && <p className="flex items-center gap-2 text-xs text-emerald-800"><CheckCircle2 className="h-4 w-4" />{message}</p>}
    {error && <p className="flex items-center gap-2 text-xs text-rose-700"><AlertCircle className="h-4 w-4" />{error}</p>}
    {reports.length > 0 && <div className="space-y-2"><p className="text-xs font-bold text-slate-700">Uploaded reports</p>{reports.map(report => <div key={report.id} className="flex items-center justify-between gap-3 rounded-lg bg-white p-2 text-xs"><span className="flex min-w-0 items-center gap-2 truncate"><FileText className="h-4 w-4 shrink-0 text-emerald-700" />{report.original_filename}</span><span className="shrink-0 text-slate-500">{report.extraction_status.replace(/_/g, ' ')}</span></div>)}</div>}
    <p className="text-[11px] text-slate-500">Scanned images and scanned PDFs are stored securely but are not OCR-processed. Uploading a report does not automatically change your saved soil measurements.</p>
  </section>;
};
