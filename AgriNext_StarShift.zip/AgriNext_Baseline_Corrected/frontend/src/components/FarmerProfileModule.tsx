import React, { useState, useEffect } from 'react';
import {
  TestTube2,
  Database,
  UserCheck,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Info
} from 'lucide-react';
import { apiService } from '../services/api';
import type {
  FarmProfile,
  FarmerProfile,
  FarmerProfileInput,
  DistrictSoilBenchmark,
  Crop
} from '../types';

interface FarmerProfileModuleProps {
  activeFarm: FarmProfile | null;
  crops: Crop[];
  onProfileUpdated?: (profile: FarmerProfile) => void;
}

const COMMON_SOIL_TYPES = [
  'Red Sandy Loam',
  'Black Cotton Soil',
  'Alluvial Clay Loam',
  'Red Loam',
  'Clay Loam',
  'Sandy Loam',
  'Heavy Black Vertisol',
  'Laterite Soil',
  'Coastal Alluvium'
];

const IRRIGATION_SOURCES = [
  'Rainfed',
  'Borewell',
  'Canal',
  'Drip Irrigation',
  'Sprinkler',
  'Lift Irrigation',
  'Farm Pond / Tank'
];

const SEASONS = ['Kharif', 'Rabi', 'Summer'];

export const FarmerProfileModule: React.FC<FarmerProfileModuleProps> = ({
  activeFarm,
  crops,
  onProfileUpdated
}) => {
  const [sourceType, setSourceType] = useState<'farmer_measured' | 'agricultural_benchmark'>('farmer_measured');
  const [soilType, setSoilType] = useState<string>('Red Sandy Loam');
  const [soilPh, setSoilPh] = useState<string>('6.8');
  const [nitrogenKgHa, setNitrogenKgHa] = useState<string>('135');
  const [nitrogenRating] = useState<string>('');
  const [phosphorusKgHa, setPhosphorusKgHa] = useState<string>('18');
  const [phosphorusRating] = useState<string>('');
  const [potassiumKgHa, setPotassiumKgHa] = useState<string>('290');
  const [potassiumRating] = useState<string>('');
  const [organicCarbonPct, setOrganicCarbonPct] = useState<string>('0.42');
  const [currentCrop, setCurrentCrop] = useState<string>('groundnut');
  const [previousCrops, setPreviousCrops] = useState<string[]>(['paddy', 'groundnut']);
  const [availableCrops, setAvailableCrops] = useState<string[]>([
    'groundnut',
    'bengal_gram',
    'red_gram',
    'black_gram',
    'maize',
    'sorghum',
    'cotton'
  ]);
  const [irrigationSource, setIrrigationSource] = useState<string>('Rainfed');
  const [farmingSeason, setFarmingSeason] = useState<string>('Kharif');
  const [preferredCrops, setPreferredCrops] = useState<string[]>(['groundnut', 'bengal_gram']);
  const [sourceReference, setSourceReference] = useState<string>(
    'Farmer self-reported field/laboratory measurement'
  );

  const [saving, setSaving] = useState<boolean>(false);
  const [loadingBenchmark, setLoadingBenchmark] = useState<boolean>(false);
  const [savedProfile, setSavedProfile] = useState<FarmerProfile | null>(null);
  const [activeBenchmark, setActiveBenchmark] = useState<DistrictSoilBenchmark | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Auto-load profile when activeFarm changes
  useEffect(() => {
    if (!activeFarm || !activeFarm.id) return;

    let isMounted = true;
    async function loadFarmProfile() {
      try {
        const prof = await apiService.getFarmerProfile(activeFarm!.id!);
        if (isMounted && prof) {
          setSavedProfile(prof);
          setSoilType(prof.soil_type || 'Red Sandy Loam');
          setSourceType(
            prof.soil_source_type === 'agricultural_benchmark'
              ? 'agricultural_benchmark'
              : 'farmer_measured'
          );
          setSoilPh(prof.soil_ph !== null && prof.soil_ph !== undefined ? String(prof.soil_ph) : '');
          setNitrogenKgHa(prof.nitrogen_value !== null && prof.nitrogen_value !== undefined ? String(prof.nitrogen_value) : '');
          setPhosphorusKgHa(prof.phosphorus_value !== null && prof.phosphorus_value !== undefined ? String(prof.phosphorus_value) : '');
          setPotassiumKgHa(prof.potassium_value !== null && prof.potassium_value !== undefined ? String(prof.potassium_value) : '');
          setOrganicCarbonPct(prof.organic_carbon_pct !== null && prof.organic_carbon_pct !== undefined ? String(prof.organic_carbon_pct) : '');
          setCurrentCrop(prof.current_crop || '');
          setPreviousCrops(prof.previous_crops || []);
          setAvailableCrops(prof.available_crops || []);
          setIrrigationSource(prof.irrigation_source || 'Rainfed');
          setFarmingSeason(prof.farming_season || 'Kharif');
          setPreferredCrops(prof.preferred_crops || []);
          setSourceReference(prof.soil_source_reference || '');
          if (onProfileUpdated) onProfileUpdated(prof);
        }
      } catch {
        // No saved profile for this farm yet, which is expected for new farms
      }
    }

    loadFarmProfile();
    return () => {
      isMounted = false;
    };
  }, [activeFarm?.id]);

  // Derived classifications for dynamic display
  const getPhClass = (val: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return { label: 'Unknown / Not Provided', color: 'text-slate-400 bg-slate-100' };
    if (num < 6.5) return { label: 'Acidic (< 6.5)', color: 'text-amber-700 bg-amber-50 border-amber-200' };
    if (num <= 7.5) return { label: 'Neutral (6.5 - 7.5)', color: 'text-emerald-700 bg-emerald-50 border-emerald-200' };
    if (num <= 8.5) return { label: 'Moderately Alkaline (7.6 - 8.5)', color: 'text-blue-700 bg-blue-50 border-blue-200' };
    return { label: 'Strongly Alkaline (> 8.5)', color: 'text-purple-700 bg-purple-50 border-purple-200' };
  };

  const getNRating = (val: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return { label: 'Unknown', color: 'bg-slate-100 text-slate-500' };
    if (num < 140) return { label: 'Low (< 140 kg/ha)', color: 'bg-red-50 text-red-700 border-red-200' };
    if (num <= 280) return { label: 'Medium (140-280 kg/ha)', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
    return { label: 'High (> 280 kg/ha)', color: 'bg-blue-50 text-blue-700 border-blue-200' };
  };

  const getPRating = (val: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return { label: 'Unknown', color: 'bg-slate-100 text-slate-500' };
    if (num < 10) return { label: 'Low (< 10 kg/ha)', color: 'bg-red-50 text-red-700 border-red-200' };
    if (num <= 25) return { label: 'Medium (10-25 kg/ha)', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
    return { label: 'High (> 25 kg/ha)', color: 'bg-blue-50 text-blue-700 border-blue-200' };
  };

  const getKRating = (val: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return { label: 'Unknown', color: 'bg-slate-100 text-slate-500' };
    if (num < 120) return { label: 'Low (< 120 kg/ha)', color: 'bg-red-50 text-red-700 border-red-200' };
    if (num <= 280) return { label: 'Medium (120-280 kg/ha)', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
    return { label: 'High (> 280 kg/ha)', color: 'bg-blue-50 text-blue-700 border-blue-200' };
  };

  const getOCRating = (val: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return { label: 'Unknown', color: 'bg-slate-100 text-slate-500' };
    if (num < 0.50) return { label: 'Low (< 0.50%)', color: 'bg-red-50 text-red-700 border-red-200' };
    if (num <= 0.75) return { label: 'Medium (0.50-0.75%)', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
    return { label: 'High (> 0.75%)', color: 'bg-blue-50 text-blue-700 border-blue-200' };
  };

  // Handler to load verified agricultural benchmark for the active district
  const handleLoadDistrictBenchmark = async () => {
    const districtId = activeFarm?.district_id || 'anantapur';
    setLoadingBenchmark(true);
    setErrorMessage(null);
    try {
      const benchmark = await apiService.getSoilBenchmark(districtId);
      setActiveBenchmark(benchmark);
      setSoilType(benchmark.dominant_soil_type);
      setSoilPh(String(benchmark.soil_ph));
      setNitrogenKgHa(String(benchmark.available_nitrogen_kg_ha));
      setPhosphorusKgHa(String(benchmark.available_phosphorus_kg_ha));
      setPotassiumKgHa(String(benchmark.available_potassium_kg_ha));
      setOrganicCarbonPct(String(benchmark.organic_carbon_pct));
      setSourceType('agricultural_benchmark');
      setSourceReference(
        benchmark.source_reference ||
        'Government of India Soil Health Card Portal (https://soilhealth.dac.gov.in/) & ANGRAU Agro-Ecological District Profiles'
      );
      setStatusMessage(`Loaded official Soil Health Card benchmark for ${benchmark.district_name} district.`);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to load official district soil benchmark.');
    } finally {
      setLoadingBenchmark(false);
    }
  };

  const handleToggleCrop = (cropId: string, list: string[], setter: (v: string[]) => void) => {
    if (list.includes(cropId)) {
      setter(list.filter((c) => c !== cropId));
    } else {
      setter([...list, cropId]);
    }
  };

  const handleSaveProfile = async () => {
    setSaving(true);
    setStatusMessage(null);
    setErrorMessage(null);

    const inputData: FarmerProfileInput = {
      farm_id: activeFarm?.id || null,
      soil_type: soilType.trim() || 'Red Sandy Loam',
      soil_ph: soilPh.trim() ? parseFloat(soilPh) : null,
      nitrogen_kg_ha: nitrogenKgHa.trim() ? parseFloat(nitrogenKgHa) : null,
      nitrogen_rating: nitrogenRating || null,
      phosphorus_kg_ha: phosphorusKgHa.trim() ? parseFloat(phosphorusKgHa) : null,
      phosphorus_rating: phosphorusRating || null,
      potassium_kg_ha: potassiumKgHa.trim() ? parseFloat(potassiumKgHa) : null,
      potassium_rating: potassiumRating || null,
      organic_carbon_pct: organicCarbonPct.trim() ? parseFloat(organicCarbonPct) : null,
      current_crop: currentCrop || null,
      previous_crops: previousCrops,
      available_crops: availableCrops,
      irrigation_source: irrigationSource,
      farming_season: farmingSeason,
      preferred_crops: preferredCrops,
      soil_source_type: sourceType,
      soil_source_reference: sourceReference || (
        sourceType === 'agricultural_benchmark'
          ? 'Government of India Soil Health Card Portal (https://soilhealth.dac.gov.in/) & ANGRAU District Soil Benchmark'
          : 'Farmer self-reported field/laboratory measurement'
      )
    };

    try {
      const response = await apiService.saveFarmerProfile(inputData);
      setSavedProfile(response.farmer_profile);
      setStatusMessage('Farmer profile and ground-truth soil parameters saved successfully.');
      if (onProfileUpdated) {
        onProfileUpdated(response.farmer_profile);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save farmer profile.');
    } finally {
      setSaving(false);
    }
  };

  const phStatus = getPhClass(soilPh);
  const nStatus = getNRating(nitrogenKgHa);
  const pStatus = getPRating(phosphorusKgHa);
  const kStatus = getKRating(potassiumKgHa);
  const ocStatus = getOCRating(organicCarbonPct);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-6">
      {/* Module Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
              Module 5
            </span>
            <h2 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
              <TestTube2 className="w-5 h-5 text-amber-600" />
              <span>Farmer Profile & Ground-Truth Soil Module</span>
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Captures parcel-level soil characteristics, cropping history, irrigation feasibility, and farmer preferences.
          </p>
        </div>

        {/* Action Button */}
        <div className="flex items-center space-x-3">
          <button
            type="button"
            onClick={handleSaveProfile}
            disabled={saving}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold text-xs flex items-center space-x-2 transition-all shadow-md shadow-amber-900/20"
          >
            <UserCheck className={`w-3.5 h-3.5 ${saving ? 'animate-spin' : ''}`} />
            <span>{saving ? 'Saving Profile...' : 'Save Farmer Profile'}</span>
          </button>
        </div>
      </div>

      {/* Strict Provenance Distinction Alert */}
      <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 text-xs text-amber-950 flex items-start space-x-2.5">
        <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Strict Provenance Boundary: </span>
          Farmer-entered soil values and verified agricultural benchmarks (Soil Health Card & ANGRAU) represent{' '}
          <b>ground-truth parcel realities</b>. They are kept completely distinct from regional satellite Earth observations
          (NASA POWER ~50 km reanalysis, NASA SMAP ~9 km, NASA GPM ~10 km). Unverified attributes remain marked as unknown
          without synthetic imputation.
        </div>
      </div>

      {statusMessage && (
        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Section 1: Soil Source & Baseline Selection */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center space-x-2">
              <Database className="w-4 h-4 text-slate-600" />
              <span>Soil Data Source Selection</span>
            </h3>
            <p className="text-[11px] text-slate-500">
              Choose between farmer-measured lab test values or official Soil Health Card district baselines.
            </p>
          </div>

          <button
            type="button"
            onClick={handleLoadDistrictBenchmark}
            disabled={loadingBenchmark}
            className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold text-xs flex items-center space-x-1.5 shadow-sm"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingBenchmark ? 'animate-spin text-amber-600' : 'text-slate-500'}`} />
            <span>Load {activeFarm?.district_id ? activeFarm.district_id.toUpperCase() : 'AP'} Benchmark</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <label
            className={`p-3 rounded-xl border flex items-start space-x-3 cursor-pointer transition-all ${
              sourceType === 'farmer_measured'
                ? 'bg-amber-50/60 border-amber-400 ring-1 ring-amber-400/30'
                : 'bg-white border-slate-200 hover:border-slate-300'
            }`}
          >
            <input
              type="radio"
              name="soil_source_type"
              checked={sourceType === 'farmer_measured'}
              onChange={() => {
                setSourceType('farmer_measured');
                setSourceReference('Farmer self-reported field/laboratory measurement');
              }}
              className="mt-0.5 text-amber-600 focus:ring-amber-500"
            />
            <div>
              <span className="text-xs font-bold text-slate-800 block">Farmer Lab Measurements</span>
              <span className="text-[11px] text-slate-500 block leading-tight mt-0.5">
                Direct on-farm chemical soil test results from soil testing lab or portable sensor kit.
              </span>
            </div>
          </label>

          <label
            className={`p-3 rounded-xl border flex items-start space-x-3 cursor-pointer transition-all ${
              sourceType === 'agricultural_benchmark'
                ? 'bg-amber-50/60 border-amber-400 ring-1 ring-amber-400/30'
                : 'bg-white border-slate-200 hover:border-slate-300'
            }`}
          >
            <input
              type="radio"
              name="soil_source_type"
              checked={sourceType === 'agricultural_benchmark'}
              onChange={() => {
                setSourceType('agricultural_benchmark');
                if (activeBenchmark) {
                  setSourceReference(activeBenchmark.source_reference);
                } else {
                  handleLoadDistrictBenchmark();
                }
              }}
              className="mt-0.5 text-amber-600 focus:ring-amber-500"
            />
            <div>
              <span className="text-xs font-bold text-slate-800 block">Verified Agricultural Benchmark</span>
              <span className="text-[11px] text-slate-500 block leading-tight mt-0.5">
                Soil Health Card Portal (https://soilhealth.dac.gov.in/) & ANGRAU district agro-ecological baselines.
              </span>
            </div>
          </label>
        </div>

        {sourceReference && (
          <div className="text-[11px] text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200">
            <span className="font-semibold text-slate-700">Active Soil Reference: </span>
            <span className="font-mono text-slate-800">{sourceReference}</span>
          </div>
        )}
      </div>

      {/* Section 2: 10 Farmer Inputs */}
      <div className="space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
          The 10 Required Agronomic & Soil Inputs
        </h3>

        {/* Inputs 1-4: Soil Properties */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* 1. Soil Type */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
              <span>1. Soil Type</span>
              <span className="text-[10px] text-amber-700 font-semibold">Required</span>
            </label>
            <select
              value={soilType}
              onChange={(e) => setSoilType(e.target.value)}
              className="w-full text-xs font-semibold p-2 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              {COMMON_SOIL_TYPES.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
            <p className="text-[10px] text-slate-500">Major soil textural class of the parcel.</p>
          </div>

          {/* 2. Soil pH */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">2. Soil pH</label>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${phStatus.color}`}>
                {phStatus.label}
              </span>
            </div>
            <input
              type="number"
              step="0.1"
              min="3.0"
              max="11.0"
              placeholder="e.g. 6.8 (Leave blank if unknown)"
              value={soilPh}
              onChange={(e) => setSoilPh(e.target.value)}
              className="w-full text-xs font-mono p-2 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
            <p className="text-[10px] text-slate-500">Optimal crop range: 6.0 – 7.5 (ANGRAU standard).</p>
          </div>

          {/* 3a. Nitrogen (N) */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">3a. Available Nitrogen (N)</label>
              <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded border ${nStatus.color}`}>
                {nStatus.label}
              </span>
            </div>
            <input
              type="number"
              step="1"
              min="0"
              placeholder="kg/ha (optional)"
              value={nitrogenKgHa}
              onChange={(e) => setNitrogenKgHa(e.target.value)}
              className="w-full text-xs font-mono p-2 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
            <p className="text-[10px] text-slate-500">Soil Health Card: Low &lt; 140, Med 140-280, High &gt; 280</p>
          </div>

          {/* 3b. Phosphorus (P) */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">3b. Available Phosphorus (P)</label>
              <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded border ${pStatus.color}`}>
                {pStatus.label}
              </span>
            </div>
            <input
              type="number"
              step="0.5"
              min="0"
              placeholder="kg/ha (optional)"
              value={phosphorusKgHa}
              onChange={(e) => setPhosphorusKgHa(e.target.value)}
              className="w-full text-xs font-mono p-2 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
            <p className="text-[10px] text-slate-500">Soil Health Card: Low &lt; 10, Med 10-25, High &gt; 25</p>
          </div>
        </div>

        {/* Inputs 3c & 4: Potassium & Organic Carbon */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* 3c. Potassium (K) */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">3c. Available Potassium (K)</label>
              <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded border ${kStatus.color}`}>
                {kStatus.label}
              </span>
            </div>
            <input
              type="number"
              step="1"
              min="0"
              placeholder="kg/ha (optional)"
              value={potassiumKgHa}
              onChange={(e) => setPotassiumKgHa(e.target.value)}
              className="w-full text-xs font-mono p-2 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
            <p className="text-[10px] text-slate-500">Soil Health Card: Low &lt; 120, Med 120-280, High &gt; 280</p>
          </div>

          {/* 4. Organic Carbon */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">4. Organic Carbon (OC %)</label>
              <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded border ${ocStatus.color}`}>
                {ocStatus.label}
              </span>
            </div>
            <input
              type="number"
              step="0.05"
              min="0"
              max="5.0"
              placeholder="e.g. 0.45 (optional)"
              value={organicCarbonPct}
              onChange={(e) => setOrganicCarbonPct(e.target.value)}
              className="w-full text-xs font-mono p-2 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
            <p className="text-[10px] text-slate-500">Soil Health Card: Low &lt; 0.50%, Med 0.50-0.75%, High &gt; 0.75%</p>
          </div>

          {/* 8. Irrigation Source */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <label className="text-xs font-bold text-slate-700">8. Irrigation Source</label>
            <select
              value={irrigationSource}
              onChange={(e) => setIrrigationSource(e.target.value)}
              className="w-full text-xs font-semibold p-2 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              {IRRIGATION_SOURCES.map((src) => (
                <option key={src} value={src}>
                  {src}
                </option>
              ))}
            </select>
            <p className="text-[10px] text-slate-500">Key water security constraint for rabi/summer crops.</p>
          </div>

          {/* 9. Farming Season */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <label className="text-xs font-bold text-slate-700">9. Target Farming Season</label>
            <select
              value={farmingSeason}
              onChange={(e) => setFarmingSeason(e.target.value)}
              className="w-full text-xs font-semibold p-2 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              {SEASONS.map((sn) => (
                <option key={sn} value={sn}>
                  {sn}
                </option>
              ))}
            </select>
            <p className="text-[10px] text-slate-500">Primary season for the recommendation cycle.</p>
          </div>
        </div>

        {/* Inputs 5, 6, 7, 10: Crop History & Preferences */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-2">
          {/* 5. Current Standing Crop */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <label className="text-xs font-bold text-slate-700">5. Current Standing Crop</label>
            <select
              value={currentCrop}
              onChange={(e) => setCurrentCrop(e.target.value)}
              className="w-full text-xs font-semibold p-2 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              <option value="">-- None / Fallow --</option>
              {crops.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.telugu_name ? `(${c.telugu_name})` : ''}
                </option>
              ))}
            </select>
            <p className="text-[10px] text-slate-500">
              Evaluates monoculture penalties and biological nitrogen balance.
            </p>
          </div>

          {/* 6. Previous Crops History */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <label className="text-xs font-bold text-slate-700">6. Previous Crops History (Past 2-3 Seasons)</label>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1.5 bg-slate-50 rounded-lg border border-slate-200">
              {crops.map((c) => {
                const isSelected = previousCrops.includes(c.id);
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => handleToggleCrop(c.id, previousCrops, setPreviousCrops)}
                    className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                      isSelected
                        ? 'bg-amber-600 text-white font-bold shadow-xs'
                        : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {c.name}
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] text-slate-500">Helps break pest/pathogen carryover cycles.</p>
          </div>

          {/* 7. Available Feasible Crops */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <label className="text-xs font-bold text-slate-700">7. Available Feasible Crops for Farmer</label>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1.5 bg-slate-50 rounded-lg border border-slate-200">
              {crops.map((c) => {
                const isSelected = availableCrops.includes(c.id);
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => handleToggleCrop(c.id, availableCrops, setAvailableCrops)}
                    className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                      isSelected
                        ? 'bg-emerald-600 text-white font-bold shadow-xs'
                        : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {c.name}
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] text-slate-500">Crops with local seed availability and market access.</p>
          </div>

          {/* 10. Farmer's Preferred Crops */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5">
            <label className="text-xs font-bold text-slate-700">10. Farmer's Preferred Crops</label>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1.5 bg-slate-50 rounded-lg border border-slate-200">
              {crops.map((c) => {
                const isSelected = preferredCrops.includes(c.id);
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => handleToggleCrop(c.id, preferredCrops, setPreferredCrops)}
                    className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                      isSelected
                        ? 'bg-purple-600 text-white font-bold shadow-xs'
                        : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {c.name}
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] text-slate-500">Farmer's economic and dietary crop preferences.</p>
          </div>
        </div>
      </div>

      {/* Profile Active Status Summary Card */}
      {savedProfile && (
        <div className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/50 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <span className="font-bold text-emerald-950">Active Saved Profile: </span>
              <span className="text-emerald-800">
                {savedProfile.soil_type} • pH {savedProfile.soil_ph ?? 'Unknown'} ({savedProfile.ph_classification}) •
                Season: {savedProfile.farming_season} • Irrigation: {savedProfile.irrigation_source}
              </span>
            </div>
          </div>
          <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded">
            Source: {savedProfile.soil_source_type}
          </span>
        </div>
      )}
    </div>
  );
};