import React, { useEffect, useState } from 'react';
import { AlertTriangle, Bell, CheckCircle2, RefreshCw } from 'lucide-react';
import { apiService } from '../services/api';

type AlertRecord = {
  id: string; farm_id: string; alert_type: string; severity: string; title: string;
  message: string; observed_value: number; threshold_value: number; unit: string;
  source: string; observed_at: string; acknowledged_at?: string | null;
};

type Props = { farmId?: string | null };

export const FarmAlertCenter: React.FC<Props> = ({ farmId }) => {
  const [alerts, setAlerts] = useState<AlertRecord[]>([]);
  const [rainfall, setRainfall] = useState('');
  const [temperature, setTemperature] = useState('');
  const [moisture, setMoisture] = useState('');
  const [source, setSource] = useState('Farmer / local weather observation');
  const [observedAt, setObservedAt] = useState(() => new Date().toISOString().slice(0, 16));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const refresh = async () => {
    try { setAlerts(await apiService.getFarmAlerts(farmId || undefined)); }
    catch (e: any) { setError(e.message || 'Unable to load alerts'); }
  };
  useEffect(() => { refresh(); }, [farmId]);

  const evaluate = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!farmId) { setError('Select and save a farm before evaluating alerts.'); return; }
    const payload: any = { farm_id: farmId, source, observed_at: new Date(observedAt).toISOString() };
    if (rainfall.trim() !== '') payload.rainfall_24h_mm = Number(rainfall);
    if (temperature.trim() !== '') payload.max_temperature_c = Number(temperature);
    if (moisture.trim() !== '') payload.soil_moisture_pct = Number(moisture);
    if (![payload.rainfall_24h_mm, payload.max_temperature_c, payload.soil_moisture_pct].some(v => v !== undefined && Number.isFinite(v))) {
      setError('Enter at least one measured observation.'); return;
    }
    setBusy(true); setError(''); setNotice('');
    try {
      const result = await apiService.evaluateFarmAlerts(payload);
      setNotice(`${result.alerts_created} advisory alert(s) generated.`);
      setRainfall(''); setTemperature(''); setMoisture('');
      await refresh();
    } catch (e: any) { setError(e.message || 'Alert evaluation failed'); }
    finally { setBusy(false); }
  };

  const acknowledge = async (id: string) => {
    try { await apiService.acknowledgeFarmAlert(id); await refresh(); }
    catch (e: any) { setError(e.message || 'Could not acknowledge alert'); }
  };

  const severityClass = (severity: string) => severity === 'critical' ? 'bg-rose-100 text-rose-800' : severity === 'high' ? 'bg-orange-100 text-orange-800' : 'bg-amber-100 text-amber-800';

  return <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm space-y-4">
    <div className="flex items-center justify-between gap-3">
      <div className="flex items-center gap-2"><div className="rounded-xl bg-amber-50 p-2 text-amber-700"><Bell className="h-5 w-5" /></div><div><h2 className="font-bold text-slate-900">Farm Alerts & Early Advisories</h2><p className="text-xs text-slate-500">Evaluate measured observations for a selected farm</p></div></div>
      <button type="button" onClick={refresh} className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50" aria-label="Refresh alerts"><RefreshCw className="h-4 w-4" /></button>
    </div>
    <form onSubmit={evaluate} className="grid grid-cols-1 gap-3 md:grid-cols-2">
      <label className="text-xs font-semibold text-slate-600">24-hour rainfall (mm)<input type="number" min="0" max="2000" step="0.1" value={rainfall} onChange={e => setRainfall(e.target.value)} placeholder="Enter measured rainfall" className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm font-normal" /></label>
      <label className="text-xs font-semibold text-slate-600">Maximum temperature (°C)<input type="number" min="-20" max="65" step="0.1" value={temperature} onChange={e => setTemperature(e.target.value)} placeholder="Enter measured temperature" className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm font-normal" /></label>
      <label className="text-xs font-semibold text-slate-600">Soil moisture (%)<input type="number" min="0" max="100" step="0.1" value={moisture} onChange={e => setMoisture(e.target.value)} placeholder="Enter measured soil moisture" className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm font-normal" /></label>
      <label className="text-xs font-semibold text-slate-600">Observation source<input value={source} onChange={e => setSource(e.target.value)} required maxLength={120} className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm font-normal" /></label>
      <label className="text-xs font-semibold text-slate-600 md:col-span-2">Observation date and time<input type="datetime-local" value={observedAt} onChange={e => setObservedAt(e.target.value)} required className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm font-normal" /></label>
      <button disabled={busy || !farmId} className="md:col-span-2 rounded-xl bg-emerald-700 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-800 disabled:cursor-not-allowed disabled:opacity-50">{busy ? 'Evaluating…' : 'Evaluate observations'}</button>
    </form>
    {!farmId && <p className="text-xs text-amber-700">Select a saved farm to create and view its alerts.</p>}
    {error && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-xs text-rose-700">{error}</p>}
    {notice && <p className="rounded-lg bg-emerald-50 p-3 text-xs text-emerald-700">{notice}</p>}
    <div className="space-y-2">
      <h3 className="text-sm font-bold text-slate-800">Recent alerts</h3>
      {alerts.length === 0 ? <p className="rounded-lg bg-slate-50 p-4 text-xs text-slate-500">No alerts recorded for this view yet.</p> : alerts.map(alert => <div key={alert.id} className="rounded-xl border border-slate-200 p-3">
        <div className="flex flex-wrap items-center justify-between gap-2"><div className="flex items-center gap-2"><AlertTriangle className="h-4 w-4 text-amber-600" /><strong className="text-sm text-slate-800">{alert.title}</strong></div><span className={`rounded-full px-2 py-1 text-[10px] font-bold uppercase ${severityClass(alert.severity)}`}>{alert.severity}</span></div>
        <p className="mt-2 text-xs text-slate-600">{alert.message}</p>
        <p className="mt-1 text-[10px] text-slate-400">{alert.source} · {new Date(alert.observed_at).toLocaleString()}</p>
        {alert.acknowledged_at ? <span className="mt-2 inline-flex items-center gap-1 text-[10px] text-emerald-700"><CheckCircle2 className="h-3 w-3"/> Acknowledged</span> : <button type="button" onClick={() => acknowledge(alert.id)} className="mt-2 text-xs font-semibold text-emerald-700 hover:underline">Mark as reviewed</button>}
      </div>)}
    </div>
    <p className="text-[10px] leading-relaxed text-slate-500">These are screening advisories based on observations you provide, not official forecasts or government disaster warnings. Thresholds are configurable screening rules and do not replace local authority instructions.</p>
  </section>;
};
