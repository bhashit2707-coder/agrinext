import React, { useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine
} from 'recharts';
import {
  Droplets,
  ExternalLink,
  ShieldAlert,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  Minus,
  RefreshCw,
  Info,
  Lock
} from 'lucide-react';
import { apiService } from '../services/api';
import type { NASASMAPResponse, FarmProfile } from '../types';

interface NASASMAPModuleProps {
  activeFarm: FarmProfile | null;
  defaultCoords: { lat: number; lng: number };
  onEvidenceLoaded?: (evidence: any) => void;
}

export const NASASMAPModule: React.FC<NASASMAPModuleProps> = ({
  activeFarm,
  defaultCoords,
  onEvidenceLoaded
}) => {
  const [data, setData] = useState<NASASMAPResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const targetCoords = activeFarm
    ? { lat: activeFarm.latitude, lng: activeFarm.longitude }
    : defaultCoords;

  const handleFetchSMAP = async (forceRefresh: boolean = false) => {
    setLoading(true);
    setError(null);
    try {
      const response = await apiService.queryNASASMAP({
        latitude: targetCoords.lat,
        longitude: targetCoords.lng,
        farm_id: activeFarm?.id,
        use_cache: !forceRefresh
      });
      setData(response);
      if (onEvidenceLoaded && response.evidence_object) {
        onEvidenceLoaded(response.evidence_object);
      }
    } catch (err: any) {
      console.error('NASA SMAP query error:', err);
      setError(err.message || 'Failed to query NASA SMAP SPL3SMP_E V6.');
    } finally {
      setLoading(false);
    }
  };

  const getRegimeColor = (regime?: string) => {
    switch (regime) {
      case 'deficit':
        return 'bg-amber-100 text-amber-900 border-amber-300';
      case 'adequate':
        return 'bg-emerald-100 text-emerald-900 border-emerald-300';
      case 'surplus':
        return 'bg-blue-100 text-blue-900 border-blue-300';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const renderTrendIcon = (trend?: string) => {
    if (trend === 'drying') {
      return <TrendingDown className="w-4 h-4 text-amber-600" />;
    } else if (trend === 'wetting') {
      return <TrendingUp className="w-4 h-4 text-emerald-600" />;
    }
    return <Minus className="w-4 h-4 text-slate-500" />;
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-5">
      {/* Module Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
              Dataset A
            </span>
            <h2 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
              <Droplets className="w-5 h-5 text-amber-600" />
              <span>NASA SMAP Soil Moisture (SPL3SMP_E V6)</span>
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Enhanced L3 Radiometer Daily 9 km EASE-Grid 2.0 surface soil moisture (0-5 cm volumetric fraction).
          </p>
        </div>

        {/* Documentation link and Action button */}
        <div className="flex items-center space-x-3">
          <a
            href="https://nsidc.org/data/spl3smp_e/versions/6"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs font-medium text-amber-700 hover:text-amber-800 flex items-center space-x-1"
          >
            <span>NSIDC Docs</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <button
            type="button"
            onClick={() => handleFetchSMAP(false)}
            disabled={loading}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold text-xs flex items-center space-x-2 transition-all shadow-md shadow-amber-900/20"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? 'Retrieving SMAP...' : data ? 'Refresh SMAP' : 'Retrieve SMAP V6'}</span>
          </button>
        </div>
      </div>

      {/* Spatial Limitation Warning Banner */}
      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-600 flex items-start space-x-2.5">
        <Info className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-slate-800">Spatial Resolution Boundary (~9 km): </span>
          Native resolution is 9 km x 9 km EASE-Grid 2.0 (~81 km²). A typical farm (2-10 acres) is orders of magnitude
          smaller than a single grid cell. SMAP characterizes regional macro surface moisture, not on-farm probe readings.
          Never claim this product provides independently measured conditions for each isolated acre.
        </div>
      </div>

      {/* Unconfigured / Auth Required State */}
      {data?.status === 'auth_required' && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 space-y-2">
          <div className="flex items-center space-x-2">
            <Lock className="w-5 h-5 text-amber-600 shrink-0" />
            <h3 className="text-sm font-bold">NASA Earthdata Login Required (AppEEARS V006)</h3>
          </div>
          <p className="text-xs leading-relaxed text-amber-800">
            {data.message}
          </p>
          <div className="text-[11px] bg-white/70 p-2.5 rounded-lg border border-amber-200/80 font-mono text-slate-700">
            Register for free at <a href="https://urs.earthdata.nasa.gov/" target="_blank" rel="noopener noreferrer" className="text-cyan-700 underline font-sans">urs.earthdata.nasa.gov</a> and configure <code>EARTHDATA_USERNAME</code> and <code>EARTHDATA_PASSWORD</code> in <code>backend/.env</code>.
          </div>
        </div>
      )}

      {/* Unavailable State */}
      {data?.status === 'unavailable' && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-900 flex items-start space-x-2">
          <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div>
            <h3 className="text-sm font-bold">NASA AppEEARS Service Currently Unreachable</h3>
            <p className="text-xs mt-1 text-red-800">{data.message}</p>
          </div>
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs">
          <b>Error:</b> {error}
        </div>
      )}

      {/* Connected & Retrieved SMAP Evidence */}
      {data?.status === 'success' && data.evidence_object && (
        <div className="space-y-4">
          {/* Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
            {/* Mean Surface Moisture */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
              <span className="text-[11px] font-semibold uppercase text-slate-500">Surface Moisture (0-5cm)</span>
              <div className="flex items-baseline space-x-1.5 mt-1">
                <span className="text-2xl font-bold text-slate-900 font-mono">
                  {data.mean_moisture_m3_m3?.toFixed(3)}
                </span>
                <span className="text-xs text-slate-500 font-medium">m³/m³</span>
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Volumetric fraction</span>
            </div>

            {/* Moisture Regime */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
              <span className="text-[11px] font-semibold uppercase text-slate-500">Moisture Regime</span>
              <div className="mt-1.5">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold capitalize border ${getRegimeColor(data.regime)}`}>
                  {data.regime}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                {data.evidence_object.regime_description}
              </p>
            </div>

            {/* Trend Indicator */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
              <span className="text-[11px] font-semibold uppercase text-slate-500">Soil Moisture Trend</span>
              <div className="flex items-center space-x-1.5 mt-1">
                {renderTrendIcon(data.trend)}
                <span className="text-sm font-bold text-slate-800 capitalize font-mono">
                  {data.trend}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Δ {data.evidence_object.trend_indicator?.delta_m3_m3 > 0 ? '+' : ''}{data.evidence_object.trend_indicator?.delta_m3_m3} m³/m³
              </p>
            </div>

            {/* Quality Summary */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
              <span className="text-[11px] font-semibold uppercase text-slate-500">Quality Flags</span>
              <div className="flex items-center space-x-1.5 mt-1">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span className="text-sm font-bold text-slate-900 font-mono">
                  {data.quality_summary?.recommended_quality_pct}%
                </span>
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">
                {data.quality_summary?.valid_count} valid / {data.quality_summary?.missing_count} fill filtered
              </span>
            </div>
          </div>

          {/* Observations Chart (if readings available) */}
          {data.recent_readings && data.recent_readings.length > 0 && (
            <div className="p-4 rounded-xl border border-slate-200/70 bg-white">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-800">
                  Daily Surface Soil Moisture Series ({data.product})
                </span>
                <span className="text-[11px] text-slate-500">Optimal Range: 0.12 - 0.25 m³/m³</span>
              </div>
              <div className="h-44 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.recent_readings}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis
                      dataKey="date"
                      tick={{ fontSize: 10 }}
                      stroke="#94a3b8"
                      tickFormatter={(d) => d.slice(5)}
                    />
                    <YAxis
                      domain={[0, 0.4]}
                      tick={{ fontSize: 10 }}
                      stroke="#94a3b8"
                      tickFormatter={(v) => `${v.toFixed(2)}`}
                    />
                    <Tooltip
                      formatter={(val: any) => [`${Number(val).toFixed(3)} m³/m³`, 'Soil Moisture']}
                      labelFormatter={(lbl) => `Date: ${lbl}`}
                    />
                    <ReferenceLine y={0.12} stroke="#f59e0b" strokeDasharray="3 3" label={{ value: 'Deficit threshold', fill: '#f59e0b', fontSize: 10 }} />
                    <ReferenceLine y={0.25} stroke="#3b82f6" strokeDasharray="3 3" label={{ value: 'Surplus threshold', fill: '#3b82f6', fontSize: 10 }} />
                    <Line
                      type="monotone"
                      dataKey="soil_moisture"
                      stroke="#d97706"
                      strokeWidth={2}
                      dot={{ r: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Evidence Provenance Footer */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-[11px] text-slate-500">
            <div>
              Source: <b className="text-slate-700">NASA NSIDC DAAC / AppEEARS</b> • Layer: <code>Soil_Moisture_Retrieval_Data_AM</code>
            </div>
            <div>
              Evidence ID: <code className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-700">{data.evidence_object.evidence_id}</code>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
