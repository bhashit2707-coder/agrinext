import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Search,
  Calendar,
  Droplets,
  Thermometer,
  ShieldAlert,
  Repeat,
  MapPin,
  ChevronDown,
  ChevronUp,
  Layers,
  Sprout,
  Info
} from 'lucide-react';
import { apiService } from '../services/api';
import type { CropKnowledgeProfile } from '../types';

export const CropKnowledgeModule: React.FC = () => {
  const [crops, setCrops] = useState<CropKnowledgeProfile[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSeason, setSelectedSeason] = useState<string>('all');
  const [selectedFamily, setSelectedFamily] = useState<string>('all');
  const [expandedCropId, setExpandedCropId] = useState<string | null>(null);

  useEffect(() => {
    async function loadCatalog() {
      try {
        setLoading(true);
        setError(null);
        const data = await apiService.getCropKnowledge();
        setCrops(data);
        if (data.length > 0) {
          setExpandedCropId(data[0].id); // Expand first crop by default
        }
      } catch (err: any) {
        console.error('Failed to load crop knowledge catalog:', err);
        setError(err.message || 'Unable to load ANGRAU/ICAR crop knowledge catalog.');
      } finally {
        setLoading(false);
      }
    }

    loadCatalog();
  }, []);

  const families = ['all', ...Array.from(new Set(crops.map((c) => c.crop_family)))];

  const filteredCrops = crops.filter((crop) => {
    const matchesSearch =
      crop.crop_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (crop.telugu_name && crop.telugu_name.toLowerCase().includes(searchQuery.toLowerCase())) ||
      crop.crop_family.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (crop.scientific_name && crop.scientific_name.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesSeason =
      selectedSeason === 'all' ||
      crop.growing_season.some((s) => s.toLowerCase() === selectedSeason.toLowerCase());

    const matchesFamily =
      selectedFamily === 'all' || crop.crop_family === selectedFamily;

    return matchesSearch && matchesSeason && matchesFamily;
  });

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-6">
      {/* Module Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
              Crop Knowledge Base
            </span>
            <h2 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-emerald-600" />
              <span>Verified Andhra Pradesh Crop Knowledge Catalog</span>
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Official agronomic profiles codified from ANGRAU Vyavasaya Panchangam (2023-2024) and ICAR-CRIDA contingency plans.
          </p>
        </div>

        <div className="text-right">
          <span className="text-xs font-semibold text-slate-500">Verified Profiles: </span>
          <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
            {crops.length} Andhra Pradesh Crops
          </span>
        </div>
      </div>

      {/* Scientific Integrity Notice */}
      <div className="p-3.5 rounded-xl bg-emerald-50/60 border border-emerald-200 text-xs text-emerald-950 flex items-start space-x-2.5">
        <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Agronomic Authority & Integrity Rule: </span>
          Crop biological parameters, thermal/water stress thresholds, and rotation compatibility are strictly extracted from
          <b> ANGRAU (Acharya N.G. Ranga Agricultural University)</b> and <b>ICAR-CRIDA</b> documentation. No values are fabricated.
          This local agricultural knowledge operates in synergy with farmer ground-truth soil tests and NASA regional Earth observations.
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200/80">
        {/* Search */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search crop, Telugu name, or botanical family..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        {/* Season Filter */}
        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-500 font-medium">Season:</span>
          <select
            value={selectedSeason}
            onChange={(e) => setSelectedSeason(e.target.value)}
            className="p-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          >
            <option value="all">All Seasons</option>
            <option value="kharif">Kharif</option>
            <option value="rabi">Rabi</option>
            <option value="summer">Summer</option>
          </select>
        </div>

        {/* Family Filter */}
        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-500 font-medium">Botanical Family:</span>
          <select
            value={selectedFamily}
            onChange={(e) => setSelectedFamily(e.target.value)}
            className="p-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500 max-w-[200px]"
          >
            {families.map((f) => (
              <option key={f} value={f}>
                {f === 'all' ? 'All Families' : f}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading && (
        <div className="p-8 text-center text-xs text-slate-500">
          Loading verified crop knowledge catalog...
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs">
          {error}
        </div>
      )}

      {/* Crop Cards List */}
      <div className="space-y-3.5">
        {filteredCrops.map((crop) => {
          const isExpanded = expandedCropId === crop.id;

          return (
            <div
              key={crop.id}
              className={`rounded-xl border transition-all ${
                isExpanded
                  ? 'border-emerald-300 bg-white shadow-sm'
                  : 'border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              {/* Card Header / Summary Row */}
              <div
                onClick={() => setExpandedCropId(isExpanded ? null : crop.id)}
                className="p-4 flex flex-wrap items-center justify-between gap-3 cursor-pointer select-none"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700 font-bold text-sm shrink-0">
                    <Sprout className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="text-sm font-bold text-slate-900">{crop.crop_name}</h3>
                      {crop.telugu_name && (
                        <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                          {crop.telugu_name}
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px] text-slate-500">
                      <span className="font-semibold text-slate-600 font-serif italic">
                        {crop.scientific_name || 'N/A'}
                      </span>
                      <span>•</span>
                      <span className="text-purple-700 font-semibold bg-purple-50 px-1.5 py-0.2 rounded border border-purple-100">
                        {crop.crop_family}
                      </span>
                      <span>•</span>
                      <span className="text-slate-600">{crop.category}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  {/* Quick indicators */}
                  <div className="hidden sm:flex items-center space-x-3 text-xs">
                    <span className="text-slate-500">
                      Water: <b className="text-slate-700 font-mono">{crop.water_requirement_mm[0]}–{crop.water_requirement_mm[1]} mm</b>
                    </span>
                    <span className="text-slate-500">
                      Duration: <b className="text-slate-700 font-mono">{crop.crop_duration_days[0]}–{crop.crop_duration_days[1]} d</b>
                    </span>
                  </div>

                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Expanded Full Agronomic Detail */}
              {isExpanded && (
                <div className="p-4 border-t border-slate-100 bg-slate-50/50 space-y-4 text-xs">
                  {/* Row 1: Key Agronomic Parameters */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="p-3 bg-white rounded-lg border border-slate-200">
                      <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1 flex items-center space-x-1">
                        <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Seasons & Duration</span>
                      </span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {crop.growing_season.map((s) => (
                          <span key={s} className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700">
                            {s}
                          </span>
                        ))}
                      </div>
                      <p className="text-xs font-mono font-bold text-slate-800 mt-1.5">
                        {crop.crop_duration_days[0]} – {crop.crop_duration_days[1]} Days
                      </p>
                    </div>

                    <div className="p-3 bg-white rounded-lg border border-slate-200">
                      <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1 flex items-center space-x-1">
                        <Droplets className="w-3.5 h-3.5 text-blue-600" />
                        <span>Water Requirement</span>
                      </span>
                      <p className="text-base font-bold font-mono text-blue-700 mt-1">
                        {crop.water_requirement_mm[0]} – {crop.water_requirement_mm[1]} mm
                      </p>
                      <p className="text-[10px] text-slate-500 mt-0.5">
                        Status: {crop.water_requirement_status || 'Verified Range'}
                      </p>
                    </div>

                    <div className="p-3 bg-white rounded-lg border border-slate-200">
                      <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1 flex items-center space-x-1">
                        <Thermometer className="w-3.5 h-3.5 text-amber-600" />
                        <span>Heat Sensitivity</span>
                      </span>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                          {crop.heat_sensitivity.rating}
                        </span>
                        {crop.heat_sensitivity.critical_temperature_celsius && (
                          <span className="font-mono text-xs font-bold text-slate-700">
                            &gt; {crop.heat_sensitivity.critical_temperature_celsius}°C
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-600 mt-1 leading-tight line-clamp-2">
                        {crop.heat_sensitivity.impact}
                      </p>
                    </div>

                    <div className="p-3 bg-white rounded-lg border border-slate-200">
                      <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1 flex items-center space-x-1">
                        <ShieldAlert className="w-3.5 h-3.5 text-red-600" />
                        <span>Water-Stress Sensitivity</span>
                      </span>
                      <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-red-50 text-red-800 border border-red-200 inline-block mt-1">
                        {crop.water_stress_sensitivity.rating}
                      </span>
                      <p className="text-[10px] text-slate-600 mt-1 leading-tight line-clamp-2">
                        {crop.water_stress_sensitivity.drought_adaptation}
                      </p>
                    </div>
                  </div>

                  {/* Row 2: Soil Suitability & Nutrient Demands */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {/* Soil Suitability */}
                    <div className="p-3.5 bg-white rounded-lg border border-slate-200 space-y-2">
                      <h4 className="text-xs font-bold text-slate-800 flex items-center space-x-1.5">
                        <Layers className="w-3.5 h-3.5 text-amber-600" />
                        <span>Soil Suitability & pH Tolerance</span>
                      </h4>
                      <div className="space-y-1 text-[11px]">
                        <div>
                          <span className="font-semibold text-slate-600">Suitable Soils: </span>
                          <span className="text-slate-800">{crop.soil_suitability.suitable_soil_types.join(', ')}</span>
                        </div>
                        {crop.soil_suitability.unsuitable_soil_types && crop.soil_suitability.unsuitable_soil_types.length > 0 && (
                          <div>
                            <span className="font-semibold text-red-700">Avoid: </span>
                            <span className="text-red-900">{crop.soil_suitability.unsuitable_soil_types.join(', ')}</span>
                          </div>
                        )}
                        <div>
                          <span className="font-semibold text-slate-600">Optimal pH: </span>
                          <span className="font-mono text-emerald-700 font-bold">
                            {crop.soil_suitability.optimal_ph_range[0]} – {crop.soil_suitability.optimal_ph_range[1]}
                          </span>
                        </div>
                        <div className="text-slate-600 text-[10px] pt-1 border-t border-slate-100">
                          {crop.soil_suitability.drainage_requirement}
                        </div>
                      </div>
                    </div>

                    {/* Nutrient Requirements */}
                    <div className="p-3.5 bg-white rounded-lg border border-slate-200 space-y-2">
                      <h4 className="text-xs font-bold text-slate-800 flex items-center space-x-1.5">
                        <Sprout className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Nutrient Requirements & Nitrogen Impact</span>
                      </h4>
                      <div className="space-y-1.5 text-[11px]">
                        {crop.nutrient_requirements.recommended_npk_kg_ha && (
                          <div className="flex items-center space-x-2">
                            <span className="font-semibold text-slate-600">Recommended NPK: </span>
                            <span className="font-mono text-xs font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                              {crop.nutrient_requirements.recommended_npk_kg_ha.nitrogen} N :{' '}
                              {crop.nutrient_requirements.recommended_npk_kg_ha.phosphorus} P :{' '}
                              {crop.nutrient_requirements.recommended_npk_kg_ha.potassium} K kg/ha
                            </span>
                          </div>
                        )}
                        <div className="flex items-center space-x-2">
                          <span className="font-semibold text-slate-600">Nitrogen Balance: </span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              crop.nutrient_requirements.nitrogen_impact === 'fixing'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {crop.nutrient_requirements.nitrogen_impact.toUpperCase()}
                            {crop.nutrient_requirements.biological_nitrogen_fixation_kg_ha && (
                              <span> (+{crop.nutrient_requirements.biological_nitrogen_fixation_kg_ha} kg BNF/ha)</span>
                            )}
                          </span>
                        </div>
                        {crop.nutrient_requirements.gypsum_recommendation_kg_ha && (
                          <p className="text-[10px] text-slate-600">
                            Gypsum Recommendation: <b>{crop.nutrient_requirements.gypsum_recommendation_kg_ha} kg/ha</b> (pod filling & Ca/S supply)
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Row 3: Rotation Compatibility */}
                  <div className="p-3.5 bg-white rounded-lg border border-slate-200 space-y-2">
                    <h4 className="text-xs font-bold text-slate-800 flex items-center space-x-1.5">
                      <Repeat className="w-3.5 h-3.5 text-purple-600" />
                      <span>Rotation Compatibility & Pest Break Guidelines</span>
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px]">
                      <div>
                        <span className="font-semibold text-emerald-800 block">Beneficial Predecessors:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {crop.rotation_compatibility.beneficial_predecessors.map((p) => (
                            <span key={p} className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded font-medium border border-emerald-100">
                              {p}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div>
                        <span className="font-semibold text-red-800 block">Incompatible Predecessors (Avoid Monoculture):</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {crop.rotation_compatibility.incompatible_predecessors.map((p) => (
                            <span key={p} className="px-2 py-0.5 bg-red-50 text-red-700 rounded font-medium border border-red-100">
                              {p}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-600 pt-1 border-t border-slate-100 italic">
                      <b>Agronomic Rationale: </b>{crop.rotation_compatibility.rotational_benefits} • {crop.rotation_compatibility.pest_cycle_breaks}
                    </p>
                  </div>

                  {/* Row 4: Local Cultivation Evidence & Official Citations */}
                  <div className="p-3 bg-emerald-50/50 rounded-lg border border-emerald-200/80 space-y-1.5 text-[11px]">
                    <div className="flex items-center space-x-1.5 font-bold text-emerald-950">
                      <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Local Cultivation Evidence (Andhra Pradesh):</span>
                    </div>
                    <p className="text-slate-700 leading-relaxed">
                      {crop.local_cultivation_evidence}
                    </p>
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-emerald-200/60 text-[10px] text-emerald-900">
                      <span>
                        <b>Primary Authority:</b> {crop.source_and_reference_date.primary_authority} — <i>{crop.source_and_reference_date.publication}</i> ({crop.source_and_reference_date.reference_year})
                      </span>
                      {crop.source_and_reference_date.secondary_reference && (
                        <span className="text-slate-500">
                          Ref: {crop.source_and_reference_date.secondary_reference}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};