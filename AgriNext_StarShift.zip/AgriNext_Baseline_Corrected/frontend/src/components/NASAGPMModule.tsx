import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';
import {
  CloudRain,
  ExternalLink,
  ShieldCheck,
  ShieldAlert,
  Scale,
  RefreshCw,
  Info,
  ChevronDown,
  ChevronUp,
  Lock,
  Sparkles
} from 'lucide-react';
import { apiService } from '../services/api';
import type { NASAGPMResponse, FarmProfile } from '../types';

interface NASAGPMModuleProps {
  activeFarm: FarmProfile | null;
  defaultCoords: { lat: number; lng: number };
  onEvidenceLoaded?: (evidence: any) => void;
}

export const NASAGPMModule: React.FC<NASAGPMModuleProps> = ({
  activeFarm,
  defaultCoords,
  onEvidenceLoaded
}) => {
  const [data, setData] = useState<NASAGPMResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState<boolean>(false);

  const targetCoords = activeFarm
    ? { lat: activeFarm.latitude, lng: activeFarm.longitude }
    : defaultCoords;

  const handleFetchGPM = async (forceRefresh: boolean = false) => {
    setLoading(true);
    setError(null);
    try {
      const response = await apiService.queryNASAGPM({
        latitude: targetCoords.lat,
        longitude: targetCoords.lng,
        farm_id: activeFarm?.id,
        use_cache: !forceRefresh,
        compare_with_power: true
      });
      setData(response);
      if (onEvidenceLoaded && response.evidence_object) {
        onEvidenceLoaded(response.evidence_object);
      }
    } catch (err: any) {
      console.error('NASA GPM query error:', err);
      setError(err.message || 'Failed to query NASA GPM IMERG V07.');
    } finally {
      setLoading(false);
    }
  };

  const getConcordanceBadge = (concordance?: string) => {
    switch (concordance) {
      case 'High':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Moderate':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'Divergent':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-5">
      {/* Module Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">
              Dataset B
            </span>
            <h2 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
              <CloudRain className="w-5 h-5 text-blue-600" />
              <span>NASA GPM IMERG Precipitation (V07 Final Run)</span>
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            GPM_3IMERGDF 0.1° (~10 km) daily satellite radar (Ku/Ka-band) & microwave radiometer estimates.
          </p>
        </div>

        {/* Documentation link and Action button */}
        <div className="flex items-center space-x-3">
          <a
            href="https://gpm.nasa.gov/data/directory"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs font-medium text-blue-700 hover:text-blue-800 flex items-center space-x-1"
          >
            <span>GPM Directory</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <button
            type="button"
            onClick={() => handleFetchGPM(false)}
            disabled={loading}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs flex items-center space-x-2 transition-all shadow-md shadow-blue-900/20"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? 'Retrieving GPM...' : data ? 'Refresh GPM' : 'Retrieve GPM V07'}</span>
          </button>
        </div>
      </div>

      {/* Spatial Limitation Warning Banner */}
      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-600 flex items-start space-x-2.5">
        <Info className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-slate-800">Spatial Resolution Boundary (~10 km): </span>
          Native resolution is 0.1° x 0.1° (~10 km grid cell, ~100 km²). A farm parcel is orders of magnitude smaller
          than a single grid cell. GPM IMERG provides satellite constellation radar/radiometer macro rainfall estimates,
          not an in-situ rain gauge on each acre. Never claim this product provides independently measured conditions for each acre.
        </div>
      </div>

      {/* Unconfigured / Auth Required State */}
      {data?.status === 'auth_required' && (
        <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 space-y-2">
          <div className="flex items-center space-x-2">
            <Lock className="w-5 h-5 text-blue-600 shrink-0" />
            <h3 className="text-sm font-bold">NASA Earthdata Login Required (GES DISC V07)</h3>
          </div>
          <p className="text-xs leading-relaxed text-blue-800">
            {data.message}
          </p>
          <div className="text-[11px] bg-white/70 p-2.5 rounded-lg border border-blue-200/80 font-mono text-slate-700">
            Register for free at <a href="https://urs.earthdata.nasa.gov/" target="_blank" rel="noopener noreferrer" className="text-blue-700 underline font-sans">urs.earthdata.nasa.gov</a> and configure <code>EARTHDATA_USERNAME</code> and <code>EARTHDATA_PASSWORD</code> in <code>backend/.env</code>.
          </div>
        </div>
      )}

      {/* Unavailable State */}
      {data?.status === 'unavailable' && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-900 flex items-start space-x-2">
          <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div>
            <h3 className="text-sm font-bold">NASA GES DISC Service Unreachable</h3>
            <p className="text-xs mt-1 text-red-800">{data.message}</p>
          </div>
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs">
          <b>Error:</b> {error}
        </div>
      )}

      {/* Connected & Retrieved GPM Evidence */}
      {data?.status === 'success' && data.evidence_object && (
        <div className="space-y-4">
          {/* Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
            {/* Annual Precipitation */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
              <span className="text-[11px] font-semibold uppercase text-slate-500">Annual Satellite Rain</span>
              <div className="flex items-baseline space-x-1.5 mt-1">
                <span className="text-2xl font-bold text-slate-900 font-mono">
                  {data.annual_precipitation_mm}
                </span>
                <span className="text-xs text-slate-500 font-medium">mm/year</span>
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Final Run V07</span>
            </div>

            {/* Peak Daily Convective Rain */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
              <span className="text-[11px] font-semibold uppercase text-slate-500">Peak Convective Rain</span>
              <div className="flex items-baseline space-x-1.5 mt-1">
                <span className="text-2xl font-bold text-blue-800 font-mono">
                  {data.max_daily_rain_mm ?? data.evidence_object.statistics?.max_single_day_rain_mm}
                </span>
                <span className="text-xs text-slate-500 font-medium">mm/day</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">Max single-day event</span>
            </div>

            {/* Gauge Calibration */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
              <span className="text-[11px] font-semibold uppercase text-slate-500">Surface Calibration</span>
              <div className="mt-1 flex items-center space-x-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-slate-800">GPCC Monthly</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">Global gauge-adjusted</span>
            </div>

            {/* Grid Resolution */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
              <span className="text-[11px] font-semibold uppercase text-slate-500">Native Resolution</span>
              <div className="mt-1">
                <span className="text-xs font-mono font-bold text-slate-900">0.1° x 0.1°</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">~10 km spatial cell</span>
            </div>
          </div>

          {/* NASA POWER vs NASA GPM Comparison Card */}
          {data.power_comparison && (
            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/40 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center space-x-2">
                  <Scale className="w-4 h-4 text-blue-700" />
                  <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Comparative Synthesis: NASA GPM vs NASA POWER Precipitation
                  </span>
                </div>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${getConcordanceBadge(data.power_comparison.comparison_summary.concordance)}`}>
                  {data.power_comparison.comparison_summary.concordance} Concordance
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-3 rounded-xl border border-blue-100 text-xs">
                <div>
                  <span className="text-slate-500">GPM Satellite:</span>
                  <p className="font-mono font-bold text-slate-900 text-sm">
                    {data.power_comparison.comparison_summary.gpm_annual_rainfall_mm} mm
                  </p>
                </div>
                <div>
                  <span className="text-slate-500">POWER Reanalysis:</span>
                  <p className="font-mono font-bold text-slate-900 text-sm">
                    {data.power_comparison.comparison_summary.power_annual_rainfall_mm} mm
                  </p>
                </div>
                <div>
                  <span className="text-slate-500">Difference:</span>
                  <p className="font-mono font-bold text-slate-900 text-sm">
                    {data.power_comparison.comparison_summary.difference_mm > 0 ? '+' : ''}
                    {data.power_comparison.comparison_summary.difference_mm} mm
                  </p>
                </div>
                <div>
                  <span className="text-slate-500">Variance:</span>
                  <p className="font-mono font-bold text-slate-900 text-sm">
                    {data.power_comparison.comparison_summary.percentage_variance > 0 ? '+' : ''}
                    {data.power_comparison.comparison_summary.percentage_variance}%
                  </p>
                </div>
              </div>

              {/* Expandable Scientific Explanation */}
              <div>
                <button
                  type="button"
                  onClick={() => setShowExplanation(!showExplanation)}
                  className="text-xs font-bold text-blue-700 hover:text-blue-800 flex items-center space-x-1"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>
                    {showExplanation
                      ? 'Hide Scientific Explanation of Differences'
                      : 'Why do NASA GPM and NASA POWER produce different precipitation values?'}
                  </span>
                  {showExplanation ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                {showExplanation && (
                  <div className="mt-2.5 p-3.5 bg-white rounded-xl border border-slate-200 text-xs space-y-3">
                    <p className="text-slate-600 font-medium leading-relaxed">
                      Instead of assuming both datasets must match, AgriNext explains the physical and methodological reasons for variance:
                    </p>
                    <div className="space-y-2.5">
                      {data.power_comparison.scientific_explanation_of_differences.map((item, idx) => (
                        <div key={idx} className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                          <p className="font-bold text-slate-800 text-[11px]">{item.factor}</p>
                          <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">{item.explanation}</p>
                        </div>
                      ))}
                    </div>
                    <div className="pt-2 border-t border-slate-100 text-[11px] text-blue-900">
                      <b>Agronomic Recommendation:</b> {data.power_comparison.agronomic_recommendation}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Monthly Rainfall Chart */}
          {data.monthly_rainfall && data.monthly_rainfall.length > 0 && (
            <div className="p-4 rounded-xl border border-slate-200/70 bg-white">
              <span className="text-xs font-bold text-slate-800 block mb-3">
                Monthly Satellite Precipitation Distribution ({data.product})
              </span>
              <div className="h-44 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.monthly_rainfall}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="month_label" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                    <YAxis tick={{ fontSize: 10 }} stroke="#94a3b8" tickFormatter={(v) => `${v}mm`} />
                    <Tooltip formatter={(val: any) => [`${val} mm`, 'Satellite Rainfall']} />
                    <Bar dataKey="gpm_rain_mm" fill="#2563eb" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Evidence Provenance Footer */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-[11px] text-slate-500">
            <div>
              Source: <b className="text-slate-700">NASA GES DISC / PPS</b> • Variable: <code>precipitationCal</code>
            </div>
            <div>
              Evidence ID: <code className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-700">{data.evidence_object.evidence_id}</code>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
