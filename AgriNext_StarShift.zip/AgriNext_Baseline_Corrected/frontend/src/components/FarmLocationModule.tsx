import React, { useState, useEffect, useMemo } from 'react';
import {
  MapPin,
  Maximize2,
  AlertTriangle,
  Save,
  CheckCircle2,
  Trash2,
  Satellite,
  Compass,
  FileText,
  Bookmark,
  Home,
  Navigation
} from 'lucide-react';
import { FarmMap, type LocationPointer } from './FarmMap';
import { calculateAcreageAndCentroid, geojsonToLatLngs } from '../services/turfHelper';
import { apiService } from '../services/api';
import { useNotification } from '../context/NotificationContext';
import { useAuth } from '../context/AuthContext';
import type {
  SupportedState,
  District,
  Mandal,
  Village,
  FarmProfile,
  PolygonAnalysisResponse
} from '../types';

interface FarmLocationModuleProps {
  states: SupportedState[];
  districts: District[];
  onFarmSelected?: (farm: FarmProfile) => void;
}

export const FarmLocationModule: React.FC<FarmLocationModuleProps> = ({
  states,
  districts,
  onFarmSelected
}) => {
  const { notify } = useNotification();
  const { currentUser } = useAuth();

  // Administrative selections
  const [selectedStateId, setSelectedStateId] = useState<string>('andhra_pradesh');
  const [selectedDistrictId, setSelectedDistrictId] = useState<string>(
    currentUser?.district_id || 'anantapur'
  );
  const [selectedMandalId, setSelectedMandalId] = useState<string>(
    currentUser?.mandal_id || 'anantapur_rural'
  );
  const [selectedVillageId, setSelectedVillageId] = useState<string>('');
  const [mandals, setMandals] = useState<Mandal[]>([]);
  const [villages, setVillages] = useState<Village[]>([]);
  const [loadingMandals, setLoadingMandals] = useState<boolean>(false);
  const [loadingVillages, setLoadingVillages] = useState<boolean>(false);
  const [mandalError, setMandalError] = useState<string | null>(null);
  const [villageError, setVillageError] = useState<string | null>(null);
  const [mandalRetryCount, setMandalRetryCount] = useState<number>(0);
  const [villageRetryCount, setVillageRetryCount] = useState<number>(0);

  // Dynamic Map Location Pointer
  const [locationPointer, setLocationPointer] = useState<LocationPointer | null>({
    lat: 14.6805,
    lng: 77.6005,
    title: 'Anantapur',
    subtitle: 'Anantapur District (LGD: 502)',
    type: 'district'
  });

  // Map state
  const [mapCenter, setMapCenter] = useState<[number, number]>([14.6805, 77.6005]);
  const [mapZoom, setMapZoom] = useState<number>(12);
  const [vertices, setVertices] = useState<Array<{ lat: number; lng: number }>>([]);

  // Acreage inputs
  const [manualAcreageInput, setManualAcreageInput] = useState<string>('');
  const [acreagePreference, setAcreagePreference] = useState<'polygon' | 'manual'>('polygon');
  const [farmName, setFarmName] = useState<string>('My Andhra Farm Plot');
  const [editingFarmId, setEditingFarmId] = useState<string | undefined>(undefined);

  // Persistence & Saved Farms
  const [savedFarms, setSavedFarms] = useState<FarmProfile[]>([]);
  const [saving, setSaving] = useState<boolean>(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [backendAnalysis, setBackendAnalysis] = useState<PolygonAnalysisResponse | null>(null);

  // Safe coordinate resolution
  const resolveLocationCoordinates = (
    v?: Village,
    m?: Mandal,
    d?: District
  ): { lat: number; lng: number; zoom: number } => {
    if (v && v.lat != null && v.lng != null && !isNaN(v.lat) && !isNaN(v.lng)) {
      return { lat: v.lat, lng: v.lng, zoom: 16 };
    }
    if (m && m.lat != null && m.lng != null && !isNaN(m.lat) && !isNaN(m.lng)) {
      return { lat: m.lat, lng: m.lng, zoom: 14 };
    }
    if (d && d.lat != null && d.lng != null && !isNaN(d.lat) && !isNaN(d.lng)) {
      return { lat: d.lat, lng: d.lng, zoom: 11 };
    }
    return { lat: 15.9129, lng: 79.7400, zoom: 8 }; // AP Statewide default
  };

  // 1. Load mandals whenever selectedDistrictId or retry changes
  useEffect(() => {
    let isCurrent = true;
    async function loadMandals() {
      if (!selectedStateId || !selectedDistrictId) {
        setMandals([]);
        return;
      }
      setLoadingMandals(true);
      setMandalError(null);
      try {
        const data = await apiService.getMandals(selectedStateId, selectedDistrictId);
        if (!isCurrent) return;
        setMandals(data);
        if (data.length > 0) {
          setSelectedMandalId((prev) => {
            const exists = data.find((m) => m.id === prev);
            return exists ? exists.id : data[0].id;
          });
        } else {
          setSelectedMandalId('');
          setVillages([]);
          setSelectedVillageId('');
        }
      } catch (err: any) {
        if (!isCurrent) return;
        console.error('Failed to load mandals:', err);
        setMandalError(err.message || 'Failed to load mandals. Click Retry to reload.');
        setMandals([]);
      } finally {
        if (isCurrent) setLoadingMandals(false);
      }
    }
    loadMandals();
    return () => {
      isCurrent = false;
    };
  }, [selectedStateId, selectedDistrictId, mandalRetryCount]);

  // 2. Load villages whenever selectedMandalId or retry changes
  useEffect(() => {
    let isCurrent = true;
    async function loadVillages() {
      if (!selectedStateId || !selectedDistrictId || !selectedMandalId) {
        setVillages([]);
        return;
      }
      setLoadingVillages(true);
      setVillageError(null);
      try {
        const data = await apiService.getVillages(
          selectedStateId,
          selectedMandalId,
          selectedDistrictId
        );
        if (!isCurrent) return;
        setVillages(data);

        const currentMandal = mandals.find((m) => m.id === selectedMandalId);
        const currentDist = districts.find((d) => d.id === selectedDistrictId);

        if (data.length > 0) {
          const activeVillage = data[0];
          setSelectedVillageId(activeVillage.id);
          const coords = resolveLocationCoordinates(activeVillage, currentMandal, currentDist);
          setMapCenter([coords.lat, coords.lng]);
          setMapZoom(coords.zoom);
          setLocationPointer({
            lat: coords.lat,
            lng: coords.lng,
            title: `${activeVillage.name}${activeVillage.lgd_code ? ` (LGD: ${activeVillage.lgd_code})` : ''}`,
            subtitle: `${currentMandal?.name || 'Mandal'} • ${currentDist?.name || 'District'}`,
            type: 'village'
          });
        } else {
          // 0 revenue villages under this mandal (e.g., urban municipal corporation ward)
          setSelectedVillageId('');
          const coords = resolveLocationCoordinates(undefined, currentMandal, currentDist);
          setMapCenter([coords.lat, coords.lng]);
          setMapZoom(coords.zoom);
          setLocationPointer({
            lat: coords.lat,
            lng: coords.lng,
            title: `${currentMandal?.name || 'Mandal'} (Urban Ward)`,
            subtitle: `100% Urban Municipal Corporation Area • ${currentDist?.name || 'District'}`,
            type: 'mandal'
          });
        }
      } catch (err: any) {
        if (!isCurrent) return;
        console.error('Failed to load villages:', err);
        setVillageError(err.message || 'Failed to load villages. Click Retry to reload.');
        setVillages([]);
      } finally {
        if (isCurrent) setLoadingVillages(false);
      }
    }
    loadVillages();
    return () => {
      isCurrent = false;
    };
  }, [selectedStateId, selectedDistrictId, selectedMandalId, mandals, districts, villageRetryCount]);

  // 3. Load saved farms list from backend SQLite
  useEffect(() => {
    loadSavedFarms();
  }, []);

  async function loadSavedFarms() {
    try {
      const farms = await apiService.getFarms();
      setSavedFarms(farms);
    } catch (err) {
      console.error('Failed to load saved farms:', err);
    }
  }

  // 4. Handle District change: strictly reset descendants and update map pointer
  const handleDistrictChange = (distId: string) => {
    setSelectedDistrictId(distId);
    setSelectedMandalId('');
    setSelectedVillageId('');
    setMandals([]);
    setVillages([]);
    setMandalError(null);
    setVillageError(null);

    const dist = districts.find((d) => d.id === distId);
    if (dist) {
      const coords = resolveLocationCoordinates(undefined, undefined, dist);
      setMapCenter([coords.lat, coords.lng]);
      setMapZoom(coords.zoom);
      setLocationPointer({
        lat: coords.lat,
        lng: coords.lng,
        title: `${dist.name} District (LGD: ${dist.lgd_code || 'AP'})`,
        subtitle: `${dist.region || 'Andhra Pradesh'} • ${dist.rainfall_zone || 'Standard'} Rain Zone`,
        type: 'district'
      });
    }
  };

  // 5. Handle Mandal change: strictly reset village selection and update map pointer
  const handleMandalChange = (mandalId: string) => {
    setSelectedMandalId(mandalId);
    setSelectedVillageId('');
    setVillages([]);
    setVillageError(null);

    const m = mandals.find((item) => item.id === mandalId);
    const dist = districts.find((d) => d.id === selectedDistrictId);
    if (m) {
      const coords = resolveLocationCoordinates(undefined, m, dist);
      setMapCenter([coords.lat, coords.lng]);
      setMapZoom(coords.zoom);
      setLocationPointer({
        lat: coords.lat,
        lng: coords.lng,
        title: `${m.name} Mandal (LGD: ${m.lgd_code || 'AP'})`,
        subtitle: dist ? `${dist.name} District (LGD: ${dist.lgd_code})` : 'Andhra Pradesh',
        type: 'mandal'
      });
    }
  };

  // 6. Handle Village change: fly map to village centroid and update pointer
  const handleVillageChange = (villageId: string) => {
    setSelectedVillageId(villageId);
    const v = villages.find((item) => item.id === villageId);
    const m = mandals.find((item) => item.id === selectedMandalId);
    const dist = districts.find((d) => d.id === selectedDistrictId);

    if (v) {
      const coords = resolveLocationCoordinates(v, m, dist);
      setMapCenter([coords.lat, coords.lng]);
      setMapZoom(coords.zoom);
      setLocationPointer({
        lat: coords.lat,
        lng: coords.lng,
        title: `${v.name}${v.lgd_code ? ` (LGD: ${v.lgd_code})` : ''}`,
        subtitle: `${m?.name || 'Mandal'} • ${dist?.name || 'District'}`,
        type: 'village'
      });
    }
  };

  // 7. Compute Turf.js acreage and centroid from vertices in real time
  const turfResult = useMemo(() => {
    return calculateAcreageAndCentroid(vertices);
  }, [vertices]);

  // 8. Cross-verify with backend geospatial engine when polygon is closed
  useEffect(() => {
    if (turfResult && turfResult.geojsonPolygon && vertices.length >= 3) {
      const manualNum = manualAcreageInput ? parseFloat(manualAcreageInput) : undefined;
      const timer = setTimeout(() => {
        apiService
          .analyzePolygon(turfResult.geojsonPolygon, manualNum)
          .then((res) => setBackendAnalysis(res))
          .catch((err) => console.error('Backend polygon analysis error:', err));
      }, 400);
      return () => clearTimeout(timer);
    } else {
      setBackendAnalysis(null);
    }
  }, [turfResult, manualAcreageInput, vertices.length]);

  // 9. Manual vs Polygon Acreage comparison & discrepancy computation
  const manualAcreage = parseFloat(manualAcreageInput) || null;
  const polygonAcreage = turfResult ? turfResult.acres : 0;

  const discrepancy = useMemo(() => {
    if (!manualAcreage || !polygonAcreage || polygonAcreage <= 0) return null;
    const diff = Math.abs(manualAcreage - polygonAcreage);
    const pct = (diff / polygonAcreage) * 100;
    const isSignificant = pct > 15.0 || diff > 0.5;

    return {
      diff: Number(diff.toFixed(2)),
      pct: Number(pct.toFixed(1)),
      isSignificant,
      message: isSignificant
        ? `Declared land record (${manualAcreage} ac) differs from drawn polygon (${polygonAcreage} ac) by ${pct.toFixed(1)}%. Check uncultivated borders or bunds.`
        : `Digitized boundary aligns closely with declared land records (within ${pct.toFixed(1)}%).`
    };
  }, [manualAcreage, polygonAcreage]);

  // Effective Acreage used in calculations
  const effectiveAcreage =
    acreagePreference === 'manual' && manualAcreage && manualAcreage > 0
      ? manualAcreage
      : polygonAcreage;

  // 10. Save Farm Profile to Backend SQLite with Full LGD Hierarchy
  const handleSaveFarm = async () => {
    if (!turfResult || vertices.length < 3) {
      notify('Please draw a valid closed farm boundary polygon first.', 'info');
      return;
    }

    setSaving(true);
    setSaveSuccessMsg(null);

    const currentDist = districts.find((d) => d.id === selectedDistrictId);
    const currentMandal = mandals.find((m) => m.id === selectedMandalId);
    const currentVillage = villages.find((v) => v.id === selectedVillageId);

    const farmPayload: FarmProfile = {
      id: editingFarmId,
      farm_name: farmName.trim() || 'My Andhra Farm Plot',
      state_id: selectedStateId,
      district_id: selectedDistrictId,
      mandal_id: selectedMandalId,
      village_id: selectedVillageId || undefined,
      village_name: currentVillage ? currentVillage.name : undefined,
      village_lgd: currentVillage?.lgd_code != null ? currentVillage.lgd_code : undefined,
      district_lgd: currentDist?.lgd_code != null ? currentDist.lgd_code : undefined,
      mandal_lgd: currentMandal?.lgd_code != null ? currentMandal.lgd_code : undefined,
      latitude: turfResult.centroid.lat,
      longitude: turfResult.centroid.lng,
      polygon_acreage: polygonAcreage,
      manual_acreage: manualAcreage,
      effective_acreage: effectiveAcreage,
      acreage_discrepancy_warning: discrepancy?.isSignificant ? discrepancy.message : null,
      boundary_geojson: turfResult.geojsonPolygon.geometry
    };

    try {
      const response = await apiService.saveFarm(farmPayload);
      setSaveSuccessMsg(`Farm "${farmPayload.farm_name}" ${editingFarmId ? 'updated' : 'saved'} successfully with verified LGD hierarchy!`);
      setEditingFarmId(response.farm.id);
      await loadSavedFarms();
      if (onFarmSelected) {
        onFarmSelected(response.farm);
      }
      setTimeout(() => setSaveSuccessMsg(null), 4000);
    } catch (err: any) {
      notify(`Failed to save farm: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  // 11. Load an existing farm from SQLite onto the map (validating parent hierarchy)
  const handleLoadFarm = async (farm: FarmProfile) => {
    try {
      setFarmName(farm.farm_name);
      setEditingFarmId(farm.id);
      setSelectedStateId(farm.state_id);

      // Verify district exists in loaded districts
      const dist = districts.find((d) => d.id === farm.district_id);
      if (!dist) {
        notify(`District '${farm.district_id}' from saved farm is not recognized.`);
        return;
      }
      setSelectedDistrictId(farm.district_id);

      // Fetch and validate mandals
      setLoadingMandals(true);
      const distMandals = await apiService.getMandals(farm.state_id, farm.district_id);
      setMandals(distMandals);
      setLoadingMandals(false);

      const mandal = distMandals.find((m) => m.id === farm.mandal_id);
      if (!mandal) {
        notify(`Mandal '${farm.mandal_id}' does not belong to district '${farm.district_id}'.`);
        return;
      }
      setSelectedMandalId(farm.mandal_id);

      // Fetch and validate villages
      setLoadingVillages(true);
      const mandalVillages = await apiService.getVillages(
        farm.state_id,
        farm.mandal_id,
        farm.district_id
      );
      setVillages(mandalVillages);
      setLoadingVillages(false);

      if (farm.village_id) {
        const villageExists = mandalVillages.some((v) => v.id === farm.village_id);
        if (villageExists) {
          setSelectedVillageId(farm.village_id);
        } else {
          console.warn(`Village '${farm.village_id}' not found under mandal '${farm.mandal_id}'.`);
          setSelectedVillageId('');
        }
      } else {
        setSelectedVillageId('');
      }

      setMapCenter([farm.latitude, farm.longitude]);
      setMapZoom(16);

      if (farm.manual_acreage) {
        setManualAcreageInput(farm.manual_acreage.toString());
      }

      const latlngs = geojsonToLatLngs(farm.boundary_geojson);
      setVertices(latlngs);

      setLocationPointer({
        lat: farm.latitude,
        lng: farm.longitude,
        title: farm.farm_name,
        subtitle: `${farm.village_name || farm.mandal_id} • Saved Farm Plot`,
        type: 'village'
      });

      if (onFarmSelected) {
        onFarmSelected(farm);
      }
    } catch (err: any) {
      console.error('Failed to load farm:', err);
      notify(`Error loading farm profile: ${err.message}`);
    }
  };

  // 12. Delete a saved farm
  const handleDeleteFarm = async (farmId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this saved farm plot?')) return;
    try {
      await apiService.deleteFarm(farmId);
      await loadSavedFarms();
    } catch (err: any) {
      notify(`Failed to delete farm: ${err.message}`);
    }
  };

  const currentDistrict = districts.find((d) => d.id === selectedDistrictId);
  const currentMandal = mandals.find((m) => m.id === selectedMandalId);
  const currentVillage = villages.find((v) => v.id === selectedVillageId);

  return (
    <div className="space-y-6">
      {/* Step Header */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                Step 2: Add Farm Location & Land Area
              </span>
              <h2 className="text-lg font-bold text-slate-800">
                Farm Location, Boundary Digitization & Land Area
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Select your District (28 divisions), Mandal, and Village / Gram Panchayat to center the satellite map pointer with verified LGD coordinates, then draw your farm boundary.
            </p>
          </div>

          {/* Quick Stats Banner */}
          {turfResult && (
            <div className="flex items-center space-x-3 bg-emerald-50 border border-emerald-200 px-3.5 py-2 rounded-xl text-xs">
              <Compass className="w-4 h-4 text-emerald-700" />
              <div>
                <span className="text-emerald-900 font-semibold block">
                  Effective Acreage: {effectiveAcreage} Acres
                </span>
                <span className="text-emerald-700 text-[11px]">
                  Centroid: {turfResult.centroid.lat.toFixed(4)}°N, {turfResult.centroid.lng.toFixed(4)}°E
                </span>
              </div>
            </div>
          )}
        </div>

        {/* 4-Tier Administrative Hierarchy Selectors (State -> District -> Mandal -> Village/Cadastral Unit) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 mt-5 pt-4 border-t border-slate-100">
          {/* State Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center space-x-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              <span>State</span>
            </label>
            <select
              value={selectedStateId}
              onChange={(e) => setSelectedStateId(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {states.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.name} ({st.country})
                </option>
              ))}
            </select>
          </div>

          {/* District Selection (28 Verified Divisions) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
              <span className="flex items-center space-x-1">
                <Navigation className="w-3.5 h-3.5 text-blue-600" />
                <span>District</span>
              </span>
              <span className="text-[10px] text-slate-400 font-normal">
                ({districts.length} districts)
              </span>
            </label>
            <select
              value={selectedDistrictId}
              onChange={(e) => handleDistrictChange(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {districts.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} {d.lgd_code ? `(LGD: ${d.lgd_code})` : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Mandal Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
              <span className="flex items-center space-x-1">
                <Home className="w-3.5 h-3.5 text-indigo-600" />
                <span>Mandal / Tehsil</span>
              </span>
              <span className="text-[10px] text-slate-400 font-normal">
                {loadingMandals ? 'Loading...' : `(${mandals.length} in dist)`}
              </span>
            </label>
            <select
              value={selectedMandalId}
              onChange={(e) => handleMandalChange(e.target.value)}
              disabled={loadingMandals || mandals.length === 0 || !selectedDistrictId}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:opacity-60"
            >
              {loadingMandals ? (
                <option value="">Loading mandals...</option>
              ) : mandals.length === 0 ? (
                <option value="">No mandals available</option>
              ) : (
                mandals.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} {m.lgd_code ? `(LGD: ${m.lgd_code})` : ''}
                  </option>
                ))
              )}
            </select>
            {mandalError && (
              <div className="mt-1 flex items-center justify-between text-[11px] text-rose-600">
                <span>{mandalError}</span>
                <button
                  type="button"
                  onClick={() => setMandalRetryCount((c) => c + 1)}
                  className="underline font-bold hover:text-rose-700"
                >
                  Retry
                </button>
              </div>
            )}
          </div>

          {/* Village / Gram Panchayat Selection (Authoritative LGD Data) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
              <span className="flex items-center space-x-1">
                <MapPin className="w-3.5 h-3.5 text-rose-500" />
                <span>Village / Cadastral Unit</span>
              </span>
              <span className="text-[10px] text-slate-400 font-normal">
                {loadingVillages
                  ? 'Loading...'
                  : villages.length === 0 && selectedMandalId
                  ? '(0 rural villages - Urban)'
                  : `(${villages.length} units)`}
              </span>
            </label>
            <select
              value={selectedVillageId}
              onChange={(e) => handleVillageChange(e.target.value)}
              disabled={loadingVillages || villages.length === 0 || !selectedMandalId}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:opacity-60"
            >
              {loadingVillages ? (
                <option value="">Loading villages...</option>
              ) : villages.length === 0 ? (
                <option value="">
                  {selectedMandalId
                    ? 'No rural revenue villages (100% Urban Municipal Ward)'
                    : 'Select a mandal first'}
                </option>
              ) : (
                villages.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} {v.lgd_code ? `(LGD: ${v.lgd_code})` : '(Cadastral Unit)'}
                  </option>
                ))
              )}
            </select>
            {villageError && (
              <div className="mt-1 flex items-center justify-between text-[11px] text-rose-600">
                <span>{villageError}</span>
                <button
                  type="button"
                  onClick={() => setVillageRetryCount((c) => c + 1)}
                  className="underline font-bold hover:text-rose-700"
                >
                  Retry
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Current Active Location Pill */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping inline-block" />
            <span className="font-semibold text-slate-800">
              Active Focus:
            </span>
            <span className="text-slate-700">
              {currentVillage?.name || 'Village'}, {currentMandal?.name || 'Mandal'}, {currentDistrict?.name || 'District'}
            </span>
            {locationPointer && (
              <span className="font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[11px]">
                {locationPointer.lat.toFixed(4)}°N, {locationPointer.lng.toFixed(4)}°E
              </span>
            )}
          </div>
          <span className="text-[11px] text-slate-400">
            Map pin automatically centers & zooms to high-resolution satellite imagery for boundary tracing.
          </span>
        </div>
      </div>

      {/* Main Map & Acreage Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Leaflet Map (2 Cols on lg) */}
        <div className="lg:col-span-2 space-y-3">
          <FarmMap
            center={mapCenter}
            zoom={mapZoom}
            vertices={vertices}
            onVerticesChange={setVertices}
            turfResult={turfResult}
            locationPointer={locationPointer}
          />

          {/* Map Helper Legend */}
          <div className="bg-white rounded-xl border border-slate-200/80 px-4 py-2.5 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-2">
            <div className="flex items-center space-x-4">
              <span className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500 inline-block shadow-sm" />
                <span>Selected Village / Mandal Pin</span>
              </span>
              <span className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-blue-600 inline-block" />
                <span>Boundary Vertices (Draggable)</span>
              </span>
              <span className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-600 inline-block ring-2 ring-emerald-300" />
                <span>Polygon Centroid (NASA Target)</span>
              </span>
            </div>
            <span className="text-slate-400 text-[11px]">
              Tip: Switch to Satellite view to trace actual field boundaries & bunds.
            </span>
          </div>
        </div>

        {/* Right Column: Acreage, Discrepancy & NASA Readiness (1 Col) */}
        <div className="space-y-4">
          {/* Acreage Card */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
                <Maximize2 className="w-4 h-4 text-emerald-600" />
                <span>Acreage Verification</span>
              </h3>
              <span className="text-[11px] font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-600 font-semibold">
                Turf.js Geodesic
              </span>
            </div>

            {/* Polygon Derived Acreage */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500 font-medium block">
                  Digitized Polygon Area:
                </span>
                {backendAnalysis && (
                  <span className="text-[10px] text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded font-semibold">
                    Backend Verified
                  </span>
                )}
              </div>
              <div className="flex items-baseline space-x-2 mt-1">
                <span className="text-2xl font-extrabold text-slate-900">
                  {turfResult ? turfResult.acres : '0.00'}
                </span>
                <span className="text-sm font-bold text-emerald-700">Acres</span>
                {turfResult && (
                  <span className="text-xs text-slate-400 font-mono">
                    ({turfResult.sqMeters.toLocaleString()} m²)
                  </span>
                )}
              </div>
            </div>

            {/* Manual Acreage Entry */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center space-x-1">
                <FileText className="w-3.5 h-3.5 text-slate-500" />
                <span>Manual Land Record Acreage (Optional)</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="e.g. 3.5 (from Patta Passbook)"
                  value={manualAcreageInput}
                  onChange={(e) => setManualAcreageInput(e.target.value)}
                  className="w-full text-sm bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 pr-16"
                />
                <span className="absolute right-3.5 top-2.5 text-xs font-bold text-slate-400">
                  Acres
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Official revenue record area from Andhra Pradesh Meebhoomi / ROR-1B.
              </p>
            </div>

            {/* Discrepancy Alert Banner */}
            {discrepancy && (
              <div
                className={`p-3 rounded-xl border text-xs flex items-start space-x-2.5 ${
                  discrepancy.isSignificant
                    ? 'bg-amber-50 border-amber-300 text-amber-900'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                }`}
              >
                {discrepancy.isSignificant ? (
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                )}
                <div>
                  <p className="font-semibold">
                    {discrepancy.isSignificant
                      ? 'Acreage Discrepancy Detected'
                      : 'Acreage Verification Confirmed'}
                  </p>
                  <p className="text-[11px] mt-0.5 leading-relaxed">{discrepancy.message}</p>
                </div>
              </div>
            )}

            {/* Effective Acreage Preference Toggle */}
            {manualAcreage && polygonAcreage > 0 && (
              <div className="pt-2 border-t border-slate-100">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Calculation Baseline:
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setAcreagePreference('polygon')}
                    className={`py-2 px-2.5 rounded-lg border font-medium transition-all ${
                      acreagePreference === 'polygon'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Use Polygon ({polygonAcreage} ac)
                  </button>
                  <button
                    type="button"
                    onClick={() => setAcreagePreference('manual')}
                    className={`py-2 px-2.5 rounded-lg border font-medium transition-all ${
                      acreagePreference === 'manual'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Use Land Record ({manualAcreage} ac)
                  </button>
                </div>
              </div>
            )}

            {/* Save Farm Profile Form */}
            <div className="pt-2 border-t border-slate-100 space-y-2.5">
              <label className="block text-xs font-semibold text-slate-700">
                Plot Name / Identifier:
              </label>
              <input
                type="text"
                value={farmName}
                onChange={(e) => setFarmName(e.target.value)}
                placeholder="e.g., North Field Survey #24"
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />

              <button
                type="button"
                onClick={handleSaveFarm}
                disabled={saving || !turfResult || vertices.length < 3}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-md shadow-emerald-900/20"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving to Database...' : editingFarmId ? 'Update Existing Farm' : 'Save Farm Profile (SQLite)'}</span>
              </button>

              {saveSuccessMsg && (
                <p className="text-xs text-emerald-700 font-semibold text-center animate-fade-in">
                  ✓ {saveSuccessMsg}
                </p>
              )}
            </div>
          </div>

          {/* NASA Spatial Query Targets Readiness */}
          <div className="bg-slate-900 text-slate-200 rounded-2xl p-5 border border-slate-800 shadow-sm space-y-3.5">
            <div className="flex items-center space-x-2 text-cyan-400">
              <Satellite className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-wider">
                NASA Observation Readiness
              </h3>
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700/80">
                <span className="text-[11px] font-semibold text-cyan-300 block">
                  1. NASA POWER (Point Mode):
                </span>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  Centroid Target:{' '}
                  <span className="font-mono text-emerald-400">
                    {turfResult
                      ? `${turfResult.centroid.lat}°, ${turfResult.centroid.lng}°`
                      : 'Draw polygon to compute'}
                  </span>
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700/80">
                <span className="text-[11px] font-semibold text-cyan-300 block">
                  2. NASA SMAP & GPM (Area Mode):
                </span>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  Sampling Target:{' '}
                  <span className="font-mono text-cyan-300">
                    {turfResult
                      ? `Polygon Bounding Box & Clip Geometry (${vertices.length} vertices)`
                      : 'Awaiting farm boundary'}
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Saved Farm Plots Drawer / Catalog */}
      {savedFarms.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
              <Bookmark className="w-4 h-4 text-emerald-600" />
              <span>Saved Farm Profiles in SQLite ({savedFarms.length})</span>
            </h3>
            <button
              type="button"
              onClick={() => {
                setEditingFarmId(undefined);
                setFarmName('My Andhra Farm Plot');
                setVertices([]);
                setManualAcreageInput('');
                setSaveSuccessMsg(null);
              }}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-900"
            >
              + Add another farm
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {savedFarms.map((farm) => (
              <div
                key={farm.id}
                onClick={() => handleLoadFarm(farm)}
                className="p-3.5 rounded-xl border border-slate-200 hover:border-emerald-400 bg-slate-50/50 hover:bg-emerald-50/30 transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-800">
                      {farm.farm_name}
                    </h4>
                    <button
                      type="button"
                      onClick={(e) => handleDeleteFarm(farm.id!, e)}
                      className="text-slate-400 hover:text-rose-600 p-1"
                      title="Delete saved farm"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 capitalize">
                    {farm.district_id.replace(/_/g, ' ')} • {farm.mandal_id.replace(/_/g, ' ')}
                    {farm.village_name && ` • ${farm.village_name}`}
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                  <span className="font-bold text-emerald-700">
                    {farm.effective_acreage} Acres
                  </span>
                  <span className="font-mono text-slate-400 text-[10px]">
                    {farm.latitude.toFixed(4)}, {farm.longitude.toFixed(4)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
