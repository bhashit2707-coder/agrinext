import React, { useEffect, useState } from 'react';
import {
  MapContainer,
  TileLayer,
  Polygon,
  Marker,
  Tooltip,
  useMap,
  useMapEvents
} from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import {
  Pencil,
  Check,
  RotateCcw,
  Layers,
  Crosshair,
  Satellite,
  Info,
  MapPin
} from 'lucide-react';
import type { TurfAcreageResult } from '../services/turfHelper';

// Fix Leaflet marker icons
const CentroidIcon = L.divIcon({
  className: 'custom-centroid-marker',
  html: `
    <div style="
      width: 24px;
      height: 24px;
      background: #059669;
      border: 3px solid #ffffff;
      border-radius: 50%;
      box-shadow: 0 0 12px rgba(5, 150, 105, 0.8), 0 2px 6px rgba(0,0,0,0.4);
      display: flex;
      align-items: center;
      justify-content: center;
    ">
      <div style="width: 6px; height: 6px; background: white; border-radius: 50%;"></div>
    </div>
  `,
  iconSize: [24, 24],
  iconAnchor: [12, 12]
});

const VertexIcon = L.divIcon({
  className: 'custom-vertex-marker',
  html: `
    <div style="
      width: 14px;
      height: 14px;
      background: #2563eb;
      border: 2px solid #ffffff;
      border-radius: 50%;
      box-shadow: 0 1px 4px rgba(0,0,0,0.5);
      cursor: crosshair;
    "></div>
  `,
  iconSize: [14, 14],
  iconAnchor: [7, 7]
});

// Dynamic Google-accurate Location Marker Pin (District / Mandal / Village)
const LocationPinIcon = L.divIcon({
  className: 'custom-location-pin',
  html: `
    <div style="position: relative; width: 38px; height: 38px; display: flex; align-items: center; justify-content: center;">
      <div style="
        position: absolute;
        width: 34px;
        height: 34px;
        border-radius: 50%;
        background: rgba(239, 68, 68, 0.4);
        animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;
      "></div>
      <div style="
        width: 28px;
        height: 28px;
        background: #ef4444;
        border: 2.5px solid #ffffff;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        box-shadow: 0 4px 12px rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <div style="
          width: 8px;
          height: 8px;
          background: #ffffff;
          border-radius: 50%;
          transform: rotate(45deg);
        "></div>
      </div>
    </div>
  `,
  iconSize: [38, 38],
  iconAnchor: [19, 34],
  popupAnchor: [0, -34]
});

export interface LocationPointer {
  lat: number;
  lng: number;
  title: string;
  subtitle?: string;
  type?: 'district' | 'mandal' | 'village';
}

interface FarmMapProps {
  center: [number, number];
  zoom: number;
  vertices: Array<{ lat: number; lng: number }>;
  onVerticesChange: (newVertices: Array<{ lat: number; lng: number }>) => void;
  turfResult: TurfAcreageResult | null;
  locationPointer?: LocationPointer | null;
  readOnly?: boolean;
}

// Automatic Map Resizer to prevent grey tiles and layout clipping
const MapResizer: React.FC = () => {
  const map = useMap();
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        map.invalidateSize();
      } catch {
        // map unmounted safely
      }
    }, 150);
    return () => clearTimeout(timer);
  }, [map]);
  return null;
};

// High-performance controller to smoothly reposition map when dropdown selection changes
const MapFlyTo: React.FC<{ center: [number, number]; zoom: number }> = ({ center, zoom }) => {
  const map = useMap();
  const prevCenterRef = React.useRef<[number, number]>([center[0], center[1]]);
  const prevZoomRef = React.useRef<number>(zoom);
  const isFirstRender = React.useRef(true);

  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }

    const prevLat = prevCenterRef.current[0];
    const prevLng = prevCenterRef.current[1];
    const prevZoom = prevZoomRef.current;

    const latDiff = Math.abs(prevLat - center[0]);
    const lngDiff = Math.abs(prevLng - center[1]);
    const zoomDiff = Math.abs(prevZoom - zoom);

    // Only update if parent component provided new coordinates (dropdown selection)
    // Do NOT compare against current pan position so user dragging/drawing is not interrupted
    if (latDiff > 0.0001 || lngDiff > 0.0001 || zoomDiff > 0) {
      prevCenterRef.current = [center[0], center[1]];
      prevZoomRef.current = zoom;

      // Stop any pending animations before starting a new transition
      map.stop();
      if (latDiff > 0.3 || lngDiff > 0.3) {
        map.flyTo([center[0], center[1]], zoom, { duration: 0.5, easeLinearity: 0.5 });
      } else {
        map.setView([center[0], center[1]], zoom, { animate: true, duration: 0.25 });
      }
    }
  }, [center, zoom, map]);

  return null;
};

// Map click handler for drawing vertices
const MapClickHandler: React.FC<{
  isDrawing: boolean;
  onAddVertex: (lat: number, lng: number) => void;
}> = ({ isDrawing, onAddVertex }) => {
  useMapEvents({
    click(e) {
      if (isDrawing) {
        onAddVertex(e.latlng.lat, e.latlng.lng);
      }
    }
  });
  return null;
};

export const FarmMap: React.FC<FarmMapProps> = ({
  center,
  zoom,
  vertices,
  onVerticesChange,
  turfResult,
  locationPointer,
  readOnly = false
}) => {
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [baseLayer, setBaseLayer] = useState<'streets' | 'satellite'>('satellite');

  // Handle vertex dragging
  const handleVertexDrag = (index: number, e: L.LeafletEvent) => {
    const marker = e.target as L.Marker;
    const newPos = marker.getLatLng();
    const updated = [...vertices];
    updated[index] = { lat: newPos.lat, lng: newPos.lng };
    onVerticesChange(updated);
  };

  const handleAddVertex = (lat: number, lng: number) => {
    onVerticesChange([...vertices, { lat, lng }]);
  };

  const handleClear = () => {
    setIsDrawing(false);
    onVerticesChange([]);
  };

  const handleFinishDrawing = () => {
    setIsDrawing(false);
  };

  return (
    <div className="relative w-full h-[540px] rounded-2xl overflow-hidden border border-slate-300 shadow-inner bg-slate-900">
      {/* Map Action Toolbar */}
      <div className="absolute top-3.5 left-3.5 z-[1000] flex flex-wrap items-center gap-2 bg-white/95 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-200/90 shadow-md text-xs">
        {!readOnly && (
          <>
            {!isDrawing ? (
              <button
                type="button"
                onClick={() => setIsDrawing(true)}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold transition-all shadow-sm"
              >
                <Pencil className="w-3.5 h-3.5" />
                <span>{vertices.length === 0 ? 'Draw Farm Boundary' : 'Add Vertices'}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleFinishDrawing}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold transition-all shadow-sm ring-2 ring-emerald-400"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Finish & Close Boundary ({vertices.length} pts)</span>
              </button>
            )}

            {vertices.length > 0 && (
              <button
                type="button"
                onClick={handleClear}
                className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-rose-50 hover:text-rose-700 text-slate-700 font-medium transition-all"
                title="Clear boundary"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </>
        )}

        {/* Tile Layer Toggle */}
        <div className="flex items-center space-x-1 border-l border-slate-200 pl-2">
          <button
            type="button"
            onClick={() => setBaseLayer('satellite')}
            className={`px-2.5 py-1.5 rounded-lg flex items-center space-x-1 transition-all ${
              baseLayer === 'satellite'
                ? 'bg-slate-800 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Satellite className="w-3.5 h-3.5" />
            <span>Satellite</span>
          </button>
          <button
            type="button"
            onClick={() => setBaseLayer('streets')}
            className={`px-2.5 py-1.5 rounded-lg flex items-center space-x-1 transition-all ${
              baseLayer === 'streets'
                ? 'bg-slate-800 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Streets</span>
          </button>
        </div>
      </div>

      {/* Active Drawing Help Overlay */}
      {isDrawing && (
        <div className="absolute top-16 left-3.5 z-[1000] bg-emerald-950/90 text-emerald-200 text-xs px-3 py-1.5 rounded-lg border border-emerald-700 flex items-center space-x-2 shadow-lg backdrop-blur-sm animate-pulse">
          <Info className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Click anywhere on the map to add corner points. Click "Finish" when done.</span>
        </div>
      )}

      {/* Map Canvas */}
      <MapContainer
        center={center}
        zoom={zoom}
        style={{ height: '100%', width: '100%' }}
        className="z-0"
      >
        <MapResizer />
        <MapFlyTo center={center} zoom={zoom} />
        <MapClickHandler isDrawing={isDrawing} onAddVertex={handleAddVertex} />

        {/* Base Map Tiles */}
        {baseLayer === 'satellite' ? (
          <TileLayer
            attribution='Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
            url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
            maxNativeZoom={18}
            maxZoom={19}
            keepBuffer={2}
            updateWhenIdle={true}
          />
        ) : (
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            maxNativeZoom={19}
            maxZoom={19}
            keepBuffer={2}
            updateWhenIdle={true}
          />
        )}

        {/* Dynamic Location Marker Pin (District / Mandal / Village) */}
        {locationPointer && isFinite(locationPointer.lat) && isFinite(locationPointer.lng) && (
          <Marker
            position={[locationPointer.lat, locationPointer.lng]}
            icon={LocationPinIcon}
          >
            <Tooltip
              permanent
              direction="top"
              offset={[0, -32]}
              className="bg-slate-900/95 text-white font-medium text-xs border border-slate-700 rounded-lg px-2.5 py-1.5 shadow-xl backdrop-blur-md"
            >
              <div className="flex flex-col gap-0.5 text-center">
                <span className="font-bold text-amber-300 flex items-center justify-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-red-400 inline shrink-0" />
                  <span>{locationPointer.title}</span>
                </span>
                {locationPointer.subtitle && (
                  <span className="text-[10px] text-slate-300">
                    {locationPointer.subtitle}
                  </span>
                )}
                <span className="text-[9px] text-emerald-400 font-mono">
                  {locationPointer.lat.toFixed(4)}°N, {locationPointer.lng.toFixed(4)}°E
                </span>
              </div>
            </Tooltip>
          </Marker>
        )}

        {/* Render Drawn Farm Boundary Polygon */}
        {vertices.length >= 3 && (
          <Polygon
            positions={vertices.map((v): [number, number] => [v.lat, v.lng])}
            pathOptions={{
              color: '#10b981',
              fillColor: '#059669',
              fillOpacity: 0.35,
              weight: 3,
              dashArray: isDrawing ? '6, 6' : undefined
            }}
          />
        )}

        {/* Vertices Draggable Markers (while editing or drawing) */}
        {!readOnly &&
          vertices.map((v, idx) => (
            <Marker
              key={`vertex-${idx}-${v.lat.toFixed(5)}-${v.lng.toFixed(5)}`}
              position={[v.lat, v.lng]}
              icon={VertexIcon}
              draggable={!isDrawing}
              eventHandlers={{
                dragend: (e) => handleVertexDrag(idx, e)
              }}
            >
              <Tooltip direction="top" offset={[0, -10]} opacity={0.9}>
                Point {idx + 1}: {v.lat.toFixed(5)}, {v.lng.toFixed(5)}
              </Tooltip>
            </Marker>
          ))}

        {/* NASA POWER Centroid Target Pin */}
        {turfResult && (
          <Marker
            position={[turfResult.centroid.lat, turfResult.centroid.lng]}
            icon={CentroidIcon}
          >
            <Tooltip permanent direction="bottom" offset={[0, 12]} className="bg-slate-900 text-white font-medium text-[11px] border border-slate-700 rounded px-2 py-0.5 shadow">
              <span className="flex items-center space-x-1">
                <Crosshair className="w-3 h-3 text-emerald-400 inline" />
                <span>NASA Centroid: {turfResult.centroid.lat.toFixed(4)}, {turfResult.centroid.lng.toFixed(4)}</span>
              </span>
            </Tooltip>
          </Marker>
        )}
      </MapContainer>

      {/* Floating Coordinate & Status Badge */}
      <div className="absolute bottom-3 right-3 z-[1000] bg-slate-900/90 text-slate-200 text-[11px] font-mono px-3 py-1.5 rounded-lg border border-slate-700 backdrop-blur-md shadow-lg flex items-center space-x-3">
        <span>Points: <b className="text-white">{vertices.length}</b></span>
        {turfResult && (
          <>
            <span className="text-slate-600">|</span>
            <span>Acreage: <b className="text-emerald-400">{turfResult.acres} ac</b></span>
            <span className="text-slate-600">|</span>
            <span>Area: <b className="text-cyan-300">{turfResult.sqMeters.toLocaleString()} m²</b></span>
          </>
        )}
      </div>
    </div>
  );
};
