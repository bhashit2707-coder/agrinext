import React from 'react';
import { Satellite, Activity, CheckCircle2, AlertTriangle, Lock } from 'lucide-react';
import type { NASAServiceMetadata, BackendHealth } from '../types';

interface StatusCardProps {
  health: BackendHealth | null;
  nasaServices: NASAServiceMetadata[];
  loading: boolean;
  error: string | null;
}

export const StatusCard: React.FC<StatusCardProps> = ({
  health,
  nasaServices,
  loading,
  error
}) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2.5">
          <Activity className="w-5 h-5 text-emerald-600" />
          <h2 className="text-base font-semibold text-slate-800">
            System Connectivity & Observation Services
          </h2>
        </div>
        {loading && (
          <span className="text-xs text-slate-500 animate-pulse">Syncing services...</span>
        )}
      </div>

      {error ? (
        <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-sm flex items-start space-x-2">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Backend Connection Pending</p>
            <p className="text-xs mt-0.5">
              Ensure FastAPI backend is running on <code>http://localhost:8000</code>.
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3.5">
          {/* API Health */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Core Engine
              </span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <p className="text-sm font-bold text-slate-800">
              {health ? health.service : 'Loading...'}
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              Scope: {health ? health.region_scope : 'Initializing'}
            </p>
          </div>

          {/* NASA Services */}
          {nasaServices.map((svc: any) => {
            const isAuthReq = svc.status === 'configuration_required' ||
              (svc.authentication_required && svc.credentials_configured === false);
            const isLiveVerified = svc.reachable === true && (!svc.authentication_required || svc.authenticated === true);
            const resolution = svc.metadata?.spatial_resolution || svc.metadata?.resolution || 'N/A';
            const title = svc.title || svc.metadata?.source || svc.metadata?.dataset_name || svc.service;

            return (
              <div
                key={svc.service}
                className={`p-3.5 rounded-xl border flex flex-col justify-between ${
                  isAuthReq
                    ? 'bg-amber-50/40 border-amber-200'
                    : 'bg-cyan-50/50 border-cyan-100'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className={`text-xs font-semibold uppercase tracking-wider ${
                      isAuthReq ? 'text-amber-800' : 'text-cyan-800'
                    }`}>
                      {svc.service}
                    </span>
                    {isAuthReq ? (
                      <Lock className="w-3.5 h-3.5 text-amber-600" />
                    ) : (
                      <Satellite className="w-4 h-4 text-cyan-600" />
                    )}
                  </div>
                  <p className="text-xs font-semibold text-slate-800 line-clamp-1" title={title}>
                    {title}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Grid: <span className="font-mono text-slate-700">{resolution}</span>
                  </p>
                </div>
                <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                  {isLiveVerified ? (
                    <span className="text-emerald-700 font-medium">Live verified</span>
                  ) : isAuthReq ? (
                    <span className="text-amber-700 font-medium">Credentials required</span>
                  ) : (
                    <span className="text-slate-500 font-medium">Not live-checked</span>
                  )}
                  <span className="text-slate-400">Traceable</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
