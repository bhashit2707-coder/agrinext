import React from 'react';
import { Terminal, Code, Cpu, ShieldAlert } from 'lucide-react';

export const DeveloperGuide: React.FC = () => {
  return (
    <div className="bg-slate-900 text-slate-200 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-6">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-xl bg-slate-800 text-cyan-400">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Beginner Developer Architecture Brief</h3>
            <p className="text-xs text-slate-400">Step-by-step foundation and verification guide</p>
          </div>
        </div>
        <span className="text-xs px-2.5 py-1 bg-cyan-950 text-cyan-300 border border-cyan-800 rounded-full font-mono">
          Phase 1: Foundation
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Architecture Pattern */}
        <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
          <div className="flex items-center space-x-2 text-emerald-400 mb-2">
            <Cpu className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">Config-Driven Extensibility</h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            All state specifics (Andhra Pradesh districts, crops, and agronomic rules) are stored in declarative JSON files inside <code>backend/state_data/</code>. New Indian states can be added without altering engine code.
          </p>
        </div>

        {/* NASA Evidence Principle */}
        <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
          <div className="flex items-center space-x-2 text-cyan-400 mb-2">
            <ShieldAlert className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">NASA Evidence Engine</h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            NASA observations are treated as computational evidence in scoring calculations. Every output records source, time interval, spatial resolution (e.g. 0.5° POWER, 9km SMAP), and mathematical formulas.
          </p>
        </div>

        {/* Separation of Concerns */}
        <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
          <div className="flex items-center space-x-2 text-violet-400 mb-2">
            <Code className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">FastAPI + React Vite</h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The Python backend manages NASA ingestion, geospatial calculations, and agronomic rules. The React TypeScript frontend provides a high-performance Leaflet mapping and Recharts interface.
          </p>
        </div>
      </div>

      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 space-y-2">
        <p className="text-slate-400 font-sans font-semibold mb-1">Commands to run locally:</p>
        <div className="space-y-1">
          <p><span className="text-emerald-400"># 1. Run Backend Server (FastAPI):</span></p>
          <p className="text-cyan-300 pl-4">cd backend</p>
          <p className="text-cyan-300 pl-4">.\venv\Scripts\uvicorn.exe main:app --reload --port 8000</p>
          <p className="text-slate-400 font-sans text-[11px] pl-4">Docs available at: http://localhost:8000/docs</p>
        </div>
        <div className="pt-2 space-y-1">
          <p><span className="text-emerald-400"># 2. Run Frontend Server (Vite):</span></p>
          <p className="text-cyan-300 pl-4">cd frontend</p>
          <p className="text-cyan-300 pl-4">npm run dev</p>
          <p className="text-slate-400 font-sans text-[11px] pl-4">Web UI available at: http://localhost:5173</p>
        </div>
        <div className="pt-2 space-y-1">
          <p><span className="text-emerald-400"># 3. Run Backend Verification Tests:</span></p>
          <p className="text-cyan-300 pl-4">cd backend</p>
          <p className="text-cyan-300 pl-4">.\venv\Scripts\pytest.exe tests -v</p>
        </div>
      </div>
    </div>
  );
};
