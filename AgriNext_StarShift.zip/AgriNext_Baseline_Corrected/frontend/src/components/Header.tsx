import React, { useEffect, useState } from 'react';
import { API_BASE_URL } from '../configuration/api';
import { Sprout, Satellite, LayoutDashboard, User, LogIn, LogOut, Wheat } from 'lucide-react';
import { useNavigation } from '../context/NavigationContext';
import { useAuth } from '../context/AuthContext';

interface HeaderProps {
  backendHealthy?: boolean;
  currentRoute?: string;
  onNavigate?: (route: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  backendHealthy: backendHealthyProp,
  currentRoute: propRoute,
  onNavigate: propNavigate
}) => {
  const nav = useNavigation();
  const auth = useAuth();
  const [liveBackendHealthy, setLiveBackendHealthy] = useState(false);

  useEffect(() => {
    if (backendHealthyProp !== undefined) return;
    let active = true;
    const checkHealth = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/health`, { credentials: 'include' });
        const payload = response.ok ? await response.json() : null;
        if (active) setLiveBackendHealthy(Boolean(payload && payload.status === 'healthy'));
      } catch {
        if (active) setLiveBackendHealthy(false);
      }
    };
    void checkHealth();
    const timer = window.setInterval(checkHealth, 30000);
    return () => { active = false; window.clearInterval(timer); };
  }, [backendHealthyProp]);

  const backendHealthy = backendHealthyProp ?? liveBackendHealthy;

  const activeRoute = propRoute || nav.currentRoute;
  const handleNav = (path: string) => {
    const target = !auth.isAuthenticated && (path === '/' || path === '/dashboard' || path === '/profile' || path === '/farms') ? '/login' : path;
    if (propNavigate) {
      propNavigate(target);
    } else {
      nav.navigate(target);
    }
  };

  const handleLogout = (e: React.MouseEvent) => {
    e.stopPropagation();
    auth.logout();
    handleNav('/login');
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Brand & Title */}
        <div
          onClick={() => handleNav(auth.isAuthenticated ? '/' : '/login')}
          className="flex items-center space-x-3 cursor-pointer group"
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') handleNav(auth.isAuthenticated ? '/' : '/login');
          }}
          title={auth.isAuthenticated ? "AgriNext Dashboard" : "AgriNext Step 1: Farmer Login"}
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-green-700 flex items-center justify-center shadow-lg shadow-emerald-900/30 group-hover:scale-105 transition-transform">
            <Sprout className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-emerald-400 to-teal-200 bg-clip-text text-transparent">
                AgriNext
              </h1>
              <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
                v1.0 AP
              </span>
            </div>
            <p className="text-xs text-slate-400">
              NASA-Powered Climate-Resilient Crop Rotation Decision Support System
            </p>
          </div>
        </div>

        {/* Primary Navigation Links */}
        <nav className="flex items-center space-x-1 sm:space-x-2 bg-slate-800/80 p-1 rounded-xl border border-slate-700/80">
          <button
            type="button"
            onClick={() => handleNav('/')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              activeRoute === '/' || activeRoute === '/dashboard'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            <span>Dashboard</span>
          </button>

          <button
            type="button"
            onClick={() => handleNav('/farms')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              activeRoute === '/farms' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
            }`}
          >
            <Wheat className="w-3.5 h-3.5" />
            <span>My Farms</span>
          </button>

          <button
            type="button"
            onClick={() => handleNav('/earth-observation')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              activeRoute === '/earth-observation' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
            }`}
          >
            <Satellite className="w-3.5 h-3.5" />
            <span>Satellite & GAEZ</span>
          </button>

          <button
            type="button"
            onClick={() => handleNav('/profile')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              activeRoute === '/profile'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profile & Farms</span>
          </button>

          {auth.isAuthenticated ? (
            <div className="flex items-center pl-1 sm:pl-2 border-l border-slate-700/80 space-x-1 sm:space-x-2">
              <button
                type="button"
                onClick={() => handleNav('/profile')}
                className="flex items-center space-x-1.5 px-2 py-1 rounded-md text-xs text-slate-200 hover:bg-slate-700/60 transition-colors"
                title={`Signed in as ${auth.currentUser?.name} (${auth.currentUser?.role})`}
              >
                <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center justify-center text-[10px] font-bold">
                  {auth.currentUser?.avatar_initials || 'U'}
                </span>
                <span className="hidden md:inline font-medium text-slate-200 truncate max-w-[110px]">
                  {auth.currentUser?.name}
                </span>
              </button>

              <button
                type="button"
                onClick={handleLogout}
                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors"
                title="Sign out of AgriNext"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => handleNav('/login')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                activeRoute === '/login'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Step 1: Sign In</span>
            </button>
          )}
        </nav>

        {/* System & API Status Badges */}
        <div className="flex items-center space-x-3">
          <div className="hidden lg:flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs">
            <Satellite className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-300 font-medium">NASA Earth Data:</span>
            <span className="text-cyan-300 font-mono">POWER • SMAP • GPM</span>
          </div>

          <div className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs">
            <div
              className={`w-2.5 h-2.5 rounded-full ${
                backendHealthy ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'
              }`}
            />
            <span className="text-slate-300">
              Backend API: {backendHealthy ? 'Connected' : 'Offline'}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
