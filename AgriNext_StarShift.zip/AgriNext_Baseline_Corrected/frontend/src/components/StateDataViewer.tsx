import React, { useState } from 'react';
import { MapPin, Sprout, BookOpen, Layers, ShieldCheck } from 'lucide-react';
import type { District, Crop, CropRule, StrategyArchetype } from '../types';

interface StateDataViewerProps {
  districts: District[];
  crops: Crop[];
  cropRules: CropRule[];
  strategies: StrategyArchetype[];
}

export const StateDataViewer: React.FC<StateDataViewerProps> = ({
  districts,
  crops,
  cropRules,
  strategies
}) => {
  const [activeTab, setActiveTab] = useState<'crops' | 'districts' | 'rules' | 'strategies'>('crops');

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h2 className="text-base font-semibold text-slate-800 flex items-center space-x-2">
            <span>Andhra Pradesh Agronomic Foundations</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-normal">
              State Config Driven
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Loaded dynamically from <code>backend/state_data/andhra_pradesh/</code> without code modification.
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-medium">
          <button
            onClick={() => setActiveTab('crops')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center space-x-1.5 ${
              activeTab === 'crops'
                ? 'bg-white text-emerald-800 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sprout className="w-3.5 h-3.5" />
            <span>Crops ({crops.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('districts')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center space-x-1.5 ${
              activeTab === 'districts'
                ? 'bg-white text-emerald-800 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Districts ({districts.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('rules')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center space-x-1.5 ${
              activeTab === 'rules'
                ? 'bg-white text-emerald-800 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Agronomic Rules ({cropRules.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('strategies')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center space-x-1.5 ${
              activeTab === 'strategies'
                ? 'bg-white text-emerald-800 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Strategies (3)</span>
          </button>
        </div>
      </div>

      {/* Tab Panels */}
      {activeTab === 'crops' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {crops.map((crop) => (
            <div
              key={crop.id}
              className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/50 hover:bg-emerald-50/30 hover:border-emerald-200 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-800">{crop.name}</h3>
                  {crop.telugu_name && (
                    <p className="text-xs text-emerald-700 font-medium">{crop.telugu_name}</p>
                  )}
                </div>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                    crop.nitrogen_impact === 'fixing'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {crop.nitrogen_impact === 'fixing' ? 'Nitrogen Fixing' : 'Nitrogen Depleting'}
                </span>
              </div>
              <div className="mt-2.5 grid grid-cols-2 gap-2 text-[11px] text-slate-600">
                <div>
                  <span className="text-slate-400 block">Water Need:</span>
                  <span className="font-medium text-slate-700">
                    {crop.water_requirement_mm[0]} - {crop.water_requirement_mm[1]} mm
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Drought Tolerance:</span>
                  <span className="font-medium capitalize text-slate-700">
                    {crop.drought_tolerance}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Seasons:</span>
                  <span className="font-medium text-slate-700">{crop.season.join(', ')}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Growth Period:</span>
                  <span className="font-medium text-slate-700">
                    {crop.growth_days[0]} - {crop.growth_days[1]} days
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'districts' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
          {districts.map((district) => (
            <div
              key={district.id}
              className="p-3 rounded-xl border border-slate-200/80 bg-slate-50/50 text-center"
            >
              <p className="text-xs font-bold text-slate-800">{district.name}</p>
              <p className="text-[10px] text-slate-500 mt-0.5">{district.region}</p>
              <span className="mt-1.5 inline-block text-[9px] px-2 py-0.5 rounded-full bg-slate-200/70 text-slate-700 font-medium">
                {district.rainfall_zone} Rain
              </span>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'rules' && (
        <div className="space-y-3">
          {cropRules.map((rule) => (
            <div
              key={rule.rule_id}
              className="p-3.5 rounded-xl border border-emerald-100 bg-emerald-50/30 flex items-start space-x-3"
            >
              <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-800">{rule.name}</h4>
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-semibold">
                    Score x{rule.benefit_score_multiplier}
                  </span>
                </div>
                <p className="text-xs text-slate-600 mt-1">{rule.description}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'strategies' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
          {strategies.map((strategy, idx) => (
            <div
              key={strategy.id}
              className="p-4 rounded-xl border border-slate-200 bg-gradient-to-b from-slate-50/80 to-white flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs font-bold">
                    0{idx + 1}
                  </span>
                  <h3 className="text-sm font-bold text-slate-800">{strategy.title}</h3>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{strategy.description}</p>
              </div>
              <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] font-medium text-emerald-700">
                Evidence Model: Traceable to NASA Observations
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
