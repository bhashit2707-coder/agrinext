import React from 'react';
import {
  Sparkles,
  Droplets,
  TestTube2,
  Sun,
  BookOpen,
  TrendingUp,
  TrendingDown,
  Minus,
  AlertTriangle,
  FileDown,
  ShieldCheck,
  Calendar,
  Layers,
  Info
} from 'lucide-react';
import type { RotationStrategy, RankingComparisonItem } from '../types';

interface RotationComparisonViewProps {
  strategies: RotationStrategy[];
  rankingComparison?: {
    baseline_weights: { water: number; soil: number; climate: number; local: number };
    applied_weights: { water: number; soil: number; climate: number; local: number };
    rankings: RankingComparisonItem[];
  } | null;
  chosenWeights: { water: number; soil: number; climate: number; local: number };
  baselineWeights?: { water: number; soil: number; climate: number; local: number };
  onOpenReport: () => void;
  onSelectStrategyForTrace?: (strategyId: string) => void;
}

export const RotationComparisonView: React.FC<RotationComparisonViewProps> = ({
  strategies,
  rankingComparison = null,
  chosenWeights,
  baselineWeights = { water: 25, soil: 25, climate: 25, local: 25 },
  onOpenReport,
  onSelectStrategyForTrace
}) => {
  // Ensure we sort strategies by updated overall score descending (Rank 1, Rank 2, Rank 3)
  const sortedStrategies = [...strategies].sort((a, b) => b.overall_score - a.overall_score);
  const comparisonList = rankingComparison?.rankings || [];

  const getRankBadge = (rank: number) => {
    if (rank === 1) {
      return {
        label: '#1 Top Recommendation',
        bg: 'bg-emerald-600 text-white shadow-sm shadow-emerald-700/30 ring-2 ring-emerald-500/20',
        ring: 'border-emerald-500 ring-2 ring-emerald-500/10'
      };
    }
    if (rank === 2) {
      return {
        label: '#2 Alternative Match',
        bg: 'bg-purple-600 text-white shadow-sm shadow-purple-700/20',
        ring: 'border-purple-300'
      };
    }
    return {
      label: '#3 Specialized Option',
      bg: 'bg-slate-700 text-white shadow-sm',
      ring: 'border-slate-300'
    };
  };

  const renderRankChangePill = (baselineRank: number, updatedRank: number, rankChange: number) => {
    if (rankChange > 0) {
      return (
        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
          <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
          <span>Promoted +{rankChange} (from #{baselineRank})</span>
        </span>
      );
    }
    if (rankChange < 0) {
      return (
        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300">
          <TrendingDown className="w-3.5 h-3.5 text-amber-600" />
          <span>Shifted {rankChange} (from #{baselineRank})</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-700 border border-slate-300">
        <Minus className="w-3.5 h-3.5 text-slate-500" />
        <span>Maintained #{updatedRank}</span>
      </span>
    );
  };

  return (
    <div className="space-y-6 pt-4 border-t border-slate-200">
      {/* Header and Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-gradient-to-r from-purple-50 via-slate-50 to-blue-50 p-4 rounded-2xl border border-purple-100">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-600 text-white shadow-xs">
              Side-by-Side Analysis
            </span>
            <h3 className="text-base sm:text-lg font-bold text-slate-900 flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              <span>Three Rotation Strategies Compared Side by Side</span>
            </h3>
          </div>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Real-time multi-attribute comparison recalculated using the actual scoring formula:
            <span className="font-mono font-semibold text-purple-800 ml-1">
              (Water × {chosenWeights.water}% + Soil × {chosenWeights.soil}% + Climate × {chosenWeights.climate}% + Local × {chosenWeights.local}%) / 100
            </span>.
            Rankings and movement explanations adapt immediately.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenReport}
          className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs flex items-center space-x-2 shadow-md shadow-purple-900/20 transition-all cursor-pointer"
        >
          <FileDown className="w-4 h-4" />
          <span>Export / Print PDF Report</span>
        </button>
      </div>

      {/* Baseline vs Updated Rankings Summary Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Layers className="w-4 h-4 text-purple-600" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
              Rankings Comparison: Baseline vs. Updated Priorities
            </h4>
          </div>
          <span className="text-[11px] text-slate-500 font-medium">
            Baseline: [W:{baselineWeights.water}% S:{baselineWeights.soil}% C:{baselineWeights.climate}% L:{baselineWeights.local}%] • Updated: [W:{chosenWeights.water}% S:{chosenWeights.soil}% C:{chosenWeights.climate}% L:{chosenWeights.local}%]
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-600">
                <th className="py-2.5 px-3 font-bold w-16 text-center">Rank</th>
                <th className="py-2.5 px-3 font-bold">Rotation Strategy Archetype</th>
                <th className="py-2.5 px-3 font-bold text-center w-28">Baseline Rank & Score</th>
                <th className="py-2.5 px-3 font-bold text-center w-28">Updated Score</th>
                <th className="py-2.5 px-3 font-bold text-center w-36">Rank Movement</th>
                <th className="py-2.5 px-3 font-bold">Mathematical & Agronomic Explanation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sortedStrategies.map((strat, idx) => {
                const updatedRank = strat.updated_rank || idx + 1;
                const baselineRank = strat.baseline_rank || idx + 1;
                const rankChange = strat.rank_change !== undefined ? strat.rank_change : (baselineRank - updatedRank);
                const scoreDiff = (strat.overall_score - (strat.baseline_score || strat.overall_score)).toFixed(1);
                const compItem = comparisonList.find((c) => c.strategy_id === strat.id);

                return (
                  <tr key={strat.id} className={updatedRank === 1 ? 'bg-purple-50/30' : 'hover:bg-slate-50/60'}>
                    <td className="py-3 px-3 text-center font-mono font-bold text-sm text-purple-900">
                      #{updatedRank}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-bold text-slate-900">{strat.title}</div>
                      <div className="text-[11px] text-slate-500">
                        {strat.crop_sequence?.map((c) => c.crop).join(' → ') || strat.description}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-center font-mono text-slate-600">
                      <span className="font-bold">#{baselineRank}</span>{' '}
                      <span className="text-[11px] text-slate-400">({strat.baseline_score?.toFixed(1) || strat.overall_score.toFixed(1)})</span>
                    </td>
                    <td className="py-3 px-3 text-center font-mono font-bold text-sm text-purple-700">
                      {strat.overall_score.toFixed(1)}
                      <span className="text-[10px] font-normal text-slate-400 block">
                        {parseFloat(scoreDiff) >= 0 ? `+${scoreDiff}` : scoreDiff} pts
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      {renderRankChangePill(baselineRank, updatedRank, rankChange)}
                    </td>
                    <td className="py-3 px-3 text-slate-700 text-[11px] leading-relaxed max-w-md">
                      {strat.movement_explanation || compItem?.movement_explanation || (
                        <span>Calculated dynamically from formula using weights: Water {chosenWeights.water}%, Soil {chosenWeights.soil}%, Climate {chosenWeights.climate}%, Local {chosenWeights.local}%.</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Side-by-Side 3-Column Detailed Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {sortedStrategies.map((strat, idx) => {
          const updatedRank = strat.updated_rank || idx + 1;
          const baselineRank = strat.baseline_rank || idx + 1;
          const rankChange = strat.rank_change !== undefined ? strat.rank_change : (baselineRank - updatedRank);
          const badge = getRankBadge(updatedRank);
          const scores = strat.individual_scores || {
            water_suitability: 75,
            soil_health_potential: 75,
            climate_suitability: 75,
            local_agricultural_suitability: 75
          };

          return (
            <div
              key={strat.id}
              className={`rounded-2xl border bg-white flex flex-col justify-between shadow-xs transition-all ${
                updatedRank === 1
                  ? 'border-emerald-400 ring-2 ring-emerald-500/20 shadow-md shadow-emerald-900/5'
                  : 'border-slate-200 hover:border-purple-300'
              }`}
            >
              <div className="p-5 space-y-4">
                {/* Strategy Rank & Title Header */}
                <div className="space-y-2 border-b border-slate-100 pb-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold tracking-wide uppercase ${badge.bg}`}>
                      {badge.label}
                    </span>
                    <span className="text-[11px] font-mono font-semibold text-slate-500">
                      Baseline: #{baselineRank}
                    </span>
                  </div>

                  <div className="flex items-start justify-between gap-2">
                    <h4 className="text-base font-bold text-slate-900 leading-snug">
                      {strat.title}
                    </h4>
                    <div className="text-right shrink-0">
                      <div className="text-2xl font-mono font-bold text-purple-700 leading-none">
                        {strat.overall_score.toFixed(1)}
                        <span className="text-xs font-normal text-slate-400">/100</span>
                      </div>
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider block mt-0.5">
                        Overall Score
                      </span>
                    </div>
                  </div>

                  {/* Rank Movement Indicator */}
                  <div>
                    {renderRankChangePill(baselineRank, updatedRank, rankChange)}
                  </div>
                </div>

                {/* Explanation Callout */}
                <div className="p-3 rounded-xl bg-purple-50/70 border border-purple-100 text-xs text-purple-950 space-y-1">
                  <div className="flex items-center space-x-1.5 font-bold text-purple-900">
                    <Info className="w-3.5 h-3.5 text-purple-600" />
                    <span>Why Ranked #{updatedRank}:</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-purple-900/90">
                    {strat.movement_explanation || strat.explanation}
                  </p>
                </div>

                {/* 4 Dimension Suitability Breakdown */}
                <div className="space-y-2.5 pt-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600 block">
                    Dimensional Suitability & Weighted Points:
                  </span>

                  {/* Water Efficiency */}
                  <div className="p-2.5 rounded-xl bg-blue-50/60 border border-blue-200/70 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-blue-900 flex items-center space-x-1.5">
                        <Droplets className="w-3.5 h-3.5 text-blue-600" />
                        <span>Water Efficiency</span>
                      </span>
                      <div className="text-right">
                        <span className="font-mono font-bold text-blue-950">{scores.water_suitability}</span>
                        <span className="text-[10px] text-blue-700 ml-1">
                          (+{((scores.water_suitability * chosenWeights.water) / 100).toFixed(1)} pts)
                        </span>
                      </div>
                    </div>
                    <div className="w-full bg-blue-200/50 h-2 rounded-full overflow-hidden">
                      <div className="bg-blue-600 h-full rounded-full transition-all duration-300" style={{ width: `${scores.water_suitability}%` }} />
                    </div>
                    <div className="flex justify-between text-[10px] text-blue-800/80">
                      <span>Priority Weight: {chosenWeights.water}%</span>
                      <span>Score: {scores.water_suitability}/100</span>
                    </div>
                  </div>

                  {/* Soil-Health Potential */}
                  <div className="p-2.5 rounded-xl bg-amber-50/60 border border-amber-200/70 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-amber-950 flex items-center space-x-1.5">
                        <TestTube2 className="w-3.5 h-3.5 text-amber-700" />
                        <span>Soil-Health Potential</span>
                      </span>
                      <div className="text-right">
                        <span className="font-mono font-bold text-amber-950">{scores.soil_health_potential}</span>
                        <span className="text-[10px] text-amber-800 ml-1">
                          (+{((scores.soil_health_potential * chosenWeights.soil) / 100).toFixed(1)} pts)
                        </span>
                      </div>
                    </div>
                    <div className="w-full bg-amber-200/50 h-2 rounded-full overflow-hidden">
                      <div className="bg-amber-600 h-full rounded-full transition-all duration-300" style={{ width: `${scores.soil_health_potential}%` }} />
                    </div>
                    <div className="flex justify-between text-[10px] text-amber-900/80">
                      <span>Priority Weight: {chosenWeights.soil}%</span>
                      <span>Score: {scores.soil_health_potential}/100</span>
                    </div>
                  </div>

                  {/* Climate Resilience */}
                  <div className="p-2.5 rounded-xl bg-purple-50/60 border border-purple-200/70 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-purple-950 flex items-center space-x-1.5">
                        <Sun className="w-3.5 h-3.5 text-purple-600" />
                        <span>Climate Resilience</span>
                      </span>
                      <div className="text-right">
                        <span className="font-mono font-bold text-purple-950">{scores.climate_suitability}</span>
                        <span className="text-[10px] text-purple-700 ml-1">
                          (+{((scores.climate_suitability * chosenWeights.climate) / 100).toFixed(1)} pts)
                        </span>
                      </div>
                    </div>
                    <div className="w-full bg-purple-200/50 h-2 rounded-full overflow-hidden">
                      <div className="bg-purple-600 h-full rounded-full transition-all duration-300" style={{ width: `${scores.climate_suitability}%` }} />
                    </div>
                    <div className="flex justify-between text-[10px] text-purple-800/80">
                      <span>Priority Weight: {chosenWeights.climate}%</span>
                      <span>Score: {scores.climate_suitability}/100</span>
                    </div>
                  </div>

                  {/* Local Agricultural Suitability */}
                  <div className="p-2.5 rounded-xl bg-emerald-50/60 border border-emerald-200/70 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-emerald-950 flex items-center space-x-1.5">
                        <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Local Agricultural Suitability</span>
                      </span>
                      <div className="text-right">
                        <span className="font-mono font-bold text-emerald-950">{scores.local_agricultural_suitability}</span>
                        <span className="text-[10px] text-emerald-800 ml-1">
                          (+{((scores.local_agricultural_suitability * chosenWeights.local) / 100).toFixed(1)} pts)
                        </span>
                      </div>
                    </div>
                    <div className="w-full bg-emerald-200/50 h-2 rounded-full overflow-hidden">
                      <div className="bg-emerald-600 h-full rounded-full transition-all duration-300" style={{ width: `${scores.local_agricultural_suitability}%` }} />
                    </div>
                    <div className="flex justify-between text-[10px] text-emerald-900/80">
                      <span>Priority Weight: {chosenWeights.local}%</span>
                      <span>Score: {scores.local_agricultural_suitability}/100</span>
                    </div>
                  </div>
                </div>

                {/* 3-Season Rotation Sequence */}
                <div className="space-y-2 pt-1 border-t border-slate-100">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600 block flex items-center space-x-1">
                    <Calendar className="w-3.5 h-3.5 text-purple-600" />
                    <span>3-Season Rotation Sequence:</span>
                  </span>
                  <div className="space-y-1.5">
                    {strat.crop_sequence?.map((step: any, sIdx: number) => {
                      const cropName = typeof step === 'string' ? step : (step.crop || step.crop_name || 'Crop');
                      const role = typeof step === 'object' && step ? step.role : '';
                      const seasonLabel = typeof step === 'object' && step && step.season
                        ? String(step.season).split(' ')[0]
                        : (sIdx === 0 ? 'Kharif' : sIdx === 1 ? 'Rabi' : 'Summer');

                      return (
                        <div
                          key={sIdx}
                          className="p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between"
                        >
                          <div>
                            <span className="font-bold text-slate-800 block">{cropName}</span>
                            {role && <span className="text-[10px] text-slate-500">{role}</span>}
                          </div>
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white border border-slate-200 text-purple-800 shrink-0">
                            {seasonLabel}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Environmental Evidence Highlights */}
                <div className="space-y-1.5 pt-1 border-t border-slate-100">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600 block flex items-center space-x-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                    <span>Environmental Evidence Highlights:</span>
                  </span>
                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-700 space-y-1 leading-snug">
                    <p><b>NASA Climate:</b> {strat.environmental_rationale || strat.explanation}</p>
                    {strat.evidence_trace?.dimensions?.soil_health_potential?.derived_indicators && (
                      <p>
                        <b>Ground-Truth Soil:</b> {strat.evidence_trace.dimensions.soil_health_potential.derived_indicators.soil_texture_evaluated} • +{strat.evidence_trace.dimensions.soil_health_potential.derived_indicators.biological_nitrogen_credit_kg_ha} kg BNF/ha credit
                      </p>
                    )}
                  </div>
                </div>

                {/* Identified Potential Risks */}
                <div className="space-y-1 pt-1 border-t border-slate-100">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-amber-900 block flex items-center space-x-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                    <span>Agronomic Risks & Constraints:</span>
                  </span>
                  <ul className="text-[11px] text-amber-900 space-y-0.5 list-disc list-inside bg-amber-50/50 p-2 rounded-lg border border-amber-200">
                    {strat.potential_risks?.slice(0, 2).map((risk, rIdx) => (
                      <li key={rIdx}>{risk}</li>
                    )) || <li>Standard seasonal rainfall variability</li>}
                  </ul>
                </div>
              </div>

              {/* Action Button */}
              {onSelectStrategyForTrace && (
                <div className="p-3 bg-slate-50 border-t border-slate-100 rounded-b-2xl">
                  <button
                    type="button"
                    onClick={() => onSelectStrategyForTrace(strat.id)}
                    className="w-full py-2 px-3 rounded-lg bg-white hover:bg-purple-50 border border-slate-200 hover:border-purple-300 text-purple-700 text-xs font-bold transition-all flex items-center justify-center space-x-1 cursor-pointer"
                  >
                    <span>Inspect Full Evidence Trace</span>
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
