import React, { useState, useEffect, useCallback } from 'react';
import {
  TrendingUp,
  CloudRain,
  Thermometer,
  Droplets,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  Info,
  ShieldCheck,
  CheckCircle2,
  Activity,
  Layers,
  ChevronDown,
  ChevronUp,
  FileDown
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { apiService } from '../services/api';
import { useNotification } from '../context/NotificationContext';
import type {
  FarmProfile,
  FarmerProfile,
  ClimateSimulationResponse,
  ScenarioComparisonItem
} from '../types';

interface ClimateSimulatorModuleProps {
  activeFarm: FarmProfile | null;
  defaultCoords: { lat: number; lng: number };
  farmerProfile?: FarmerProfile | null;
  baselineDossier?: any;
  appliedWeights?: { water: number; soil: number; climate: number; local: number };
}

const DEFAULT_WEIGHTS = { water: 25, soil: 25, climate: 25, local: 25 };

export const ClimateSimulatorModule: React.FC<ClimateSimulatorModuleProps> = ({
  activeFarm,
  defaultCoords,
  farmerProfile,
  baselineDossier,
  appliedWeights = DEFAULT_WEIGHTS
}) => {
  const { notify } = useNotification();
  // Scenario Anomaly Adjustments
  const [rainfallPct, setRainfallPct] = useState<number>(0);
  const [tempChangeC, setTempChangeC] = useState<number>(0.0);
  const [waterAvailPct, setWaterAvailPct] = useState<number>(0);

  // Simulation State
  const [simulationResult, setSimulationResult] = useState<ClimateSimulationResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [downloadingPdf, setDownloadingPdf] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [showAuditTrail, setShowAuditTrail] = useState<boolean>(false);

  // Active request tracking to eliminate out-of-order race conditions
  const requestIdRef = React.useRef<number>(0);
  const debounceTimerRef = React.useRef<any>(null);

  // Primitive stable values for coordinates
  const targetLat = activeFarm ? activeFarm.latitude : defaultCoords.lat;
  const targetLng = activeFarm ? activeFarm.longitude : defaultCoords.lng;
  const farmId = activeFarm?.id || null;
  const stateId = activeFarm?.state_id || 'andhra_pradesh';

  const isSimulatedActive = rainfallPct !== 0 || tempChangeC !== 0 || waterAvailPct !== 0;

  // Execute simulation API call with race-condition protection
  const executeSimulation = useCallback(
    async (rf: number, tc: number, wa: number) => {
      const currentReqId = ++requestIdRef.current;
      setLoading(true);
      setError(null);
      try {
        const response = await apiService.simulateClimateScenario({
          state_id: stateId,
          latitude: targetLat,
          longitude: targetLng,
          farm_id: farmId,
          farmer_profile: farmerProfile || null,
          weights: appliedWeights || DEFAULT_WEIGHTS,
          baseline_dossier: baselineDossier || null,
          rainfall_pct_change: rf,
          temp_celsius_change: tc,
          water_availability_pct_change: wa
        });

        // Only commit if this response corresponds to the newest request
        if (currentReqId === requestIdRef.current) {
          setSimulationResult(response);
          setLoading(false);
        }
      } catch (err: any) {
        if (currentReqId === requestIdRef.current) {
          console.error('Climate simulation failed:', err);
          setError(err.message || 'Failed to execute climate simulation.');
          setLoading(false);
        }
      }
    },
    [stateId, targetLat, targetLng, farmId, farmerProfile, appliedWeights, baselineDossier]
  );

  // Debounced execution to prevent slider dragging request spam and score fluctuations
  useEffect(() => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    // Run immediately on first mount or reset, debounce when dragging sliders
    if (!simulationResult || (!rainfallPct && !tempChangeC && !waterAvailPct)) {
      executeSimulation(rainfallPct, tempChangeC, waterAvailPct);
    } else {
      debounceTimerRef.current = setTimeout(() => {
        executeSimulation(rainfallPct, tempChangeC, waterAvailPct);
      }, 250);
    }

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [executeSimulation, rainfallPct, tempChangeC, waterAvailPct]);

  // Scenario Presets
  const applyPreset = (rf: number, tc: number, wa: number) => {
    setRainfallPct(rf);
    setTempChangeC(tc);
    setWaterAvailPct(wa);
  };

  const handleResetToBaseline = () => {
    setRainfallPct(0);
    setTempChangeC(0.0);
    setWaterAvailPct(0);
  };

  const handleDownloadPdf = async () => {
    if (!simulationResult) return;
    try {
      setDownloadingPdf(true);
      const strategiesForReport = simulationResult.comparison_matrix.map((m) => ({
        id: m.strategy_id,
        title: m.title,
        crop_sequence: m.sequence.split(' → '),
        season: 'Kharif-Rabi-Summer',
        overall_score: m.scenario_score,
        individual_scores: m.scenario_scores,
        explanation: m.resilience_explanation,
        potential_risks: ['Simulated agro-climatic stress anomaly sensitivity test'],
        evidence_trace: {
          dimensions: {
            water_suitability: { score: m.scenario_scores.water_suitability, weight: appliedWeights.water, supporting_evidence: ['NASA GPM IMERG / SMAP Calibrated'], traceable_explanation: 'Simulated water suitability score' },
            soil_health_potential: { score: m.scenario_scores.soil_health_potential, weight: appliedWeights.soil, supporting_evidence: ['Farmer Soil Health Ground-Truth'], traceable_explanation: 'Soil fertility regeneration potential' },
            climate_suitability: { score: m.scenario_scores.climate_suitability, weight: appliedWeights.climate, supporting_evidence: ['NASA POWER Diurnal 2m Reanalysis'], traceable_explanation: 'Simulated thermal suitability score' },
            local_agricultural_suitability: { score: m.scenario_scores.local_agricultural_suitability, weight: appliedWeights.local, supporting_evidence: ['ANGRAU Vyavasaya Panchangam (2023-24)'], traceable_explanation: 'Local agricultural package of practices' }
          }
        }
      }));

      const blob = await apiService.downloadReportPdf({
        farm_id: activeFarm?.id || null,
        farm_data: activeFarm || null,
        farmer_profile: farmerProfile || null,
        weights: appliedWeights,
        baseline_weights: { water: 25, soil: 25, climate: 25, local: 25 },
        strategies: strategiesForReport,
        ranking_comparison: {
          baseline_weights: { water: 25, soil: 25, climate: 25, local: 25 },
          applied_weights: appliedWeights,
          rankings: simulationResult.comparison_matrix
        },
        dossier: baselineDossier || null,
        simulation_data: isSimulatedActive ? simulationResult : null
      });

      const districtName = activeFarm?.district_id || 'AP';
      const simTag = isSimulatedActive ? 'Simulated_Scenario' : 'NASA_Baseline';
      const filename = `AgriNext_Crop_Rotation_Report_${districtName}_${simTag}_${new Date().toISOString().slice(0, 10)}.pdf`;

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to download PDF report:', err);
      notify('Failed to generate PDF report from backend.');
    } finally {
      setDownloadingPdf(false);
    }
  };

  // Prepare chart data for Recharts
  const chartData = simulationResult?.comparison_matrix.map((item: ScenarioComparisonItem) => {
    const shortTitle = item.strategy_id === 'climate_resilient'
      ? 'Climate Resilient'
      : item.strategy_id === 'soil_restoration'
      ? 'Soil Restoration'
      : 'Economic Balanced';

    return {
      name: shortTitle,
      'NASA Baseline Score': item.baseline_score,
      'Simulated Scenario Score': item.scenario_score,
      delta: item.score_delta
    };
  }) || [];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 space-y-6">
      {/* Header & Badges */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-2 rounded-xl bg-amber-50 text-amber-600 border border-amber-200">
              <TrendingUp className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800">
              AgriNext Climate What-if Scenario Simulator
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Evaluates rotation strategy stress resistance against actual gridded NASA satellite baseline data (POWER, SMAP, GPM).
          </p>
        </div>

        {/* Scientific Badges */}
        <div className="flex flex-wrap items-center gap-2">
          {isSimulatedActive ? (
            <span className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 shadow-xs">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              <span>[SIMULATED - HYPOTHETICAL]</span>
            </span>
          ) : (
            <span className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>NASA OBSERVATIONAL BASELINE</span>
            </span>
          )}

          <span className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-100 text-slate-600 border border-slate-200">
            Step 10 of 11
          </span>
        </div>
      </div>

      {/* Critical Scientific Rules Disclaimer Banner */}
      <div className="bg-amber-50/80 border border-amber-200/90 rounded-xl p-4 flex items-start space-x-3 text-amber-900">
        <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
        <div className="text-xs space-y-1">
          <p className="font-semibold text-amber-950">
            SCIENTIFIC SIMULATION BOUNDARIES &amp; INTEGRITY RULES:
          </p>
          <p className="text-amber-800 leading-relaxed">
            Gridded satellite baseline observations (NASA POWER, SMAP, GPM) are preserved in their original state and never overwritten.
            This simulator applies hypothetical sensitivity anomalies to derived indicators.
            <strong> It is NOT a numerical weather forecast or a coupled General Circulation Model (GCM).</strong>
            If this sensitivity test is skipped or reset, all final recommendations strictly use the original NASA baseline observations.
          </p>
        </div>
      </div>

      {/* Preset Scenario Buttons */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center space-x-1.5">
          <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
          <span>Quick Scenario Presets</span>
        </label>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => applyPreset(-20, 2.0, -25)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition-all flex items-center space-x-1.5 ${
              rainfallPct === -20 && tempChangeC === 2.0 && waterAvailPct === -25
                ? 'bg-amber-600 text-white border-amber-700 shadow-sm'
                : 'bg-amber-50/70 text-amber-800 border-amber-200 hover:bg-amber-100'
            }`}
          >
            <span>📉 Mild Drought (-20% Rain, +2°C, -25% Water)</span>
          </button>

          <button
            onClick={() => applyPreset(-10, 3.5, -30)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition-all flex items-center space-x-1.5 ${
              rainfallPct === -10 && tempChangeC === 3.5 && waterAvailPct === -30
                ? 'bg-rose-600 text-white border-rose-700 shadow-sm'
                : 'bg-rose-50/70 text-rose-800 border-rose-200 hover:bg-rose-100'
            }`}
          >
            <span>🔥 Severe Heatwave (-10% Rain, +3.5°C, -30% Water)</span>
          </button>

          <button
            onClick={() => applyPreset(25, 0.0, 15)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition-all flex items-center space-x-1.5 ${
              rainfallPct === 25 && tempChangeC === 0 && waterAvailPct === 15
                ? 'bg-blue-600 text-white border-blue-700 shadow-sm'
                : 'bg-blue-50/70 text-blue-800 border-blue-200 hover:bg-blue-100'
            }`}
          >
            <span>🌧️ Monsoon Surplus (+25% Rain, 0°C, +15% Water)</span>
          </button>

          <button
            onClick={handleResetToBaseline}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition-all flex items-center space-x-1.5 ${
              !isSimulatedActive
                ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm'
                : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to NASA Baseline (0%, 0°C, 0%)</span>
          </button>

          <button
            onClick={handleDownloadPdf}
            disabled={downloadingPdf || !simulationResult}
            className="px-3.5 py-1.5 text-xs font-bold rounded-xl border border-emerald-600 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white shadow-sm transition-all flex items-center space-x-1.5 ml-auto cursor-pointer"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span>{downloadingPdf ? 'Generating PDF...' : isSimulatedActive ? 'Download Scenario PDF' : 'Download Baseline PDF'}</span>
          </button>
        </div>
      </div>

      {/* Interactive Anomaly Sliders (Rainfall, Temperature, Water) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 p-5 bg-slate-50/80 rounded-2xl border border-slate-200/80">
        {/* Slider 1: Rainfall Percentage Change */}
        <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="flex items-center space-x-1.5 text-xs font-bold text-slate-700">
              <CloudRain className="w-4 h-4 text-blue-500" />
              <span>Rainfall Percentage Change</span>
            </span>
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                rainfallPct < 0
                  ? 'bg-amber-100 text-amber-800'
                  : rainfallPct > 0
                  ? 'bg-blue-100 text-blue-800'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              {rainfallPct > 0 ? `+${rainfallPct}` : rainfallPct}%
            </span>
          </div>

          <input
            type="range"
            min="-50"
            max="50"
            step="1"
            value={rainfallPct}
            onChange={(e) => setRainfallPct(Number(e.target.value))}
            className="w-full accent-blue-600 cursor-pointer"
          />

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
            <span>-50% Drought</span>
            <span className="font-semibold text-slate-700">
              {simulationResult?.transformations_audit.rainfall.simulated_value_mm ?? '—'} mm
              <span className="text-[10px] text-slate-400 font-normal ml-1">
                (Base: {simulationResult?.transformations_audit.rainfall.baseline_value_mm ?? '—'} mm)
              </span>
            </span>
            <span>+50% Flood</span>
          </div>
        </div>

        {/* Slider 2: Temperature Change in °C */}
        <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="flex items-center space-x-1.5 text-xs font-bold text-slate-700">
              <Thermometer className="w-4 h-4 text-rose-500" />
              <span>Temperature Change (°C)</span>
            </span>
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                tempChangeC > 0
                  ? 'bg-rose-100 text-rose-800'
                  : tempChangeC < 0
                  ? 'bg-cyan-100 text-cyan-800'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              {tempChangeC > 0 ? `+${tempChangeC.toFixed(1)}` : tempChangeC.toFixed(1)}°C
            </span>
          </div>

          <input
            type="range"
            min="-2.0"
            max="6.0"
            step="0.5"
            value={tempChangeC}
            onChange={(e) => setTempChangeC(Number(e.target.value))}
            className="w-full accent-rose-600 cursor-pointer"
          />

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
            <span>-2.0°C Cool</span>
            <span className="font-semibold text-slate-700">
              {simulationResult?.transformations_audit.temperature.simulated_t2m_avg_c ?? '—'}°C avg
              <span className="text-[10px] text-slate-400 font-normal ml-1">
                (Max: {simulationResult?.transformations_audit.temperature.simulated_t2m_max_c ?? '—'}°C)
              </span>
            </span>
            <span>+6.0°C Heat</span>
          </div>
        </div>

        {/* Slider 3: Water Availability Percentage Change */}
        <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="flex items-center space-x-1.5 text-xs font-bold text-slate-700">
              <Droplets className="w-4 h-4 text-teal-500" />
              <span>Water Availability Change</span>
            </span>
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                waterAvailPct < 0
                  ? 'bg-amber-100 text-amber-800'
                  : waterAvailPct > 0
                  ? 'bg-teal-100 text-teal-800'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              {waterAvailPct > 0 ? `+${waterAvailPct}` : waterAvailPct}%
            </span>
          </div>

          <input
            type="range"
            min="-50"
            max="50"
            step="1"
            value={waterAvailPct}
            onChange={(e) => setWaterAvailPct(Number(e.target.value))}
            className="w-full accent-teal-600 cursor-pointer"
          />

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
            <span>-50% Curtailment</span>
            <span className="font-semibold text-slate-700">
              SMAP Regime: {simulationResult?.transformations_audit.water_availability.simulated_smap_regime ?? 'adequate'}
            </span>
            <span>+50% Surplus</span>
          </div>
        </div>
      </div>

      {/* Error notification */}
      {error && (
        <div className="p-3 bg-rose-50 text-rose-700 rounded-xl border border-rose-200 text-xs flex items-center space-x-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Visual Chart Comparison: Baseline vs Scenario (Recharts) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
            <Activity className="w-4 h-4 text-emerald-600" />
            <span>Suitability Score Comparison: NASA Baseline vs. Hypothetical Scenario</span>
          </h3>
          {loading && (
            <span className="text-xs text-slate-400 animate-pulse flex items-center space-x-1">
              <span>Recalculating engine...</span>
            </span>
          )}
        </div>

        <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-200/80 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 20, right: 30, left: 10, bottom: 10 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#475569' }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#475569' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  borderRadius: '10px',
                  border: '1px solid #cbd5e1',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
                }}
              />
              <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
              <Bar dataKey="NASA Baseline Score" fill="#10b981" radius={[4, 4, 0, 0]} isAnimationActive={false} />
              <Bar dataKey="Simulated Scenario Score" fill="#f59e0b" radius={[4, 4, 0, 0]} isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Most Resilient Strategy Callout */}
      {simulationResult && isSimulatedActive && (
        <div className="p-4 bg-emerald-50/70 border border-emerald-300 rounded-xl flex items-start space-x-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5 shrink-0" />
          <div className="text-xs space-y-1">
            <span className="font-bold text-emerald-900 uppercase tracking-wide">
              Most Resilient Strategy Under Simulated Stress:
            </span>
            <p className="text-emerald-800">
              <strong>{simulationResult.most_resilient_strategy.title}</strong> demonstrated superior buffering
              with a scenario suitability score of{' '}
              <strong className="text-emerald-950 font-mono">
                {simulationResult.most_resilient_strategy.scenario_score.toFixed(1)}/100
              </strong>{' '}
              (Score Delta: {simulationResult.most_resilient_strategy.score_delta > 0 ? '+' : ''}
              {simulationResult.most_resilient_strategy.score_delta.toFixed(1)} pts).
            </p>
          </div>
        </div>
      )}

      {/* Side-by-Side Strategy Ranking & Explanation Table */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
          <Layers className="w-4 h-4 text-indigo-600" />
          <span>Ranking &amp; Movement Comparison Matrix</span>
        </h3>

        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/80 text-slate-600 border-b border-slate-200 font-semibold">
                <th className="p-3">Strategy Archetype</th>
                <th className="p-3">Sequence</th>
                <th className="p-3 text-center">Baseline (NASA)</th>
                <th className="p-3 text-center">Simulated Scenario</th>
                <th className="p-3 text-center">Rank Shift</th>
                <th className="p-3">Agronomic Stress &amp; Movement Explanation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {simulationResult?.comparison_matrix.map((row: ScenarioComparisonItem) => {
                const isPromoted = row.rank_shift > 0;
                const isDemoted = row.rank_shift < 0;

                return (
                  <tr key={row.strategy_id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="p-3 font-bold text-slate-800 whitespace-nowrap">
                      {row.title}
                    </td>
                    <td className="p-3 text-slate-600 text-[11px] whitespace-nowrap font-medium">
                      {row.sequence}
                    </td>
                    <td className="p-3 text-center whitespace-nowrap">
                      <span className="font-semibold text-slate-700">Rank #{row.baseline_rank}</span>
                      <span className="text-[11px] text-slate-500 block font-mono">
                        ({row.baseline_score.toFixed(1)} pts)
                      </span>
                    </td>
                    <td className="p-3 text-center whitespace-nowrap">
                      <span
                        className={`font-bold ${
                          row.scenario_rank === 1
                            ? 'text-emerald-700'
                            : row.scenario_rank === 2
                            ? 'text-purple-700'
                            : 'text-slate-700'
                        }`}
                      >
                        Rank #{row.scenario_rank}
                      </span>
                      <span className="text-[11px] font-mono block text-slate-600">
                        ({row.scenario_score.toFixed(1)} pts)
                      </span>
                    </td>
                    <td className="p-3 text-center whitespace-nowrap">
                      {isPromoted ? (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                          <ArrowUpRight className="w-3.5 h-3.5" />
                          <span>+{row.rank_shift}</span>
                        </span>
                      ) : isDemoted ? (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300">
                          <ArrowDownRight className="w-3.5 h-3.5" />
                          <span>{row.rank_shift}</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                          <Minus className="w-3 h-3" />
                          <span>Unchanged</span>
                        </span>
                      )}
                    </td>
                    <td className="p-3 text-slate-600 leading-relaxed text-[11px]">
                      {row.resilience_explanation}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assumptions & Mathematical Transformation Audit (Collapsible) */}
      <div className="border border-slate-200 rounded-xl overflow-hidden">
        <button
          onClick={() => setShowAuditTrail(!showAuditTrail)}
          className="w-full px-4 py-3 bg-slate-50 hover:bg-slate-100 transition-colors flex items-center justify-between text-xs font-semibold text-slate-700"
        >
          <span className="flex items-center space-x-2">
            <Info className="w-4 h-4 text-blue-500" />
            <span>Mathematical Transformation Formulas &amp; Assumptions Audit</span>
          </span>
          {showAuditTrail ? (
            <ChevronUp className="w-4 h-4 text-slate-400" />
          ) : (
            <ChevronDown className="w-4 h-4 text-slate-400" />
          )}
        </button>

        {showAuditTrail && simulationResult && (
          <div className="p-4 bg-white space-y-3 text-xs border-t border-slate-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Rainfall Transformation */}
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-800 block">Rainfall Transformation:</span>
                <code className="text-[11px] text-blue-700 font-mono block">
                  {simulationResult.transformations_audit.rainfall.formula}
                </code>
                <p className="text-[11px] text-slate-600">
                  Baseline: {simulationResult.transformations_audit.rainfall.baseline_value_mm} mm &rarr; Simulated:{' '}
                  {simulationResult.transformations_audit.rainfall.simulated_value_mm} mm (Δ{' '}
                  {simulationResult.transformations_audit.rainfall.delta_mm} mm)
                </p>
                <span className="text-[10px] text-slate-400 block">
                  Source: {simulationResult.transformations_audit.rainfall.baseline_source}
                </span>
              </div>

              {/* Temperature Transformation */}
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-800 block">Temperature Transformation:</span>
                <code className="text-[11px] text-rose-700 font-mono block">
                  {simulationResult.transformations_audit.temperature.formula}
                </code>
                <p className="text-[11px] text-slate-600">
                  Baseline: {simulationResult.transformations_audit.temperature.baseline_t2m_avg_c}°C avg /{' '}
                  {simulationResult.transformations_audit.temperature.baseline_t2m_max_c}°C max &rarr; Simulated:{' '}
                  {simulationResult.transformations_audit.temperature.simulated_t2m_avg_c}°C avg /{' '}
                  {simulationResult.transformations_audit.temperature.simulated_t2m_max_c}°C max
                </p>
                <span className="text-[10px] text-slate-400 block">
                  Source: {simulationResult.transformations_audit.temperature.baseline_source}
                </span>
              </div>

              {/* Water Availability Transformation */}
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-800 block">Water Availability Transformation:</span>
                <code className="text-[11px] text-teal-700 font-mono block">
                  {simulationResult.transformations_audit.water_availability.formula}
                </code>
                <p className="text-[11px] text-slate-600">
                  Adjustment: {simulationResult.transformations_audit.water_availability.water_availability_pct_change}%
                  (Simulated Regime:{' '}
                  {simulationResult.transformations_audit.water_availability.simulated_smap_regime ?? 'adequate'})
                </p>
                <span className="text-[10px] text-slate-400 block">
                  Source: {simulationResult.transformations_audit.water_availability.baseline_source}
                </span>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-blue-50/60 border border-blue-200/70 text-[11px] text-blue-900">
              <span className="font-bold">Preservation Notice: </span>
              {simulationResult.baseline_preservation_notice}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
