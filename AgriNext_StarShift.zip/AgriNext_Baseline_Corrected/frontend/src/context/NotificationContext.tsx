import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';

type Notice = { id: number; message: string; kind: 'success' | 'error' | 'info' };
type NotificationContextValue = { notify: (message: string, kind?: Notice['kind']) => void };
const NotificationContext = createContext<NotificationContextValue | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notices, setNotices] = useState<Notice[]>([]);
  const notify = useCallback((message: string, kind: Notice['kind'] = 'error') => {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    setNotices((current) => [...current.slice(-3), { id, message, kind }]);
  }, []);
  useEffect(() => {
    if (!notices.length) return;
    const timers = notices.map((notice) => window.setTimeout(() => {
      setNotices((current) => current.filter((item) => item.id !== notice.id));
    }, 6500));
    return () => timers.forEach(window.clearTimeout);
  }, [notices]);
  return (
    <NotificationContext.Provider value={{ notify }}>
      {children}
      <div className="fixed right-4 top-4 z-[10000] flex w-[min(92vw,26rem)] flex-col gap-2" aria-live="polite" aria-atomic="false">
        {notices.map((notice) => (
          <div key={notice.id} role={notice.kind === 'error' ? 'alert' : 'status'}
            className={`rounded-xl border px-4 py-3 text-sm shadow-lg ${notice.kind === 'error' ? 'border-rose-200 bg-rose-50 text-rose-800' : notice.kind === 'success' ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : 'border-sky-200 bg-sky-50 text-sky-800'}`}>
            <div className="flex items-start justify-between gap-3"><span>{notice.message}</span>
              <button type="button" onClick={() => setNotices((current) => current.filter((item) => item.id !== notice.id))} className="font-bold opacity-70 hover:opacity-100" aria-label="Dismiss notification">×</button>
            </div>
          </div>
        ))}
      </div>
    </NotificationContext.Provider>
  );
};

export const useNotification = (): NotificationContextValue => {
  const value = useContext(NotificationContext);
  if (!value) throw new Error('useNotification must be used inside NotificationProvider');
  return value;
};
