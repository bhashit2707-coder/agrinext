import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { AppRoute } from '../types';

interface NavigationContextType {
  currentRoute: AppRoute;
  currentPath: string;
  navigate: (path: string, options?: { replace?: boolean }) => void;
  redirectParam: string | null;
}

const NavigationContext = createContext<NavigationContextType | undefined>(undefined);

function normalizeRoute(path: string): AppRoute {
  // Support hash routing (e.g. #/login or #login) or pathname routing (/login)
  const cleanPath = path.replace(/^#\/?/, '/').split('?')[0].toLowerCase();
  if (cleanPath === '' || cleanPath === '/' || cleanPath === '/dashboard') {
    return '/';
  }
  if (cleanPath.startsWith('/login')) {
    return '/login';
  }
  if (cleanPath.startsWith('/profile')) {
    return '/profile';
  }
  return cleanPath as AppRoute;
}

export const NavigationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const getInitialPath = () => {
    if (typeof window === 'undefined') return '/';
    // Prefer hash if present (e.g. in environments without rewrite), otherwise pathname
    if (window.location.hash) {
      return window.location.hash.replace(/^#/, '');
    }
    return window.location.pathname || '/';
  };

  const [currentPath, setCurrentPath] = useState<string>(getInitialPath);

  useEffect(() => {
    const handleLocationChange = () => {
      if (window.location.hash) {
        setCurrentPath(window.location.hash.replace(/^#/, ''));
      } else {
        setCurrentPath(window.location.pathname || '/');
      }
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);

    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  const navigate = useCallback((path: string, options?: { replace?: boolean }) => {
    const targetUrl = path.startsWith('/') ? path : `/${path}`;
    if (options?.replace) {
      window.history.replaceState({}, '', targetUrl);
    } else {
      window.history.pushState({}, '', targetUrl);
    }
    setCurrentPath(targetUrl);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const currentRoute = normalizeRoute(currentPath);

  const redirectParam = typeof window !== 'undefined'
    ? new URLSearchParams(window.location.search).get('redirect')
    : null;

  return (
    <NavigationContext.Provider value={{ currentRoute, currentPath, navigate, redirectParam }}>
      {children}
    </NavigationContext.Provider>
  );
};

export const useNavigation = (): NavigationContextType => {
  const context = useContext(NavigationContext);
  if (!context) {
    throw new Error('useNavigation must be used within a NavigationProvider');
  }
  return context;
};
