import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { apiService } from '../services/api';
import type { UserAccount, LoginCredentials } from '../types';

interface AuthContextType {
  currentUser: UserAccount | null;
  isAuthenticated: boolean;
  login: (credentials: LoginCredentials) => Promise<{ success: boolean; error?: string }>;
  register: (details: { fullName: string; email: string; password: string }) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateUserProfile: (updates: Partial<UserAccount>) => void;
  authIntegrationNotice: {
    status: 'integrated';
    message: string;
    details: string;
  };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [authReady, setAuthReady] = useState(false);

  const mapUser = useCallback((user: { id: string; name: string; email: string; role: string; verified: boolean; member_since: string }): UserAccount => ({
    id: user.id, name: user.name, email: user.email, role: 'farmer',
    designation: 'Registered Farmer', organization: 'AgriNext',
    state_id: '', district_id: '', verified: user.verified,
    member_since: user.member_since
  }), []);

  useEffect(() => {
    let active = true;
    apiService.getCurrentUser()
      .then((result) => { if (active) setCurrentUser(mapUser(result.user)); })
      .catch(() => { if (active) setCurrentUser(null); })
      .finally(() => { if (active) setAuthReady(true); });
    return () => { active = false; };
  }, [mapUser]);

  const authIntegrationNotice = {
    status: 'integrated' as const,
    message: 'Backend Authentication Integrated',
    details: 'Accounts are verified by the AgriNext backend. Passwords are hashed server-side and the browser receives an HttpOnly session cookie. Public registration creates farmer accounts only.'
  };

  const login = useCallback(async (credentials: LoginCredentials): Promise<{ success: boolean; error?: string }> => {
    try {
      const result = await apiService.login({ email: credentials.identifier.trim(), password: credentials.password });
      setCurrentUser(mapUser(result.user));
      return { success: true };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : 'Authentication failed' };
    }
  }, [mapUser]);

  const register = useCallback(async (details: { fullName: string; email: string; password: string }): Promise<{ success: boolean; error?: string }> => {
    try {
      const result = await apiService.register({ full_name: details.fullName, email: details.email, password: details.password });
      setCurrentUser(mapUser(result.user));
      return { success: true };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : 'Registration failed' };
    }
  }, [mapUser]);

  const logout = useCallback(async () => {
    try { await apiService.logout(); } finally { setCurrentUser(null); }
  }, []);

  const updateUserProfile = useCallback((updates: Partial<UserAccount>) => {
    setCurrentUser((prev) => (prev ? { ...prev, ...updates } : null));
  }, []);

  return (
    <AuthContext.Provider value={{ currentUser, isAuthenticated: currentUser !== null, login, register, logout, updateUserProfile, authIntegrationNotice }}>
      {authReady ? children : <div className="min-h-screen flex items-center justify-center text-sm text-slate-500">Checking secure session…</div>}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
