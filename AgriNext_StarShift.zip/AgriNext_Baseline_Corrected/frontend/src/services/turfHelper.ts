import * as turf from '@turf/turf';
import type { GeoJSONPolygonGeometry } from '../types';

export const SQ_METERS_PER_ACRE = 4046.8564224;

export interface TurfAcreageResult {
  acres: number;
  sqMeters: number;
  centroid: {
    lat: number;
    lng: number;
  };
  bbox: [number, number, number, number]; // [minLng, minLat, maxLng, maxLat]
  geojsonPolygon: GeoJSON.Feature<GeoJSON.Polygon>;
}

/**
 * Calculates geodesic acreage and centroid from an array of [lat, lng] coordinates.
 */
export function calculateAcreageAndCentroid(latLngs: Array<{ lat: number; lng: number }>): TurfAcreageResult | null {
  if (latLngs.length < 3) {
    return null;
  }

  // Convert to GeoJSON standard [lng, lat] coordinates
  const coords: number[][] = latLngs.map((pt) => [pt.lng, pt.lat]);

  // Ensure closed ring (first == last)
  if (
    coords[0][0] !== coords[coords.length - 1][0] ||
    coords[0][1] !== coords[coords.length - 1][1]
  ) {
    coords.push([...coords[0]]);
  }

  try {
    const polygonFeature = turf.polygon([coords]);
    const sqMeters = turf.area(polygonFeature);
    const acres = sqMeters / SQ_METERS_PER_ACRE;
    const centroidFeature = turf.centroid(polygonFeature);
    const [cLng, cLat] = centroidFeature.geometry.coordinates;
    const bbox = turf.bbox(polygonFeature) as [number, number, number, number];

    return {
      acres: Number(acres.toFixed(3)),
      sqMeters: Number(sqMeters.toFixed(1)),
      centroid: {
        lat: Number(cLat.toFixed(6)),
        lng: Number(cLng.toFixed(6))
      },
      bbox,
      geojsonPolygon: polygonFeature
    };
  } catch (err) {
    console.error('Turf calculation error:', err);
    return null;
  }
}

/**
 * Converts a GeoJSON Polygon Feature to array of {lat, lng} points for Leaflet.
 */
export function geojsonToLatLngs(geometry: GeoJSONPolygonGeometry | any): Array<{ lat: number; lng: number }> {
  if (!geometry) return [];
  const coords = geometry.type === 'Feature' ? geometry.geometry.coordinates : geometry.coordinates;
  if (!coords || !coords[0]) return [];
  
  // Outer ring
  return coords[0].map((pair: number[]) => ({
    lat: pair[1],
    lng: pair[0]
  }));
}
