import { API_BASE_URL } from '../configuration/api';
import type {
  BackendHealth,
  StateRegistryResponse,
  District,
  Mandal,
  Village,
  LocationProvenanceMetadata,
  Crop,
  CropRule,
  NASAServiceMetadata,
  StrategyArchetype,
  PolygonAnalysisResponse,
  FarmProfile,
  NASAPowerResponse,
  NASASMAPResponse,
  NASAGPMResponse,
  UnifiedEvidenceDossier,
  RecommendationResponse,
  FarmerProfileInput,
  FarmerProfile,
  DistrictSoilBenchmark,
  CropKnowledgeProfile,
  RecalculateScoresRequest,
  RecalculateScoresResponse,
  RotationStrategy,
  ClimateSimulationRequest,
  ClimateSimulationResponse
} from '../types';

async function fetchJson<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`;
  const response = await fetch(url, { credentials: 'include', ...options });
  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`API Request to ${endpoint} failed (${response.status}): ${errorBody}`);
  }
  return response.json();
}


async function runNasaJob<T>(jobType: 'power' | 'smap' | 'gpm', payload: object): Promise<T> {
  const submitted = await fetchJson<{ job_id: string; status: string }>(`/api/nasa/jobs/${jobType}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
  });
  const deadline = Date.now() + 15 * 60 * 1000;
  while (Date.now() < deadline) {
    await new Promise((resolve) => window.setTimeout(resolve, 2000));
    const job = await fetchJson<{ status: string; result?: T; error_message?: string }>(`/api/nasa/jobs/${submitted.job_id}`);
    if (job.status === 'succeeded' && job.result !== undefined) return job.result;
    if (job.status === 'failed' || job.status === 'cancelled') {
      throw new Error(job.error_message || `NASA ${jobType.toUpperCase()} job ${job.status}.`);
    }
  }
  throw new Error(`NASA ${jobType.toUpperCase()} request is still processing. Please retry or check job ${submitted.job_id}.`);
}

export const apiService = {
  register: (payload: { full_name: string; email: string; password: string }) =>
    fetchJson<{ status: string; user: { id: string; name: string; email: string; role: string; verified: boolean; member_since: string } }>('/api/auth/register', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    }),
  login: (payload: { email: string; password: string }) =>
    fetchJson<{ status: string; user: { id: string; name: string; email: string; role: string; verified: boolean; member_since: string } }>('/api/auth/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    }),
  getCurrentUser: () => fetchJson<{ user: { id: string; name: string; email: string; role: string; verified: boolean; member_since: string } }>('/api/auth/me'),
  logout: () => fetchJson<{ status: string }>('/api/auth/logout', { method: 'POST' }),

  getRotationHistory: (farmId: string) => fetchJson<any[]>(`/api/farms/${encodeURIComponent(farmId)}/rotation-history`),
  addRotationHistory: (farmId: string, payload: { farm_id: string; crop_name: string; season: string; crop_year: number; planting_date?: string; harvest_date?: string; yield_value?: number; yield_unit?: string; notes?: string }) => fetchJson<any>(`/api/farms/${encodeURIComponent(farmId)}/rotation-history`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }),
  deleteRotationHistory: (recordId: string) => fetchJson<{ status: string }>(`/api/rotation-history/${encodeURIComponent(recordId)}`, { method: 'DELETE' }),
  getFarmActivity: (farmId: string) => fetchJson<any[]>(`/api/farms/${encodeURIComponent(farmId)}/activity`),

  getHealth: (): Promise<BackendHealth> => fetchJson<BackendHealth>('/api/health'),
  
  getStates: (): Promise<StateRegistryResponse> => fetchJson<StateRegistryResponse>('/api/states'),
  
  getDistricts: (stateId: string): Promise<District[]> => 
    fetchJson<District[]>(`/api/states/${stateId}/districts`),

  getMandals: (stateId: string, districtId?: string): Promise<Mandal[]> => {
    if (districtId) {
      return fetchJson<Mandal[]>(`/api/states/${stateId}/districts/${encodeURIComponent(districtId)}/mandals`);
    }
    return fetchJson<Mandal[]>(`/api/states/${stateId}/mandals`);
  },

  getVillages: (stateId: string, mandalId?: string, districtId?: string): Promise<Village[]> => {
    if (districtId && mandalId) {
      return fetchJson<Village[]>(`/api/states/${stateId}/districts/${encodeURIComponent(districtId)}/mandals/${encodeURIComponent(mandalId)}/villages`);
    }
    const query = mandalId ? `?mandal_id=${encodeURIComponent(mandalId)}` : '';
    return fetchJson<Village[]>(`/api/states/${stateId}/villages${query}`);
  },

  getLocationProvenance: (stateId: string): Promise<LocationProvenanceMetadata> =>
    fetchJson<LocationProvenanceMetadata>(`/api/states/${stateId}/provenance`),
    
  getCrops: (stateId: string): Promise<Crop[]> => 
    fetchJson<Crop[]>(`/api/states/${stateId}/crops`),
    
  getCropRules: (stateId: string): Promise<{ state_id: string; agronomic_rules: CropRule[] }> => 
    fetchJson<{ state_id: string; agronomic_rules: CropRule[] }>(`/api/states/${stateId}/crop-rules`),
    
  getNASAServices: (): Promise<{ status: string; services: NASAServiceMetadata[] }> => 
    fetchJson<{ status: string; services: NASAServiceMetadata[] }>('/api/nasa/services'),
    
  getStrategyArchetypes: (): Promise<StrategyArchetype[]> => 
    fetchJson<StrategyArchetype[]>('/api/recommendations/archetypes'),

  // NASA POWER Data Endpoint
  queryNASAPower: (params: {
    latitude: number;
    longitude: number;
    start_date?: string;
    end_date?: string;
    farm_id?: string;
    use_cache?: boolean;
  }): Promise<NASAPowerResponse> =>
    runNasaJob<NASAPowerResponse>('power', params),

  // NASA SMAP Data Endpoint (SPL3SMP_E Version 6)
  queryNASASMAP: (params: {
    latitude: number;
    longitude: number;
    polygon_bbox?: any;
    start_date?: string;
    end_date?: string;
    farm_id?: string;
    use_cache?: boolean;
  }): Promise<NASASMAPResponse> =>
    runNasaJob<NASASMAPResponse>('smap', params),

  // NASA GPM IMERG Data Endpoint (Version 07 Final Run)
  queryNASAGPM: (params: {
    latitude: number;
    longitude: number;
    polygon_bbox?: any;
    start_date?: string;
    end_date?: string;
    farm_id?: string;
    use_cache?: boolean;
    compare_with_power?: boolean;
  }): Promise<NASAGPMResponse> =>
    runNasaJob<NASAGPMResponse>('gpm', params),

  // Unified Environmental Evidence Dossier Endpoint
  getUnifiedEvidence: (params: {
    latitude: number;
    longitude: number;
    polygon_bbox?: any;
    farm_id?: string;
    use_cache?: boolean;
    farmer_profile?: any;
  }): Promise<UnifiedEvidenceDossier> =>
    fetchJson<UnifiedEvidenceDossier>('/api/evidence/unified', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    }),

  // Evidence-Backed Recommendations Generation Endpoint
  generateRecommendations: (params: {
    state_id?: string;
    latitude: number;
    longitude: number;
    polygon_bbox?: any;
    farm_id?: string;
    use_cache?: boolean;
    farmer_profile?: any;
    weights?: { water: number; soil: number; climate: number; local: number };
    include_geospatial_context?: boolean;
  }): Promise<RecommendationResponse> =>
    fetchJson<RecommendationResponse>('/api/recommendations/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    }),

  // Dynamic Priority Recalculation Endpoint
  recalculateScores: (params: RecalculateScoresRequest): Promise<RecalculateScoresResponse> =>
    fetchJson<RecalculateScoresResponse>('/api/recommendations/recalculate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    }),

  // Preserved Weights PDF / Audit Report Endpoints
  generateReport: (params: {
    farm_id?: string;
    farm_data?: any;
    farmer_profile?: any;
    weights: { water: number; soil: number; climate: number; local: number };
    baseline_weights?: { water: number; soil: number; climate: number; local: number };
    strategies: RotationStrategy[];
    ranking_comparison?: any;
    dossier?: any;
  }): Promise<any> =>
    fetchJson<any>('/api/reports/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    }),

  getReportHtml: async (params: {
    farm_id?: string;
    farm_data?: any;
    farmer_profile?: any;
    weights: { water: number; soil: number; climate: number; local: number };
    baseline_weights?: { water: number; soil: number; climate: number; local: number };
    strategies: RotationStrategy[];
    ranking_comparison?: any;
    dossier?: any;
  }): Promise<string> => {
    const url = `${API_BASE_URL}/api/reports/html`;
    const res = await fetch(url, {
      credentials: 'include',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    if (!res.ok) {
      throw new Error(`Report HTML generation failed: ${res.statusText}`);
    }
    return res.text();
  },

  // Soil Benchmarks & Farmer Profile Endpoints
  getSoilBenchmark: (districtId: string): Promise<DistrictSoilBenchmark> =>
    fetchJson<DistrictSoilBenchmark>(`/api/soil-benchmarks/${districtId}`),

  saveFarmerProfile: (profile: FarmerProfileInput): Promise<{ status: string; farmer_profile: FarmerProfile }> =>
    fetchJson<{ status: string; farmer_profile: FarmerProfile }>('/api/farmer-profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile)
    }),

  getFarmerProfile: (farmId: string): Promise<FarmerProfile> =>
    fetchJson<FarmerProfile>(`/api/farmer-profile/${farmId}`),

  uploadSoilReport: async (farmId: string, file: File): Promise<any> => {
    const form = new FormData();
    form.append('farm_id', farmId);
    form.append('report_file', file);
    return fetchJson<any>('/api/soil-reports', { method: 'POST', body: form });
  },

  getSoilReports: (farmId: string): Promise<any[]> =>
    fetchJson<any[]>(`/api/soil-reports/${farmId}`),

  evaluateFarmAlerts: (payload: { farm_id: string; observed_at: string; source: string; rainfall_24h_mm?: number; max_temperature_c?: number; soil_moisture_pct?: number }): Promise<any> =>
    fetchJson<any>('/api/alerts/evaluate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }),

  getFarmAlerts: (farmId?: string): Promise<any[]> =>
    fetchJson<any[]>(`/api/alerts${farmId ? `?farm_id=${encodeURIComponent(farmId)}` : ''}`),

  acknowledgeFarmAlert: (alertId: string): Promise<{ status: string; alert_id: string }> =>
    fetchJson<{ status: string; alert_id: string }>(`/api/alerts/${encodeURIComponent(alertId)}/acknowledge`, { method: 'POST' }),

  // Crop Knowledge Catalog Endpoints
  getCropKnowledge: (): Promise<CropKnowledgeProfile[]> =>
    fetchJson<CropKnowledgeProfile[]>('/api/crop-knowledge'),

  getCropKnowledgeDetail: (cropId: string): Promise<CropKnowledgeProfile> =>
    fetchJson<CropKnowledgeProfile>(`/api/crop-knowledge/${cropId}`),

  // Geospatial & Farm Endpoints
  analyzePolygon: (boundaryGeojson: any, manualAcreage?: number | null): Promise<PolygonAnalysisResponse> =>
    fetchJson<PolygonAnalysisResponse>('/api/geospatial/analyze-polygon', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ boundary_geojson: boundaryGeojson, manual_acreage: manualAcreage })
    }),

  saveFarm: (farm: FarmProfile): Promise<{ status: string; farm: FarmProfile; nasa_query_targets: any }> =>
    fetchJson<{ status: string; farm: FarmProfile; nasa_query_targets: any }>('/api/farms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(farm)
    }),

  getFarms: (): Promise<FarmProfile[]> => fetchJson<FarmProfile[]>('/api/farms'),

  getFarm: (farmId: string): Promise<FarmProfile> => fetchJson<FarmProfile>(`/api/farms/${farmId}`),

  deleteFarm: (farmId: string): Promise<{ status: string; farm_id: string }> =>
    fetchJson<{ status: string; farm_id: string }>(`/api/farms/${farmId}`, {
      method: 'DELETE'
    }),

  // Climate What-If Scenario Simulation
  simulateClimateScenario: (req: ClimateSimulationRequest): Promise<ClimateSimulationResponse> =>
    fetchJson<ClimateSimulationResponse>('/api/simulation/simulate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req)
    }),

  // ReportLab Binary PDF Report Download
  downloadReportPdf: async (req: {
    farm_id?: string | null;
    farm_data?: any;
    farmer_profile?: any;
    weights: Record<string, number>;
    baseline_weights?: Record<string, number>;
    strategies: any[];
    ranking_comparison?: any;
    dossier?: any;
    simulation_data?: any;
  }): Promise<Blob> => {
    const url = `${API_BASE_URL}/api/reports/pdf`;
    const response = await fetch(url, {
      credentials: 'include',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req)
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`PDF generation failed (${response.status}): ${errorText}`);
    }
    return response.blob();
  }
};
